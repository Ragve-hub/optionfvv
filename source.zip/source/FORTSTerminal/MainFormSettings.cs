using System.Drawing;
using System.Windows.Forms;

namespace FORTSTerminal
{
	public class MainFormSettings
	{
		public bool MainFormTopMost;

		public Size MainFormSize;

		public Point MainFormLocation;

		public FormWindowState MainFormWindowState;
	}
}
