using System.IO;
using System.Xml.Serialization;

namespace FORTSTerminal
{
	public class TerminalSettings
	{
		private MainFormSettings main_form_settings;

		private string main_form_settings_file_name;

		public TerminalSettings()
		{
			main_form_settings_file_name = Directory.GetCurrentDirectory() + Path.DirectorySeparatorChar + "Settings" + Path.DirectorySeparatorChar + "MainFormSettings.XML";
		}

		public bool LoadMainFormSettings()
		{
			return LoadMainFormSettings(main_form_settings_file_name);
		}

		public bool LoadMainFormSettings(string _file_name)
		{
			try
			{
				XmlSerializer xmlSerializer = new XmlSerializer(typeof(MainFormSettings));
				FileStream fileStream = new FileStream(_file_name, FileMode.Open);
				TextReader textReader = new StreamReader(fileStream);
				main_form_settings = (MainFormSettings)xmlSerializer.Deserialize(textReader);
				textReader.Close();
				fileStream.Close();
			}
			catch (FileNotFoundException)
			{
				return false;
			}
			return true;
		}

		public bool SaveMainFormSettings(MainFormSettings _settings)
		{
			main_form_settings = _settings;
			return SaveMainFormSettings(main_form_settings_file_name);
		}

		public bool SaveMainFormSettings(string _file_name)
		{
			try
			{
				XmlSerializer xmlSerializer = new XmlSerializer(typeof(MainFormSettings));
				TextWriter textWriter = new StreamWriter(_file_name);
				xmlSerializer.Serialize(textWriter, main_form_settings);
				textWriter.Close();
			}
			catch (FileNotFoundException)
			{
				return false;
			}
			return true;
		}

		public MainFormSettings GetMainFormSettings()
		{
			return main_form_settings;
		}

		public void SetMainFormSettings(MainFormSettings _settings)
		{
			main_form_settings = _settings;
		}
	}
}
