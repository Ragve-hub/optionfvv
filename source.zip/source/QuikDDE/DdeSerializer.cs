using System;
using System.Collections.Generic;
using System.IO;
using System.Text;
using Ecng.Serialization;

namespace QuikDDE
{
	internal static class DdeSerializer
	{
		private enum DataTypes : short
		{
			Table = 16,
			Float = 1,
			String = 2,
			Bool = 3,
			Error = 4,
			Blank = 5,
			Int = 6,
			Skip = 7
		}

		private static Type GetCompType(DataTypes type)
		{
			switch (type)
			{
			case DataTypes.Float:
				return typeof(double);
			case DataTypes.String:
				return typeof(string);
			case DataTypes.Bool:
				return typeof(bool);
			case DataTypes.Int:
				return typeof(int);
			case DataTypes.Skip:
				return null;
			default:
				throw new ArgumentOutOfRangeException("type");
			}
		}

		public static IList<IList<object>> Deserialize(Stream stream)
		{
			if (stream == null)
			{
				throw new ArgumentNullException("stream");
			}
			DataTypes dt = stream.Read<DataTypes>();
			short size = stream.Read<short>();
			short rowCount = stream.Read<short>();
			short columnCount = stream.Read<short>();
			List<IList<object>> rows = new List<IList<object>>();
			for (int row = 0; row < rowCount; row++)
			{
				List<object> cells = new List<object>();
				do
				{
					DataTypes cellDt = stream.Read<DataTypes>();
					short cellSize = stream.Read<short>();
					if (cellDt != DataTypes.Skip)
					{
						Type type = GetCompType(cellDt);
						int typeSize = ((type == typeof(string)) ? cellSize : type.SizeOf());
						int cellColumnCount = cellSize / typeSize;
						for (int column = 0; column < cellColumnCount; column++)
						{
							if (type == typeof(string))
							{
								int pos = 0;
								byte len;
								for (byte[] buffer = stream.ReadBuffer(typeSize); pos < buffer.Length; pos += len + 1)
								{
									len = buffer[pos];
									byte[] str = new byte[len];
									Buffer.BlockCopy(buffer, pos + 1, str, 0, len);
									cells.Add(Encoding.Default.GetString(str));
								}
							}
							else
							{
								cells.Add(stream.Read(type));
							}
						}
					}
					else
					{
						stream.ReadBuffer(cellSize);
						cells.AddRange(new object[cellSize]);
					}
				}
				while (cells.Count < columnCount);
				rows.Add(cells);
			}
			return rows;
		}
	}
}
