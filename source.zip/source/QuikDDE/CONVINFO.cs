using System;

namespace QuikDDE
{
	public struct CONVINFO
	{
		public uint cb;

		public UIntPtr hUser;

		public IntPtr hConvPartner;

		public IntPtr hszSvcPartner;

		public IntPtr hszServiceReq;

		public IntPtr hszTopic;

		public IntPtr hszItem;

		public uint wFmt;

		public uint wType;

		public uint wStatus;

		public uint wConvst;

		public uint wLastError;

		public IntPtr hConvList;

		public CONVCONTEXT ConvCtxt;

		public IntPtr hwnd;

		public IntPtr hwndPartner;
	}
}
