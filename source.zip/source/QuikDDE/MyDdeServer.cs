using System;
using System.Collections.Generic;
using System.IO;
using System.Threading;
using Ecng.Common;
using Ecng.ComponentModel;
using NDde.Server;

namespace QuikDDE
{
	public class MyDdeServer : DdeServer
	{
		private readonly ManualResetEvent _registerWaitHandle = new ManualResetEvent(false);

		private Timer _adviseTimer;

		private readonly EventDispatcher _dispather;

		public event Action<string, IList<IList<object>>> Poke;

		public event Action<Exception> Error;

		public MyDdeServer(string service)
			: base(service)
		{
			_dispather = new EventDispatcher(delegate(Exception error)
			{
				this.Error.SafeInvoke(error);
			});
		}

		public void Start()
		{
			Exception error = null;
			object regLock = new object();
			lock (regLock)
			{
				ThreadingHelper.Thread(delegate
				{
					try
					{
						Register();
						lock (regLock)
						{
							Monitor.Pulse(regLock);
						}
						_registerWaitHandle.WaitOne();
					}
					catch (Exception ex)
					{
						lock (regLock)
						{
							Monitor.Pulse(regLock);
						}
						error = ex;
					}
				}).Name("Dde thread").Launch();
				Monitor.Wait(regLock);
			}
			if (error != null)
			{
				throw new InvalidOperationException("Ошибка запуска DDE сервера.", error);
			}
			_adviseTimer = ThreadingHelper.Timer(delegate
			{
				try
				{
					Advise("*", "*");
				}
				catch (Exception arg)
				{
					this.Error.SafeInvoke(arg);
				}
			}).Interval(TimeSpan.FromSeconds(1.0));
		}

		protected override PokeResult OnPoke(DdeConversation conversation, string item, byte[] data, int format)
		{
			_dispather.Add(delegate
			{
				IList<IList<object>> arg = DdeSerializer.Deserialize(data.To<Stream>());
				this.Poke.SafeInvoke(conversation.Topic, arg);
			}, conversation.Topic);
			return PokeResult.Processed;
		}

		protected override void Dispose(bool disposing)
		{
			_dispather.Dispose();
			if (disposing)
			{
				if (!_adviseTimer.IsNull())
				{
					_adviseTimer.Dispose();
				}
				_registerWaitHandle.Set();
			}
			base.Dispose(disposing);
		}
	}
}
