using System;
using System.Runtime.InteropServices;

namespace QuikDDE
{
	[StructLayout(LayoutKind.Explicit, Size = 36)]
	public struct CONVCONTEXT
	{
		[FieldOffset(0)]
		public uint cb;

		[FieldOffset(4)]
		public uint wFlags;

		[FieldOffset(8)]
		public uint wCountryID;

		[FieldOffset(12)]
		public int iCodePage;

		[FieldOffset(16)]
		public uint dwLangID;

		[FieldOffset(20)]
		public uint dwSecurity;

		[FieldOffset(24)]
		public IntPtr qos;
	}
}
