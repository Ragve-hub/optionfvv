using System;

namespace QuikDDE
{
	public abstract class DDEServer : IDisposable
	{
		public const byte DATA_TABLE = 16;

		public const byte DATA_FLOAT = 1;

		public const byte DATA_STRING = 2;

		public const byte DATA_BOOL = 3;

		public const byte DATA_ERROR = 4;

		public const byte DATA_BLANK = 5;

		public const byte DATA_INT = 6;

		public const byte DATA_SKIP = 7;

		private uint id_inst = 0u;

		private IntPtr ServiceHSz;

		private IntPtr TopicHz;

		private string ServiceName;

		private string TopicName;

		private DDECallBackDelegate DDECallBackEvent;

		private bool server_created = false;

		public bool Created
		{
			get
			{
				return server_created;
			}
		}

		public DDEServer(string _service_name, string _topic_name)
		{
			ServiceName = _service_name;
			TopicName = _topic_name;
			DDECallBackEvent = DDECallBack;
			if (DDEML.DdeInitialize(ref id_inst, DDECallBackEvent, 0u, 0u) == 0)
			{
				ServiceHSz = DDEML.DdeCreateStringHandle(id_inst, ServiceName, 1004);
				TopicHz = DDEML.DdeCreateStringHandle(id_inst, TopicName, 1004);
				if (DDEML.DdeNameService(id_inst, ServiceHSz, IntPtr.Zero, 1u) == IntPtr.Zero)
				{
					server_created = false;
				}
				else
				{
					server_created = true;
				}
			}
		}

		~DDEServer()
		{
			Dispose(false);
		}

		private IntPtr DDECallBack(uint uType, uint uFmt, IntPtr hConv, IntPtr hsz1, IntPtr hsz2, IntPtr hData, uint dwData1, uint dwData2)
		{
			if (uType == 16528 && hData != IntPtr.Zero)
			{
				byte[] numArray = new byte[DDEML.DdeGetData(hData, null, 0u, 0u)];
				DDEML.DdeGetData(hData, numArray, (uint)numArray.Length, 0u);
				ParseData(numArray);
			}
			return new IntPtr(32768L);
		}

		public abstract void ParseData(byte[] data);

		public void Dispose()
		{
			Dispose(true);
		}

		private void Dispose(bool disposing)
		{
			DDEML.DdeNameService(id_inst, ServiceHSz, IntPtr.Zero, 2u);
			DDEML.DdeFreeStringHandle(id_inst, ServiceHSz);
			DDEML.DdeFreeStringHandle(id_inst, TopicHz);
			DDEML.DdeUninitialize(id_inst);
		}
	}
}
