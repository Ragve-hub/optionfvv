using System;

namespace QuikDDE
{
	internal delegate IntPtr DDECallBackDelegate(uint wType, uint wFmt, IntPtr hConv, IntPtr hsz1, IntPtr hsz2, IntPtr hData, uint dwData1, uint dwData2);
}
