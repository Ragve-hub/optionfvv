using System;
using System.Collections.Generic;
using System.Text;
using Ecng.Common;
using QuikDDE.Data;

namespace QuikDDE
{
	public class TransactionsTable
	{
		protected Transaction table_string = default(Transaction);

		protected List<Transaction> table_string_list = new List<Transaction>(10000);

		protected List<Transaction> table_string_list_indexer = new List<Transaction>(10000);

		protected Encoding encoder = Encoding.GetEncoding(1251);

		public bool OptspotHedgeFut { get; set; }

		public event Action<Transaction> StringReceived;

		public event Action<List<Transaction>> ListReceived;

		public TransactionsTable(bool optspot_hedge_fut = false)
		{
			OptspotHedgeFut = optspot_hedge_fut;
		}

		public void ParseDataOld(byte[] data)
		{
			int startIndex1 = 0;
			bool flag = false;
			if (BitConverter.ToInt16(data, startIndex1) == 16)
			{
				startIndex1 += 8;
				flag = true;
				table_string_list.Clear();
			}
			Encoding utf8 = Encoding.GetEncoding("UTF-8");
			Encoding win1251 = Encoding.GetEncoding("Windows-1251");
			byte[] utf8Bytes = Encoding.Convert(win1251, utf8, data);
			string testStr = utf8.GetString(utf8Bytes);
			while (startIndex1 < data.Length)
			{
				int index1 = startIndex1 + 2;
				short num1 = data[index1];
				int startIndex2 = index1 + 2;
				table_string.number = BitConverter.ToUInt64(data, startIndex2).ToString();
				int index2 = startIndex2 + num1 + 7 + 2;
				short num2 = data[index2];
				int index3 = index2 + 1;
				string str = encoder.GetString(data, index3, num2);
				int index4 = index3 + num2;
				short num3 = data[index4];
				int index5 = index4 + 1;
				string dt = encoder.GetString(data, index5, num3);
				table_string.date = DateTime.Parse(str + " " + dt);
				table_string.time = table_string.date;
				int index6 = index5 + num3;
				short num4 = data[index6];
				int index7 = index6 + 1;
				table_string.paper_code = encoder.GetString(data, index7, num4);
				int index8 = index7 + num4;
				short num5 = data[index8];
				int index9 = index8 + 1;
				table_string.operation = encoder.GetString(data, index9, num5);
				int index10 = index9 + num5 + 2;
				short num6 = data[index10];
				int startIndex3 = index10 + 2;
				table_string.price = BitConverter.ToDouble(data, startIndex3);
				table_string.volume = (long)BitConverter.ToDouble(data, startIndex3 + 8);
				startIndex1 = startIndex3 + num6;
				if (!flag)
				{
					Action<Transaction> action = this.StringReceived;
					if (action != null)
					{
						action(table_string);
					}
				}
				else
				{
					table_string_list.Add(table_string);
				}
			}
			if (flag && this.ListReceived != null)
			{
				this.ListReceived(table_string_list);
			}
		}

		public void ParseData(string listName, IList<IList<object>> rows)
		{
			table_string_list.Clear();
			for (int i = 0; i < rows.Count; i++)
			{
				table_string.number = rows[i][0].ToString();
				if (table_string_list_indexer.Find((Transaction m) => m.number == table_string.number).number == null)
				{
					string dt = rows[i][1].ToString();
					if (dt.Contains(" "))
					{
						string[] series = dt.Split(" ");
						dt = series[1] + "." + series[2] + "." + series[3];
					}
					string dtTm = dt + " " + rows[i][2].ToString();
					table_string.date = DateTime.Parse(dtTm);
					table_string.time = table_string.date;
					table_string.paper_code = rows[i][3].ToString();
					table_string.operation = rows[i][4].ToString();
					table_string.price = Convert.ToDouble(rows[i][5].ToString());
					table_string.volume = Convert.ToDouble(rows[i][6].ToString());
					table_string_list.Add(table_string);
					table_string_list_indexer.Add(table_string);
				}
			}
			if (table_string_list.Count > 0)
			{
				Action<List<Transaction>> action = this.ListReceived;
				if (action != null)
				{
					action(table_string_list);
				}
			}
		}
	}
}
