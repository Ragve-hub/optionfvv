using System;
using System.Collections.Generic;
using System.Text;
using Ecng.Common;
using NLog;
using OptionFVV;
using QuikDDE.Data;

namespace QuikDDE
{
	public class QuotesTable
	{
		public delegate void StringReceivedHandler(Quotes _quick_data);

		public delegate void ListReceivedHandler(List<Quotes> _quick_data_list);

		public delegate void ListFuturesReceivedHandler(List<Quotes> _quick_data_list);

		protected Quotes table_string = default(Quotes);

		protected List<Quotes> table_string_list = new List<Quotes>(10000);

		protected List<Quotes> futures_table_string_list = new List<Quotes>(1000);

		protected Encoding encoder = Encoding.GetEncoding(1251);

		private static Logger _logger = LogManager.GetCurrentClassLogger();

		public bool OptSpotHedgeFut { get; set; }

		public event StringReceivedHandler StringReceived;

		public event ListReceivedHandler ListReceived;

		public event ListFuturesReceivedHandler FuturesListReceived;

		public QuotesTable(bool optspot_hedge_fut = false)
		{
			OptSpotHedgeFut = optspot_hedge_fut;
		}

		private int CalcDecimalPoints(double stepPrice)
		{
			double decimals = Math.Log10(stepPrice);
			decimals = ((!(decimals > 0.0)) ? (decimals * -1.0) : 0.0);
			return Convert.ToInt32(Math.Ceiling(decimals));
		}

		public void ParseData(string listName, IList<IList<object>> rows)
		{
			if (_logger != null)
			{
			}
			table_string_list.Clear();
			futures_table_string_list.Clear();
			int i = 0;
			try
			{
				for (i = 0; i < rows.Count; i++)
				{
					table_string.paper_code = rows[i][0].ToString();
					table_string.class_code = rows[i][11].ToString();
					table_string.lot = ((rows[i][12].ToString() != "") ? double.Parse(rows[i][12].ToString()) : 1.0);
					if (table_string.class_code != "SPBRU" && table_string.class_code != "TQBR")
					{
						string dt = rows[i][1].ToString();
						if (dt.Contains(" "))
						{
							string[] series = dt.Split(" ");
							if (series.Length == 4)
							{
								dt = series[1] + "." + series[2] + "." + series[3];
							}
							else if (series.Length == 2)
							{
								dt = series[1];
							}
						}
						string dtTm = dt + " 18:50:00";
						table_string.expiration_date = DateTime.Parse(dtTm);
						table_string.base_asset = rows[i][2].ToString();
					}
					else
					{
						if (table_string.paper_code.Contains("."))
						{
							string[] codeData = table_string.paper_code.Split('.');
							table_string.paper_code = codeData[0] + "_CLT";
						}
						else
						{
							table_string.paper_code += "_CLT";
						}
						table_string.expiration_date = new DateTime(2100, 1, 1, 18, 50, 0);
						table_string.base_asset = rows[i][11].ToString();
					}
					string demand = rows[i][3].ToString();
					string supply = rows[i][4].ToString();
					string last_price = rows[i][5].ToString();
					table_string.demand = 0.0;
					table_string.sentence = 0.0;
					table_string.last_price = 0.0;
					if (demand != "")
					{
						table_string.demand = Convert.ToDouble(demand);
					}
					if (supply != "")
					{
						table_string.sentence = Convert.ToDouble(supply);
					}
					if (last_price != "")
					{
						table_string.last_price = Convert.ToDouble(last_price);
					}
					if (table_string.class_code == "OPTW")
					{
						table_string.class_code = "SPBOPT";
					}
					if (table_string.class_code == "SPBOPT" || table_string.class_code == "OPTSPOT")
					{
						table_string.strike = Convert.ToDouble(rows[i][6].ToString());
						table_string.option_type = rows[i][7].ToString();
						string vol = rows[i][8].ToString();
						string theo_price = rows[i][9].ToString();
						table_string.volatility = 0.0;
						table_string.teoretical_price = 0.0;
						if (vol != "")
						{
							table_string.volatility = Convert.ToDouble(vol);
						}
						if (theo_price != "")
						{
							table_string.teoretical_price = Convert.ToDouble(theo_price);
						}
						table_string.step_price = Convert.ToDouble(rows[i][10].ToString());
						table_string.decimal_points = ((rows[i].Count == 14) ? Convert.ToInt32(rows[i][13]) : CalcDecimalPoints(table_string.step_price));
						int hereIdx = table_string_list.FindLastIndex((Quotes m) => m.paper_code == table_string.paper_code);
						if (hereIdx < 0)
						{
							table_string_list.Add(table_string);
							continue;
						}
						table_string_list[hereIdx] = table_string;
						this.StringReceived(table_string);
						continue;
					}
					table_string.strike = 0.0;
					table_string.option_type = "";
					table_string.volatility = 0.0;
					table_string.teoretical_price = 0.0;
					table_string.step_price = Convert.ToDouble(rows[i][10].ToString());
					table_string.decimal_points = ((rows[i].Count == 14) ? Convert.ToInt32(rows[i][13]) : CalcDecimalPoints(table_string.step_price));
					int hereIdx2 = futures_table_string_list.FindLastIndex((Quotes m) => m.paper_code == table_string.paper_code);
					if (hereIdx2 < 0)
					{
						futures_table_string_list.Add(table_string);
					}
					else
					{
						futures_table_string_list[hereIdx2] = table_string;
						this.StringReceived(table_string);
					}
					if (OptSpotHedgeFut && Helpers.CheckHasClt(table_string.base_asset))
					{
						string paper_code = Helpers.MapCodeClt(table_string.base_asset);
						paper_code += "_CLT";
						table_string.paper_code = paper_code;
						table_string.demand /= table_string.lot;
						table_string.demand = Math.Round(table_string.demand, 2);
						table_string.last_price /= table_string.lot;
						table_string.last_price = Math.Round(table_string.last_price, 2);
						table_string.sentence /= table_string.lot;
						table_string.sentence = Math.Round(table_string.sentence, 2);
						table_string.step_price /= table_string.lot;
						table_string.step_price = Math.Round(table_string.step_price, 2);
						hereIdx2 = futures_table_string_list.FindLastIndex((Quotes m) => m.paper_code == table_string.paper_code);
						if (hereIdx2 < 0)
						{
							futures_table_string_list.Add(table_string);
							continue;
						}
						futures_table_string_list[hereIdx2] = table_string;
						this.StringReceived(table_string);
					}
				}
				if (table_string_list.Count > 0 && this.ListReceived != null)
				{
					this.ListReceived(table_string_list);
				}
				if (futures_table_string_list.Count > 0 && this.FuturesListReceived != null)
				{
					this.FuturesListReceived(futures_table_string_list);
				}
			}
			catch (Exception ex)
			{
				_logger.Error("Error occured {0} for row {1}", ex.Message, rows[i][1].ToString());
			}
		}

		public void ParseDataOld(byte[] data)
		{
			int startIndex1 = 0;
			bool flag = false;
			if (BitConverter.ToInt16(data, startIndex1) == 16)
			{
				startIndex1 += 8;
				flag = true;
				table_string_list.Clear();
				futures_table_string_list.Clear();
			}
			while (startIndex1 < data.Length)
			{
				int index1 = startIndex1 + 2;
				int num1 = data[index1];
				int index2 = index1 + 2;
				short num2 = data[index2];
				int index3 = index2 + 1;
				table_string.paper_code = encoder.GetString(data, index3, num2);
				int index4 = index3 + num2;
				int num3 = num1 - (num2 + 1);
				short num4 = data[index4];
				int index5 = index4 + 1;
				table_string.expiration_date = DateTime.Parse(encoder.GetString(data, index5, num4) + " 19:00");
				int index6 = index5 + num4;
				int num5 = num3 - (num4 + 1);
				short num6 = data[index6];
				if (num6 == 0)
				{
					int index7 = index6 + num5 + 2;
					short num7 = data[index7];
					startIndex1 = index7 + 2 + num7;
					continue;
				}
				int index8 = index6 + 1;
				table_string.base_asset = encoder.GetString(data, index8, num6);
				int index9 = index8 + num6 + 2;
				short num8 = data[index9];
				int startIndex2 = index9 + 2;
				table_string.demand = BitConverter.ToDouble(data, startIndex2);
				table_string.sentence = BitConverter.ToDouble(data, startIndex2 + 8);
				table_string.last_price = BitConverter.ToDouble(data, startIndex2 + 16);
				short num10;
				int startIndex3;
				if (table_string.paper_code.Length > 4)
				{
					table_string.strike = BitConverter.ToDouble(data, startIndex2 + 24);
					int index10 = startIndex2 + num8 + 2 + 2;
					short num9 = data[index10];
					int index11 = index10 + 1;
					table_string.option_type = encoder.GetString(data, index11, num9);
					int index12 = index11 + num9 + 2;
					num10 = data[index12];
					startIndex3 = index12 + 2;
					table_string.volatility = BitConverter.ToDouble(data, startIndex3);
					table_string.teoretical_price = BitConverter.ToDouble(data, startIndex3 + 8);
					table_string.step_price = BitConverter.ToDouble(data, startIndex3 + 16);
					if (!flag)
					{
						if (this.StringReceived != null)
						{
							this.StringReceived(table_string);
						}
					}
					else
					{
						table_string_list.Add(table_string);
					}
				}
				else
				{
					int index13 = startIndex2 + num8 + 2;
					short num11 = data[index13];
					int num12 = index13 + 2;
					table_string.strike = 0.0;
					table_string.option_type = "";
					table_string.volatility = 0.0;
					table_string.teoretical_price = 0.0;
					int index14 = num12 + num11 + 2;
					num10 = data[index14];
					startIndex3 = index14 + 2;
					table_string.step_price = BitConverter.ToDouble(data, startIndex3);
					if (!flag)
					{
						if (this.StringReceived != null)
						{
							this.StringReceived(table_string);
						}
					}
					else
					{
						futures_table_string_list.Add(table_string);
					}
				}
				startIndex1 = startIndex3 + num10;
			}
			if (flag)
			{
				if (table_string_list.Count > 0 && this.ListReceived != null)
				{
					this.ListReceived(table_string_list);
				}
				if (futures_table_string_list.Count > 0 && this.FuturesListReceived != null)
				{
					this.FuturesListReceived(futures_table_string_list);
				}
			}
		}
	}
}
