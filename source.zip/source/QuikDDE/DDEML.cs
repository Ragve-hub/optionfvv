using System;
using System.Runtime.InteropServices;
using System.Text;

namespace QuikDDE
{
	internal sealed class DDEML
	{
		internal const uint XTYPF_NOBLOCK = 2u;

		internal const uint XCLASS_BOOL = 4096u;

		internal const uint XCLASS_DATA = 8192u;

		internal const uint XCLASS_FLAGS = 16384u;

		internal const uint XCLASS_NOTIFICATION = 32768u;

		internal const uint DDE_FACK = 32768u;

		internal const int CP_WINANSI = 1004;

		internal const int CP_WINUNICODE = 1200;

		internal const uint CF_TEXT = 1u;

		internal const uint QID_SYN = uint.MaxValue;

		internal const uint APPCLASS_STANDART = 0u;

		internal const uint DMLERR_NO_ERROR = 0u;

		internal const uint DNS_REGISTER = 1u;

		internal const uint DNS_UNREGISTER = 2u;

		internal const uint XTYP_ADVSTART = 4144u;

		internal const uint XTYP_REQUEST = 8368u;

		internal const uint XTYP_ADVSTOP = 32832u;

		internal const uint XTYP_ADVDATA = 16400u;

		internal const uint XTYP_DISCONNECT = 32962u;

		internal const uint XTYP_POKE = 16528u;

		[DllImport("user32.dll", CharSet = CharSet.Ansi)]
		internal static extern uint DdeInitialize(ref uint pidInst, DDECallBackDelegate pfnCallback, uint afCmd, uint ulRes);

		[DllImport("user32.dll", CharSet = CharSet.Ansi)]
		internal static extern bool DdeUninitialize(uint idInst);

		[DllImport("user32.dll", CharSet = CharSet.Ansi)]
		internal static extern IntPtr DdeCreateStringHandle(uint idInst, string psz, int iCodePage);

		[DllImport("user32.dll", CharSet = CharSet.Ansi)]
		internal static extern bool DdeFreeStringHandle(uint idInst, IntPtr hsz);

		[DllImport("user32.dll", CharSet = CharSet.Ansi)]
		internal static extern IntPtr DdeConnect(uint idInst, IntPtr hszService, IntPtr hszTopic, IntPtr pCC);

		[DllImport("user32.dll", CharSet = CharSet.Ansi)]
		internal static extern bool DdeDisconnect(IntPtr hConv);

		[DllImport("user32.dll", CharSet = CharSet.Ansi)]
		internal static extern IntPtr DdeClientTransaction(IntPtr pData, uint cbData, IntPtr hConv, IntPtr hszItem, uint uFmt, uint uType, uint dwTimeout, ref uint pdwResult);

		[DllImport("user32.dll", CharSet = CharSet.Ansi)]
		internal static extern uint DdeGetData(IntPtr hData, [Out] byte[] pDst, uint cbMax, uint cbOff);

		[DllImport("user32.dll", CharSet = CharSet.Ansi)]
		internal static extern uint DdeQueryString(uint idInst, IntPtr hsz, StringBuilder psz, uint cchMax, int iCodePage);

		[DllImport("user32.dll", CharSet = CharSet.Ansi)]
		internal static extern uint DdeQueryConvInfo(IntPtr hConv, uint idTransaction, ref CONVINFO info);

		[DllImport("user32.dll", CharSet = CharSet.Ansi)]
		internal static extern IntPtr DdeNameService(uint idInst, IntPtr hsz1, IntPtr hsz2, uint afCmd);
	}
}
