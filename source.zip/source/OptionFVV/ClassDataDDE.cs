using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using NLog;
using QuikDDE;
using QuikDDE.Data;

namespace OptionFVV
{
	internal class ClassDataDDE
	{
		private string iFileName;

		public static double iStepStrike = 0.0;

		public static bool F_ErrorOpenFile;

		public static bool F_Error;

		public static string ErrorMessage;

		public static string iText = "";

		private Stopwatch swatch = new Stopwatch();

		public static Dictionary<string, int> CacheQuotesTable = new Dictionary<string, int>(100);

		private MyDdeServer transactions_table_dde_server;

		private MyDdeServer quotes_table_dde_server;

		private QuotesTable quotesTableProcessor;

		private TransactionsTable transactionsTableProcessor;

		public static List<Quotes> FuturesQuotesTable = new List<Quotes>(100);

		public static List<Quotes> QuotesTable = new List<Quotes>(10000);

		public static Quotes QuotesPaper = default(Quotes);

		private Quotes LocalCopyQuotesPaper = default(Quotes);

		public static List<Transaction> TransactionTable = new List<Transaction>(10000);

		public static Transaction TransactionPaper = default(Transaction);

		private SortedList<double, double> StrikeCall = new SortedList<double, double>();

		private SortedList<double, double> StrikePut = new SortedList<double, double>();

		public static string dde_prefix = "";

		public static bool optspot_hedge_fut = false;

		private static Logger _logger = LogManager.GetCurrentClassLogger();

		public string FileName
		{
			get
			{
				return iFileName;
			}
			set
			{
				iFileName = value;
			}
		}

		public ClassDataDDE(bool F)
		{
			if (F)
			{
				CacheQuotesTable.Clear();
				FuturesQuotesTable.Clear();
				QuotesTable.Clear();
				TransactionTable.Clear();
				StrikeCall.Clear();
				StrikePut.Clear();
				F_ErrorOpenFile = false;
				F_Error = false;
				ErrorMessage = "";
				quotesTableProcessor = new QuotesTable(ClassSettings.optspot_hedge_fut);
				quotesTableProcessor.ListReceived += QuotesData_ListReceived;
				quotesTableProcessor.FuturesListReceived += QuotesData_FuturesListReceived;
				transactionsTableProcessor = new TransactionsTable(ClassSettings.optspot_hedge_fut);
				transactionsTableProcessor.ListReceived += TransactionsData_ListReceived;
				start_transactions_dde_server(dde_prefix + "TransactionsTable", "all");
				start_quotes_dde_server(dde_prefix + "QuotesTable", "all");
			}
		}

		private void start_transactions_dde_server(string _service_name, string _topic_name)
		{
			if (transactions_table_dde_server == null)
			{
				transactions_table_dde_server = new MyDdeServer(_service_name);
				transactions_table_dde_server.Poke += transactionsTableProcessor.ParseData;
				transactions_table_dde_server.Start();
				_logger.Info("Transactions DDE started");
			}
		}

		private void stop_transactions_dde_server_old(object sender, EventArgs e)
		{
			if (transactions_table_dde_server != null)
			{
				transactions_table_dde_server.Dispose();
			}
		}

		private void start_quotes_dde_server(string _service_name, string _topic_name)
		{
			if (quotes_table_dde_server == null)
			{
				quotes_table_dde_server = new MyDdeServer(_service_name);
				quotes_table_dde_server.Poke += quotesTableProcessor.ParseData;
				quotes_table_dde_server.Start();
				_logger.Info("Quotes DDE started");
			}
		}

		private void stop_quotes_dde_server_old(object sender, EventArgs e)
		{
			if (quotes_table_dde_server != null)
			{
				quotes_table_dde_server.Dispose();
			}
		}

		private void TransactionsData_ListReceived(List<Transaction> _table_string_list)
		{
			TransactionTable.AddRange(_table_string_list);
		}

		private void QuotesData_ListReceived(List<Quotes> _table_string_list)
		{
			if (QuotesTable.Count == 0)
			{
				QuotesTable.AddRange(_table_string_list);
				return;
			}
			foreach (Quotes tableString in _table_string_list)
			{
				int index = SearchRecordByPaperCode(tableString, QuotesTable);
				if (index >= 0)
				{
					QuotesTable.Insert(index, tableString);
					QuotesTable.RemoveAt(index + 1);
				}
				else
				{
					QuotesTable.AddRange(_table_string_list);
				}
			}
		}

		private void QuotesData_FuturesListReceived(List<Quotes> _table_string_list)
		{
			if (FuturesQuotesTable.Count == 0)
			{
				FuturesQuotesTable.AddRange(_table_string_list);
				return;
			}
			foreach (Quotes tableString in _table_string_list)
			{
				int index = SearchRecordByPaperCode(tableString, FuturesQuotesTable);
				if (index >= 0)
				{
					FuturesQuotesTable.Insert(index, tableString);
					FuturesQuotesTable.RemoveAt(index + 1);
				}
				else
				{
					FuturesQuotesTable.AddRange(_table_string_list);
				}
			}
		}

		public int SearchRecordByPaperCode(Transaction _tr_string, List<Transaction> _table_string_list)
		{
			return _table_string_list.FindLastIndex((Transaction m) => m.paper_code == _tr_string.paper_code);
		}

		public int SearchRecordByPaperCode(Quotes _qu_string, List<Quotes> _table_string_list)
		{
			return _table_string_list.FindLastIndex((Quotes m) => m.paper_code == _qu_string.paper_code);
		}

		public void AddTransaction(Transaction f_TransactionPaper)
		{
			lock (TransactionTable)
			{
				TransactionTable.Add(f_TransactionPaper);
			}
		}

		public double GetCentralStrikeVol(string futures, DateTime expiration_date, double priceDiff = 0.0)
		{
			double last_price = FuturesQuotesTable.FindLast((Quotes x) => x.paper_code == futures).last_price;
			if (last_price == 0.0)
			{
				return 0.0;
			}
			if (priceDiff != 0.0)
			{
				last_price += priceDiff;
			}
			List<Quotes> quotesCollection = QuotesTable.FindAll((Quotes x) => x.base_asset == futures && x.expiration_date.Date == expiration_date.Date).ToList();
			if (quotesCollection.Count > 0)
			{
				List<double> strikesCollection = (from x in quotesCollection
					select x.strike into x
					orderby Math.Abs(x - last_price)
					select x).ToList();
				double central_strike = strikesCollection[0];
				Quotes optionQuote = quotesCollection.FindLast((Quotes x) => x.strike == central_strike);
				if (optionQuote.paper_code != "")
				{
					return optionQuote.volatility;
				}
			}
			return 0.0;
		}

		public bool SearchPaper(string iCode)
		{
			bool flag = false;
			if (Helpers.IsFutures(iCode))
			{
				lock (FuturesQuotesTable)
				{
					for (int index = 0; index < FuturesQuotesTable.Count; index++)
					{
						if (FuturesQuotesTable[index].paper_code == iCode)
						{
							QuotesPaper.paper_code = FuturesQuotesTable[index].paper_code;
							QuotesPaper.expiration_date = FuturesQuotesTable[index].expiration_date;
							QuotesPaper.base_asset = FuturesQuotesTable[index].base_asset;
							QuotesPaper.demand = FuturesQuotesTable[index].demand;
							QuotesPaper.sentence = FuturesQuotesTable[index].sentence;
							QuotesPaper.last_price = FuturesQuotesTable[index].last_price;
							QuotesPaper.strike = FuturesQuotesTable[index].strike;
							QuotesPaper.option_type = FuturesQuotesTable[index].option_type;
							QuotesPaper.volatility = FuturesQuotesTable[index].volatility;
							QuotesPaper.teoretical_price = FuturesQuotesTable[index].teoretical_price;
							QuotesPaper.step_price = FuturesQuotesTable[index].step_price;
							QuotesPaper.decimal_points = FuturesQuotesTable[index].decimal_points;
							LocalCopyQuotesPaper = QuotesPaper;
							flag = true;
							break;
						}
					}
				}
			}
			else if (CacheQuotesTable.ContainsKey(iCode))
			{
				int index2 = CacheQuotesTable[iCode];
				lock (QuotesTable)
				{
					if (QuotesTable[index2].paper_code == iCode)
					{
						QuotesPaper.paper_code = QuotesTable[index2].paper_code;
						QuotesPaper.expiration_date = QuotesTable[index2].expiration_date;
						QuotesPaper.base_asset = QuotesTable[index2].base_asset;
						QuotesPaper.demand = QuotesTable[index2].demand;
						QuotesPaper.sentence = QuotesTable[index2].sentence;
						QuotesPaper.last_price = QuotesTable[index2].last_price;
						QuotesPaper.strike = QuotesTable[index2].strike;
						QuotesPaper.option_type = QuotesTable[index2].option_type;
						QuotesPaper.volatility = QuotesTable[index2].volatility;
						QuotesPaper.teoretical_price = QuotesTable[index2].teoretical_price;
						QuotesPaper.step_price = QuotesTable[index2].step_price;
						QuotesPaper.decimal_points = QuotesTable[index2].decimal_points;
						LocalCopyQuotesPaper = QuotesPaper;
						flag = true;
					}
					else
					{
						for (int i = 0; i < QuotesTable.Count; i++)
						{
							if (QuotesTable[i].paper_code == iCode)
							{
								QuotesPaper.paper_code = QuotesTable[i].paper_code;
								QuotesPaper.expiration_date = QuotesTable[i].expiration_date;
								QuotesPaper.base_asset = QuotesTable[i].base_asset;
								QuotesPaper.demand = QuotesTable[i].demand;
								QuotesPaper.sentence = QuotesTable[i].sentence;
								QuotesPaper.last_price = QuotesTable[i].last_price;
								QuotesPaper.strike = QuotesTable[i].strike;
								QuotesPaper.option_type = QuotesTable[i].option_type;
								QuotesPaper.volatility = QuotesTable[i].volatility;
								QuotesPaper.teoretical_price = QuotesTable[i].teoretical_price;
								QuotesPaper.step_price = QuotesTable[i].step_price;
								QuotesPaper.decimal_points = QuotesTable[i].decimal_points;
								CacheQuotesTable[iCode] = i;
								LocalCopyQuotesPaper = QuotesPaper;
								flag = true;
								break;
							}
						}
					}
				}
			}
			else
			{
				lock (QuotesTable)
				{
					for (int j = 0; j < QuotesTable.Count; j++)
					{
						if (QuotesTable[j].paper_code == iCode)
						{
							QuotesPaper.paper_code = QuotesTable[j].paper_code;
							QuotesPaper.expiration_date = QuotesTable[j].expiration_date;
							QuotesPaper.base_asset = QuotesTable[j].base_asset;
							QuotesPaper.demand = QuotesTable[j].demand;
							QuotesPaper.sentence = QuotesTable[j].sentence;
							QuotesPaper.last_price = QuotesTable[j].last_price;
							QuotesPaper.strike = QuotesTable[j].strike;
							QuotesPaper.option_type = QuotesTable[j].option_type;
							QuotesPaper.volatility = QuotesTable[j].volatility;
							QuotesPaper.teoretical_price = QuotesTable[j].teoretical_price;
							QuotesPaper.step_price = QuotesTable[j].step_price;
							QuotesPaper.decimal_points = QuotesTable[j].decimal_points;
							CacheQuotesTable.Add(iCode, j);
							LocalCopyQuotesPaper = QuotesPaper;
							flag = true;
							break;
						}
					}
				}
			}
			return flag;
		}

		public bool SearchPaper(DateTime expiration_date, string base_asset, double strike, string option_type)
		{
			bool flag = false;
			lock (QuotesTable)
			{
				for (int index = 0; index < QuotesTable.Count; index++)
				{
					if (QuotesTable[index].expiration_date.Date == expiration_date && QuotesTable[index].base_asset == base_asset && QuotesTable[index].strike == strike && QuotesTable[index].option_type == option_type)
					{
						QuotesPaper.paper_code = QuotesTable[index].paper_code;
						QuotesPaper.expiration_date = QuotesTable[index].expiration_date;
						QuotesPaper.base_asset = QuotesTable[index].base_asset;
						QuotesPaper.demand = QuotesTable[index].demand;
						QuotesPaper.sentence = QuotesTable[index].sentence;
						QuotesPaper.last_price = QuotesTable[index].last_price;
						QuotesPaper.strike = QuotesTable[index].strike;
						QuotesPaper.option_type = QuotesTable[index].option_type;
						QuotesPaper.volatility = QuotesTable[index].volatility;
						QuotesPaper.teoretical_price = QuotesTable[index].teoretical_price;
						QuotesPaper.step_price = QuotesTable[index].step_price;
						QuotesPaper.decimal_points = QuotesTable[index].decimal_points;
						flag = true;
						break;
					}
				}
			}
			return flag;
		}

		public bool SearchPaperQuotesTable(int iLineNumber)
		{
			bool flag = false;
			lock (QuotesTable)
			{
				if (iLineNumber >= 0 && iLineNumber < QuotesTable.Count)
				{
					QuotesPaper.paper_code = QuotesTable[iLineNumber].paper_code;
					QuotesPaper.expiration_date = QuotesTable[iLineNumber].expiration_date;
					QuotesPaper.base_asset = QuotesTable[iLineNumber].base_asset;
					QuotesPaper.demand = QuotesTable[iLineNumber].demand;
					QuotesPaper.sentence = QuotesTable[iLineNumber].sentence;
					QuotesPaper.last_price = QuotesTable[iLineNumber].last_price;
					QuotesPaper.strike = QuotesTable[iLineNumber].strike;
					QuotesPaper.option_type = QuotesTable[iLineNumber].option_type;
					QuotesPaper.volatility = QuotesTable[iLineNumber].volatility;
					QuotesPaper.teoretical_price = QuotesTable[iLineNumber].teoretical_price;
					QuotesPaper.step_price = QuotesTable[iLineNumber].step_price;
					QuotesPaper.decimal_points = QuotesTable[iLineNumber].decimal_points;
					LocalCopyQuotesPaper = QuotesPaper;
					flag = true;
				}
				else
				{
					flag = false;
				}
			}
			return flag;
		}

		public bool SearchTransaction(string iNumber)
		{
			bool flag = false;
			lock (TransactionTable)
			{
				for (int index = 0; index < TransactionTable.Count; index++)
				{
					if (TransactionTable[index].number == iNumber)
					{
						TransactionPaper.number = TransactionTable[index].number;
						TransactionPaper.date = TransactionTable[index].date;
						TransactionPaper.time = TransactionTable[index].time;
						TransactionPaper.paper_code = TransactionTable[index].paper_code;
						TransactionPaper.operation = TransactionTable[index].operation;
						TransactionPaper.price = TransactionTable[index].price;
						TransactionPaper.volume = TransactionTable[index].volume;
						flag = true;
						break;
					}
				}
			}
			return flag;
		}

		public int QuantityFuturesQuotesTable()
		{
			int num = 0;
			lock (FuturesQuotesTable)
			{
				num = FuturesQuotesTable.Count;
			}
			return num;
		}

		public int QuantityQuotesTable()
		{
			int num = 0;
			lock (QuotesTable)
			{
				num = QuotesTable.Count;
			}
			return num;
		}

		public int QuantityTransaction()
		{
			int num = 0;
			lock (TransactionTable)
			{
				num = TransactionTable.Count;
			}
			return num;
		}

		public bool SearchTransactionLineNumber(int iNumber)
		{
			bool flag = false;
			lock (TransactionTable)
			{
				if (iNumber - 1 >= 0 && iNumber <= TransactionTable.Count)
				{
					TransactionPaper.number = TransactionTable[iNumber - 1].number;
					TransactionPaper.date = TransactionTable[iNumber - 1].date;
					TransactionPaper.time = TransactionTable[iNumber - 1].time;
					TransactionPaper.paper_code = TransactionTable[iNumber - 1].paper_code;
					TransactionPaper.operation = TransactionTable[iNumber - 1].operation;
					TransactionPaper.price = TransactionTable[iNumber - 1].price;
					TransactionPaper.volume = TransactionTable[iNumber - 1].volume;
					flag = true;
				}
				else
				{
					flag = false;
				}
			}
			return flag;
		}

		public void ClearQuotes()
		{
			lock (QuotesTable)
			{
				QuotesTable.Clear();
			}
			lock (FuturesQuotesTable)
			{
				FuturesQuotesTable.Clear();
			}
			lock (CacheQuotesTable)
			{
				CacheQuotesTable.Clear();
			}
		}

		public void ClearTransaction()
		{
			lock (TransactionTable)
			{
				TransactionTable.Clear();
			}
		}

		public bool StepStrike(string baseAsset)
		{
			StrikeCall.Clear();
			StrikePut.Clear();
			double val1 = 0.0;
			double num = 0.0;
			bool flag1 = true;
			int decimal_points = 0;
			if (!F_ErrorOpenFile)
			{
				lock (QuotesTable)
				{
					for (int index = 0; index < QuotesTable.Count; index++)
					{
						try
						{
							if (!(QuotesTable[index].base_asset == baseAsset) || !Helpers.IsOption(QuotesTable[index].paper_code))
							{
								continue;
							}
							string upper = Convert.ToString(QuotesTable[index].option_type).ToUpper();
							if (upper == "CALL")
							{
								if (!StrikeCall.ContainsValue(QuotesTable[index].strike))
								{
									StrikeCall.Add(QuotesTable[index].strike, QuotesTable[index].strike);
								}
							}
							else if (upper == "PUT" && !StrikePut.ContainsValue(QuotesTable[index].strike))
							{
								StrikePut.Add(QuotesTable[index].strike, QuotesTable[index].strike);
							}
							decimal_points = QuotesTable[index].decimal_points;
						}
						catch (Exception)
						{
							_logger.Error("Cannot add option strike {0} for base asset {1}", QuotesTable[index].strike, baseAsset);
						}
					}
				}
			}
			bool flag2 = true;
			bool flag3 = true;
			if (StrikeCall.Count >= 2)
			{
				for (int i = 0; i < StrikeCall.Count - 1; i++)
				{
					if (flag2)
					{
						val1 = StrikeCall.Values[i + 1] - StrikeCall.Values[i];
						flag2 = false;
					}
					else
					{
						val1 = Math.Min(val1, StrikeCall.Values[i + 1] - StrikeCall.Values[i]);
					}
				}
			}
			if (StrikePut.Count >= 2)
			{
				for (int j = 0; j < StrikePut.Count - 1; j++)
				{
					if (flag3)
					{
						num = StrikePut.Values[j + 1] - StrikePut.Values[j];
						flag3 = false;
					}
					else
					{
						num = Math.Min(num, StrikePut.Values[j + 1] - StrikePut.Values[j]);
					}
				}
			}
			bool flag4;
			if (flag4 = false)
			{
				iStepStrike = Math.Min(val1, num);
				if (iStepStrike <= 0.0)
				{
					flag1 = false;
				}
			}
			else if (!flag4)
			{
				iStepStrike = val1;
				if (iStepStrike <= 0.0)
				{
					flag1 = false;
				}
			}
			else if (!flag3)
			{
				iStepStrike = num;
				if (iStepStrike <= 0.0)
				{
					flag1 = false;
				}
			}
			else
			{
				flag1 = false;
			}
			if (iStepStrike < 1.0)
			{
				iStepStrike = Math.Round(iStepStrike, decimal_points);
			}
			return flag1;
		}
	}
}
