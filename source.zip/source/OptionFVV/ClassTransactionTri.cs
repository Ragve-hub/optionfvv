using System.IO;
using System.Windows.Forms;

namespace OptionFVV
{
	internal class ClassTransactionTri
	{
		private static string gFileName;

		private static string gFolderName;

		private string CurrentDirectory;

		private string gAccount;

		private string gClientCode;

		private string gType;

		private string gTransID;

		private string gClassCode;

		private string gSecCode;

		private string gAction;

		private string gOperation;

		private string gPrice;

		private string gQuantity;

		public string FileName
		{
			get
			{
				return gFileName;
			}
			set
			{
				gFileName = value;
			}
		}

		public string FolderName
		{
			get
			{
				return gFolderName;
			}
		}

		public string Account
		{
			get
			{
				return gAccount;
			}
			set
			{
				gAccount = value;
			}
		}

		public string ClientCode
		{
			get
			{
				return gClientCode;
			}
			set
			{
				gClientCode = value;
			}
		}

		public string Type
		{
			get
			{
				return gType;
			}
			set
			{
				gType = value;
			}
		}

		public string TransID
		{
			get
			{
				return gTransID;
			}
			set
			{
				gTransID = value;
			}
		}

		public string ClassCode
		{
			get
			{
				return gClassCode;
			}
			set
			{
				gClassCode = value;
			}
		}

		public string SecCode
		{
			get
			{
				return gSecCode;
			}
			set
			{
				gSecCode = value;
			}
		}

		public string Action
		{
			get
			{
				return gAction;
			}
			set
			{
				gAction = value;
			}
		}

		public string Operation
		{
			get
			{
				return gOperation;
			}
			set
			{
				gOperation = value;
			}
		}

		public string Price
		{
			get
			{
				return gPrice;
			}
			set
			{
				gPrice = value;
			}
		}

		public string Quantity
		{
			get
			{
				return gQuantity;
			}
			set
			{
				gQuantity = value;
			}
		}

		public ClassTransactionTri()
		{
			gFileName = "ImportTransaction";
			gFolderName = "";
			CurrentDirectory = Application.StartupPath;
			gFolderName = CurrentDirectory + "\\ImportTransaction";
			gAccount = "4110SMI";
			gClientCode = "";
			gType = "L";
			gTransID = "1";
			gClassCode = "SPBOPT";
			gSecCode = "";
			gAction = "NEW_ORDER";
			gOperation = "";
			gPrice = "";
			gQuantity = "";
		}

		public bool CheckFolderImportTransaction()
		{
			DirectoryInfo directoryInfo = new DirectoryInfo(gFolderName);
			bool flag;
			if (directoryInfo.Exists)
			{
				flag = true;
			}
			else
			{
				flag = true;
				try
				{
					directoryInfo.Create();
				}
				catch
				{
					flag = false;
				}
			}
			return flag;
		}

		public void NewOrder()
		{
			string path = gFolderName + "\\" + gFileName + ".tri";
			if (CheckFolderImportTransaction())
			{
				StreamWriter streamWriter = new StreamWriter(path, true);
				streamWriter.WriteLine("ACCOUNT=" + gAccount + ";TYPE=" + gType + ";TRANS_ID=" + gTransID + ";CLASSCODE=" + gClassCode + ";SECCODE=" + gSecCode + ";ACTION=" + gAction + ";OPERATION=" + gOperation + ";PRICE=" + gPrice + ";QUANTITY=" + gQuantity + ";");
				streamWriter.Close();
			}
		}
	}
}
