using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.IO;
using System.Windows.Forms;
using System.Windows.Forms.DataVisualization.Charting;
using QuikDDE.Data;

namespace OptionFVV
{
	public class FormSmile : Form
	{
		private delegate double dGetModelSmile();

		private delegate bool dGetModelSmileChecked();

		private delegate string dGetModelSmileName();

		public struct BaseAsset
		{
			public string base_asset_fut;

			public string base_asset;

			public DateTime expiration_date;

			public double price_fut;
		}

		public struct ModelSmile
		{
			public string name;

			public string base_asset;

			public DateTime date;

			public double vola;

			public double Skew;

			public double Kink;
		}

		public struct CalendarInfo
		{
			public string base_asset_fut;

			public string base_asset1;

			public string paper_code1;

			public DateTime expiration_date1;

			public double price_fut1;

			public double strike1;

			public double volatility1;

			public string base_asset2;

			public string paper_code2;

			public DateTime expiration_date2;

			public double strike2;

			public double volatility2;

			public string base_assets_Calendar;

			public double spreadvolatility;
		}

		public struct Quotes
		{
			public string paper_code;

			public DateTime expiration_date;

			public string base_asset;

			public double demand;

			public double sentence;

			public double last_price;

			public double strike;

			public string option_type;

			public double volatility;

			public double teoretical_price;

			public double step_price;

			public bool F;
		}

		public struct SmileTotal
		{
			public string paper_code_call;

			public string option_type_call;

			public double demand_call;

			public double sentence_call;

			public double last_price_call;

			public double teoretical_price_call;

			public double strike;

			public double volatility;

			public DateTime expiration_date;

			public string base_asset;

			public double step_price;

			public double teoretical_price_put;

			public double last_price_put;

			public double sentence_put;

			public double demand_put;

			public string option_type_put;

			public string paper_code_put;

			public double volatilityModelSmile;
		}

		private string gSmileSortMethod;

		private double PositionX;

		private double PositionY;

		private double ModelVolatility;

		private double ModelCurrentStrike;

		private double ModelSmileSkew;

		private double ModelSmileKink;

		private double PortfolioD;

		private double PortfolioV;

		private double PortfolioP;

		private ClassCalculationOptions cCalculationOptions = new ClassCalculationOptions();

		private ClassDataDDE cDataDDE = new ClassDataDDE(false);

		private ClassHistoryDataDDE cHistoryDataDDE = new ClassHistoryDataDDE();

		private AverageSmile cAverageSmile = new AverageSmile();

		private string CurrentDirectory;

		private List<BaseAsset> BaseAssetTable = new List<BaseAsset>();

		private BaseAsset BaseAssetPaper = default(BaseAsset);

		private List<BaseAsset> CopyBaseAssetTable = new List<BaseAsset>();

		private BaseAsset CopyBaseAssetPaper = default(BaseAsset);

		private List<ModelSmile> SettingModelSmile = new List<ModelSmile>();

		private ModelSmile SettingModelSmilePaper = default(ModelSmile);

		private List<CalendarInfo> CalendarInfoTable = new List<CalendarInfo>();

		private CalendarInfo CalendarInfoPaper = default(CalendarInfo);

		private List<QuikDDE.Data.Quotes> qQuotesTable = new List<QuikDDE.Data.Quotes>(10000);

		private QuikDDE.Data.Quotes qQuotesPaper = default(QuikDDE.Data.Quotes);

		private List<QuikDDE.Data.Quotes> qFuturesQuotesTable = new List<QuikDDE.Data.Quotes>(100);

		private QuikDDE.Data.Quotes qFuturesQuotesPaper = default(QuikDDE.Data.Quotes);

		private Quotes FuturePaper1 = default(Quotes);

		private Quotes FuturePaper2 = default(Quotes);

		private SortedList<double, SmileTotal> SmileTable1 = new SortedList<double, SmileTotal>();

		private SortedList<double, SmileTotal> SmileTable2 = new SortedList<double, SmileTotal>();

		private SortedList<double, SmileTotal> SmileTable3 = new SortedList<double, SmileTotal>();

		private SortedList<double, double> SmileTablePrev = new SortedList<double, double>();

		private SmileTotal SmilePaper1 = default(SmileTotal);

		private SmileTotal SmilePaper2 = default(SmileTotal);

		private SmileTotal SmilePaper3 = default(SmileTotal);

		private IContainer components = null;

		private SplitContainer splitContainer1;

		private SplitContainer splitContainer2;

		private GroupBox groupBox1;

		private ComboBox comboBoxExpirationDate1;

		private Label label3;

		private ComboBox comboBoxBaseAsset1;

		private Label label1;

		private GroupBox groupBox2;

		private ComboBox comboBoxExpirationDate2;

		private Label label4;

		private ComboBox comboBoxBaseAsset2;

		private Label label5;

		private TextBox textBoxStepGridX;

		private TextBox textBoxStepGridY;

		private Label label6;

		private GroupBox groupBox3;

		private Label label8;

		private Label label7;

		private TextBox textBoxIndentDn;

		private TextBox textBoxIndentUp;

		private Chart chart1;

		private Chart chart2;

		private Button buttonIndentDnMore;

		private Button buttonIndentDnLess;

		private Button buttonIndentUpMore;

		private Button buttonIndentUpLess;

		private ComboBox comboBoxDemandSentence1;

		private Label label9;

		private ComboBox comboBoxHistory;

		private Label label10;

		private ComboBox comboBoxDemandSentence2;

		private Label label11;

		private GroupBox groupBoxCalendarInfo;

		private DataGridView dataGridViewCalendarInfo;

		private ContextMenuStrip contextMenuStripCalendarInfo;

		private ToolStripMenuItem toolStripMenuItemUpdate;

		private ToolStripMenuItem toolStripMenuItemApply;

		private ToolStripMenuItem toolStripMenuItemSortMethod;

		private ToolStripMenuItem toolStripMenuItemBaseAssets;

		private ToolStripMenuItem toolStripMenuItemSpread;

		private ContextMenuStrip contextMenuStripSmile;

		private ToolStripMenuItem ToolStripMenuItemGlass;

		private ToolStripMenuItem ToolStripMenuItemInstrument1;

		private ToolStripMenuItem ToolStripMenuItemInstrument2;

		private GroupBox groupBoxModelSmile;

		private Label label13;

		private Label label12;

		private CheckBox checkBoxModelSmile;

		private CheckBox checkBoxModelVolatility;

		private NumericUpDown numericUpDownModelSmileVolatility;

		private NumericUpDown numericUpDownModelSmileSkew;

		private NumericUpDown numericUpDownModelSmileKink;

		private Button buttonRemoveModelSmile;

		private Button buttonSaveModelSmile;

		private ComboBox comboBoxCurrentModel;

		public FormSmile()
		{
			PortfolioD = 0.0;
			PortfolioV = 0.0;
			PortfolioP = 0.0;
			gSmileSortMethod = "1";
			BaseAssetTable.Clear();
			CopyBaseAssetTable.Clear();
			CalendarInfoTable.Clear();
			qQuotesTable.Clear();
			qFuturesQuotesTable.Clear();
			CallBackMy.callbackEventHandlerColorThemeFormSmile = PaintColorTheme;
			InitializeComponent();
		}

		private void FormSmile_Load(object sender, EventArgs e)
		{
			CurrentDirectory = Application.StartupPath + "\\SettingsModelSmile.txt";
			SettingModelSmile.Clear();
			CallBackMy.callbackEventHandlerModelSmileVolatility = GetModelSmileVolatility;
			CallBackMy.callbackEventHandlerModelSmileSkew = GetModelSmileSkew;
			CallBackMy.callbackEventHandlerModelSmileKink = GetModelSmileKink;
			CallBackMy.callbackEventHandlerModelSmileChecked = GetModelSmileChecked;
			CallBackMy.callbackEventHandlerModelSmileVolatilityChecked = GetModelVolatilityChecked;
			CallBackMy.callbackEventHandlerModelSmileCurrentStrike = GetModelCurrentStrike;
			CallBackMy.callbackEventHandlerModelSmileName = GetModelName;
			PositionX = 0.0;
			PositionY = 0.0;
			ModelVolatility = 0.0;
			ModelSmileSkew = 0.0;
			ModelSmileKink = 0.0;
			checkBoxModelSmile.Checked = ClassSettings.gSmileCheckBoxModelSmile == "True";
			checkBoxModelVolatility.Checked = ClassSettings.gSmileCheckBoxModelVolatility == "True";
			double result;
			if (!double.TryParse(ClassSettings.gSmileModelVolatility, out result))
			{
				result = 0.0;
			}
			numericUpDownModelSmileVolatility.Value = Convert.ToDecimal(result);
			if (!double.TryParse(ClassSettings.gSmileModelSkew, out result))
			{
				result = 0.0;
			}
			numericUpDownModelSmileSkew.Value = Convert.ToDecimal(result);
			if (!double.TryParse(ClassSettings.gSmileModelKink, out result))
			{
				result = 0.0;
			}
			numericUpDownModelSmileKink.Value = Convert.ToDecimal(result);
			cAverageSmile.FiLLData();
			gSmileSortMethod = ClassSettings.gSmileSortMethod;
			base.FormBorderStyle = FormBorderStyle.None;
			Dock = DockStyle.Fill;
			comboBoxBaseAsset1.Items.Clear();
			comboBoxBaseAsset1.Items.Add("");
			comboBoxBaseAsset1.Items.Add(ClassSettings.gSmileBaseAsset1);
			comboBoxBaseAsset1.SelectedIndex = 1;
			comboBoxBaseAsset1.FlatStyle = FlatStyle.System;
			comboBoxExpirationDate1.Items.Clear();
			comboBoxExpirationDate1.Items.Add("");
			comboBoxExpirationDate1.Items.Add(ClassSettings.gSmileExpirationDate1);
			comboBoxExpirationDate1.SelectedIndex = 1;
			comboBoxExpirationDate1.FlatStyle = FlatStyle.System;
			comboBoxBaseAsset2.Items.Clear();
			comboBoxBaseAsset2.Items.Add("");
			comboBoxBaseAsset2.Items.Add(ClassSettings.gSmileBaseAsset2);
			comboBoxBaseAsset2.SelectedIndex = 1;
			comboBoxBaseAsset2.FlatStyle = FlatStyle.System;
			comboBoxExpirationDate2.Items.Clear();
			comboBoxExpirationDate2.Items.Add("");
			comboBoxExpirationDate2.Items.Add(ClassSettings.gSmileExpirationDate2);
			comboBoxExpirationDate2.SelectedIndex = 1;
			comboBoxExpirationDate2.FlatStyle = FlatStyle.System;
			comboBoxDemandSentence1.FlatStyle = FlatStyle.System;
			comboBoxDemandSentence2.FlatStyle = FlatStyle.System;
			comboBoxHistory.Items.Clear();
			if (ClassSettings.gSmileHistory1 == "NULL")
			{
				comboBoxHistory.Items.Add("NULL");
				comboBoxHistory.SelectedIndex = 0;
			}
			else
			{
				comboBoxHistory.Items.Add("NULL");
				comboBoxHistory.Items.Add(ClassSettings.gSmileHistory1);
				comboBoxHistory.SelectedIndex = 1;
			}
			comboBoxHistory.FlatStyle = FlatStyle.System;
			FillcomboBoxDemandSentence1(ClassSettings.gSmileDemandSentence1);
			FillcomboBoxDemandSentence2(ClassSettings.gSmileDemandSentence2);
			textBoxStepGridX.Text = ClassSettings.gSmileStepGridX;
			textBoxStepGridY.Text = ClassSettings.gSmileStepGridY;
			textBoxIndentDn.Text = ClassSettings.gSmileIndentDn;
			textBoxIndentUp.Text = ClassSettings.gSmileIndentUp;
			ReadFileSettings();
			FillcomboBoxCurrentModel(FindCurrentModel(comboBoxBaseAsset1.Text));
			Create();
			dataGridViewCalendarInfo.EnableHeadersVisualStyles = false;
			dataGridViewCalendarInfo.AutoGenerateColumns = false;
			chart1.ChartAreas[0].AxisX.LineWidth = 2;
			chart1.ChartAreas[0].AxisY.LineWidth = 2;
			chart1.ChartAreas[0].AxisX.LabelStyle.Angle = -90;
			chart1.Titles.Add("Улыбка");
			chart1.Titles[0].Font = new Font("Arial", 10f);
			chart1.ChartAreas[0].Name = "ChartAreas1";
			chart1.Legends[0].DockedToChartArea = "ChartAreas1";
			chart1.Legends[0].Docking = Docking.Right;
			chart1.Legends[0].Alignment = StringAlignment.Near;
			chart1.Legends[0].LegendStyle = LegendStyle.Table;
			chart1.Legends[0].TableStyle = LegendTableStyle.Tall;
			chart1.Legends[0].Position.Auto = true;
			SeriesCollection series1 = chart1.Series;
			Series series2 = new Series("Инструмент 1");
			series2.ChartType = SeriesChartType.Spline;
			series2.BorderWidth = 1;
			series2.ShadowOffset = 0;
			series2.Color = ClassColorTheme.ChartCurrentColor;
			series1.Add(series2);
			if (comboBoxBaseAsset1.Text != "")
			{
				chart1.Series["Инструмент 1"].Enabled = true;
			}
			else
			{
				chart1.Series["Инструмент 1"].Enabled = false;
			}
			SeriesCollection series3 = chart1.Series;
			Series series4 = new Series("Инструмент 2");
			series4.ChartType = SeriesChartType.Spline;
			series4.BorderWidth = 1;
			series4.ShadowOffset = 0;
			series4.Color = Color.Red;
			series3.Add(series4);
			if (comboBoxBaseAsset2.Text != "")
			{
				chart1.Series["Инструмент 2"].Enabled = true;
			}
			else
			{
				chart1.Series["Инструмент 2"].Enabled = false;
			}
			SeriesCollection series5 = chart1.Series;
			Series series6 = new Series("Инструмент 3");
			series6.ChartType = SeriesChartType.Spline;
			series6.BorderWidth = 1;
			series6.ShadowOffset = 0;
			series6.Color = Color.Green;
			series5.Add(series6);
			if (comboBoxHistory.Text != "" && comboBoxHistory.Text != "NULL")
			{
				chart1.Series["Инструмент 3"].Enabled = true;
			}
			else
			{
				chart1.Series["Инструмент 3"].Enabled = false;
			}
			SeriesCollection series7 = chart1.Series;
			Series series8 = new Series("Тек. цена");
			series8.ChartType = SeriesChartType.Line;
			series8.BorderWidth = 1;
			series8.ShadowOffset = 0;
			series8.Color = Color.SlateGray;
			series8.Enabled = true;
			series7.Add(series8);
			if (comboBoxBaseAsset1.Text != "" || comboBoxBaseAsset2.Text != "")
			{
				chart1.Series["Тек. цена"].Enabled = true;
			}
			else
			{
				chart1.Series["Тек. цена"].Enabled = false;
			}
			SeriesCollection series9 = chart1.Series;
			Series series10 = new Series("Предложение инструмент 1");
			series10.ChartType = SeriesChartType.Point;
			series10.BorderWidth = 1;
			series10.ShadowOffset = 0;
			series10.Color = ClassColorTheme.ChartCurrentColor;
			series10.MarkerImage = "sentence1.png";
			series9.Add(series10);
			if (comboBoxBaseAsset1.Text != "" && comboBoxDemandSentence1.Text != "NULL")
			{
				chart1.Series["Предложение инструмент 1"].Enabled = true;
			}
			else
			{
				chart1.Series["Предложение инструмент 1"].Enabled = false;
			}
			SeriesCollection series11 = chart1.Series;
			Series series12 = new Series("Спрос инструмент 1");
			series12.ChartType = SeriesChartType.Point;
			series12.BorderWidth = 1;
			series12.ShadowOffset = 0;
			series12.MarkerImage = "demand1.png";
			series11.Add(series12);
			if (comboBoxBaseAsset1.Text != "" && comboBoxDemandSentence1.Text != "NULL")
			{
				chart1.Series["Спрос инструмент 1"].Enabled = true;
			}
			else
			{
				chart1.Series["Спрос инструмент 1"].Enabled = false;
			}
			SeriesCollection series13 = chart1.Series;
			Series series14 = new Series("Предложение инструмент 2");
			series14.ChartType = SeriesChartType.Point;
			series14.BorderWidth = 1;
			series14.ShadowOffset = 0;
			series14.Color = Color.SlateGray;
			series14.MarkerImage = "sentence2.png";
			series13.Add(series14);
			if (comboBoxBaseAsset2.Text != "" && comboBoxDemandSentence2.Text != "NULL")
			{
				chart1.Series["Предложение инструмент 2"].Enabled = true;
			}
			else
			{
				chart1.Series["Предложение инструмент 2"].Enabled = false;
			}
			SeriesCollection series15 = chart1.Series;
			Series series16 = new Series("Спрос инструмент 2");
			series16.ChartType = SeriesChartType.Point;
			series16.BorderWidth = 1;
			series16.ShadowOffset = 0;
			series16.Color = Color.SlateGray;
			series16.MarkerImage = "demand2.png";
			series15.Add(series16);
			if (comboBoxBaseAsset2.Text != "" && comboBoxDemandSentence2.Text != "NULL")
			{
				chart1.Series["Спрос инструмент 2"].Enabled = true;
			}
			else
			{
				chart1.Series["Спрос инструмент 2"].Enabled = false;
			}
			SeriesCollection series17 = chart1.Series;
			Series series18 = new Series("AvSmile");
			series18.ChartType = SeriesChartType.Point;
			series18.BorderWidth = 6;
			series18.ShadowOffset = 0;
			series18.Color = ClassColorTheme.SmileModelColor;
			series18.Enabled = true;
			series18.MarkerStyle = MarkerStyle.Circle;
			series17.Add(series18);
			SeriesCollection series19 = chart1.Series;
			Series series20 = new Series("Модель");
			series20.ChartType = SeriesChartType.Spline;
			series20.BorderWidth = 1;
			series20.ShadowOffset = 0;
			series20.Color = ClassColorTheme.SmileModelColor;
			series19.Add(series20);
			if (checkBoxModelSmile.Checked)
			{
				chart1.Series["Модель"].Enabled = true;
			}
			else
			{
				chart1.Series["Модель"].Enabled = false;
			}
			SeriesCollection series21 = chart1.Series;
			Series series22 = new Series("Тек. цена модель");
			series22.ChartType = SeriesChartType.Line;
			series22.BorderWidth = 1;
			series22.ShadowOffset = 0;
			series22.Color = ClassColorTheme.SmileModelColor;
			series22.Enabled = false;
			series21.Add(series22);
			chart2.ChartAreas[0].AxisX.LineWidth = 2;
			chart2.ChartAreas[0].AxisY.LineWidth = 2;
			chart2.Titles.Add("");
			chart2.Titles[0].Font = new Font("Arial", 10f);
			chart2.ChartAreas[0].Name = "ChartAreas2";
			chart2.Legends[0].DockedToChartArea = "ChartAreas2";
			chart2.Legends[0].Docking = Docking.Right;
			chart2.Legends[0].Alignment = StringAlignment.Near;
			chart2.Legends[0].LegendStyle = LegendStyle.Table;
			chart2.Legends[0].TableStyle = LegendTableStyle.Tall;
			chart2.Legends[0].Position.Auto = true;
			SeriesCollection series23 = chart2.Series;
			Series series24 = new Series("Раздвижка");
			series24.ChartType = SeriesChartType.Spline;
			series24.BorderWidth = 1;
			series24.ShadowOffset = 0;
			series24.Color = ClassColorTheme.ChartCurrentColor;
			series23.Add(series24);
			if (comboBoxBaseAsset1.Text != "" && comboBoxBaseAsset2.Text != "")
			{
				chart2.Series["Раздвижка"].Enabled = true;
			}
			else
			{
				chart2.Series["Раздвижка"].Enabled = false;
			}
			SeriesCollection series25 = chart2.Series;
			Series series26 = new Series("РаздвижкаИстория");
			series26.ChartType = SeriesChartType.Spline;
			series26.BorderWidth = 1;
			series26.ShadowOffset = 0;
			series26.Color = Color.Green;
			series25.Add(series26);
			if (comboBoxBaseAsset1.Text != "" && comboBoxHistory.Text != "" && comboBoxHistory.Text != "NULL")
			{
				chart2.Series["Раздвижка"].Enabled = true;
			}
			else
			{
				chart2.Series["Раздвижка"].Enabled = false;
			}
			SeriesCollection series27 = chart2.Series;
			Series series28 = new Series("Тек. цена");
			series28.ChartType = SeriesChartType.Line;
			series28.BorderWidth = 1;
			series28.ShadowOffset = 0;
			series28.Color = Color.SlateGray;
			series28.Enabled = true;
			series27.Add(series28);
			if (comboBoxBaseAsset1.Text != "" && comboBoxBaseAsset2.Text != "")
			{
				chart2.Series["Тек. цена"].Enabled = true;
			}
			else
			{
				chart2.Series["Тек. цена"].Enabled = false;
			}
			chart1.ContextMenuStrip = contextMenuStripSmile;
			PaintColorTheme();
		}

		public void Create()
		{
			DataGridViewTextBoxColumn viewTextBoxColumn1 = new DataGridViewTextBoxColumn();
			viewTextBoxColumn1.HeaderText = "Баз. актив";
			viewTextBoxColumn1.Name = "base_asset";
			viewTextBoxColumn1.AutoSizeMode = DataGridViewAutoSizeColumnMode.DisplayedCells;
			viewTextBoxColumn1.DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;
			viewTextBoxColumn1.ReadOnly = true;
			DataGridViewTextBoxColumn viewTextBoxColumn2 = new DataGridViewTextBoxColumn();
			viewTextBoxColumn2.HeaderText = "Спред";
			viewTextBoxColumn2.Name = "Spread";
			viewTextBoxColumn2.DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;
			viewTextBoxColumn2.ReadOnly = true;
			dataGridViewCalendarInfo.Columns.Add(viewTextBoxColumn1);
			dataGridViewCalendarInfo.Columns.Add(viewTextBoxColumn2);
			dataGridViewCalendarInfo.RowHeadersVisible = false;
			dataGridViewCalendarInfo.ColumnHeadersDefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;
			viewTextBoxColumn2.AutoSizeMode = DataGridViewAutoSizeColumnMode.AllCells;
			viewTextBoxColumn1.AutoSizeMode = DataGridViewAutoSizeColumnMode.Fill;
			viewTextBoxColumn1.MinimumWidth = 100;
			viewTextBoxColumn1.SortMode = DataGridViewColumnSortMode.NotSortable;
			viewTextBoxColumn2.SortMode = DataGridViewColumnSortMode.NotSortable;
			dataGridViewCalendarInfo.ContextMenuStrip = contextMenuStripCalendarInfo;
		}

		public void CreateChartTable()
		{
			double f_FutLastPrice = 0.0;
			double f_Volatility = 0.0;
			double num = 0.0;
			FuturePaper1.F = false;
			FuturePaper2.F = false;
			SmileTable1.Clear();
			SmileTable2.Clear();
			SmileTable3.Clear();
			if (checkBoxModelSmile.Checked)
			{
				ModelSmileSkew = Convert.ToDouble(numericUpDownModelSmileSkew.Value);
				ModelSmileKink = Convert.ToDouble(numericUpDownModelSmileKink.Value);
				if (checkBoxModelVolatility.Checked)
				{
					ModelVolatility = Convert.ToDouble(numericUpDownModelSmileVolatility.Value);
					if (ModelVolatility < 0.0)
					{
						ModelVolatility = 0.0;
					}
				}
				else
				{
					ModelVolatility = 0.0;
				}
			}
			else
			{
				ModelVolatility = 0.0;
				ModelSmileSkew = 0.0;
				ModelSmileKink = 0.0;
			}
			PortfolioD = CallBackMy.callbackEventHandlerD();
			PortfolioV = CallBackMy.callbackEventHandlerV();
			PortfolioP = CallBackMy.callbackEventHandlerP();
			if (Convert.ToString(comboBoxBaseAsset1.Text) != "")
			{
				lock (ClassDataDDE.FuturesQuotesTable)
				{
					for (int index = 0; index < ClassDataDDE.FuturesQuotesTable.Count; index++)
					{
						if (Convert.ToString(comboBoxBaseAsset1.Text) == ClassDataDDE.FuturesQuotesTable[index].paper_code)
						{
							FuturePaper1.paper_code = ClassDataDDE.FuturesQuotesTable[index].paper_code;
							FuturePaper1.expiration_date = ClassDataDDE.FuturesQuotesTable[index].expiration_date;
							FuturePaper1.base_asset = ClassDataDDE.FuturesQuotesTable[index].base_asset;
							FuturePaper1.demand = ClassDataDDE.FuturesQuotesTable[index].demand;
							FuturePaper1.sentence = ClassDataDDE.FuturesQuotesTable[index].sentence;
							FuturePaper1.last_price = ClassDataDDE.FuturesQuotesTable[index].last_price;
							FuturePaper1.strike = ClassDataDDE.FuturesQuotesTable[index].strike;
							FuturePaper1.option_type = ClassDataDDE.FuturesQuotesTable[index].option_type;
							FuturePaper1.volatility = ClassDataDDE.FuturesQuotesTable[index].volatility;
							FuturePaper1.teoretical_price = ClassDataDDE.FuturesQuotesTable[index].teoretical_price;
							FuturePaper1.step_price = ClassDataDDE.FuturesQuotesTable[index].step_price;
							FuturePaper1.F = true;
							break;
						}
					}
				}
			}
			if (Convert.ToString(comboBoxBaseAsset2.Text) != "")
			{
				lock (ClassDataDDE.FuturesQuotesTable)
				{
					for (int i = 0; i < ClassDataDDE.FuturesQuotesTable.Count; i++)
					{
						if (Convert.ToString(comboBoxBaseAsset2.Text) == ClassDataDDE.FuturesQuotesTable[i].paper_code)
						{
							FuturePaper2.paper_code = ClassDataDDE.FuturesQuotesTable[i].paper_code;
							FuturePaper2.expiration_date = ClassDataDDE.FuturesQuotesTable[i].expiration_date;
							FuturePaper2.base_asset = ClassDataDDE.FuturesQuotesTable[i].base_asset;
							FuturePaper2.demand = ClassDataDDE.FuturesQuotesTable[i].demand;
							FuturePaper2.sentence = ClassDataDDE.FuturesQuotesTable[i].sentence;
							FuturePaper2.last_price = ClassDataDDE.FuturesQuotesTable[i].last_price;
							FuturePaper2.strike = ClassDataDDE.FuturesQuotesTable[i].strike;
							FuturePaper2.option_type = ClassDataDDE.FuturesQuotesTable[i].option_type;
							FuturePaper2.volatility = ClassDataDDE.FuturesQuotesTable[i].volatility;
							FuturePaper2.teoretical_price = ClassDataDDE.FuturesQuotesTable[i].teoretical_price;
							FuturePaper2.step_price = ClassDataDDE.FuturesQuotesTable[i].step_price;
							FuturePaper2.F = true;
							break;
						}
					}
				}
			}
			DateTime result;
			if (FuturePaper1.F)
			{
				lock (ClassDataDDE.QuotesTable)
				{
					for (int j = 0; j < ClassDataDDE.QuotesTable.Count; j++)
					{
						if (!DateTime.TryParse(Convert.ToString(comboBoxExpirationDate1.Text), out result))
						{
							FuturePaper1.F = false;
							break;
						}
						if (!(Convert.ToString(comboBoxBaseAsset1.Text) == ClassDataDDE.QuotesTable[j].base_asset) || !(result.Date == ClassDataDDE.QuotesTable[j].expiration_date.Date))
						{
							continue;
						}
						if (ClassDataDDE.QuotesTable[j].option_type == "Call")
						{
							if (SmileTable1.Count > 0)
							{
								bool flag = false;
								for (int k = 0; k < SmileTable1.Count; k++)
								{
									if (SmileTable1.Values[k].strike == ClassDataDDE.QuotesTable[j].strike)
									{
										SmilePaper1 = SmileTable1.Values[k];
										SmilePaper1.paper_code_call = ClassDataDDE.QuotesTable[j].paper_code;
										SmilePaper1.option_type_call = "Call";
										SmilePaper1.demand_call = ClassDataDDE.QuotesTable[j].demand;
										SmilePaper1.sentence_call = ClassDataDDE.QuotesTable[j].sentence;
										SmilePaper1.last_price_call = ClassDataDDE.QuotesTable[j].last_price;
										SmilePaper1.teoretical_price_call = ClassDataDDE.QuotesTable[j].teoretical_price;
										SmilePaper1.strike = ClassDataDDE.QuotesTable[j].strike;
										SmilePaper1.volatility = ClassDataDDE.QuotesTable[j].volatility;
										SmilePaper1.expiration_date = ClassDataDDE.QuotesTable[j].expiration_date;
										SmilePaper1.base_asset = ClassDataDDE.QuotesTable[j].base_asset;
										SmilePaper1.step_price = ClassDataDDE.QuotesTable[j].step_price;
										SmilePaper1.volatilityModelSmile = 0.0;
										SmileTable1.RemoveAt(k);
										SmileTable1.Add(SmilePaper1.strike, SmilePaper1);
										flag = true;
										break;
									}
								}
								if (!flag)
								{
									SmilePaper1.paper_code_call = ClassDataDDE.QuotesTable[j].paper_code;
									SmilePaper1.option_type_call = "Call";
									SmilePaper1.demand_call = ClassDataDDE.QuotesTable[j].demand;
									SmilePaper1.sentence_call = ClassDataDDE.QuotesTable[j].sentence;
									SmilePaper1.last_price_call = ClassDataDDE.QuotesTable[j].last_price;
									SmilePaper1.teoretical_price_call = ClassDataDDE.QuotesTable[j].teoretical_price;
									SmilePaper1.strike = ClassDataDDE.QuotesTable[j].strike;
									SmilePaper1.volatility = ClassDataDDE.QuotesTable[j].volatility;
									SmilePaper1.expiration_date = ClassDataDDE.QuotesTable[j].expiration_date;
									SmilePaper1.base_asset = ClassDataDDE.QuotesTable[j].base_asset;
									SmilePaper1.step_price = ClassDataDDE.QuotesTable[j].step_price;
									SmilePaper1.volatilityModelSmile = 0.0;
									SmileTable1.Add(SmilePaper1.strike, SmilePaper1);
								}
							}
							else
							{
								SmilePaper1.paper_code_call = ClassDataDDE.QuotesTable[j].paper_code;
								SmilePaper1.option_type_call = "Call";
								SmilePaper1.demand_call = ClassDataDDE.QuotesTable[j].demand;
								SmilePaper1.sentence_call = ClassDataDDE.QuotesTable[j].sentence;
								SmilePaper1.last_price_call = ClassDataDDE.QuotesTable[j].last_price;
								SmilePaper1.teoretical_price_call = ClassDataDDE.QuotesTable[j].teoretical_price;
								SmilePaper1.strike = ClassDataDDE.QuotesTable[j].strike;
								SmilePaper1.volatility = ClassDataDDE.QuotesTable[j].volatility;
								SmilePaper1.expiration_date = ClassDataDDE.QuotesTable[j].expiration_date;
								SmilePaper1.base_asset = ClassDataDDE.QuotesTable[j].base_asset;
								SmilePaper1.step_price = ClassDataDDE.QuotesTable[j].step_price;
								SmilePaper1.volatilityModelSmile = 0.0;
								SmileTable1.Add(SmilePaper1.strike, SmilePaper1);
							}
						}
						else
						{
							if (!(ClassDataDDE.QuotesTable[j].option_type == "Put"))
							{
								continue;
							}
							if (SmileTable1.Count > 0)
							{
								bool flag2 = false;
								for (int l = 0; l < SmileTable1.Count; l++)
								{
									if (SmileTable1.Values[l].strike == ClassDataDDE.QuotesTable[j].strike)
									{
										SmilePaper1 = SmileTable1.Values[l];
										SmilePaper1.paper_code_put = ClassDataDDE.QuotesTable[j].paper_code;
										SmilePaper1.option_type_put = "Put";
										SmilePaper1.demand_put = ClassDataDDE.QuotesTable[j].demand;
										SmilePaper1.sentence_put = ClassDataDDE.QuotesTable[j].sentence;
										SmilePaper1.last_price_put = ClassDataDDE.QuotesTable[j].last_price;
										SmilePaper1.teoretical_price_put = ClassDataDDE.QuotesTable[j].teoretical_price;
										SmilePaper1.strike = ClassDataDDE.QuotesTable[j].strike;
										SmilePaper1.volatility = ClassDataDDE.QuotesTable[j].volatility;
										SmilePaper1.expiration_date = ClassDataDDE.QuotesTable[j].expiration_date;
										SmilePaper1.base_asset = ClassDataDDE.QuotesTable[j].base_asset;
										SmilePaper1.step_price = ClassDataDDE.QuotesTable[j].step_price;
										SmilePaper1.volatilityModelSmile = 0.0;
										SmileTable1.RemoveAt(l);
										SmileTable1.Add(SmilePaper1.strike, SmilePaper1);
										flag2 = true;
										break;
									}
								}
								if (!flag2)
								{
									SmilePaper1.paper_code_put = ClassDataDDE.QuotesTable[j].paper_code;
									SmilePaper1.option_type_put = "Put";
									SmilePaper1.demand_put = ClassDataDDE.QuotesTable[j].demand;
									SmilePaper1.sentence_put = ClassDataDDE.QuotesTable[j].sentence;
									SmilePaper1.last_price_put = ClassDataDDE.QuotesTable[j].last_price;
									SmilePaper1.teoretical_price_put = ClassDataDDE.QuotesTable[j].teoretical_price;
									SmilePaper1.strike = ClassDataDDE.QuotesTable[j].strike;
									SmilePaper1.volatility = ClassDataDDE.QuotesTable[j].volatility;
									SmilePaper1.expiration_date = ClassDataDDE.QuotesTable[j].expiration_date;
									SmilePaper1.base_asset = ClassDataDDE.QuotesTable[j].base_asset;
									SmilePaper1.step_price = ClassDataDDE.QuotesTable[j].step_price;
									SmilePaper1.volatilityModelSmile = 0.0;
									SmileTable1.Add(SmilePaper1.strike, SmilePaper1);
								}
							}
							else
							{
								SmilePaper1.paper_code_put = ClassDataDDE.QuotesTable[j].paper_code;
								SmilePaper1.option_type_put = "Put";
								SmilePaper1.demand_put = ClassDataDDE.QuotesTable[j].demand;
								SmilePaper1.sentence_put = ClassDataDDE.QuotesTable[j].sentence;
								SmilePaper1.last_price_put = ClassDataDDE.QuotesTable[j].last_price;
								SmilePaper1.teoretical_price_put = ClassDataDDE.QuotesTable[j].teoretical_price;
								SmilePaper1.strike = ClassDataDDE.QuotesTable[j].strike;
								SmilePaper1.volatility = ClassDataDDE.QuotesTable[j].volatility;
								SmilePaper1.expiration_date = ClassDataDDE.QuotesTable[j].expiration_date;
								SmilePaper1.base_asset = ClassDataDDE.QuotesTable[j].base_asset;
								SmilePaper1.step_price = ClassDataDDE.QuotesTable[j].step_price;
								SmilePaper1.volatilityModelSmile = 0.0;
								SmileTable1.Add(SmilePaper1.strike, SmilePaper1);
							}
						}
					}
				}
			}
			if (FuturePaper1.F && SmileTable1.Count >= 1)
			{
				for (int m = 0; m < SmileTable1.Count - 1; m++)
				{
					if (m == 0)
					{
						f_FutLastPrice = SmileTable1.Values[m].strike;
						f_Volatility = ((!checkBoxModelVolatility.Checked) ? SmileTable1.Values[m].volatility : ModelVolatility);
						num = Math.Abs(f_FutLastPrice - FuturePaper1.last_price);
					}
					else if (Math.Abs(SmileTable1.Values[m].strike - FuturePaper1.last_price) < num)
					{
						f_FutLastPrice = SmileTable1.Values[m].strike;
						f_Volatility = ((!checkBoxModelVolatility.Checked) ? SmileTable1.Values[m].volatility : ModelVolatility);
						num = Math.Abs(f_FutLastPrice - FuturePaper1.last_price);
					}
				}
			}
			if (FuturePaper1.F && SmileTable1.Count >= 2)
			{
				SortedList<double, double> vols = new SortedList<double, double>();
				if (checkBoxModelSmile.Checked && ModelSmileSkew != 0.0 && ModelSmileKink != 0.0)
				{
					for (int n = 0; n < SmileTable1.Count - 1; n++)
					{
						SmilePaper1 = SmileTable1.Values[n];
						vols.Add(SmilePaper1.strike, CalculationVolatilityModelSmile(SmilePaper1.base_asset, f_Volatility, SmilePaper1.strike, f_FutLastPrice, SmilePaper1.expiration_date, ModelSmileSkew, ModelSmileKink, FuturePaper1.last_price));
					}
					SmileTablePrev = vols;
					for (int num2 = 0; num2 < SmileTable1.Count - 1; num2++)
					{
						SmilePaper1 = SmileTable1.Values[num2];
						double current_vol;
						if (vols.TryGetValue(SmilePaper1.strike, out current_vol))
						{
							SmilePaper1.volatilityModelSmile = current_vol;
							SmileTable1.RemoveAt(num2);
							SmileTable1.Add(SmilePaper1.strike, SmilePaper1);
						}
					}
				}
			}
			if (!checkBoxModelVolatility.Checked)
			{
				numericUpDownModelSmileVolatility.Value = Convert.ToDecimal(f_Volatility);
				ModelCurrentStrike = f_FutLastPrice;
			}
			else
			{
				ModelCurrentStrike = f_FutLastPrice;
			}
			SmileTable1 = SmileTable3;
			if (!FuturePaper2.F)
			{
				return;
			}
			lock (ClassDataDDE.QuotesTable)
			{
				for (int num3 = 0; num3 < ClassDataDDE.QuotesTable.Count; num3++)
				{
					if (!DateTime.TryParse(Convert.ToString(comboBoxExpirationDate2.Text), out result))
					{
						FuturePaper2.F = false;
						break;
					}
					if (!(Convert.ToString(comboBoxBaseAsset2.Text) == ClassDataDDE.QuotesTable[num3].base_asset) || !(result.Date == ClassDataDDE.QuotesTable[num3].expiration_date.Date))
					{
						continue;
					}
					if (ClassDataDDE.QuotesTable[num3].option_type == "Call")
					{
						if (SmileTable2.Count > 0)
						{
							bool flag3 = false;
							for (int num4 = 0; num4 < SmileTable2.Count; num4++)
							{
								if (SmileTable2.Values[num4].strike == ClassDataDDE.QuotesTable[num3].strike)
								{
									SmilePaper2 = SmileTable2.Values[num4];
									SmilePaper2.paper_code_call = ClassDataDDE.QuotesTable[num3].paper_code;
									SmilePaper2.option_type_call = "Call";
									SmilePaper2.demand_call = ClassDataDDE.QuotesTable[num3].demand;
									SmilePaper2.sentence_call = ClassDataDDE.QuotesTable[num3].sentence;
									SmilePaper2.last_price_call = ClassDataDDE.QuotesTable[num3].last_price;
									SmilePaper2.teoretical_price_call = ClassDataDDE.QuotesTable[num3].teoretical_price;
									SmilePaper2.strike = ClassDataDDE.QuotesTable[num3].strike;
									SmilePaper2.volatility = ClassDataDDE.QuotesTable[num3].volatility;
									SmilePaper2.expiration_date = ClassDataDDE.QuotesTable[num3].expiration_date;
									SmilePaper2.base_asset = ClassDataDDE.QuotesTable[num3].base_asset;
									SmilePaper2.step_price = ClassDataDDE.QuotesTable[num3].step_price;
									SmileTable2.RemoveAt(num4);
									SmileTable2.Add(SmilePaper2.strike, SmilePaper2);
									flag3 = true;
									break;
								}
							}
							if (!flag3)
							{
								SmilePaper2.paper_code_call = ClassDataDDE.QuotesTable[num3].paper_code;
								SmilePaper2.option_type_call = "Call";
								SmilePaper2.demand_call = ClassDataDDE.QuotesTable[num3].demand;
								SmilePaper2.sentence_call = ClassDataDDE.QuotesTable[num3].sentence;
								SmilePaper2.last_price_call = ClassDataDDE.QuotesTable[num3].last_price;
								SmilePaper2.teoretical_price_call = ClassDataDDE.QuotesTable[num3].teoretical_price;
								SmilePaper2.strike = ClassDataDDE.QuotesTable[num3].strike;
								SmilePaper2.volatility = ClassDataDDE.QuotesTable[num3].volatility;
								SmilePaper2.expiration_date = ClassDataDDE.QuotesTable[num3].expiration_date;
								SmilePaper2.base_asset = ClassDataDDE.QuotesTable[num3].base_asset;
								SmilePaper2.step_price = ClassDataDDE.QuotesTable[num3].step_price;
								SmileTable2.Add(SmilePaper2.strike, SmilePaper2);
							}
						}
						else
						{
							SmilePaper2.paper_code_call = ClassDataDDE.QuotesTable[num3].paper_code;
							SmilePaper2.option_type_call = "Call";
							SmilePaper2.demand_call = ClassDataDDE.QuotesTable[num3].demand;
							SmilePaper2.sentence_call = ClassDataDDE.QuotesTable[num3].sentence;
							SmilePaper2.last_price_call = ClassDataDDE.QuotesTable[num3].last_price;
							SmilePaper2.teoretical_price_call = ClassDataDDE.QuotesTable[num3].teoretical_price;
							SmilePaper2.strike = ClassDataDDE.QuotesTable[num3].strike;
							SmilePaper2.volatility = ClassDataDDE.QuotesTable[num3].volatility;
							SmilePaper2.expiration_date = ClassDataDDE.QuotesTable[num3].expiration_date;
							SmilePaper2.base_asset = ClassDataDDE.QuotesTable[num3].base_asset;
							SmilePaper2.step_price = ClassDataDDE.QuotesTable[num3].step_price;
							SmileTable2.Add(SmilePaper2.strike, SmilePaper2);
						}
					}
					else
					{
						if (!(ClassDataDDE.QuotesTable[num3].option_type == "Put"))
						{
							continue;
						}
						if (SmileTable2.Count > 0)
						{
							bool flag4 = false;
							for (int num5 = 0; num5 < SmileTable2.Count; num5++)
							{
								if (SmileTable2.Values[num5].strike == ClassDataDDE.QuotesTable[num3].strike)
								{
									SmilePaper2 = SmileTable2.Values[num5];
									SmilePaper2.paper_code_put = ClassDataDDE.QuotesTable[num3].paper_code;
									SmilePaper2.option_type_put = "Put";
									SmilePaper2.demand_put = ClassDataDDE.QuotesTable[num3].demand;
									SmilePaper2.sentence_put = ClassDataDDE.QuotesTable[num3].sentence;
									SmilePaper2.last_price_put = ClassDataDDE.QuotesTable[num3].last_price;
									SmilePaper2.teoretical_price_put = ClassDataDDE.QuotesTable[num3].teoretical_price;
									SmilePaper2.strike = ClassDataDDE.QuotesTable[num3].strike;
									SmilePaper2.volatility = ClassDataDDE.QuotesTable[num3].volatility;
									SmilePaper2.expiration_date = ClassDataDDE.QuotesTable[num3].expiration_date;
									SmilePaper2.base_asset = ClassDataDDE.QuotesTable[num3].base_asset;
									SmilePaper2.step_price = ClassDataDDE.QuotesTable[num3].step_price;
									SmileTable2.RemoveAt(num5);
									SmileTable2.Add(SmilePaper2.strike, SmilePaper2);
									flag4 = true;
									break;
								}
							}
							if (!flag4)
							{
								SmilePaper2.paper_code_put = ClassDataDDE.QuotesTable[num3].paper_code;
								SmilePaper2.option_type_put = "Put";
								SmilePaper2.demand_put = ClassDataDDE.QuotesTable[num3].demand;
								SmilePaper2.sentence_put = ClassDataDDE.QuotesTable[num3].sentence;
								SmilePaper2.last_price_put = ClassDataDDE.QuotesTable[num3].last_price;
								SmilePaper2.teoretical_price_put = ClassDataDDE.QuotesTable[num3].teoretical_price;
								SmilePaper2.strike = ClassDataDDE.QuotesTable[num3].strike;
								SmilePaper2.volatility = ClassDataDDE.QuotesTable[num3].volatility;
								SmilePaper2.expiration_date = ClassDataDDE.QuotesTable[num3].expiration_date;
								SmilePaper2.base_asset = ClassDataDDE.QuotesTable[num3].base_asset;
								SmilePaper2.step_price = ClassDataDDE.QuotesTable[num3].step_price;
								SmileTable2.Add(SmilePaper2.strike, SmilePaper2);
							}
						}
						else
						{
							SmilePaper2.paper_code_put = ClassDataDDE.QuotesTable[num3].paper_code;
							SmilePaper2.option_type_put = "Put";
							SmilePaper2.demand_put = ClassDataDDE.QuotesTable[num3].demand;
							SmilePaper2.sentence_put = ClassDataDDE.QuotesTable[num3].sentence;
							SmilePaper2.last_price_put = ClassDataDDE.QuotesTable[num3].last_price;
							SmilePaper2.teoretical_price_put = ClassDataDDE.QuotesTable[num3].teoretical_price;
							SmilePaper2.strike = ClassDataDDE.QuotesTable[num3].strike;
							SmilePaper2.volatility = ClassDataDDE.QuotesTable[num3].volatility;
							SmilePaper2.expiration_date = ClassDataDDE.QuotesTable[num3].expiration_date;
							SmilePaper2.base_asset = ClassDataDDE.QuotesTable[num3].base_asset;
							SmilePaper2.step_price = ClassDataDDE.QuotesTable[num3].step_price;
							SmileTable2.Add(SmilePaper2.strike, SmilePaper2);
						}
					}
				}
			}
		}

		public double GetCentralStrikeVol(string futures, double last_price, DateTime expiration_date)
		{
			double strike_step = 250.0;
			if (futures.StartsWith("RI"))
			{
				strike_step = 2500.0;
			}
			else if (futures.StartsWith("BR"))
			{
				strike_step = 1.0;
			}
			else if (futures.StartsWith("CR"))
			{
				strike_step = 0.25;
			}
			double num1 = last_price % strike_step;
			double central_strike = last_price;
			central_strike = ((!(strike_step - num1 > strike_step / 2.0)) ? (last_price + strike_step - num1) : (last_price - num1));
			SmileTotal optionQuote;
			if (SmileTable1.TryGetValue(central_strike, out optionQuote))
			{
				return (optionQuote.volatilityModelSmile > 0.0) ? optionQuote.volatilityModelSmile : optionQuote.volatility;
			}
			return 0.0;
		}

		private double CalculationVolatilityModelSmile(string base_asset, double f_Volatility, double f_strike, double f_FutLastPrice, DateTime expiration_date, double f_Skew, double f_Kink, double f_indicativePrice = 0.0)
		{
			double num1 = 0.0;
			if ((FormPortfolio.AbsWhatIf && DateTime.Now < expiration_date) || (!FormPortfolio.AbsWhatIf && DateTime.Now.AddDays(PortfolioD) < expiration_date))
			{
				double d;
				double p;
				double v;
				if (FormPortfolio.AbsWhatIf && (PortfolioV > 0.0 || PortfolioP > 0.0))
				{
					d = ((PortfolioD > 0.0) ? f_CalculationT(expiration_date.AddDays(0.0 - PortfolioD), expiration_date) : f_CalculationT(DateTime.Now.AddDays(PortfolioD), expiration_date));
					if (f_indicativePrice == 0.0)
					{
						f_indicativePrice = f_FutLastPrice;
					}
					p = ((PortfolioP > 0.0 && f_indicativePrice / PortfolioP < 10.0) ? PortfolioP : f_indicativePrice);
					double vol_center = GetCentralStrikeVol(base_asset, f_indicativePrice, expiration_date);
					if (PortfolioV > 0.0 && f_Volatility / PortfolioV <= 3.0)
					{
						v = PortfolioV - vol_center;
						if (PortfolioP > 0.0 && f_indicativePrice / PortfolioP < 10.0 && PortfolioP != f_indicativePrice)
						{
							double vol_center_2 = GetCentralStrikeVol(base_asset, PortfolioP, expiration_date);
						}
						v = f_Volatility + v;
					}
					else
					{
						v = f_Volatility;
					}
				}
				else
				{
					d = f_CalculationT(DateTime.Now.AddDays(PortfolioD), expiration_date);
					p = f_FutLastPrice + PortfolioP;
					v = f_Volatility + PortfolioV;
				}
				double num2 = Math.Log(f_strike / p) / (v / 100.0 * Math.Sqrt(d));
				num1 = 100.0 * (v / 100.0) * (1.0 + f_Skew * num2 / 6.0 + f_Kink * num2 * num2 / 24.0);
			}
			return num1;
		}

		private double f_CalculationT(DateTime f_Date, DateTime f_Exp)
		{
			DateTime dateTime1 = new DateTime(f_Exp.Year, 1, 1, 0, 0, 0);
			DateTime dateTime2 = new DateTime(f_Exp.Year, 12, 31, 23, 59, 59);
			return (double)(int)(f_Exp - f_Date).TotalSeconds / (double)(int)(dateTime2 - dateTime1).TotalSeconds;
		}

		public void DrawSmile()
		{
			double num1 = 0.0;
			double num2 = 0.0;
			double num3 = 0.0;
			double num4 = 0.0;
			double num5 = 0.0;
			double num6 = 0.0;
			double result1 = 0.0;
			double val1_1 = 0.0;
			double val1_2 = 0.0;
			double result2 = 0.0;
			double result3 = 0.0;
			double num7 = 0.0;
			double num8 = 0.0;
			double val1_3 = 0.0;
			double val1_4 = 0.0;
			if (!double.TryParse(textBoxStepGridY.Text, out result1))
			{
				result1 = 10000.0;
			}
			if (!double.TryParse(textBoxIndentDn.Text, out result2))
			{
				result2 = 30.0;
			}
			if (!double.TryParse(textBoxIndentUp.Text, out result3))
			{
				result3 = 30.0;
			}
			double num9;
			double num10;
			double iStepStrike;
			if (FuturePaper1.F)
			{
				num9 = cCalculationOptions.RoundStepPriceFloor(FuturePaper1.last_price * result3 / 100.0, FuturePaper1.step_price);
				num10 = cCalculationOptions.RoundStepPriceFloor(FuturePaper1.last_price * result2 / 100.0, FuturePaper1.step_price);
				if (!cDataDDE.StepStrike(Convert.ToString(FuturePaper1.paper_code)))
				{
					return;
				}
				iStepStrike = ClassDataDDE.iStepStrike;
				textBoxStepGridX.Text = Convert.ToString(iStepStrike);
			}
			else
			{
				if (!FuturePaper2.F)
				{
					return;
				}
				num9 = cCalculationOptions.RoundStepPriceFloor(FuturePaper2.last_price * result3 / 100.0, FuturePaper2.step_price);
				num10 = cCalculationOptions.RoundStepPriceFloor(FuturePaper2.last_price * result2 / 100.0, FuturePaper2.step_price);
				if (!cDataDDE.StepStrike(Convert.ToString(FuturePaper2.paper_code)))
				{
					return;
				}
				iStepStrike = ClassDataDDE.iStepStrike;
				textBoxStepGridX.Text = Convert.ToString(iStepStrike);
			}
			chart1.Series["Инструмент 1"].Points.Clear();
			chart1.Series["Инструмент 2"].Points.Clear();
			chart1.Series["Инструмент 3"].Points.Clear();
			chart1.Series["Тек. цена"].Points.Clear();
			chart1.Series["Спрос инструмент 1"].Points.Clear();
			chart1.Series["Предложение инструмент 1"].Points.Clear();
			chart1.Series["Спрос инструмент 2"].Points.Clear();
			chart1.Series["Предложение инструмент 2"].Points.Clear();
			chart1.Series["AvSmile"].Points.Clear();
			chart1.Series["Модель"].Points.Clear();
			chart1.Series["Тек. цена модель"].Points.Clear();
			chart2.Series["Раздвижка"].Points.Clear();
			chart2.Series["РаздвижкаИстория"].Points.Clear();
			chart2.Series["Тек. цена"].Points.Clear();
			double num11;
			double num12;
			if (FuturePaper1.F)
			{
				num11 = cCalculationOptions.RoundStepPriceFloor(FuturePaper1.last_price - num10, iStepStrike);
				num12 = cCalculationOptions.RoundStepPriceFloor(FuturePaper1.last_price + num9, iStepStrike);
			}
			else
			{
				if (!FuturePaper2.F)
				{
					return;
				}
				num11 = cCalculationOptions.RoundStepPriceFloor(FuturePaper2.last_price - num10, iStepStrike);
				num12 = cCalculationOptions.RoundStepPriceFloor(FuturePaper2.last_price + num9, iStepStrike);
			}
			double num13 = num11;
			double num14 = num12;
			chart1.ChartAreas[0].AxisX.Minimum = num11;
			chart1.ChartAreas[0].AxisX.Maximum = num12;
			chart2.ChartAreas[0].AxisX.Minimum = num13;
			chart2.ChartAreas[0].AxisX.Maximum = num14;
			for (int index = 0; index < SmileTable1.Count; index++)
			{
				if (!(SmileTable1.Values[index].strike >= num11) || !(SmileTable1.Values[index].strike <= num12))
				{
					continue;
				}
				if (val1_1 == 0.0 && val1_2 == 0.0)
				{
					val1_1 = SmileTable1.Values[index].volatility;
					val1_2 = SmileTable1.Values[index].volatility;
					if (comboBoxHistory.Text != "NULL" && comboBoxHistory.Text != "" && cHistoryDataDDE.SearchPaper(SmileTable1.Values[index].expiration_date, SmileTable1.Values[index].base_asset, SmileTable1.Values[index].strike, SmileTable1.Values[index].option_type_call))
					{
						double volatility = ClassHistoryDataDDE.QuotesPaper.volatility;
						val1_1 = Math.Min(val1_1, volatility);
						val1_2 = Math.Max(val1_2, volatility);
					}
					if (checkBoxModelSmile.Checked && SmileTable1.Values[index].volatilityModelSmile > 0.0)
					{
						val1_1 = Math.Min(val1_1, SmileTable1.Values[index].volatilityModelSmile);
						val1_2 = Math.Max(val1_2, SmileTable1.Values[index].volatilityModelSmile);
					}
				}
				else
				{
					val1_1 = Math.Min(val1_1, SmileTable1.Values[index].volatility);
					val1_2 = Math.Max(val1_2, SmileTable1.Values[index].volatility);
					if (comboBoxHistory.Text != "NULL" && comboBoxHistory.Text != "" && cHistoryDataDDE.SearchPaper(SmileTable1.Values[index].expiration_date, SmileTable1.Values[index].base_asset, SmileTable1.Values[index].strike, SmileTable1.Values[index].option_type_call))
					{
						double volatility2 = ClassHistoryDataDDE.QuotesPaper.volatility;
						val1_1 = Math.Min(val1_1, volatility2);
						val1_2 = Math.Max(val1_2, volatility2);
					}
					if (checkBoxModelSmile.Checked && SmileTable1.Values[index].volatilityModelSmile > 0.0)
					{
						val1_1 = Math.Min(val1_1, SmileTable1.Values[index].volatilityModelSmile);
						val1_2 = Math.Max(val1_2, SmileTable1.Values[index].volatilityModelSmile);
					}
				}
			}
			for (int i = 0; i < SmileTable2.Count; i++)
			{
				if (SmileTable2.Values[i].strike >= num11 && SmileTable2.Values[i].strike <= num12)
				{
					if (val1_1 == 0.0 && val1_2 == 0.0)
					{
						val1_1 = SmileTable2.Values[i].volatility;
						val1_2 = SmileTable2.Values[i].volatility;
					}
					else
					{
						val1_1 = Math.Min(val1_1, SmileTable2.Values[i].volatility);
						val1_2 = Math.Max(val1_2, SmileTable2.Values[i].volatility);
					}
				}
			}
			double yValue1 = cCalculationOptions.RoundStepPriceFloor(val1_1 - Math.Abs(val1_2 - val1_1) * 0.05, result1);
			double yValue2 = cCalculationOptions.RoundStepPriceCeiling(val1_2 + Math.Abs(val1_2 - yValue1) * 0.05, result1);
			chart1.ChartAreas[0].AxisX.Interval = iStepStrike;
			chart1.ChartAreas[0].AxisX.MajorGrid.Interval = iStepStrike;
			chart1.ChartAreas[0].AxisX.MajorGrid.LineWidth = 1;
			chart1.ChartAreas[0].AxisX.MajorGrid.LineDashStyle = ChartDashStyle.Dash;
			chart1.ChartAreas[0].AxisY.Interval = result1;
			chart1.ChartAreas[0].AxisY.Minimum = yValue1;
			chart1.ChartAreas[0].AxisY.Maximum = yValue2;
			chart1.ChartAreas[0].AxisY.MajorGrid.Interval = result1;
			chart1.ChartAreas[0].AxisY.MajorGrid.LineWidth = 1;
			chart1.ChartAreas[0].AxisY.MajorGrid.LineDashStyle = ChartDashStyle.Dash;
			chart1.Series["Тек. цена"].Color = Color.SlateGray;
			chart1.Series["Тек. цена"].BorderWidth = 1;
			chart2.Series["Тек. цена"].Color = Color.SlateGray;
			chart2.Series["Тек. цена"].BorderWidth = 1;
			if (FuturePaper1.F)
			{
				for (int j = 0; j < SmileTable1.Count && !(SmileTable1.Values[j].base_asset == ""); j++)
				{
					chart1.Series["Инструмент 1"].Enabled = true;
					chart1.Series["Инструмент 1"].Points.AddXY(SmileTable1.Values[j].strike, SmileTable1.Values[j].volatility);
					chart1.Series["Модель"].Enabled = true;
					chart1.Series["Модель"].Points.AddXY(SmileTable1.Values[j].strike, SmileTable1.Values[j].volatilityModelSmile);
					if (comboBoxDemandSentence1.Text != "NULL")
					{
						double yValue3 = CalculationVolaSmile1(j, "Demand");
						chart1.Series["Спрос инструмент 1"].Enabled = true;
						chart1.Series["Спрос инструмент 1"].Points.AddXY(SmileTable1.Values[j].strike, yValue3);
					}
					else
					{
						chart1.Series["Спрос инструмент 1"].Enabled = false;
					}
					if (comboBoxDemandSentence1.Text != "NULL")
					{
						double yValue4 = CalculationVolaSmile1(j, "Sentence");
						chart1.Series["Предложение инструмент 1"].Enabled = true;
						chart1.Series["Предложение инструмент 1"].Points.AddXY(SmileTable1.Values[j].strike, yValue4);
					}
					else
					{
						chart1.Series["Предложение инструмент 1"].Enabled = false;
					}
					if (comboBoxHistory.Text != "NULL" && comboBoxHistory.Text != "")
					{
						if (cHistoryDataDDE.SearchPaper(SmileTable1.Values[j].expiration_date, SmileTable1.Values[j].base_asset, SmileTable1.Values[j].strike, SmileTable1.Values[j].option_type_call))
						{
							double volatility3 = ClassHistoryDataDDE.QuotesPaper.volatility;
							chart1.Series["Инструмент 3"].Enabled = true;
							chart1.Series["Инструмент 3"].Points.AddXY(SmileTable1.Values[j].strike, volatility3);
						}
					}
					else
					{
						chart1.Series["Инструмент 3"].Enabled = false;
					}
				}
			}
			else
			{
				chart1.Series["Инструмент 1"].Enabled = false;
				chart1.Series["Инструмент 3"].Enabled = false;
				chart1.Series["Спрос инструмент 1"].Enabled = false;
				chart1.Series["Предложение инструмент 1"].Enabled = false;
				chart1.Series["AvSmile"].Enabled = false;
				chart1.Series["Модель"].Enabled = false;
				chart1.Series["Тек. цена модель"].Enabled = false;
			}
			if (FuturePaper2.F)
			{
				for (int k = 0; k < SmileTable2.Count && !(SmileTable2.Values[k].base_asset == ""); k++)
				{
					chart1.Series["Инструмент 2"].Enabled = true;
					chart1.Series["Инструмент 2"].Points.AddXY(SmileTable2.Values[k].strike, SmileTable2.Values[k].volatility);
					if (comboBoxDemandSentence2.Text != "NULL")
					{
						double yValue5 = CalculationVolaSmile2(k, "Demand");
						chart1.Series["Спрос инструмент 2"].Enabled = true;
						chart1.Series["Спрос инструмент 2"].Points.AddXY(SmileTable2.Values[k].strike, yValue5);
					}
					else
					{
						chart1.Series["Спрос инструмент 2"].Enabled = false;
					}
					if (comboBoxDemandSentence2.Text != "NULL")
					{
						double yValue6 = CalculationVolaSmile2(k, "Sentence");
						chart1.Series["Предложение инструмент 2"].Enabled = true;
						chart1.Series["Предложение инструмент 2"].Points.AddXY(SmileTable2.Values[k].strike, yValue6);
					}
					else
					{
						chart1.Series["Предложение инструмент 2"].Enabled = false;
					}
				}
			}
			else
			{
				chart1.Series["Инструмент 2"].Enabled = false;
				chart1.Series["Спрос инструмент 2"].Enabled = false;
				chart1.Series["Предложение инструмент 2"].Enabled = false;
			}
			if (FuturePaper1.F)
			{
				chart1.Series["Тек. цена"].Enabled = true;
				chart1.Series["Тек. цена"].Points.AddXY(FuturePaper1.last_price, yValue1);
				chart1.Series["Тек. цена"].Points.AddXY(FuturePaper1.last_price, yValue2);
				if (checkBoxModelSmile.Checked && PortfolioP != 0.0)
				{
					chart1.Series["Тек. цена модель"].Enabled = true;
					double p = ((!FormPortfolio.AbsWhatIf) ? (FuturePaper1.last_price + PortfolioP) : ((PortfolioP > 0.0) ? PortfolioP : FuturePaper1.last_price));
					chart1.Series["Тек. цена модель"].Points.AddXY(p, yValue1);
					chart1.Series["Тек. цена модель"].Points.AddXY(p, yValue2);
				}
				else
				{
					chart1.Series["Тек. цена модель"].Enabled = false;
				}
			}
			else if (FuturePaper2.F)
			{
				chart1.Series["Тек. цена"].Enabled = true;
				chart1.Series["Тек. цена"].Points.AddXY(FuturePaper2.last_price, yValue1);
				chart1.Series["Тек. цена"].Points.AddXY(FuturePaper2.last_price, yValue2);
			}
			else
			{
				chart1.Series["Тек. цена"].Enabled = false;
			}
			if (FuturePaper1.F && FuturePaper2.F)
			{
				chart2.Series["Раздвижка"].Enabled = true;
				bool flag = true;
				for (int l = 0; l < SmileTable1.Count && !(SmileTable1.Values[l].base_asset == ""); l++)
				{
					if (!(SmileTable1.Values[l].strike >= num13) || !(SmileTable1.Values[l].strike <= num14) || !(SmileTable1.Values[l].volatility > 0.0))
					{
						continue;
					}
					for (int m = 0; m < SmileTable2.Count; m++)
					{
						if (SmileTable1.Values[l].strike == SmileTable2.Values[m].strike && SmileTable2.Values[m].volatility > 0.0)
						{
							if (flag)
							{
								num7 = SmileTable1.Values[l].volatility - SmileTable2.Values[m].volatility;
								num8 = SmileTable1.Values[l].volatility - SmileTable2.Values[m].volatility;
								flag = false;
							}
							else
							{
								num7 = Math.Min(num7, SmileTable1.Values[l].volatility - SmileTable2.Values[m].volatility);
								num8 = Math.Max(num8, SmileTable1.Values[l].volatility - SmileTable2.Values[m].volatility);
							}
							chart2.Series["Раздвижка"].Points.AddXY(SmileTable1.Values[l].strike, SmileTable1.Values[l].volatility - SmileTable2.Values[m].volatility);
						}
					}
				}
				num7 = cCalculationOptions.RoundStepPriceFloor(num7 - Math.Abs(num8 - num7) * 0.05, result1);
				num8 = cCalculationOptions.RoundStepPriceCeiling(num8 + Math.Abs(num8 - num7) * 0.05, result1);
			}
			else
			{
				chart2.Series["Раздвижка"].Enabled = false;
			}
			if (FuturePaper1.F && comboBoxHistory.Text != "NULL" && comboBoxHistory.Text != "")
			{
				chart2.Series["РаздвижкаИстория"].Enabled = true;
				bool flag2 = true;
				for (int n = 0; n < SmileTable1.Count && !(SmileTable1.Values[n].base_asset == ""); n++)
				{
					if (!(SmileTable1.Values[n].strike >= num13) || !(SmileTable1.Values[n].strike <= num14) || !(SmileTable1.Values[n].volatility > 0.0))
					{
						continue;
					}
					if (comboBoxHistory.Text != "NULL" && comboBoxHistory.Text != "")
					{
						if (cHistoryDataDDE.SearchPaper(SmileTable1.Values[n].expiration_date, SmileTable1.Values[n].base_asset, SmileTable1.Values[n].strike, SmileTable1.Values[n].option_type_call))
						{
							double volatility4 = ClassHistoryDataDDE.QuotesPaper.volatility;
							if (flag2)
							{
								val1_3 = SmileTable1.Values[n].volatility - volatility4;
								val1_4 = SmileTable1.Values[n].volatility - volatility4;
								flag2 = false;
							}
							else
							{
								val1_3 = Math.Min(val1_3, SmileTable1.Values[n].volatility - volatility4);
								val1_4 = Math.Max(val1_4, SmileTable1.Values[n].volatility - volatility4);
							}
							chart2.Series["РаздвижкаИстория"].Enabled = true;
							chart2.Series["РаздвижкаИстория"].Points.AddXY(SmileTable1.Values[n].strike, SmileTable1.Values[n].volatility - volatility4);
						}
						continue;
					}
					chart2.Series["РаздвижкаИстория"].Enabled = false;
					break;
				}
			}
			else
			{
				chart2.Series["РаздвижкаИстория"].Enabled = false;
			}
			double num15 = Math.Min(val1_3, num7);
			double num16 = Math.Max(val1_4, num8);
			double yValue7 = cCalculationOptions.RoundStepPriceFloor(num15 - Math.Abs(num16 - num15) * 0.05, result1);
			double yValue8 = cCalculationOptions.RoundStepPriceCeiling(num16 + Math.Abs(num16 - yValue7) * 0.05, result1);
			if ((FuturePaper1.F && FuturePaper2.F) || (FuturePaper1.F && comboBoxHistory.Text != "NULL" && comboBoxHistory.Text != ""))
			{
				chart2.Series["Тек. цена"].Enabled = true;
				chart2.Series["Тек. цена"].Points.AddXY(FuturePaper1.last_price, yValue7);
				chart2.Series["Тек. цена"].Points.AddXY(FuturePaper1.last_price, yValue8);
			}
			else
			{
				chart2.Series["Тек. цена"].Enabled = false;
			}
			chart2.ChartAreas[0].AxisX.Interval = iStepStrike;
			chart2.ChartAreas[0].AxisX.MajorGrid.Interval = iStepStrike;
			chart2.ChartAreas[0].AxisX.MajorGrid.LineWidth = 1;
			chart2.ChartAreas[0].AxisX.MajorGrid.LineDashStyle = ChartDashStyle.Dash;
			chart2.ChartAreas[0].AxisY.Interval = result1;
			chart2.ChartAreas[0].AxisY.Minimum = yValue7;
			chart2.ChartAreas[0].AxisY.Maximum = yValue8;
			chart2.ChartAreas[0].AxisY.MajorGrid.Interval = result1;
			chart2.ChartAreas[0].AxisY.MajorGrid.LineWidth = 1;
			chart2.ChartAreas[0].AxisY.MajorGrid.LineDashStyle = ChartDashStyle.Dash;
			chart2.ChartAreas[0].AxisX.ArrowStyle = AxisArrowStyle.None;
			chart2.ChartAreas[0].AxisY.Crossing = 0.0;
			if (FuturePaper1.F && FuturePaper2.F && FuturePaper1.F && comboBoxHistory.Text != "NULL" && comboBoxHistory.Text != "")
			{
				chart2.Titles[0].Text = "Спред: (Инструмент 1) - (Инструмент 2)\nСпред: (Инструмент 1) - (История)";
			}
			else if (FuturePaper1.F && FuturePaper2.F)
			{
				chart2.Titles[0].Text = "Спред: (Инструмент 1) - (Инструмент 2)";
			}
			else if (FuturePaper1.F && comboBoxHistory.Text != "NULL" && comboBoxHistory.Text != "")
			{
				chart2.Titles[0].Text = "Спред: (Инструмент 1) - (История)";
			}
			double num17 = -1.0;
			double num18 = -1.0;
			if (FuturePaper1.F && SmileTable1.Count >= 2)
			{
				if (cDataDDE.SearchPaper(SmileTable1.Values[0].base_asset))
				{
					cCalculationOptions.LastF = ClassDataDDE.QuotesPaper.last_price;
				}
				for (int num19 = 0; num19 < SmileTable1.Count - 1; num19++)
				{
					if (num19 == 0)
					{
						double strike = SmileTable1.Values[num19].strike;
						num4 = SmileTable1.Values[num19].volatility;
						num18 = Math.Abs(strike - cCalculationOptions.LastF);
					}
					else if (Math.Abs(SmileTable1.Values[num19].strike - cCalculationOptions.LastF) < num18)
					{
						double strike2 = SmileTable1.Values[num19].strike;
						num4 = SmileTable1.Values[num19].volatility;
						num18 = Math.Abs(strike2 - cCalculationOptions.LastF);
					}
				}
			}
			num17 = -1.0;
			double num20 = -1.0;
			if (FuturePaper1.F && SmileTable1.Count >= 2)
			{
				cCalculationOptions.TypeO = SmileTable1.Values[0].option_type_put;
				cCalculationOptions.DateExp = SmileTable1.Values[0].expiration_date;
				cCalculationOptions.DateCurrent = DateTime.Now;
				cCalculationOptions.Q = Convert.ToInt32(1);
				if (cDataDDE.SearchPaper(SmileTable1.Values[0].base_asset))
				{
					cCalculationOptions.LastF = ClassDataDDE.QuotesPaper.last_price;
				}
				for (int num21 = 0; num21 < SmileTable1.Count - 1; num21++)
				{
					cCalculationOptions.Strike = SmileTable1.Values[num21].strike;
					cCalculationOptions.VolaO = SmileTable1.Values[num21].volatility;
					if (cCalculationOptions.CalculationOpt())
					{
						num2 = Math.Round(cCalculationOptions.calcDelta, 3);
						num5 = SmileTable1.Values[num21].strike;
						num17 = Math.Abs(-0.1 - num2);
					}
					cCalculationOptions.Strike = SmileTable1.Values[num21 + 1].strike;
					cCalculationOptions.VolaO = SmileTable1.Values[num21 + 1].volatility;
					if (cCalculationOptions.CalculationOpt())
					{
						num3 = Math.Round(cCalculationOptions.calcDelta, 3);
						num6 = SmileTable1.Values[num21 + 1].strike;
					}
					if (!(num2 >= -0.1) || !(num3 <= -0.1) || !(num5 < num6))
					{
						continue;
					}
					double num22 = Math.Abs(-0.1 - num2);
					num1 = num2;
					double xValue = num5;
					cCalculationOptions.VolaO = SmileTable1.Values[num21].volatility;
					double num23 = cCalculationOptions.RoundStepPrice(Math.Abs(num5 - num6) / 10.0, SmileTable1.Values[num21].step_price);
					for (int num24 = 1; num24 <= 10; num24++)
					{
						cCalculationOptions.Strike = SmileTable1.Values[num21].strike + num23 * (double)num24;
						if (cCalculationOptions.CalculationOpt())
						{
							num2 = Math.Round(cCalculationOptions.calcDelta, 3);
							num5 = cCalculationOptions.Strike;
							if (Math.Abs(-0.1 - num2) < num22)
							{
								num1 = num2;
								xValue = num5;
								num22 = Math.Abs(-0.1 - num2);
							}
						}
					}
					if (num22 == -1.0)
					{
						continue;
					}
					int num25;
					if (SmileTable1.Values[0].base_asset.Length >= 4)
					{
						DateTime date1 = DateTime.Now.Date;
						DateTime date2 = SmileTable1.Values[0].expiration_date.Date;
						num25 = ((FormPortfolio.DifferenceInDays(date1, date2) > 0) ? 1 : 0);
					}
					else
					{
						num25 = 0;
					}
					if (num25 != 0)
					{
						AverageSmile cAverageSmile = this.cAverageSmile;
						string baseAsset = SmileTable1.Values[0].base_asset;
						DateTime date3 = DateTime.Now.Date;
						DateTime date4 = SmileTable1.Values[0].expiration_date.Date;
						int QDays = FormPortfolio.DifferenceInDays(date3, date4);
						double num26 = cAverageSmile.AvSmile(baseAsset, QDays, -0.1);
						double standartDeviation = this.cAverageSmile.RTSPaper.standart_deviation;
						if (num26 != 0.0)
						{
							chart1.Series["AvSmile"].Enabled = true;
							chart1.Series["AvSmile"].Points.AddXY(xValue, num4 * (1.0 - num26 / 100.0));
							chart1.Series["AvSmile"].Points.AddXY(xValue, num4 * (1.0 - (num26 + 2.0 * standartDeviation) / 100.0));
							chart1.Series["AvSmile"].Points.AddXY(xValue, num4 * (1.0 - (num26 - 2.0 * standartDeviation) / 100.0));
						}
						else
						{
							chart1.Series["AvSmile"].Enabled = true;
						}
					}
				}
			}
			num17 = -1.0;
			num20 = -1.0;
			if (FuturePaper1.F && SmileTable1.Count >= 2)
			{
				cCalculationOptions.TypeO = SmileTable1.Values[0].option_type_call;
				cCalculationOptions.DateExp = SmileTable1.Values[0].expiration_date;
				cCalculationOptions.DateCurrent = DateTime.Now;
				cCalculationOptions.Q = Convert.ToInt32(1);
				if (cDataDDE.SearchPaper(SmileTable1.Values[0].base_asset))
				{
					cCalculationOptions.LastF = ClassDataDDE.QuotesPaper.last_price;
				}
				for (int num27 = 0; num27 < SmileTable1.Count - 1; num27++)
				{
					cCalculationOptions.Strike = SmileTable1.Values[num27].strike;
					cCalculationOptions.VolaO = SmileTable1.Values[num27].volatility;
					if (cCalculationOptions.CalculationOpt())
					{
						num2 = Math.Round(cCalculationOptions.calcDelta, 3);
						num5 = SmileTable1.Values[num27].strike;
						num17 = Math.Abs(num2 - 0.25);
					}
					cCalculationOptions.Strike = SmileTable1.Values[num27 + 1].strike;
					cCalculationOptions.VolaO = SmileTable1.Values[num27 + 1].volatility;
					if (cCalculationOptions.CalculationOpt())
					{
						num3 = Math.Round(cCalculationOptions.calcDelta, 3);
						num6 = SmileTable1.Values[num27 + 1].strike;
					}
					if (!(num2 >= 0.25) || !(num3 <= 0.25) || !(num5 < num6))
					{
						continue;
					}
					double num28 = Math.Abs(num2 - 0.25);
					num1 = num2;
					double xValue2 = num5;
					cCalculationOptions.VolaO = SmileTable1.Values[num27].volatility;
					double num29 = cCalculationOptions.RoundStepPrice(Math.Abs(num5 - num6) / 10.0, SmileTable1.Values[num27].step_price);
					for (int num30 = 1; num30 <= 10; num30++)
					{
						cCalculationOptions.Strike = SmileTable1.Values[num27].strike + num29 * (double)num30;
						if (cCalculationOptions.CalculationOpt())
						{
							num2 = Math.Round(cCalculationOptions.calcDelta, 3);
							num5 = cCalculationOptions.Strike;
							if (Math.Abs(num2 - 0.25) < num28)
							{
								num1 = num2;
								xValue2 = num5;
								num28 = Math.Abs(num2 - 0.25);
							}
						}
					}
					if (num28 == -1.0)
					{
						continue;
					}
					int num31;
					if (SmileTable1.Values[0].base_asset.Length >= 4)
					{
						DateTime date5 = DateTime.Now.Date;
						DateTime date6 = SmileTable1.Values[0].expiration_date.Date;
						num31 = ((FormPortfolio.DifferenceInDays(date5, date6) > 0) ? 1 : 0);
					}
					else
					{
						num31 = 0;
					}
					if (num31 != 0)
					{
						AverageSmile cAverageSmile2 = this.cAverageSmile;
						string baseAsset2 = SmileTable1.Values[0].base_asset;
						DateTime date7 = DateTime.Now.Date;
						DateTime date8 = SmileTable1.Values[0].expiration_date.Date;
						int QDays2 = FormPortfolio.DifferenceInDays(date7, date8);
						double num32 = cAverageSmile2.AvSmile(baseAsset2, QDays2, 0.25);
						double standartDeviation2 = this.cAverageSmile.RTSPaper.standart_deviation;
						if (num32 != 0.0)
						{
							chart1.Series["AvSmile"].Enabled = true;
							chart1.Series["AvSmile"].Points.AddXY(xValue2, num4 * (1.0 - num32 / 100.0));
							chart1.Series["AvSmile"].Points.AddXY(xValue2, num4 * (1.0 - (num32 + 2.0 * standartDeviation2) / 100.0));
							chart1.Series["AvSmile"].Points.AddXY(xValue2, num4 * (1.0 - (num32 - 2.0 * standartDeviation2) / 100.0));
						}
						else
						{
							chart1.Series["AvSmile"].Enabled = true;
						}
					}
				}
			}
			num17 = -1.0;
			num20 = -1.0;
			if (!FuturePaper1.F || SmileTable1.Count < 2)
			{
				return;
			}
			cCalculationOptions.TypeO = SmileTable1.Values[0].option_type_call;
			cCalculationOptions.DateExp = SmileTable1.Values[0].expiration_date;
			cCalculationOptions.DateCurrent = DateTime.Now;
			cCalculationOptions.Q = Convert.ToInt32(1);
			if (cDataDDE.SearchPaper(SmileTable1.Values[0].base_asset))
			{
				cCalculationOptions.LastF = ClassDataDDE.QuotesPaper.last_price;
			}
			for (int num33 = 0; num33 < SmileTable1.Count - 1; num33++)
			{
				cCalculationOptions.Strike = SmileTable1.Values[num33].strike;
				cCalculationOptions.VolaO = SmileTable1.Values[num33].volatility;
				if (cCalculationOptions.CalculationOpt())
				{
					num2 = Math.Round(cCalculationOptions.calcDelta, 3);
					num5 = SmileTable1.Values[num33].strike;
					num17 = Math.Abs(num2 - 0.1);
				}
				cCalculationOptions.Strike = SmileTable1.Values[num33 + 1].strike;
				cCalculationOptions.VolaO = SmileTable1.Values[num33 + 1].volatility;
				if (cCalculationOptions.CalculationOpt())
				{
					num3 = Math.Round(cCalculationOptions.calcDelta, 3);
					num6 = SmileTable1.Values[num33 + 1].strike;
				}
				if (!(num2 >= 0.1) || !(num3 <= 0.1) || !(num5 < num6))
				{
					continue;
				}
				double num34 = Math.Abs(num2 - 0.1);
				num1 = num2;
				double xValue3 = num5;
				cCalculationOptions.VolaO = SmileTable1.Values[num33].volatility;
				double num35 = cCalculationOptions.RoundStepPrice(Math.Abs(num5 - num6) / 10.0, SmileTable1.Values[num33].step_price);
				for (int num36 = 1; num36 <= 10; num36++)
				{
					cCalculationOptions.Strike = SmileTable1.Values[num33].strike + num35 * (double)num36;
					if (cCalculationOptions.CalculationOpt())
					{
						num2 = Math.Round(cCalculationOptions.calcDelta, 3);
						num5 = cCalculationOptions.Strike;
						if (Math.Abs(num2 - 0.1) < num34)
						{
							num1 = num2;
							xValue3 = num5;
							num34 = Math.Abs(num2 - 0.1);
						}
					}
				}
				if (num34 == -1.0)
				{
					continue;
				}
				int num37;
				if (SmileTable1.Values[0].base_asset.Length >= 4)
				{
					DateTime date9 = DateTime.Now.Date;
					DateTime date10 = SmileTable1.Values[0].expiration_date.Date;
					num37 = ((FormPortfolio.DifferenceInDays(date9, date10) > 0) ? 1 : 0);
				}
				else
				{
					num37 = 0;
				}
				if (num37 != 0)
				{
					AverageSmile cAverageSmile3 = this.cAverageSmile;
					string baseAsset3 = SmileTable1.Values[0].base_asset;
					DateTime date11 = DateTime.Now.Date;
					DateTime date12 = SmileTable1.Values[0].expiration_date.Date;
					int QDays3 = FormPortfolio.DifferenceInDays(date11, date12);
					double num38 = cAverageSmile3.AvSmile(baseAsset3, QDays3, 0.1);
					double standartDeviation3 = this.cAverageSmile.RTSPaper.standart_deviation;
					if (num38 != 0.0)
					{
						chart1.Series["AvSmile"].Enabled = true;
						chart1.Series["AvSmile"].Points.AddXY(xValue3, num4 * (1.0 - num38 / 100.0));
						chart1.Series["AvSmile"].Points.AddXY(xValue3, num4 * (1.0 - (num38 + 2.0 * standartDeviation3) / 100.0));
						chart1.Series["AvSmile"].Points.AddXY(xValue3, num4 * (1.0 - (num38 - 2.0 * standartDeviation3) / 100.0));
					}
					else
					{
						chart1.Series["AvSmile"].Enabled = true;
					}
				}
			}
		}

		public void Tick()
		{
			CreateChartTable();
			DrawSmile();
		}

		public void FillcomboBoxBaseAsset1(string defaultBaseAsset)
		{
			int num = 0;
			List<string> stringList = new List<string>();
			stringList.Clear();
			comboBoxBaseAsset1.Items.Clear();
			lock (ClassDataDDE.QuotesTable)
			{
				for (int index1 = 0; index1 < ClassDataDDE.QuotesTable.Count; index1++)
				{
					bool flag = false;
					string baseAsset = ClassDataDDE.QuotesTable[index1].base_asset;
					if (baseAsset != "" && stringList.Count == 0 && Helpers.IsOption(ClassDataDDE.QuotesTable[index1].paper_code))
					{
						stringList.Add(baseAsset);
					}
					else
					{
						if (!(baseAsset != "") || !Helpers.IsOption(ClassDataDDE.QuotesTable[index1].paper_code))
						{
							continue;
						}
						for (int i = 0; i < stringList.Count; i++)
						{
							if (baseAsset == stringList[i])
							{
								flag = true;
								break;
							}
						}
						if (!flag)
						{
							stringList.Add(baseAsset);
						}
					}
				}
			}
			stringList.Add("");
			for (int j = 0; j < stringList.Count; j++)
			{
				if (stringList[j] == defaultBaseAsset)
				{
					num = j;
				}
				comboBoxBaseAsset1.Items.Add(stringList[j]);
			}
			if (stringList.Count > 0)
			{
				comboBoxBaseAsset1.SelectedIndex = num;
			}
		}

		public void FillcomboBoxBaseAsset2(string defaultBaseAsset)
		{
			int num = 0;
			List<string> stringList = new List<string>();
			stringList.Clear();
			comboBoxBaseAsset2.Items.Clear();
			lock (ClassDataDDE.QuotesTable)
			{
				for (int index1 = 0; index1 < ClassDataDDE.QuotesTable.Count; index1++)
				{
					bool flag = false;
					string baseAsset = ClassDataDDE.QuotesTable[index1].base_asset;
					if (baseAsset != "" && stringList.Count == 0 && Helpers.IsOption(ClassDataDDE.QuotesTable[index1].paper_code))
					{
						stringList.Add(baseAsset);
					}
					else
					{
						if (!(baseAsset != "") || !Helpers.IsOption(ClassDataDDE.QuotesTable[index1].paper_code))
						{
							continue;
						}
						for (int i = 0; i < stringList.Count; i++)
						{
							if (baseAsset == stringList[i])
							{
								flag = true;
								break;
							}
						}
						if (!flag)
						{
							stringList.Add(baseAsset);
						}
					}
				}
			}
			stringList.Add("");
			for (int j = 0; j < stringList.Count; j++)
			{
				if (stringList[j] == defaultBaseAsset)
				{
					num = j;
				}
				comboBoxBaseAsset2.Items.Add(stringList[j]);
			}
			if (stringList.Count > 0)
			{
				comboBoxBaseAsset2.SelectedIndex = num;
			}
		}

		public void FillcomboBoxExpirationDate1(string baseAsset, string defaultExpirationDate)
		{
			int num = 0;
			List<DateTime> dateTimeList = new List<DateTime>();
			dateTimeList.Clear();
			comboBoxExpirationDate1.Items.Clear();
			lock (ClassDataDDE.QuotesTable)
			{
				for (int index1 = 0; index1 < ClassDataDDE.QuotesTable.Count; index1++)
				{
					bool flag = false;
					DateTime expirationDate = ClassDataDDE.QuotesTable[index1].expiration_date;
					if (ClassDataDDE.QuotesTable[index1].base_asset == baseAsset && dateTimeList.Count == 0 && Helpers.IsOption(ClassDataDDE.QuotesTable[index1].paper_code))
					{
						dateTimeList.Add(expirationDate);
					}
					else
					{
						if (!(ClassDataDDE.QuotesTable[index1].base_asset == baseAsset) || !Helpers.IsOption(ClassDataDDE.QuotesTable[index1].paper_code))
						{
							continue;
						}
						for (int i = 0; i < dateTimeList.Count; i++)
						{
							if (expirationDate == dateTimeList[i])
							{
								flag = true;
								break;
							}
						}
						if (!flag)
						{
							dateTimeList.Add(expirationDate);
						}
					}
				}
			}
			for (int j = 0; j < dateTimeList.Count; j++)
			{
				if (dateTimeList[j].ToShortDateString() == defaultExpirationDate)
				{
					num = j;
				}
				ComboBox.ObjectCollection items = comboBoxExpirationDate1.Items;
				string shortDateString = dateTimeList[j].ToShortDateString();
				items.Add(shortDateString);
			}
			if (dateTimeList.Count > 0)
			{
				comboBoxExpirationDate1.SelectedIndex = num;
			}
		}

		public void FillcomboBoxExpirationDate2(string baseAsset, string defaultExpirationDate)
		{
			int num = 0;
			List<DateTime> dateTimeList = new List<DateTime>();
			dateTimeList.Clear();
			comboBoxExpirationDate2.Items.Clear();
			lock (ClassDataDDE.QuotesTable)
			{
				for (int index1 = 0; index1 < ClassDataDDE.QuotesTable.Count; index1++)
				{
					bool flag = false;
					DateTime expirationDate = ClassDataDDE.QuotesTable[index1].expiration_date;
					if (ClassDataDDE.QuotesTable[index1].base_asset == baseAsset && dateTimeList.Count == 0 && Helpers.IsOption(ClassDataDDE.QuotesTable[index1].paper_code))
					{
						dateTimeList.Add(expirationDate);
					}
					else
					{
						if (!(ClassDataDDE.QuotesTable[index1].base_asset == baseAsset) || !Helpers.IsOption(ClassDataDDE.QuotesTable[index1].paper_code))
						{
							continue;
						}
						for (int i = 0; i < dateTimeList.Count; i++)
						{
							if (expirationDate == dateTimeList[i])
							{
								flag = true;
								break;
							}
						}
						if (!flag)
						{
							dateTimeList.Add(expirationDate);
						}
					}
				}
			}
			for (int j = 0; j < dateTimeList.Count; j++)
			{
				if (dateTimeList[j].ToShortDateString() == defaultExpirationDate)
				{
					num = j;
				}
				ComboBox.ObjectCollection items = comboBoxExpirationDate2.Items;
				string shortDateString = dateTimeList[j].ToShortDateString();
				items.Add(shortDateString);
			}
			if (dateTimeList.Count > 0)
			{
				comboBoxExpirationDate2.SelectedIndex = num;
			}
		}

		public void FillcomboBoxDemandSentence1(string defaultDemandSentence)
		{
			comboBoxDemandSentence1.Items.Clear();
			comboBoxDemandSentence1.Items.Add("NULL");
			comboBoxDemandSentence1.Items.Add("PutCall");
			comboBoxDemandSentence1.Items.Add("Put");
			comboBoxDemandSentence1.Items.Add("Call");
			switch (defaultDemandSentence)
			{
			case "NULL":
				comboBoxDemandSentence1.SelectedIndex = 0;
				break;
			case "PutCall":
				comboBoxDemandSentence1.SelectedIndex = 1;
				break;
			case "Put":
				comboBoxDemandSentence1.SelectedIndex = 2;
				break;
			case "Call":
				comboBoxDemandSentence1.SelectedIndex = 3;
				break;
			default:
				comboBoxDemandSentence1.SelectedIndex = 0;
				break;
			}
		}

		public void FillcomboBoxDemandSentence2(string defaultDemandSentence)
		{
			comboBoxDemandSentence2.Items.Clear();
			comboBoxDemandSentence2.Items.Add("NULL");
			comboBoxDemandSentence2.Items.Add("PutCall");
			comboBoxDemandSentence2.Items.Add("Put");
			comboBoxDemandSentence2.Items.Add("Call");
			switch (defaultDemandSentence)
			{
			case "NULL":
				comboBoxDemandSentence2.SelectedIndex = 0;
				break;
			case "PutCall":
				comboBoxDemandSentence2.SelectedIndex = 1;
				break;
			case "Put":
				comboBoxDemandSentence2.SelectedIndex = 2;
				break;
			case "Call":
				comboBoxDemandSentence2.SelectedIndex = 3;
				break;
			default:
				comboBoxDemandSentence2.SelectedIndex = 0;
				break;
			}
		}

		private void comboBoxBaseAsset1_Click(object sender, EventArgs e)
		{
			FillcomboBoxBaseAsset1(comboBoxBaseAsset1.Text);
		}

		private void comboBoxExpirationDate1_Click(object sender, EventArgs e)
		{
			FillcomboBoxExpirationDate1(comboBoxBaseAsset1.Text, comboBoxExpirationDate1.Text);
		}

		private void comboBoxBaseAsset2_Click(object sender, EventArgs e)
		{
			FillcomboBoxBaseAsset2(comboBoxBaseAsset2.Text);
		}

		private void comboBoxExpirationDate2_Click(object sender, EventArgs e)
		{
			FillcomboBoxExpirationDate2(comboBoxBaseAsset2.Text, comboBoxExpirationDate2.Text);
		}

		public void FillSettings()
		{
			ClassSettings.gSmileBaseAsset1 = comboBoxBaseAsset1.Text;
			ClassSettings.gSmileExpirationDate1 = comboBoxExpirationDate1.Text;
			ClassSettings.gSmileBaseAsset2 = comboBoxBaseAsset2.Text;
			ClassSettings.gSmileExpirationDate2 = comboBoxExpirationDate2.Text;
			ClassSettings.gSmileStepGridX = textBoxStepGridX.Text;
			ClassSettings.gSmileStepGridY = textBoxStepGridY.Text;
			ClassSettings.gSmileIndentUp = textBoxIndentUp.Text;
			ClassSettings.gSmileIndentDn = textBoxIndentDn.Text;
			ClassSettings.gSmileDemandSentence1 = comboBoxDemandSentence1.Text;
			ClassSettings.gSmileDemandSentence2 = comboBoxDemandSentence2.Text;
			ClassSettings.gSmileHistory1 = comboBoxHistory.Text;
			ClassSettings.gSmileSortMethod = gSmileSortMethod;
			ClassSettings.gSmileCheckBoxModelSmile = Convert.ToString(checkBoxModelSmile.Checked);
			ClassSettings.gSmileCheckBoxModelVolatility = Convert.ToString(checkBoxModelVolatility.Checked);
			ClassSettings.gSmileModelVolatility = Convert.ToString(numericUpDownModelSmileVolatility.Value);
			ClassSettings.gSmileModelSkew = Convert.ToString(numericUpDownModelSmileSkew.Value);
			ClassSettings.gSmileModelKink = Convert.ToString(numericUpDownModelSmileKink.Value);
		}

		private void PaintColorTheme()
		{
			BackColor = ClassColorTheme.BackColor;
			ForeColor = ClassColorTheme.BackColorFore;
			label12.BackColor = ClassColorTheme.BackColor;
			label13.ForeColor = ClassColorTheme.BackColorFore;
			checkBoxModelSmile.ForeColor = ClassColorTheme.BackColorFore;
			buttonIndentUpMore.FlatStyle = FlatStyle.System;
			buttonIndentUpLess.FlatStyle = FlatStyle.System;
			buttonIndentDnMore.FlatStyle = FlatStyle.System;
			buttonIndentDnLess.FlatStyle = FlatStyle.System;
			groupBox1.BackColor = ClassColorTheme.BackColor;
			groupBox1.ForeColor = ClassColorTheme.BackColorFore;
			groupBox2.BackColor = ClassColorTheme.BackColor;
			groupBox2.ForeColor = ClassColorTheme.BackColorFore;
			groupBox3.BackColor = ClassColorTheme.BackColor;
			groupBox3.ForeColor = ClassColorTheme.BackColorFore;
			groupBoxCalendarInfo.BackColor = ClassColorTheme.BackColor;
			groupBoxCalendarInfo.ForeColor = ClassColorTheme.BackColorFore;
			groupBoxModelSmile.BackColor = ClassColorTheme.BackColor;
			groupBoxModelSmile.ForeColor = ClassColorTheme.BackColorFore;
			splitContainer1.BackColor = ClassColorTheme.HeadersColor;
			splitContainer1.Panel1.BackColor = ClassColorTheme.BackColor;
			splitContainer1.Panel2.BackColor = ClassColorTheme.BackColor;
			splitContainer1.BorderStyle = BorderStyle.None;
			splitContainer2.BackColor = ClassColorTheme.HeadersColor;
			splitContainer2.Panel1.BackColor = ClassColorTheme.BackColor;
			splitContainer2.Panel2.BackColor = ClassColorTheme.BackColor;
			splitContainer2.BorderStyle = BorderStyle.None;
			chart1.BackColor = ClassColorTheme.BackColor;
			chart1.BackSecondaryColor = ClassColorTheme.BackColor;
			chart1.ForeColor = ClassColorTheme.BackColorFore;
			chart1.ChartAreas[0].AxisX.LabelStyle.ForeColor = ClassColorTheme.BackColorFore;
			chart1.ChartAreas[0].AxisY.LabelStyle.ForeColor = ClassColorTheme.BackColorFore;
			chart1.ChartAreas[0].AxisX.TitleForeColor = ClassColorTheme.BackColorFore;
			chart1.ChartAreas[0].AxisY.TitleForeColor = ClassColorTheme.BackColorFore;
			chart1.ChartAreas[0].AxisX.MajorGrid.LineColor = ClassColorTheme.ChartGridColor;
			chart1.ChartAreas[0].AxisY.MajorGrid.LineColor = ClassColorTheme.ChartGridColor;
			chart1.ChartAreas[0].AxisX.LineColor = ClassColorTheme.ChartGridColor;
			chart1.ChartAreas[0].AxisY.LineColor = ClassColorTheme.ChartGridColor;
			chart1.ChartAreas[0].BackColor = ClassColorTheme.BackColor;
			chart1.Legends[0].BackColor = ClassColorTheme.BackColor;
			chart1.Legends[0].ForeColor = ClassColorTheme.BackColorFore;
			if (chart1.Series["Инструмент 1"].Enabled)
			{
				chart1.Series["Инструмент 1"].Color = ClassColorTheme.ChartCurrentColor;
			}
			if (chart1.Series["Инструмент 2"].Enabled)
			{
				chart1.Series["Инструмент 2"].Color = Color.Red;
			}
			chart2.BackColor = ClassColorTheme.BackColor;
			chart2.BackSecondaryColor = ClassColorTheme.BackColor;
			chart2.ForeColor = ClassColorTheme.BackColorFore;
			chart2.ChartAreas[0].AxisX.LabelStyle.ForeColor = ClassColorTheme.BackColorFore;
			chart2.ChartAreas[0].AxisY.LabelStyle.ForeColor = ClassColorTheme.BackColorFore;
			chart2.ChartAreas[0].AxisX.TitleForeColor = ClassColorTheme.BackColorFore;
			chart2.ChartAreas[0].AxisY.TitleForeColor = ClassColorTheme.BackColorFore;
			chart2.ChartAreas[0].AxisX.MajorGrid.LineColor = ClassColorTheme.ChartGridColor;
			chart2.ChartAreas[0].AxisY.MajorGrid.LineColor = ClassColorTheme.ChartGridColor;
			chart2.ChartAreas[0].AxisX.LineColor = ClassColorTheme.ChartGridColor;
			chart2.ChartAreas[0].AxisY.LineColor = ClassColorTheme.ChartGridColor;
			chart2.ChartAreas[0].BackColor = ClassColorTheme.BackColor;
			chart2.Legends[0].BackColor = ClassColorTheme.BackColor;
			chart2.Legends[0].ForeColor = ClassColorTheme.BackColorFore;
			if (chart2.Series["Раздвижка"].Enabled)
			{
				chart2.Series["Раздвижка"].Color = ClassColorTheme.ChartCurrentColor;
			}
			dataGridViewCalendarInfo.ColumnHeadersDefaultCellStyle.BackColor = ClassColorTheme.HeadersColor;
			dataGridViewCalendarInfo.BackgroundColor = ClassColorTheme.BackColor;
			dataGridViewCalendarInfo.ForeColor = ClassColorTheme.BackColorFore;
			dataGridViewCalendarInfo.DefaultCellStyle.BackColor = ClassColorTheme.BackColor;
			dataGridViewCalendarInfo.ColumnHeadersDefaultCellStyle.ForeColor = ClassColorTheme.HeadersColorFore;
			dataGridViewCalendarInfo.GridColor = ClassColorTheme.GridColor;
			dataGridViewCalendarInfo.RowsDefaultCellStyle.BackColor = ClassColorTheme.BackColor;
			dataGridViewCalendarInfo.AlternatingRowsDefaultCellStyle.BackColor = ClassColorTheme.HeadersColor;
			PaintSpreadVolatilityDataGridViewCalendarInfo();
		}

		private void buttonIndentUpMore_Click(object sender, EventArgs e)
		{
			double result = 0.0;
			if (double.TryParse(textBoxIndentUp.Text, out result) && !(result <= 0.0))
			{
				textBoxIndentUp.Text = Convert.ToString(result + 5.0);
			}
		}

		private void buttonIndentUpLess_Click(object sender, EventArgs e)
		{
			double result = 0.0;
			if (double.TryParse(textBoxIndentUp.Text, out result) && !(result - 5.0 <= 0.0))
			{
				textBoxIndentUp.Text = Convert.ToString(result - 5.0);
			}
		}

		private void buttonIndentDnMore_Click(object sender, EventArgs e)
		{
			double result = 0.0;
			if (double.TryParse(textBoxIndentDn.Text, out result) && !(result <= 0.0) && !(result + 5.0 >= 100.0))
			{
				textBoxIndentDn.Text = Convert.ToString(result + 5.0);
			}
		}

		private void buttonIndentDnLess_Click(object sender, EventArgs e)
		{
			double result = 0.0;
			if (double.TryParse(textBoxIndentDn.Text, out result) && !(result - 5.0 <= 0.0))
			{
				textBoxIndentDn.Text = Convert.ToString(result - 5.0);
			}
		}

		private double CalculationVolaSmile1(int i, string DemandSentence)
		{
			double num1 = 0.0;
			double num2 = 0.5;
			if (comboBoxDemandSentence1.Text == "PutCall")
			{
				if (SmileTable1.Values[i].strike < FuturePaper1.last_price)
				{
					cCalculationOptions.TypeO = SmileTable1.Values[i].option_type_put;
					if (DemandSentence == "Demand")
					{
						cCalculationOptions.Theo = SmileTable1.Values[i].demand_put;
						if (cCalculationOptions.Theo < SmileTable1.Values[i].teoretical_price_put - num2 * SmileTable1.Values[i].teoretical_price_put || cCalculationOptions.Theo > SmileTable1.Values[i].teoretical_price_put + num2 * SmileTable1.Values[i].teoretical_price_put)
						{
							return 0.0;
						}
					}
					else
					{
						cCalculationOptions.Theo = SmileTable1.Values[i].sentence_put;
						if (cCalculationOptions.Theo < SmileTable1.Values[i].teoretical_price_put - num2 * SmileTable1.Values[i].teoretical_price_put || cCalculationOptions.Theo > SmileTable1.Values[i].teoretical_price_put + num2 * SmileTable1.Values[i].teoretical_price_put)
						{
							return 0.0;
						}
					}
				}
				else
				{
					cCalculationOptions.TypeO = SmileTable1.Values[i].option_type_call;
					if (DemandSentence == "Demand")
					{
						cCalculationOptions.Theo = SmileTable1.Values[i].demand_call;
						if (cCalculationOptions.Theo < SmileTable1.Values[i].teoretical_price_call - num2 * SmileTable1.Values[i].teoretical_price_call || cCalculationOptions.Theo > SmileTable1.Values[i].teoretical_price_call + num2 * SmileTable1.Values[i].teoretical_price_call)
						{
							return 0.0;
						}
					}
					else
					{
						cCalculationOptions.Theo = SmileTable1.Values[i].sentence_call;
						if (cCalculationOptions.Theo < SmileTable1.Values[i].teoretical_price_call - num2 * SmileTable1.Values[i].teoretical_price_call || cCalculationOptions.Theo > SmileTable1.Values[i].teoretical_price_call + num2 * SmileTable1.Values[i].teoretical_price_call)
						{
							return 0.0;
						}
					}
				}
			}
			else if (comboBoxDemandSentence1.Text == "Call")
			{
				cCalculationOptions.TypeO = SmileTable1.Values[i].option_type_call;
				if (DemandSentence == "Demand")
				{
					cCalculationOptions.Theo = SmileTable1.Values[i].demand_call;
					if (cCalculationOptions.Theo < SmileTable1.Values[i].teoretical_price_call - num2 * SmileTable1.Values[i].teoretical_price_call || cCalculationOptions.Theo > SmileTable1.Values[i].teoretical_price_call + num2 * SmileTable1.Values[i].teoretical_price_call)
					{
						return 0.0;
					}
				}
				else
				{
					cCalculationOptions.Theo = SmileTable1.Values[i].sentence_call;
					if (cCalculationOptions.Theo < SmileTable1.Values[i].teoretical_price_call - num2 * SmileTable1.Values[i].teoretical_price_call || cCalculationOptions.Theo > SmileTable1.Values[i].teoretical_price_call + num2 * SmileTable1.Values[i].teoretical_price_call)
					{
						return 0.0;
					}
				}
			}
			else if (comboBoxDemandSentence1.Text == "Put")
			{
				cCalculationOptions.TypeO = SmileTable1.Values[i].option_type_put;
				if (DemandSentence == "Demand")
				{
					cCalculationOptions.Theo = SmileTable1.Values[i].demand_put;
					if (cCalculationOptions.Theo < SmileTable1.Values[i].teoretical_price_put - num2 * SmileTable1.Values[i].teoretical_price_put || cCalculationOptions.Theo > SmileTable1.Values[i].teoretical_price_put + num2 * SmileTable1.Values[i].teoretical_price_put)
					{
						return 0.0;
					}
				}
				else
				{
					cCalculationOptions.Theo = SmileTable1.Values[i].sentence_put;
					if (cCalculationOptions.Theo < SmileTable1.Values[i].teoretical_price_put - num2 * SmileTable1.Values[i].teoretical_price_put || cCalculationOptions.Theo > SmileTable1.Values[i].teoretical_price_put + num2 * SmileTable1.Values[i].teoretical_price_put)
					{
						return 0.0;
					}
				}
			}
			cCalculationOptions.Strike = SmileTable1.Values[i].strike;
			cCalculationOptions.DateExp = SmileTable1.Values[i].expiration_date;
			cCalculationOptions.DateCurrent = DateTime.Now;
			cCalculationOptions.Q = Convert.ToInt32(1);
			cCalculationOptions.LastF = FuturePaper1.last_price;
			if (cCalculationOptions.Theo > 0.0)
			{
				num1 = ((!cCalculationOptions.CalculationVola()) ? 0.0 : Math.Round(cCalculationOptions.calcVola, 2));
			}
			return num1;
		}

		private double CalculationVolaSmile2(int i, string DemandSentence)
		{
			double num1 = 0.0;
			double num2 = 0.5;
			if (comboBoxDemandSentence2.Text == "PutCall")
			{
				if (SmileTable2.Values[i].strike < FuturePaper2.last_price)
				{
					cCalculationOptions.TypeO = SmileTable2.Values[i].option_type_put;
					if (DemandSentence == "Demand")
					{
						cCalculationOptions.Theo = SmileTable2.Values[i].demand_put;
						if (cCalculationOptions.Theo < SmileTable2.Values[i].teoretical_price_put - num2 * SmileTable2.Values[i].teoretical_price_put || cCalculationOptions.Theo > SmileTable2.Values[i].teoretical_price_put + num2 * SmileTable2.Values[i].teoretical_price_put)
						{
							return 0.0;
						}
					}
					else
					{
						cCalculationOptions.Theo = SmileTable2.Values[i].sentence_put;
						if (cCalculationOptions.Theo < SmileTable2.Values[i].teoretical_price_put - num2 * SmileTable2.Values[i].teoretical_price_put || cCalculationOptions.Theo > SmileTable2.Values[i].teoretical_price_put + num2 * SmileTable2.Values[i].teoretical_price_put)
						{
							return 0.0;
						}
					}
				}
				else
				{
					cCalculationOptions.TypeO = SmileTable2.Values[i].option_type_call;
					if (DemandSentence == "Demand")
					{
						cCalculationOptions.Theo = SmileTable2.Values[i].demand_call;
						if (cCalculationOptions.Theo < SmileTable2.Values[i].teoretical_price_call - num2 * SmileTable2.Values[i].teoretical_price_call || cCalculationOptions.Theo > SmileTable2.Values[i].teoretical_price_call + num2 * SmileTable2.Values[i].teoretical_price_call)
						{
							return 0.0;
						}
					}
					else
					{
						cCalculationOptions.Theo = SmileTable2.Values[i].sentence_call;
						if (cCalculationOptions.Theo < SmileTable2.Values[i].teoretical_price_call - num2 * SmileTable2.Values[i].teoretical_price_call || cCalculationOptions.Theo > SmileTable2.Values[i].teoretical_price_call + num2 * SmileTable2.Values[i].teoretical_price_call)
						{
							return 0.0;
						}
					}
				}
			}
			else if (comboBoxDemandSentence2.Text == "Call")
			{
				cCalculationOptions.TypeO = SmileTable2.Values[i].option_type_call;
				if (DemandSentence == "Demand")
				{
					cCalculationOptions.Theo = SmileTable2.Values[i].demand_call;
					if (cCalculationOptions.Theo < SmileTable2.Values[i].teoretical_price_call - num2 * SmileTable2.Values[i].teoretical_price_call || cCalculationOptions.Theo > SmileTable2.Values[i].teoretical_price_call + num2 * SmileTable2.Values[i].teoretical_price_call)
					{
						return 0.0;
					}
				}
				else
				{
					cCalculationOptions.Theo = SmileTable2.Values[i].sentence_call;
					if (cCalculationOptions.Theo < SmileTable2.Values[i].teoretical_price_call - num2 * SmileTable2.Values[i].teoretical_price_call || cCalculationOptions.Theo > SmileTable2.Values[i].teoretical_price_call + num2 * SmileTable2.Values[i].teoretical_price_call)
					{
						return 0.0;
					}
				}
			}
			else if (comboBoxDemandSentence2.Text == "Put")
			{
				cCalculationOptions.TypeO = SmileTable2.Values[i].option_type_put;
				if (DemandSentence == "Demand")
				{
					cCalculationOptions.Theo = SmileTable2.Values[i].demand_put;
					if (cCalculationOptions.Theo < SmileTable2.Values[i].teoretical_price_put - num2 * SmileTable2.Values[i].teoretical_price_put || cCalculationOptions.Theo > SmileTable2.Values[i].teoretical_price_put + num2 * SmileTable2.Values[i].teoretical_price_put)
					{
						return 0.0;
					}
				}
				else
				{
					cCalculationOptions.Theo = SmileTable2.Values[i].sentence_put;
					if (cCalculationOptions.Theo < SmileTable2.Values[i].teoretical_price_put - num2 * SmileTable2.Values[i].teoretical_price_put || cCalculationOptions.Theo > SmileTable2.Values[i].teoretical_price_put + num2 * SmileTable2.Values[i].teoretical_price_put)
					{
						return 0.0;
					}
				}
			}
			cCalculationOptions.Strike = SmileTable2.Values[i].strike;
			cCalculationOptions.DateExp = SmileTable2.Values[i].expiration_date;
			cCalculationOptions.DateCurrent = DateTime.Now;
			cCalculationOptions.Q = Convert.ToInt32(1);
			cCalculationOptions.LastF = FuturePaper2.last_price;
			if (cCalculationOptions.Theo > 0.0)
			{
				num1 = ((!cCalculationOptions.CalculationVola()) ? 0.0 : Math.Round(cCalculationOptions.calcVola, 2));
			}
			return num1;
		}

		private void comboBoxHistory_Click(object sender, EventArgs e)
		{
			string str = "";
			str = comboBoxHistory.Text;
			int num = 0;
			comboBoxHistory.Items.Clear();
			comboBoxHistory.Items.Add("NULL");
			string path = Application.StartupPath + "\\History";
			if (Directory.Exists(path))
			{
				string[] files = Directory.GetFiles(path);
				foreach (string file in files)
				{
					string withoutExtension = Path.GetFileNameWithoutExtension(file);
					if (Path.GetExtension(file) == ".txt")
					{
						comboBoxHistory.Items.Add(withoutExtension);
						num++;
					}
				}
			}
			comboBoxHistory.SelectedIndex = num;
		}

		private void comboBoxHistory_SelectedIndexChanged(object sender, EventArgs e)
		{
			cHistoryDataDDE.FileName = comboBoxHistory.Text;
			cHistoryDataDDE.ReadFileHistory();
			Tick();
		}

		private void toolStripMenuItemUpdate_Click(object sender, EventArgs e)
		{
			qQuotesTable.Clear();
			qFuturesQuotesTable.Clear();
			lock (ClassDataDDE.QuotesTable)
			{
				qQuotesTable.AddRange(ClassDataDDE.QuotesTable);
			}
			lock (ClassDataDDE.FuturesQuotesTable)
			{
				qFuturesQuotesTable.AddRange(ClassDataDDE.FuturesQuotesTable);
			}
			Fill_BaseAssetTable();
			Fill_CalendarInfoTable();
			UpdateCalendarInfoTable();
			CalculateSpreadCalendarInfoTable();
			SortCalendarInfoTable();
			Fill_dataGridViewCalendarInfo();
			PaintSpreadVolatilityDataGridViewCalendarInfo();
		}

		private void Fill_CalendarInfoTable()
		{
			CalendarInfoTable.Clear();
			CopyBaseAssetTable.Clear();
			CopyBaseAssetTable.AddRange(BaseAssetTable);
			if (BaseAssetTable.Count <= 0)
			{
				return;
			}
			for (int index1 = 0; index1 < CopyBaseAssetTable.Count; index1++)
			{
				for (int i = 0; i < BaseAssetTable.Count; i++)
				{
					if (BaseAssetTable[i].base_asset_fut == CopyBaseAssetTable[index1].base_asset_fut && BaseAssetTable[i].expiration_date > CopyBaseAssetTable[index1].expiration_date)
					{
						CalendarInfoPaper.base_asset_fut = CopyBaseAssetTable[index1].base_asset_fut;
						CalendarInfoPaper.price_fut1 = CopyBaseAssetTable[index1].price_fut;
						CalendarInfoPaper.base_asset1 = CopyBaseAssetTable[index1].base_asset;
						CalendarInfoPaper.paper_code1 = "";
						CalendarInfoPaper.expiration_date1 = CopyBaseAssetTable[index1].expiration_date;
						CalendarInfoPaper.strike1 = 0.0;
						CalendarInfoPaper.volatility1 = 0.0;
						CalendarInfoPaper.base_asset2 = BaseAssetTable[i].base_asset;
						CalendarInfoPaper.paper_code2 = "";
						CalendarInfoPaper.expiration_date2 = BaseAssetTable[i].expiration_date;
						CalendarInfoPaper.strike2 = 0.0;
						CalendarInfoPaper.volatility2 = 0.0;
						CalendarInfoPaper.base_assets_Calendar = "";
						CalendarInfoPaper.spreadvolatility = 0.0;
						CalendarInfoTable.Add(CalendarInfoPaper);
					}
				}
			}
		}

		private void Fill_BaseAssetTable()
		{
			double num = 0.0;
			BaseAssetTable.Clear();
			if (qQuotesTable.Count <= 0 || qFuturesQuotesTable.Count <= 0)
			{
				return;
			}
			for (int index1 = 0; index1 < qQuotesTable.Count; index1++)
			{
				if (index1 == 0)
				{
					string str = "";
					for (int i = 0; i < qFuturesQuotesTable.Count; i++)
					{
						if (qFuturesQuotesTable[i].paper_code == qQuotesTable[index1].base_asset)
						{
							str = qFuturesQuotesTable[i].base_asset;
							num = qFuturesQuotesTable[i].last_price;
							break;
						}
					}
					if (str.Length > 0)
					{
						BaseAssetPaper.base_asset_fut = str;
						BaseAssetPaper.price_fut = num;
						BaseAssetPaper.base_asset = qQuotesTable[index1].base_asset;
						BaseAssetPaper.expiration_date = qQuotesTable[index1].expiration_date;
						BaseAssetTable.Add(BaseAssetPaper);
					}
					continue;
				}
				bool flag = false;
				for (int j = 0; j < BaseAssetTable.Count; j++)
				{
					if (BaseAssetTable[j].base_asset == qQuotesTable[index1].base_asset && qQuotesTable[index1].expiration_date == BaseAssetTable[j].expiration_date)
					{
						flag = true;
						break;
					}
				}
				if (flag)
				{
					continue;
				}
				string str2 = "";
				for (int k = 0; k < qFuturesQuotesTable.Count; k++)
				{
					if (qFuturesQuotesTable[k].paper_code == qQuotesTable[index1].base_asset)
					{
						str2 = qFuturesQuotesTable[k].base_asset;
						num = qFuturesQuotesTable[k].last_price;
						break;
					}
				}
				if (str2.Length > 0)
				{
					BaseAssetPaper.base_asset_fut = str2;
					BaseAssetPaper.price_fut = num;
					BaseAssetPaper.base_asset = qQuotesTable[index1].base_asset;
					BaseAssetPaper.expiration_date = qQuotesTable[index1].expiration_date;
					BaseAssetTable.Add(BaseAssetPaper);
				}
			}
		}

		private void Fill_dataGridViewCalendarInfo()
		{
			dataGridViewCalendarInfo.Rows.Clear();
			for (int index = 0; index < CalendarInfoTable.Count; index++)
			{
				if (CalendarInfoTable[index].strike1 == CalendarInfoTable[index].strike2 && CalendarInfoTable[index].volatility1 > 0.0 && CalendarInfoTable[index].volatility2 > 0.0)
				{
					dataGridViewCalendarInfo.Rows.Add(CalendarInfoTable[index].base_assets_Calendar, Convert.ToString(CalendarInfoTable[index].spreadvolatility));
				}
			}
		}

		private void UpdateCalendarInfoTable()
		{
			if (CalendarInfoTable.Count <= 0 || qQuotesTable.Count <= 0)
			{
				return;
			}
			for (int index1 = 0; index1 < qQuotesTable.Count; index1++)
			{
				for (int i = 0; i < CalendarInfoTable.Count; i++)
				{
					if (qQuotesTable[index1].base_asset == CalendarInfoTable[i].base_asset1 && qQuotesTable[index1].expiration_date == CalendarInfoTable[i].expiration_date1)
					{
						if (CalendarInfoTable[i].strike1 == 0.0)
						{
							CalendarInfoPaper = CalendarInfoTable[i];
							CalendarInfoPaper.paper_code1 = qQuotesTable[index1].paper_code;
							CalendarInfoPaper.strike1 = qQuotesTable[index1].strike;
							CalendarInfoPaper.volatility1 = qQuotesTable[index1].volatility;
							CalendarInfoTable[i] = CalendarInfoPaper;
						}
						else if (Math.Abs(qQuotesTable[index1].strike - CalendarInfoTable[i].price_fut1) < Math.Abs(CalendarInfoTable[i].strike1 - CalendarInfoTable[i].price_fut1))
						{
							CalendarInfoPaper = CalendarInfoTable[i];
							CalendarInfoPaper.paper_code1 = qQuotesTable[index1].paper_code;
							CalendarInfoPaper.strike1 = qQuotesTable[index1].strike;
							CalendarInfoPaper.volatility1 = qQuotesTable[index1].volatility;
							CalendarInfoTable[i] = CalendarInfoPaper;
						}
					}
					if (qQuotesTable[index1].base_asset == CalendarInfoTable[i].base_asset2 && qQuotesTable[index1].expiration_date == CalendarInfoTable[i].expiration_date2)
					{
						if (CalendarInfoTable[i].strike2 == 0.0)
						{
							CalendarInfoPaper = CalendarInfoTable[i];
							CalendarInfoPaper.paper_code2 = qQuotesTable[index1].paper_code;
							CalendarInfoPaper.strike2 = qQuotesTable[index1].strike;
							CalendarInfoPaper.volatility2 = qQuotesTable[index1].volatility;
							CalendarInfoTable[i] = CalendarInfoPaper;
						}
						else if (Math.Abs(qQuotesTable[index1].strike - CalendarInfoTable[i].price_fut1) < Math.Abs(CalendarInfoTable[i].strike2 - CalendarInfoTable[i].price_fut1))
						{
							CalendarInfoPaper = CalendarInfoTable[i];
							CalendarInfoPaper.paper_code2 = qQuotesTable[index1].paper_code;
							CalendarInfoPaper.strike2 = qQuotesTable[index1].strike;
							CalendarInfoPaper.volatility2 = qQuotesTable[index1].volatility;
							CalendarInfoTable[i] = CalendarInfoPaper;
						}
					}
				}
			}
		}

		private void CalculateSpreadCalendarInfoTable()
		{
			for (int index = 0; index < CalendarInfoTable.Count; index++)
			{
				if (CalendarInfoTable[index].strike1 == CalendarInfoTable[index].strike2 && CalendarInfoTable[index].volatility1 > 0.0 && CalendarInfoTable[index].volatility2 > 0.0)
				{
					string str1 = CalendarInfoTable[index].expiration_date1.ToString("dd.MM");
					string str2 = CalendarInfoTable[index].expiration_date2.ToString("dd.MM");
					string str3 = CalendarInfoTable[index].base_asset_fut + " " + str1 + " " + str2;
					double num = Math.Round(CalendarInfoTable[index].volatility1 - CalendarInfoTable[index].volatility2, 2);
					CalendarInfoPaper = CalendarInfoTable[index];
					CalendarInfoPaper.base_assets_Calendar = str3;
					CalendarInfoPaper.spreadvolatility = num;
					CalendarInfoTable[index] = CalendarInfoPaper;
				}
			}
		}

		private void PaintSpreadVolatilityDataGridViewCalendarInfo()
		{
			for (int index = 0; index < dataGridViewCalendarInfo.RowCount; index++)
			{
				double result;
				if (!double.TryParse(Convert.ToString(dataGridViewCalendarInfo.Rows[index].Cells["Spread"].Value), out result))
				{
					continue;
				}
				if (ClassSettings.gColorTheme == "Витек" || ClassSettings.gColorTheme == "Небо с облаками" || ClassSettings.gColorTheme == "Кофе с молоком")
				{
					if (result > 4.0)
					{
						dataGridViewCalendarInfo.Rows[index].Cells["Spread"].Style.BackColor = Color.FromArgb(0, 180, 0);
					}
					else if (result <= 4.0 && result > 2.0)
					{
						dataGridViewCalendarInfo.Rows[index].Cells["Spread"].Style.BackColor = Color.FromArgb(100, 255, 100);
					}
					else if (result <= 2.0 && result > 1.0)
					{
						dataGridViewCalendarInfo.Rows[index].Cells["Spread"].Style.BackColor = Color.FromArgb(200, 255, 200);
					}
					else if (result <= 1.0 && result > 0.0)
					{
						dataGridViewCalendarInfo.Rows[index].Cells["Spread"].Style.BackColor = ClassColorTheme.BackColor;
					}
					else if (result == 0.0)
					{
						dataGridViewCalendarInfo.Rows[index].Cells["Spread"].Style.BackColor = ClassColorTheme.BackColor;
					}
					else if (result < 0.0 && result >= -1.0)
					{
						dataGridViewCalendarInfo.Rows[index].Cells["Spread"].Style.BackColor = ClassColorTheme.BackColor;
					}
					else if (result < -1.0 && result >= -2.0)
					{
						dataGridViewCalendarInfo.Rows[index].Cells["Spread"].Style.BackColor = Color.FromArgb(255, 200, 200);
					}
					else if (result < -2.0 && result >= -4.0)
					{
						dataGridViewCalendarInfo.Rows[index].Cells["Spread"].Style.BackColor = Color.FromArgb(255, 100, 100);
					}
					else if (result < -4.0)
					{
						dataGridViewCalendarInfo.Rows[index].Cells["Spread"].Style.BackColor = Color.FromArgb(180, 0, 0);
					}
				}
				else if (result > 4.0)
				{
					dataGridViewCalendarInfo.Rows[index].Cells["Spread"].Style.BackColor = Color.FromArgb(20, 170, 20);
				}
				else if (result <= 4.0 && result > 2.0)
				{
					dataGridViewCalendarInfo.Rows[index].Cells["Spread"].Style.BackColor = Color.FromArgb(10, 120, 10);
				}
				else if (result <= 2.0 && result > 1.0)
				{
					dataGridViewCalendarInfo.Rows[index].Cells["Spread"].Style.BackColor = Color.FromArgb(10, 70, 10);
				}
				else if (result <= 1.0 && result > 0.0)
				{
					dataGridViewCalendarInfo.Rows[index].Cells["Spread"].Style.BackColor = ClassColorTheme.BackColor;
				}
				else if (result == 0.0)
				{
					dataGridViewCalendarInfo.Rows[index].Cells["Spread"].Style.BackColor = ClassColorTheme.BackColor;
				}
				else if (result < 0.0 && result >= -1.0)
				{
					dataGridViewCalendarInfo.Rows[index].Cells["Spread"].Style.BackColor = ClassColorTheme.BackColor;
				}
				else if (result < -1.0 && result >= -2.0)
				{
					dataGridViewCalendarInfo.Rows[index].Cells["Spread"].Style.BackColor = Color.FromArgb(70, 10, 10);
				}
				else if (result < -2.0 && result >= -4.0)
				{
					dataGridViewCalendarInfo.Rows[index].Cells["Spread"].Style.BackColor = Color.FromArgb(120, 10, 10);
				}
				else if (result < -4.0)
				{
					dataGridViewCalendarInfo.Rows[index].Cells["Spread"].Style.BackColor = Color.FromArgb(170, 20, 20);
				}
			}
		}

		private void toolStripMenuItemApply_Click(object sender, EventArgs e)
		{
			if (dataGridViewCalendarInfo.RowCount > 0)
			{
				int rowIndex = dataGridViewCalendarInfo.SelectedCells[0].RowIndex;
				if (rowIndex >= 0 && rowIndex < dataGridViewCalendarInfo.RowCount)
				{
					comboBoxBaseAsset1.Items.Clear();
					comboBoxBaseAsset1.Items.Add(CalendarInfoTable[rowIndex].base_asset1);
					comboBoxBaseAsset1.SelectedIndex = 0;
					comboBoxBaseAsset2.Items.Clear();
					comboBoxBaseAsset2.Items.Add(CalendarInfoTable[rowIndex].base_asset2);
					comboBoxBaseAsset2.SelectedIndex = 0;
					comboBoxExpirationDate1.Items.Clear();
					comboBoxExpirationDate1.Items.Add(CalendarInfoTable[rowIndex].expiration_date1.ToShortDateString());
					comboBoxExpirationDate1.SelectedIndex = 0;
					comboBoxExpirationDate2.Items.Clear();
					comboBoxExpirationDate2.Items.Add(CalendarInfoTable[rowIndex].expiration_date2.ToShortDateString());
					comboBoxExpirationDate2.SelectedIndex = 0;
				}
			}
			Tick();
		}

		private void toolStripMenuItemBaseAssets_Click(object sender, EventArgs e)
		{
			gSmileSortMethod = "1";
			SortCalendarInfoTable();
			Fill_dataGridViewCalendarInfo();
			PaintSpreadVolatilityDataGridViewCalendarInfo();
		}

		private void toolStripMenuItemSpread_Click(object sender, EventArgs e)
		{
			gSmileSortMethod = "2";
			SortCalendarInfoTable();
			Fill_dataGridViewCalendarInfo();
			PaintSpreadVolatilityDataGridViewCalendarInfo();
		}

		private void SortCalendarInfoTable()
		{
			if (gSmileSortMethod == "2")
			{
				CalendarInfoTable.Sort((CalendarInfo CalendarInfoTable1, CalendarInfo CalendarInfoTable2) => CalendarInfoTable1.spreadvolatility.CompareTo(CalendarInfoTable2.spreadvolatility));
			}
			else
			{
				CalendarInfoTable.Sort((CalendarInfo CalendarInfoTable1, CalendarInfo CalendarInfoTable2) => CalendarInfoTable1.base_assets_Calendar.CompareTo(CalendarInfoTable2.base_assets_Calendar));
			}
		}

		private void contextMenuStripSmile_Opening(object sender, CancelEventArgs e)
		{
			if (comboBoxBaseAsset1.Text != "" && comboBoxBaseAsset1.Text != "NULL" && comboBoxBaseAsset1.Text.Length > 0)
			{
				ToolStripMenuItemInstrument1.Enabled = true;
			}
			else
			{
				ToolStripMenuItemInstrument1.Enabled = false;
			}
			if (comboBoxBaseAsset2.Text != "" && comboBoxBaseAsset2.Text != "NULL" && comboBoxBaseAsset2.Text.Length > 0)
			{
				ToolStripMenuItemInstrument2.Enabled = true;
			}
			else
			{
				ToolStripMenuItemInstrument2.Enabled = false;
			}
		}

		private void ToolStripMenuItemInstrument1_Click(object sender, EventArgs e)
		{
			double strike = 0.0;
			double num1 = 0.0;
			bool flag = true;
			if (PositionX > 0.0)
			{
				for (int index = 0; index < SmileTable1.Count; index++)
				{
					if (strike == 0.0)
					{
						if (SmileTable1.Values[index].strike > 0.0)
						{
							strike = SmileTable1.Values[index].strike;
							num1 = Math.Abs(PositionX - strike);
						}
					}
					else if (SmileTable1.Values[index].strike > 0.0 && Math.Abs(PositionX - SmileTable1.Values[index].strike) < num1)
					{
						strike = SmileTable1.Values[index].strike;
						num1 = Math.Abs(PositionX - strike);
					}
				}
			}
			if (!(strike <= 0.0))
			{
				DateTime result;
				if (!DateTime.TryParse(comboBoxExpirationDate1.Text, out result))
				{
					int num2 = (int)MessageBox.Show("Не корректна теоретическая цена. Она должна быть числом");
					flag = false;
				}
				string base_asset = Convert.ToString(comboBoxBaseAsset1.Text);
				string option_type;
				if (comboBoxDemandSentence1.Text == "Call")
				{
					option_type = "Call";
				}
				else if (comboBoxDemandSentence1.Text == "Put")
				{
					option_type = "Put";
				}
				else if (comboBoxDemandSentence1.Text == "PutCall")
				{
					option_type = ((strike < FuturePaper1.last_price) ? "Put" : "Call");
				}
				else
				{
					option_type = "";
					flag = false;
				}
				if (flag && !cDataDDE.SearchPaper(result, base_asset, strike, option_type))
				{
					int num3 = (int)MessageBox.Show("Не удалось найти этот инструмент в DDE");
					flag = false;
				}
				string iText = Convert.ToString(ClassDataDDE.QuotesPaper.paper_code);
				if (flag)
				{
					CallBackMy.callbackEventHandlerOpenGlass(iText);
				}
			}
		}

		private void ToolStripMenuItemInstrument2_Click(object sender, EventArgs e)
		{
			double strike = 0.0;
			double num1 = 0.0;
			bool flag = true;
			if (PositionX > 0.0)
			{
				for (int index = 0; index < SmileTable2.Count; index++)
				{
					if (strike == 0.0)
					{
						if (SmileTable2.Values[index].strike > 0.0)
						{
							strike = SmileTable2.Values[index].strike;
							num1 = Math.Abs(PositionX - strike);
						}
					}
					else if (SmileTable2.Values[index].strike > 0.0 && Math.Abs(PositionX - SmileTable2.Values[index].strike) < num1)
					{
						strike = SmileTable2.Values[index].strike;
						num1 = Math.Abs(PositionX - strike);
					}
				}
			}
			if (!(strike <= 0.0))
			{
				DateTime result;
				if (!DateTime.TryParse(comboBoxExpirationDate2.Text, out result))
				{
					int num2 = (int)MessageBox.Show("Не корректна теоретическая цена. Она должна быть числом");
					flag = false;
				}
				string base_asset = Convert.ToString(comboBoxBaseAsset2.Text);
				string option_type;
				if (comboBoxDemandSentence2.Text == "Call")
				{
					option_type = "Call";
				}
				else if (comboBoxDemandSentence2.Text == "Put")
				{
					option_type = "Put";
				}
				else if (comboBoxDemandSentence2.Text == "PutCall")
				{
					option_type = ((strike < FuturePaper2.last_price) ? "Put" : "Call");
				}
				else
				{
					option_type = "";
					flag = false;
				}
				if (flag && !cDataDDE.SearchPaper(result, base_asset, strike, option_type))
				{
					int num3 = (int)MessageBox.Show("Не удалось найти этот инструмент в DDE");
					flag = false;
				}
				string iText = Convert.ToString(ClassDataDDE.QuotesPaper.paper_code);
				if (flag)
				{
					CallBackMy.callbackEventHandlerOpenGlass(iText);
				}
			}
		}

		private void chart1_MouseMove(object sender, MouseEventArgs e)
		{
			double result;
			if (!double.TryParse(Convert.ToString(e.X), out result) || result <= 0.0)
			{
				return;
			}
			try
			{
				PositionX = Convert.ToDouble(chart1.ChartAreas[0].AxisX.PixelPositionToValue(result));
			}
			catch
			{
			}
		}

		public double GetModelSmileVolatility()
		{
			dGetModelSmile dGetModelSmile = GetModelSmileVolatility;
			return (!numericUpDownModelSmileVolatility.InvokeRequired) ? Convert.ToDouble(numericUpDownModelSmileVolatility.Value) : Convert.ToDouble(Invoke(dGetModelSmile, new object[0]));
		}

		public double GetModelSmileSkew()
		{
			dGetModelSmile dGetModelSmile = GetModelSmileSkew;
			return (!numericUpDownModelSmileSkew.InvokeRequired) ? Convert.ToDouble(numericUpDownModelSmileSkew.Value) : Convert.ToDouble(Invoke(dGetModelSmile, new object[0]));
		}

		public double GetModelSmileKink()
		{
			dGetModelSmile dGetModelSmile = GetModelSmileKink;
			return (!numericUpDownModelSmileKink.InvokeRequired) ? Convert.ToDouble(numericUpDownModelSmileKink.Value) : Convert.ToDouble(Invoke(dGetModelSmile, new object[0]));
		}

		public bool GetModelSmileChecked()
		{
			dGetModelSmileChecked modelSmileChecked = GetModelSmileChecked;
			return (!checkBoxModelSmile.InvokeRequired) ? checkBoxModelSmile.Checked : Convert.ToBoolean(Invoke(modelSmileChecked, new object[0]));
		}

		public bool GetModelVolatilityChecked()
		{
			dGetModelSmileChecked modelSmileChecked = GetModelVolatilityChecked;
			return (!checkBoxModelVolatility.InvokeRequired) ? checkBoxModelVolatility.Checked : Convert.ToBoolean(Invoke(modelSmileChecked, new object[0]));
		}

		public double GetModelCurrentStrike()
		{
			return ModelCurrentStrike;
		}

		public string GetModelName()
		{
			dGetModelSmileName getModelSmileName = GetModelName;
			return (!comboBoxCurrentModel.InvokeRequired) ? comboBoxCurrentModel.Text : Convert.ToString(Invoke(getModelSmileName, new object[0]));
		}

		private void buttonSaveModelSmile_Click(object sender, EventArgs e)
		{
			if (comboBoxCurrentModel.Text.Length > 0)
			{
				if (SettingModelSmile.Count > 0)
				{
					bool flag = false;
					for (int index = 0; index < SettingModelSmile.Count; index++)
					{
						SettingModelSmilePaper = SettingModelSmile[index];
						if (comboBoxCurrentModel.Text == SettingModelSmilePaper.name)
						{
							SettingModelSmilePaper.name = comboBoxCurrentModel.Text;
							SettingModelSmilePaper.base_asset = comboBoxBaseAsset1.Text;
							SettingModelSmilePaper.date = DateTime.Now;
							SettingModelSmilePaper.vola = Convert.ToDouble(numericUpDownModelSmileVolatility.Value);
							SettingModelSmilePaper.Skew = Convert.ToDouble(numericUpDownModelSmileSkew.Value);
							SettingModelSmilePaper.Kink = Convert.ToDouble(numericUpDownModelSmileKink.Value);
							SettingModelSmile[index] = SettingModelSmilePaper;
							flag = true;
							break;
						}
					}
					if (!flag)
					{
						SettingModelSmilePaper.name = comboBoxCurrentModel.Text;
						SettingModelSmilePaper.base_asset = comboBoxBaseAsset1.Text;
						SettingModelSmilePaper.date = DateTime.Now;
						SettingModelSmilePaper.vola = Convert.ToDouble(numericUpDownModelSmileVolatility.Value);
						SettingModelSmilePaper.Skew = Convert.ToDouble(numericUpDownModelSmileSkew.Value);
						SettingModelSmilePaper.Kink = Convert.ToDouble(numericUpDownModelSmileKink.Value);
						SettingModelSmile.Add(SettingModelSmilePaper);
					}
				}
				else
				{
					SettingModelSmilePaper.name = comboBoxCurrentModel.Text;
					SettingModelSmilePaper.base_asset = comboBoxBaseAsset1.Text;
					SettingModelSmilePaper.date = DateTime.Now;
					SettingModelSmilePaper.vola = Convert.ToDouble(numericUpDownModelSmileVolatility.Value);
					SettingModelSmilePaper.Skew = Convert.ToDouble(numericUpDownModelSmileSkew.Value);
					SettingModelSmilePaper.Kink = Convert.ToDouble(numericUpDownModelSmileKink.Value);
					SettingModelSmile.Add(SettingModelSmilePaper);
				}
			}
			WriteFileSettings();
			FillcomboBoxCurrentModel(comboBoxCurrentModel.Text);
		}

		public bool WriteFileSettings()
		{
			bool flag = true;
			StreamWriter streamWriter = new StreamWriter(CurrentDirectory, false);
			if (SettingModelSmile.Count > 0)
			{
				for (int index = 0; index < SettingModelSmile.Count; index++)
				{
					SettingModelSmilePaper = SettingModelSmile[index];
					streamWriter.WriteLine(SettingModelSmilePaper.name + ";" + SettingModelSmilePaper.base_asset + ";" + SettingModelSmilePaper.date.ToString() + ";" + Convert.ToString(SettingModelSmilePaper.vola) + ";" + Convert.ToString(SettingModelSmilePaper.Skew) + ";" + Convert.ToString(SettingModelSmilePaper.Kink));
				}
			}
			streamWriter.Close();
			return flag;
		}

		public bool ReadFileSettings()
		{
			bool flag = true;
			if (File.Exists(CurrentDirectory))
			{
				try
				{
					StreamReader streamReader = new StreamReader(CurrentDirectory);
					while (streamReader.Peek() != -1)
					{
						string[] strArray = streamReader.ReadLine().Split(';');
						SettingModelSmilePaper.name = strArray[0];
						SettingModelSmilePaper.base_asset = strArray[1];
						if (!DateTime.TryParse(strArray[2], out SettingModelSmilePaper.date))
						{
							SettingModelSmilePaper.date = Convert.ToDateTime("01.01.2000");
						}
						if (!double.TryParse(strArray[3], out SettingModelSmilePaper.vola))
						{
							SettingModelSmilePaper.vola = 0.0;
						}
						if (!double.TryParse(strArray[4], out SettingModelSmilePaper.Skew))
						{
							SettingModelSmilePaper.Skew = 0.0;
						}
						if (!double.TryParse(strArray[5], out SettingModelSmilePaper.Kink))
						{
							SettingModelSmilePaper.Kink = 0.0;
						}
						SettingModelSmile.Add(SettingModelSmilePaper);
					}
				}
				catch
				{
				}
			}
			return flag;
		}

		public void FillcomboBoxCurrentModel(string defaultCurrentModel)
		{
			int num = 0;
			comboBoxCurrentModel.Items.Clear();
			if (SettingModelSmile.Count > 0)
			{
				for (int index = 0; index < SettingModelSmile.Count; index++)
				{
					SettingModelSmilePaper = SettingModelSmile[index];
					if (SettingModelSmilePaper.name == defaultCurrentModel)
					{
						num = index;
					}
					comboBoxCurrentModel.Items.Add(SettingModelSmilePaper.name);
				}
			}
			if (SettingModelSmile.Count > num)
			{
				comboBoxCurrentModel.SelectedIndex = num;
			}
		}

		private void comboBoxBaseAsset1_SelectedIndexChanged(object sender, EventArgs e)
		{
			FillSettingsCurrentModelFromBaseAsset1();
		}

		public void FillSettingsCurrentModel(string defaultCurrentModel)
		{
			for (int index = 0; index < SettingModelSmile.Count; index++)
			{
				SettingModelSmilePaper = SettingModelSmile[index];
				if (defaultCurrentModel == SettingModelSmilePaper.name)
				{
					checkBoxModelVolatility.Checked = true;
					numericUpDownModelSmileVolatility.Value = Convert.ToDecimal(SettingModelSmilePaper.vola);
					numericUpDownModelSmileSkew.Value = Convert.ToDecimal(SettingModelSmilePaper.Skew);
					numericUpDownModelSmileKink.Value = Convert.ToDecimal(SettingModelSmilePaper.Kink);
					break;
				}
			}
		}

		private void comboBoxCurrentModel_SelectedIndexChanged(object sender, EventArgs e)
		{
			FillSettingsCurrentModel(comboBoxCurrentModel.Text);
		}

		private void FillSettingsCurrentModelFromBaseAsset1()
		{
			int num = 0;
			for (int index = 0; index < SettingModelSmile.Count; index++)
			{
				SettingModelSmilePaper = SettingModelSmile[index];
				if (comboBoxBaseAsset1.Text == SettingModelSmilePaper.base_asset)
				{
					num = index;
					checkBoxModelVolatility.Checked = true;
					numericUpDownModelSmileVolatility.Value = Convert.ToDecimal(SettingModelSmilePaper.vola);
					numericUpDownModelSmileSkew.Value = Convert.ToDecimal(SettingModelSmilePaper.Skew);
					numericUpDownModelSmileKink.Value = Convert.ToDecimal(SettingModelSmilePaper.Kink);
					break;
				}
			}
			if (SettingModelSmile.Count > num)
			{
				comboBoxCurrentModel.SelectedIndex = num;
			}
		}

		private string FindCurrentModel(string defaultBaseAsset)
		{
			string str = "";
			for (int index = 0; index < SettingModelSmile.Count; index++)
			{
				SettingModelSmilePaper = SettingModelSmile[index];
				if (defaultBaseAsset == SettingModelSmilePaper.base_asset)
				{
					str = SettingModelSmilePaper.name;
					break;
				}
			}
			return str;
		}

		private void buttonRemoveModelSmile_Click(object sender, EventArgs e)
		{
			for (int index = 0; index < SettingModelSmile.Count; index++)
			{
				SettingModelSmilePaper = SettingModelSmile[index];
				if (comboBoxCurrentModel.Text == SettingModelSmilePaper.name)
				{
					SettingModelSmile.RemoveAt(index);
					break;
				}
			}
			WriteFileSettings();
			FillcomboBoxCurrentModel(FindCurrentModel(comboBoxBaseAsset1.Text));
		}

		protected override void Dispose(bool disposing)
		{
			if (disposing && components != null)
			{
				components.Dispose();
			}
			base.Dispose(disposing);
		}

		private void InitializeComponent()
		{
			this.components = new System.ComponentModel.Container();
			System.Windows.Forms.DataVisualization.Charting.ChartArea chartArea1 = new System.Windows.Forms.DataVisualization.Charting.ChartArea();
			System.Windows.Forms.DataVisualization.Charting.Legend legend1 = new System.Windows.Forms.DataVisualization.Charting.Legend();
			System.Windows.Forms.DataVisualization.Charting.ChartArea chartArea2 = new System.Windows.Forms.DataVisualization.Charting.ChartArea();
			System.Windows.Forms.DataVisualization.Charting.Legend legend2 = new System.Windows.Forms.DataVisualization.Charting.Legend();
			System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(OptionFVV.FormSmile));
			this.splitContainer1 = new System.Windows.Forms.SplitContainer();
			this.groupBoxModelSmile = new System.Windows.Forms.GroupBox();
			this.numericUpDownModelSmileKink = new System.Windows.Forms.NumericUpDown();
			this.numericUpDownModelSmileSkew = new System.Windows.Forms.NumericUpDown();
			this.numericUpDownModelSmileVolatility = new System.Windows.Forms.NumericUpDown();
			this.buttonRemoveModelSmile = new System.Windows.Forms.Button();
			this.buttonSaveModelSmile = new System.Windows.Forms.Button();
			this.checkBoxModelVolatility = new System.Windows.Forms.CheckBox();
			this.checkBoxModelSmile = new System.Windows.Forms.CheckBox();
			this.label13 = new System.Windows.Forms.Label();
			this.comboBoxCurrentModel = new System.Windows.Forms.ComboBox();
			this.label12 = new System.Windows.Forms.Label();
			this.groupBoxCalendarInfo = new System.Windows.Forms.GroupBox();
			this.dataGridViewCalendarInfo = new System.Windows.Forms.DataGridView();
			this.groupBox3 = new System.Windows.Forms.GroupBox();
			this.buttonIndentDnMore = new System.Windows.Forms.Button();
			this.buttonIndentDnLess = new System.Windows.Forms.Button();
			this.buttonIndentUpMore = new System.Windows.Forms.Button();
			this.buttonIndentUpLess = new System.Windows.Forms.Button();
			this.label8 = new System.Windows.Forms.Label();
			this.label7 = new System.Windows.Forms.Label();
			this.textBoxIndentDn = new System.Windows.Forms.TextBox();
			this.textBoxIndentUp = new System.Windows.Forms.TextBox();
			this.textBoxStepGridX = new System.Windows.Forms.TextBox();
			this.textBoxStepGridY = new System.Windows.Forms.TextBox();
			this.label6 = new System.Windows.Forms.Label();
			this.groupBox2 = new System.Windows.Forms.GroupBox();
			this.comboBoxDemandSentence2 = new System.Windows.Forms.ComboBox();
			this.label11 = new System.Windows.Forms.Label();
			this.comboBoxExpirationDate2 = new System.Windows.Forms.ComboBox();
			this.label4 = new System.Windows.Forms.Label();
			this.comboBoxBaseAsset2 = new System.Windows.Forms.ComboBox();
			this.label5 = new System.Windows.Forms.Label();
			this.groupBox1 = new System.Windows.Forms.GroupBox();
			this.comboBoxHistory = new System.Windows.Forms.ComboBox();
			this.comboBoxDemandSentence1 = new System.Windows.Forms.ComboBox();
			this.label10 = new System.Windows.Forms.Label();
			this.comboBoxExpirationDate1 = new System.Windows.Forms.ComboBox();
			this.label9 = new System.Windows.Forms.Label();
			this.label3 = new System.Windows.Forms.Label();
			this.comboBoxBaseAsset1 = new System.Windows.Forms.ComboBox();
			this.label1 = new System.Windows.Forms.Label();
			this.splitContainer2 = new System.Windows.Forms.SplitContainer();
			this.chart1 = new System.Windows.Forms.DataVisualization.Charting.Chart();
			this.chart2 = new System.Windows.Forms.DataVisualization.Charting.Chart();
			this.contextMenuStripCalendarInfo = new System.Windows.Forms.ContextMenuStrip(this.components);
			this.toolStripMenuItemUpdate = new System.Windows.Forms.ToolStripMenuItem();
			this.toolStripMenuItemApply = new System.Windows.Forms.ToolStripMenuItem();
			this.toolStripMenuItemSortMethod = new System.Windows.Forms.ToolStripMenuItem();
			this.toolStripMenuItemBaseAssets = new System.Windows.Forms.ToolStripMenuItem();
			this.toolStripMenuItemSpread = new System.Windows.Forms.ToolStripMenuItem();
			this.contextMenuStripSmile = new System.Windows.Forms.ContextMenuStrip(this.components);
			this.ToolStripMenuItemGlass = new System.Windows.Forms.ToolStripMenuItem();
			this.ToolStripMenuItemInstrument1 = new System.Windows.Forms.ToolStripMenuItem();
			this.ToolStripMenuItemInstrument2 = new System.Windows.Forms.ToolStripMenuItem();
			this.splitContainer1.BeginInit();
			this.splitContainer1.Panel1.SuspendLayout();
			this.splitContainer1.Panel2.SuspendLayout();
			this.splitContainer1.SuspendLayout();
			this.groupBoxModelSmile.SuspendLayout();
			this.numericUpDownModelSmileKink.BeginInit();
			this.numericUpDownModelSmileSkew.BeginInit();
			this.numericUpDownModelSmileVolatility.BeginInit();
			this.groupBoxCalendarInfo.SuspendLayout();
			((System.ComponentModel.ISupportInitialize)this.dataGridViewCalendarInfo).BeginInit();
			this.groupBox3.SuspendLayout();
			this.groupBox2.SuspendLayout();
			this.groupBox1.SuspendLayout();
			this.splitContainer2.BeginInit();
			this.splitContainer2.Panel1.SuspendLayout();
			this.splitContainer2.Panel2.SuspendLayout();
			this.splitContainer2.SuspendLayout();
			this.chart1.BeginInit();
			this.chart2.BeginInit();
			this.contextMenuStripCalendarInfo.SuspendLayout();
			this.contextMenuStripSmile.SuspendLayout();
			base.SuspendLayout();
			this.splitContainer1.Dock = System.Windows.Forms.DockStyle.Fill;
			this.splitContainer1.FixedPanel = System.Windows.Forms.FixedPanel.Panel1;
			this.splitContainer1.IsSplitterFixed = true;
			this.splitContainer1.Location = new System.Drawing.Point(0, 0);
			this.splitContainer1.Name = "splitContainer1";
			this.splitContainer1.Panel1.Controls.Add(this.groupBoxModelSmile);
			this.splitContainer1.Panel1.Controls.Add(this.groupBoxCalendarInfo);
			this.splitContainer1.Panel1.Controls.Add(this.groupBox3);
			this.splitContainer1.Panel1.Controls.Add(this.textBoxStepGridX);
			this.splitContainer1.Panel1.Controls.Add(this.textBoxStepGridY);
			this.splitContainer1.Panel1.Controls.Add(this.label6);
			this.splitContainer1.Panel1.Controls.Add(this.groupBox2);
			this.splitContainer1.Panel1.Controls.Add(this.groupBox1);
			this.splitContainer1.Panel2.Controls.Add(this.splitContainer2);
			this.splitContainer1.Size = new System.Drawing.Size(1162, 618);
			this.splitContainer1.SplitterDistance = 357;
			this.splitContainer1.TabIndex = 0;
			this.groupBoxModelSmile.Controls.Add(this.numericUpDownModelSmileKink);
			this.groupBoxModelSmile.Controls.Add(this.numericUpDownModelSmileSkew);
			this.groupBoxModelSmile.Controls.Add(this.numericUpDownModelSmileVolatility);
			this.groupBoxModelSmile.Controls.Add(this.buttonRemoveModelSmile);
			this.groupBoxModelSmile.Controls.Add(this.buttonSaveModelSmile);
			this.groupBoxModelSmile.Controls.Add(this.checkBoxModelVolatility);
			this.groupBoxModelSmile.Controls.Add(this.checkBoxModelSmile);
			this.groupBoxModelSmile.Controls.Add(this.label13);
			this.groupBoxModelSmile.Controls.Add(this.comboBoxCurrentModel);
			this.groupBoxModelSmile.Controls.Add(this.label12);
			this.groupBoxModelSmile.Location = new System.Drawing.Point(4, 252);
			this.groupBoxModelSmile.Name = "groupBoxModelSmile";
			this.groupBoxModelSmile.Size = new System.Drawing.Size(167, 156);
			this.groupBoxModelSmile.TabIndex = 2;
			this.groupBoxModelSmile.TabStop = false;
			this.groupBoxModelSmile.Text = "Модель улыбки";
			this.numericUpDownModelSmileKink.DecimalPlaces = 2;
			this.numericUpDownModelSmileKink.Increment = new decimal(new int[4] { 1, 0, 0, 65536 });
			this.numericUpDownModelSmileKink.Location = new System.Drawing.Point(83, 101);
			this.numericUpDownModelSmileKink.Maximum = new decimal(new int[4] { 1000, 0, 0, 0 });
			this.numericUpDownModelSmileKink.Minimum = new decimal(new int[4] { 1000, 0, 0, -2147483648 });
			this.numericUpDownModelSmileKink.Name = "numericUpDownModelSmileKink";
			this.numericUpDownModelSmileKink.Size = new System.Drawing.Size(77, 20);
			this.numericUpDownModelSmileKink.TabIndex = 1;
			this.numericUpDownModelSmileKink.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
			this.numericUpDownModelSmileSkew.DecimalPlaces = 2;
			this.numericUpDownModelSmileSkew.Increment = new decimal(new int[4] { 1, 0, 0, 65536 });
			this.numericUpDownModelSmileSkew.Location = new System.Drawing.Point(84, 75);
			this.numericUpDownModelSmileSkew.Maximum = new decimal(new int[4] { 1000, 0, 0, 0 });
			this.numericUpDownModelSmileSkew.Minimum = new decimal(new int[4] { 1000, 0, 0, -2147483648 });
			this.numericUpDownModelSmileSkew.Name = "numericUpDownModelSmileSkew";
			this.numericUpDownModelSmileSkew.Size = new System.Drawing.Size(77, 20);
			this.numericUpDownModelSmileSkew.TabIndex = 1;
			this.numericUpDownModelSmileSkew.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
			this.numericUpDownModelSmileVolatility.DecimalPlaces = 2;
			this.numericUpDownModelSmileVolatility.Increment = new decimal(new int[4] { 1, 0, 0, 65536 });
			this.numericUpDownModelSmileVolatility.Location = new System.Drawing.Point(84, 49);
			this.numericUpDownModelSmileVolatility.Maximum = new decimal(new int[4] { 1000, 0, 0, 0 });
			this.numericUpDownModelSmileVolatility.Name = "numericUpDownModelSmileVolatility";
			this.numericUpDownModelSmileVolatility.Size = new System.Drawing.Size(77, 20);
			this.numericUpDownModelSmileVolatility.TabIndex = 1;
			this.numericUpDownModelSmileVolatility.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
			this.buttonRemoveModelSmile.Location = new System.Drawing.Point(130, 127);
			this.buttonRemoveModelSmile.Name = "buttonRemoveModelSmile";
			this.buttonRemoveModelSmile.Size = new System.Drawing.Size(29, 23);
			this.buttonRemoveModelSmile.TabIndex = 2;
			this.buttonRemoveModelSmile.Text = "У";
			this.buttonRemoveModelSmile.UseVisualStyleBackColor = true;
			this.buttonRemoveModelSmile.Click += new System.EventHandler(buttonRemoveModelSmile_Click);
			this.buttonSaveModelSmile.Location = new System.Drawing.Point(95, 127);
			this.buttonSaveModelSmile.Name = "buttonSaveModelSmile";
			this.buttonSaveModelSmile.Size = new System.Drawing.Size(29, 23);
			this.buttonSaveModelSmile.TabIndex = 2;
			this.buttonSaveModelSmile.Text = "С";
			this.buttonSaveModelSmile.UseVisualStyleBackColor = true;
			this.buttonSaveModelSmile.Click += new System.EventHandler(buttonSaveModelSmile_Click);
			this.checkBoxModelVolatility.AutoSize = true;
			this.checkBoxModelVolatility.Location = new System.Drawing.Point(11, 50);
			this.checkBoxModelVolatility.Name = "checkBoxModelVolatility";
			this.checkBoxModelVolatility.Size = new System.Drawing.Size(54, 17);
			this.checkBoxModelVolatility.TabIndex = 1;
			this.checkBoxModelVolatility.Text = "Вола.";
			this.checkBoxModelVolatility.UseVisualStyleBackColor = true;
			this.checkBoxModelSmile.AutoSize = true;
			this.checkBoxModelSmile.Location = new System.Drawing.Point(11, 25);
			this.checkBoxModelSmile.Name = "checkBoxModelSmile";
			this.checkBoxModelSmile.Size = new System.Drawing.Size(116, 17);
			this.checkBoxModelSmile.TabIndex = 1;
			this.checkBoxModelSmile.Text = "Включить модель";
			this.checkBoxModelSmile.UseVisualStyleBackColor = true;
			this.label13.AutoSize = true;
			this.label13.Location = new System.Drawing.Point(8, 103);
			this.label13.Name = "label13";
			this.label13.Size = new System.Drawing.Size(37, 13);
			this.label13.TabIndex = 2;
			this.label13.Text = "Загиб";
			this.comboBoxCurrentModel.FormattingEnabled = true;
			this.comboBoxCurrentModel.Location = new System.Drawing.Point(12, 127);
			this.comboBoxCurrentModel.Name = "comboBoxCurrentModel";
			this.comboBoxCurrentModel.Size = new System.Drawing.Size(77, 21);
			this.comboBoxCurrentModel.TabIndex = 1;
			this.comboBoxCurrentModel.SelectedIndexChanged += new System.EventHandler(comboBoxCurrentModel_SelectedIndexChanged);
			this.comboBoxCurrentModel.Click += new System.EventHandler(comboBoxBaseAsset1_Click);
			this.label12.AutoSize = true;
			this.label12.Location = new System.Drawing.Point(8, 77);
			this.label12.Name = "label12";
			this.label12.Size = new System.Drawing.Size(45, 13);
			this.label12.TabIndex = 2;
			this.label12.Text = "Наклон";
			this.groupBoxCalendarInfo.Anchor = System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left | System.Windows.Forms.AnchorStyles.Right;
			this.groupBoxCalendarInfo.Controls.Add(this.dataGridViewCalendarInfo);
			this.groupBoxCalendarInfo.Location = new System.Drawing.Point(177, 3);
			this.groupBoxCalendarInfo.Name = "groupBoxCalendarInfo";
			this.groupBoxCalendarInfo.Size = new System.Drawing.Size(177, 612);
			this.groupBoxCalendarInfo.TabIndex = 7;
			this.groupBoxCalendarInfo.TabStop = false;
			this.groupBoxCalendarInfo.Text = "Календари";
			this.dataGridViewCalendarInfo.AllowUserToAddRows = false;
			this.dataGridViewCalendarInfo.AllowUserToDeleteRows = false;
			this.dataGridViewCalendarInfo.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
			this.dataGridViewCalendarInfo.Dock = System.Windows.Forms.DockStyle.Fill;
			this.dataGridViewCalendarInfo.Location = new System.Drawing.Point(3, 16);
			this.dataGridViewCalendarInfo.Name = "dataGridViewCalendarInfo";
			this.dataGridViewCalendarInfo.Size = new System.Drawing.Size(171, 593);
			this.dataGridViewCalendarInfo.TabIndex = 0;
			this.groupBox3.Controls.Add(this.buttonIndentDnMore);
			this.groupBox3.Controls.Add(this.buttonIndentDnLess);
			this.groupBox3.Controls.Add(this.buttonIndentUpMore);
			this.groupBox3.Controls.Add(this.buttonIndentUpLess);
			this.groupBox3.Controls.Add(this.label8);
			this.groupBox3.Controls.Add(this.label7);
			this.groupBox3.Controls.Add(this.textBoxIndentDn);
			this.groupBox3.Controls.Add(this.textBoxIndentUp);
			this.groupBox3.Location = new System.Drawing.Point(4, 414);
			this.groupBox3.Name = "groupBox3";
			this.groupBox3.Size = new System.Drawing.Size(168, 88);
			this.groupBox3.TabIndex = 6;
			this.groupBox3.TabStop = false;
			this.groupBox3.Text = "Отрисовка графика %";
			this.buttonIndentDnMore.Location = new System.Drawing.Point(131, 43);
			this.buttonIndentDnMore.Name = "buttonIndentDnMore";
			this.buttonIndentDnMore.Size = new System.Drawing.Size(29, 23);
			this.buttonIndentDnMore.TabIndex = 5;
			this.buttonIndentDnMore.Text = ">";
			this.buttonIndentDnMore.UseVisualStyleBackColor = true;
			this.buttonIndentDnMore.Click += new System.EventHandler(buttonIndentDnMore_Click);
			this.buttonIndentDnLess.Location = new System.Drawing.Point(54, 43);
			this.buttonIndentDnLess.Name = "buttonIndentDnLess";
			this.buttonIndentDnLess.Size = new System.Drawing.Size(29, 23);
			this.buttonIndentDnLess.TabIndex = 4;
			this.buttonIndentDnLess.Text = "<";
			this.buttonIndentDnLess.UseVisualStyleBackColor = true;
			this.buttonIndentDnLess.Click += new System.EventHandler(buttonIndentDnLess_Click);
			this.buttonIndentUpMore.Location = new System.Drawing.Point(131, 17);
			this.buttonIndentUpMore.Name = "buttonIndentUpMore";
			this.buttonIndentUpMore.Size = new System.Drawing.Size(29, 23);
			this.buttonIndentUpMore.TabIndex = 3;
			this.buttonIndentUpMore.Text = ">";
			this.buttonIndentUpMore.UseVisualStyleBackColor = true;
			this.buttonIndentUpMore.Click += new System.EventHandler(buttonIndentUpMore_Click);
			this.buttonIndentUpLess.Location = new System.Drawing.Point(54, 17);
			this.buttonIndentUpLess.Name = "buttonIndentUpLess";
			this.buttonIndentUpLess.Size = new System.Drawing.Size(29, 23);
			this.buttonIndentUpLess.TabIndex = 2;
			this.buttonIndentUpLess.Text = "<";
			this.buttonIndentUpLess.UseVisualStyleBackColor = true;
			this.buttonIndentUpLess.Click += new System.EventHandler(buttonIndentUpLess_Click);
			this.label8.AutoSize = true;
			this.label8.Location = new System.Drawing.Point(9, 48);
			this.label8.Name = "label8";
			this.label8.Size = new System.Drawing.Size(35, 13);
			this.label8.TabIndex = 1;
			this.label8.Text = "Ниже";
			this.label7.AutoSize = true;
			this.label7.Location = new System.Drawing.Point(9, 22);
			this.label7.Name = "label7";
			this.label7.Size = new System.Drawing.Size(36, 13);
			this.label7.TabIndex = 1;
			this.label7.Text = "Выше";
			this.textBoxIndentDn.Location = new System.Drawing.Point(89, 45);
			this.textBoxIndentDn.Name = "textBoxIndentDn";
			this.textBoxIndentDn.ReadOnly = true;
			this.textBoxIndentDn.Size = new System.Drawing.Size(36, 20);
			this.textBoxIndentDn.TabIndex = 0;
			this.textBoxIndentDn.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
			this.textBoxIndentUp.Location = new System.Drawing.Point(89, 19);
			this.textBoxIndentUp.Name = "textBoxIndentUp";
			this.textBoxIndentUp.ReadOnly = true;
			this.textBoxIndentUp.Size = new System.Drawing.Size(36, 20);
			this.textBoxIndentUp.TabIndex = 0;
			this.textBoxIndentUp.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
			this.textBoxStepGridX.Location = new System.Drawing.Point(89, 534);
			this.textBoxStepGridX.Name = "textBoxStepGridX";
			this.textBoxStepGridX.ReadOnly = true;
			this.textBoxStepGridX.Size = new System.Drawing.Size(77, 20);
			this.textBoxStepGridX.TabIndex = 5;
			this.textBoxStepGridX.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
			this.textBoxStepGridY.Location = new System.Drawing.Point(89, 508);
			this.textBoxStepGridY.Name = "textBoxStepGridY";
			this.textBoxStepGridY.Size = new System.Drawing.Size(77, 20);
			this.textBoxStepGridY.TabIndex = 5;
			this.textBoxStepGridY.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
			this.label6.AutoSize = true;
			this.label6.Location = new System.Drawing.Point(14, 511);
			this.label6.Name = "label6";
			this.label6.Size = new System.Drawing.Size(69, 13);
			this.label6.TabIndex = 3;
			this.label6.Text = "Шаг сетки Y";
			this.groupBox2.Controls.Add(this.comboBoxDemandSentence2);
			this.groupBox2.Controls.Add(this.label11);
			this.groupBox2.Controls.Add(this.comboBoxExpirationDate2);
			this.groupBox2.Controls.Add(this.label4);
			this.groupBox2.Controls.Add(this.comboBoxBaseAsset2);
			this.groupBox2.Controls.Add(this.label5);
			this.groupBox2.Location = new System.Drawing.Point(4, 141);
			this.groupBox2.Name = "groupBox2";
			this.groupBox2.Size = new System.Drawing.Size(168, 105);
			this.groupBox2.TabIndex = 2;
			this.groupBox2.TabStop = false;
			this.groupBox2.Text = "Инструмент 2";
			this.comboBoxDemandSentence2.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
			this.comboBoxDemandSentence2.FormattingEnabled = true;
			this.comboBoxDemandSentence2.Location = new System.Drawing.Point(83, 73);
			this.comboBoxDemandSentence2.Name = "comboBoxDemandSentence2";
			this.comboBoxDemandSentence2.Size = new System.Drawing.Size(77, 21);
			this.comboBoxDemandSentence2.TabIndex = 3;
			this.label11.AutoSize = true;
			this.label11.Location = new System.Drawing.Point(9, 76);
			this.label11.Name = "label11";
			this.label11.Size = new System.Drawing.Size(52, 13);
			this.label11.TabIndex = 2;
			this.label11.Text = "Маркера";
			this.comboBoxExpirationDate2.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
			this.comboBoxExpirationDate2.FormattingEnabled = true;
			this.comboBoxExpirationDate2.Location = new System.Drawing.Point(83, 46);
			this.comboBoxExpirationDate2.Name = "comboBoxExpirationDate2";
			this.comboBoxExpirationDate2.Size = new System.Drawing.Size(77, 21);
			this.comboBoxExpirationDate2.TabIndex = 3;
			this.comboBoxExpirationDate2.Click += new System.EventHandler(comboBoxExpirationDate2_Click);
			this.label4.AutoSize = true;
			this.label4.Location = new System.Drawing.Point(9, 49);
			this.label4.Name = "label4";
			this.label4.Size = new System.Drawing.Size(63, 13);
			this.label4.TabIndex = 2;
			this.label4.Text = "Дата эксп.";
			this.comboBoxBaseAsset2.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
			this.comboBoxBaseAsset2.FormattingEnabled = true;
			this.comboBoxBaseAsset2.Location = new System.Drawing.Point(99, 19);
			this.comboBoxBaseAsset2.Name = "comboBoxBaseAsset2";
			this.comboBoxBaseAsset2.Size = new System.Drawing.Size(61, 21);
			this.comboBoxBaseAsset2.TabIndex = 1;
			this.comboBoxBaseAsset2.Click += new System.EventHandler(comboBoxBaseAsset2_Click);
			this.label5.AutoSize = true;
			this.label5.Location = new System.Drawing.Point(9, 22);
			this.label5.Name = "label5";
			this.label5.Size = new System.Drawing.Size(84, 13);
			this.label5.TabIndex = 0;
			this.label5.Text = "Базовый актив";
			this.groupBox1.Controls.Add(this.comboBoxHistory);
			this.groupBox1.Controls.Add(this.comboBoxDemandSentence1);
			this.groupBox1.Controls.Add(this.label10);
			this.groupBox1.Controls.Add(this.comboBoxExpirationDate1);
			this.groupBox1.Controls.Add(this.label9);
			this.groupBox1.Controls.Add(this.label3);
			this.groupBox1.Controls.Add(this.comboBoxBaseAsset1);
			this.groupBox1.Controls.Add(this.label1);
			this.groupBox1.ForeColor = System.Drawing.SystemColors.ControlText;
			this.groupBox1.Location = new System.Drawing.Point(3, 3);
			this.groupBox1.Name = "groupBox1";
			this.groupBox1.Size = new System.Drawing.Size(168, 132);
			this.groupBox1.TabIndex = 2;
			this.groupBox1.TabStop = false;
			this.groupBox1.Text = "Инструмент 1";
			this.comboBoxHistory.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
			this.comboBoxHistory.FormattingEnabled = true;
			this.comboBoxHistory.Location = new System.Drawing.Point(83, 100);
			this.comboBoxHistory.Name = "comboBoxHistory";
			this.comboBoxHistory.Size = new System.Drawing.Size(77, 21);
			this.comboBoxHistory.TabIndex = 3;
			this.comboBoxHistory.SelectedIndexChanged += new System.EventHandler(comboBoxHistory_SelectedIndexChanged);
			this.comboBoxHistory.Click += new System.EventHandler(comboBoxHistory_Click);
			this.comboBoxDemandSentence1.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
			this.comboBoxDemandSentence1.FormattingEnabled = true;
			this.comboBoxDemandSentence1.Location = new System.Drawing.Point(83, 73);
			this.comboBoxDemandSentence1.Name = "comboBoxDemandSentence1";
			this.comboBoxDemandSentence1.Size = new System.Drawing.Size(77, 21);
			this.comboBoxDemandSentence1.TabIndex = 3;
			this.label10.AutoSize = true;
			this.label10.Location = new System.Drawing.Point(9, 103);
			this.label10.Name = "label10";
			this.label10.Size = new System.Drawing.Size(50, 13);
			this.label10.TabIndex = 2;
			this.label10.Text = "История";
			this.comboBoxExpirationDate1.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
			this.comboBoxExpirationDate1.FormattingEnabled = true;
			this.comboBoxExpirationDate1.Location = new System.Drawing.Point(83, 46);
			this.comboBoxExpirationDate1.Name = "comboBoxExpirationDate1";
			this.comboBoxExpirationDate1.Size = new System.Drawing.Size(77, 21);
			this.comboBoxExpirationDate1.TabIndex = 3;
			this.comboBoxExpirationDate1.Click += new System.EventHandler(comboBoxExpirationDate1_Click);
			this.label9.AutoSize = true;
			this.label9.Location = new System.Drawing.Point(9, 76);
			this.label9.Name = "label9";
			this.label9.Size = new System.Drawing.Size(52, 13);
			this.label9.TabIndex = 2;
			this.label9.Text = "Маркера";
			this.label3.AutoSize = true;
			this.label3.Location = new System.Drawing.Point(9, 49);
			this.label3.Name = "label3";
			this.label3.Size = new System.Drawing.Size(63, 13);
			this.label3.TabIndex = 2;
			this.label3.Text = "Дата эксп.";
			this.comboBoxBaseAsset1.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
			this.comboBoxBaseAsset1.FormattingEnabled = true;
			this.comboBoxBaseAsset1.Location = new System.Drawing.Point(99, 19);
			this.comboBoxBaseAsset1.Name = "comboBoxBaseAsset1";
			this.comboBoxBaseAsset1.Size = new System.Drawing.Size(61, 21);
			this.comboBoxBaseAsset1.TabIndex = 1;
			this.comboBoxBaseAsset1.SelectedIndexChanged += new System.EventHandler(comboBoxBaseAsset1_SelectedIndexChanged);
			this.comboBoxBaseAsset1.Click += new System.EventHandler(comboBoxBaseAsset1_Click);
			this.label1.AutoSize = true;
			this.label1.Location = new System.Drawing.Point(9, 22);
			this.label1.Name = "label1";
			this.label1.Size = new System.Drawing.Size(84, 13);
			this.label1.TabIndex = 0;
			this.label1.Text = "Базовый актив";
			this.splitContainer2.Dock = System.Windows.Forms.DockStyle.Fill;
			this.splitContainer2.Location = new System.Drawing.Point(0, 0);
			this.splitContainer2.Name = "splitContainer2";
			this.splitContainer2.Panel1.Controls.Add(this.chart1);
			this.splitContainer2.Panel2.Controls.Add(this.chart2);
			this.splitContainer2.Size = new System.Drawing.Size(801, 618);
			this.splitContainer2.SplitterDistance = 770;
			this.splitContainer2.TabIndex = 0;
			chartArea1.Name = "ChartArea1";
			this.chart1.ChartAreas.Add(chartArea1);
			this.chart1.Dock = System.Windows.Forms.DockStyle.Fill;
			legend1.Name = "Legend1";
			this.chart1.Legends.Add(legend1);
			this.chart1.Location = new System.Drawing.Point(0, 0);
			this.chart1.Name = "chart1";
			this.chart1.Size = new System.Drawing.Size(770, 618);
			this.chart1.TabIndex = 0;
			this.chart1.Text = "chart1";
			this.chart1.MouseMove += new System.Windows.Forms.MouseEventHandler(chart1_MouseMove);
			chartArea2.Name = "ChartArea1";
			this.chart2.ChartAreas.Add(chartArea2);
			this.chart2.Dock = System.Windows.Forms.DockStyle.Fill;
			legend2.Name = "Legend1";
			this.chart2.Legends.Add(legend2);
			this.chart2.Location = new System.Drawing.Point(0, 0);
			this.chart2.Name = "chart2";
			this.chart2.Size = new System.Drawing.Size(27, 618);
			this.chart2.TabIndex = 0;
			this.chart2.Text = "chart2";
			this.contextMenuStripCalendarInfo.Items.AddRange(new System.Windows.Forms.ToolStripItem[3] { this.toolStripMenuItemUpdate, this.toolStripMenuItemApply, this.toolStripMenuItemSortMethod });
			this.contextMenuStripCalendarInfo.Name = "contextMenuStripCalendarInfo";
			this.contextMenuStripCalendarInfo.Size = new System.Drawing.Size(177, 70);
			this.toolStripMenuItemUpdate.Image = (System.Drawing.Image)resources.GetObject("toolStripMenuItemUpdate.Image");
			this.toolStripMenuItemUpdate.Name = "toolStripMenuItemUpdate";
			this.toolStripMenuItemUpdate.Size = new System.Drawing.Size(176, 22);
			this.toolStripMenuItemUpdate.Text = "Обновить таблицу";
			this.toolStripMenuItemUpdate.Click += new System.EventHandler(toolStripMenuItemUpdate_Click);
			this.toolStripMenuItemApply.Image = (System.Drawing.Image)resources.GetObject("toolStripMenuItemApply.Image");
			this.toolStripMenuItemApply.Name = "toolStripMenuItemApply";
			this.toolStripMenuItemApply.Size = new System.Drawing.Size(176, 22);
			this.toolStripMenuItemApply.Text = "Применить";
			this.toolStripMenuItemApply.Click += new System.EventHandler(toolStripMenuItemApply_Click);
			this.toolStripMenuItemSortMethod.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[2] { this.toolStripMenuItemBaseAssets, this.toolStripMenuItemSpread });
			this.toolStripMenuItemSortMethod.Name = "toolStripMenuItemSortMethod";
			this.toolStripMenuItemSortMethod.Size = new System.Drawing.Size(176, 22);
			this.toolStripMenuItemSortMethod.Text = "Сортировка";
			this.toolStripMenuItemBaseAssets.Name = "toolStripMenuItemBaseAssets";
			this.toolStripMenuItemBaseAssets.Size = new System.Drawing.Size(162, 22);
			this.toolStripMenuItemBaseAssets.Text = "По баз. активам";
			this.toolStripMenuItemBaseAssets.Click += new System.EventHandler(toolStripMenuItemBaseAssets_Click);
			this.toolStripMenuItemSpread.Name = "toolStripMenuItemSpread";
			this.toolStripMenuItemSpread.Size = new System.Drawing.Size(162, 22);
			this.toolStripMenuItemSpread.Text = "По спреду";
			this.toolStripMenuItemSpread.Click += new System.EventHandler(toolStripMenuItemSpread_Click);
			this.contextMenuStripSmile.Items.AddRange(new System.Windows.Forms.ToolStripItem[1] { this.ToolStripMenuItemGlass });
			this.contextMenuStripSmile.Name = "contextMenuStripSmile";
			this.contextMenuStripSmile.Size = new System.Drawing.Size(113, 26);
			this.contextMenuStripSmile.Opening += new System.ComponentModel.CancelEventHandler(contextMenuStripSmile_Opening);
			this.ToolStripMenuItemGlass.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[2] { this.ToolStripMenuItemInstrument1, this.ToolStripMenuItemInstrument2 });
			this.ToolStripMenuItemGlass.Name = "ToolStripMenuItemGlass";
			this.ToolStripMenuItemGlass.Size = new System.Drawing.Size(112, 22);
			this.ToolStripMenuItemGlass.Text = "Стакан";
			this.ToolStripMenuItemInstrument1.Name = "ToolStripMenuItemInstrument1";
			this.ToolStripMenuItemInstrument1.Size = new System.Drawing.Size(150, 22);
			this.ToolStripMenuItemInstrument1.Text = "Инструмент 1";
			this.ToolStripMenuItemInstrument1.Click += new System.EventHandler(ToolStripMenuItemInstrument1_Click);
			this.ToolStripMenuItemInstrument2.Name = "ToolStripMenuItemInstrument2";
			this.ToolStripMenuItemInstrument2.Size = new System.Drawing.Size(150, 22);
			this.ToolStripMenuItemInstrument2.Text = "Инструмент 2";
			this.ToolStripMenuItemInstrument2.Click += new System.EventHandler(ToolStripMenuItemInstrument2_Click);
			base.AutoScaleDimensions = new System.Drawing.SizeF(6f, 13f);
			base.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
			base.ClientSize = new System.Drawing.Size(1162, 618);
			base.Controls.Add(this.splitContainer1);
			base.Load += new System.EventHandler(FormSmile_Load);
			this.splitContainer1.Panel1.ResumeLayout(false);
			this.splitContainer1.Panel1.PerformLayout();
			this.splitContainer1.Panel2.ResumeLayout(false);
			this.splitContainer1.EndInit();
			this.splitContainer1.ResumeLayout(false);
			this.groupBoxModelSmile.ResumeLayout(false);
			this.groupBoxModelSmile.PerformLayout();
			this.numericUpDownModelSmileKink.EndInit();
			this.numericUpDownModelSmileSkew.EndInit();
			this.numericUpDownModelSmileVolatility.EndInit();
			this.groupBoxCalendarInfo.ResumeLayout(false);
			((System.ComponentModel.ISupportInitialize)this.dataGridViewCalendarInfo).EndInit();
			this.groupBox3.ResumeLayout(false);
			this.groupBox3.PerformLayout();
			this.groupBox2.ResumeLayout(false);
			this.groupBox2.PerformLayout();
			this.groupBox1.ResumeLayout(false);
			this.groupBox1.PerformLayout();
			this.splitContainer2.Panel1.ResumeLayout(false);
			this.splitContainer2.Panel2.ResumeLayout(false);
			this.splitContainer2.EndInit();
			this.splitContainer2.ResumeLayout(false);
			this.chart1.EndInit();
			this.chart2.EndInit();
			this.contextMenuStripCalendarInfo.ResumeLayout(false);
			this.contextMenuStripSmile.ResumeLayout(false);
			base.ResumeLayout(false);
		}
	}
}
