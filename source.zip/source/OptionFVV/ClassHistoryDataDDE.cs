using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using System.Windows.Forms;

namespace OptionFVV
{
	internal class ClassHistoryDataDDE
	{
		public struct Quotes
		{
			public string paper_code;

			public DateTime expiration_date;

			public string base_asset;

			public double demand;

			public double sentence;

			public double last_price;

			public double strike;

			public string option_type;

			public double volatility;

			public double teoretical_price;

			public double step_price;
		}

		private ClassDataDDE cDataDDE = new ClassDataDDE(false);

		private static string gFileName;

		private static string gFolderName;

		private string CurrentDirectory;

		public static List<Quotes> QuotesTable = new List<Quotes>();

		public static Quotes QuotesPaper = default(Quotes);

		public string FileName
		{
			get
			{
				return gFileName;
			}
			set
			{
				gFileName = value;
			}
		}

		public string FolderName
		{
			get
			{
				return gFolderName;
			}
		}

		public ClassHistoryDataDDE()
		{
			gFileName = "";
			gFolderName = "";
			CurrentDirectory = Application.StartupPath;
			gFolderName = CurrentDirectory + "\\History";
		}

		public bool WriteFileHistory()
		{
			bool flag = true;
			string path = gFolderName + "\\" + gFileName + ".txt";
			if (CheckFolderHistory())
			{
				StreamWriter streamWriter = new StreamWriter(path, false);
				lock (ClassDataDDE.QuotesTable)
				{
					for (int index = 0; index < ClassDataDDE.QuotesTable.Count; index++)
					{
						streamWriter.WriteLine(Convert.ToString(ClassDataDDE.QuotesTable[index].paper_code) + ";" + Convert.ToString(ClassDataDDE.QuotesTable[index].expiration_date) + ";" + Convert.ToString(ClassDataDDE.QuotesTable[index].base_asset) + ";" + Convert.ToString(ClassDataDDE.QuotesTable[index].demand) + ";" + Convert.ToString(ClassDataDDE.QuotesTable[index].sentence) + ";" + Convert.ToString(ClassDataDDE.QuotesTable[index].last_price) + ";" + Convert.ToString(ClassDataDDE.QuotesTable[index].strike) + ";" + Convert.ToString(ClassDataDDE.QuotesTable[index].option_type) + ";" + Convert.ToString(ClassDataDDE.QuotesTable[index].volatility) + ";" + Convert.ToString(ClassDataDDE.QuotesTable[index].teoretical_price) + ";" + Convert.ToString(ClassDataDDE.QuotesTable[index].step_price));
					}
				}
				streamWriter.Close();
			}
			return flag;
		}

		public bool ReadFileHistory()
		{
			Quotes quotes = default(Quotes);
			bool flag = true;
			string path = gFolderName + "\\" + gFileName + ".txt";
			QuotesTable.Clear();
			if (File.Exists(path))
			{
				try
				{
					StreamReader streamReader = new StreamReader(path);
					while (streamReader.Peek() != -1)
					{
						string[] strArray = streamReader.ReadLine().Split(';');
						quotes.paper_code = Convert.ToString(strArray[0]);
						quotes.expiration_date = Convert.ToDateTime(strArray[1]);
						quotes.base_asset = Convert.ToString(strArray[2]);
						if (double.TryParse(Convert.ToString(strArray[3]), out quotes.demand))
						{
							if (quotes.demand < 0.0)
							{
								quotes.demand = 0.0;
							}
						}
						else
						{
							quotes.demand = 0.0;
						}
						if (double.TryParse(Convert.ToString(strArray[4]), out quotes.sentence))
						{
							if (quotes.sentence < 0.0)
							{
								quotes.sentence = 0.0;
							}
						}
						else
						{
							quotes.sentence = 0.0;
						}
						if (double.TryParse(Convert.ToString(strArray[5]), out quotes.last_price))
						{
							if (quotes.last_price < 0.0)
							{
								quotes.last_price = 0.0;
							}
						}
						else
						{
							quotes.last_price = 0.0;
						}
						if (double.TryParse(Convert.ToString(strArray[6]), out quotes.strike))
						{
							if (quotes.strike < 0.0)
							{
								quotes.strike = 0.0;
							}
						}
						else
						{
							quotes.strike = 0.0;
						}
						quotes.option_type = Convert.ToString(strArray[7]);
						if (double.TryParse(Convert.ToString(strArray[8]), out quotes.volatility))
						{
							if (quotes.volatility < 0.0)
							{
								quotes.volatility = 0.0;
							}
						}
						else
						{
							quotes.volatility = 0.0;
						}
						if (double.TryParse(Convert.ToString(strArray[9]), out quotes.teoretical_price))
						{
							if (quotes.teoretical_price < 0.0)
							{
								quotes.teoretical_price = 0.0;
							}
						}
						else
						{
							quotes.teoretical_price = 0.0;
						}
						if (double.TryParse(Convert.ToString(strArray[9]), out quotes.step_price))
						{
							if (quotes.step_price < 0.0)
							{
								quotes.step_price = 0.0;
							}
						}
						else
						{
							quotes.step_price = 0.0;
						}
						QuotesTable.Add(quotes);
					}
				}
				catch
				{
				}
			}
			return flag;
		}

		public bool CheckFolderHistory()
		{
			DirectoryInfo directoryInfo = new DirectoryInfo(gFolderName);
			bool flag;
			if (directoryInfo.Exists)
			{
				flag = true;
			}
			else
			{
				flag = true;
				try
				{
					directoryInfo.Create();
				}
				catch
				{
					flag = false;
				}
			}
			return flag;
		}

		public bool SearchPaper(DateTime expiration_date, string base_asset, double strike, string option_type)
		{
			bool flag = false;
			for (int index = 0; index < QuotesTable.Count; index++)
			{
				if (QuotesTable[index].expiration_date.Date == expiration_date.Date && QuotesTable[index].base_asset == base_asset && QuotesTable[index].strike == strike && QuotesTable[index].option_type == option_type)
				{
					QuotesPaper.paper_code = QuotesTable[index].paper_code;
					QuotesPaper.expiration_date = QuotesTable[index].expiration_date;
					QuotesPaper.base_asset = QuotesTable[index].base_asset;
					QuotesPaper.demand = QuotesTable[index].demand;
					QuotesPaper.sentence = QuotesTable[index].sentence;
					QuotesPaper.last_price = QuotesTable[index].last_price;
					QuotesPaper.strike = QuotesTable[index].strike;
					QuotesPaper.option_type = QuotesTable[index].option_type;
					QuotesPaper.volatility = QuotesTable[index].volatility;
					QuotesPaper.teoretical_price = QuotesTable[index].teoretical_price;
					QuotesPaper.step_price = QuotesTable[index].step_price;
					flag = true;
					break;
				}
			}
			return flag;
		}

		public void OpenFile()
		{
			string str = gFolderName + "\\" + gFileName + ".txt";
			if (File.Exists(str))
			{
				try
				{
					Process.Start(str);
					return;
				}
				catch
				{
					return;
				}
			}
			int num = (int)MessageBox.Show("Пока файл не создан");
		}

		public void DeleteFile()
		{
			string path = gFolderName + "\\" + gFileName + ".txt";
			if (File.Exists(path))
			{
				try
				{
					File.Delete(path);
					return;
				}
				catch
				{
					return;
				}
			}
			int num = (int)MessageBox.Show("Файла не существует");
		}
	}
}
