using System;

namespace OptionFVV
{
	internal class BlackSholes
	{
		public double CalcD1(double S, double K, double t, double sigma, double r = 0.0, double q = 0.0)
		{
			return (Math.Log(S / K) + (r - q + Math.Pow(sigma, 2.0) / 2.0) * t) / (sigma * Math.Pow(t, 0.5));
		}

		public double CalcD2(double d1, double t, double sigma)
		{
			return d1 - sigma * Math.Pow(t, 0.5);
		}

		public double Dnorm(double d)
		{
			return Math.Exp(-1.0 * Math.Pow(d, 2.0) / 2.0) / Math.Pow(Math.PI * 2.0, 0.5);
		}

		public double Pnorm(double d)
		{
			double d2 = Dnorm(d);
			double d3 = 1.0 / (1.0 + 0.2316419 * Math.Abs(d));
			double d4 = d2 * (0.31938153 * d3 + -0.356563782 * Math.Pow(d3, 2.0) + 1.781477937 * Math.Pow(d3, 3.0) + -1.821255978 * Math.Pow(d3, 4.0) + 1.330274429 * Math.Pow(d3, 5.0));
			if (d >= 0.0)
			{
				d4 = 1.0 - d4;
			}
			return d4;
		}

		public double TheoPricePut(double S, double K, double t, double sigma, double r = 0.0, double q = 0.0)
		{
			double d1 = CalcD1(S, K, t, sigma, r, q);
			double d2 = CalcD2(d1, t, sigma);
			return Math.Exp((0.0 - r) * t) * K * Pnorm(0.0 - d2) - Math.Exp((0.0 - q) * t) * S * Pnorm(0.0 - d1);
		}

		public double TheoPriceCall(double S, double K, double t, double sigma, double r = 0.0, double q = 0.0)
		{
			double d1 = CalcD1(S, K, t, sigma, r, q);
			double d2 = CalcD2(d1, t, sigma);
			return Math.Exp((0.0 - q) * t) * S * Pnorm(d1) - Math.Exp((0.0 - r) * t) * K * Pnorm(d2);
		}

		public double DeltaPut(double S, double K, double t, double sigma, double r = 0.0, double q = 0.0)
		{
			double d1 = CalcD1(S, K, t, sigma, r, q);
			return (0.0 - Math.Exp((0.0 - r) * t)) * Pnorm(0.0 - d1);
		}

		public double DeltaCall(double S, double K, double t, double sigma, double r = 0.0, double q = 0.0)
		{
			double d1 = CalcD1(S, K, t, sigma, r, q);
			return Math.Exp((0.0 - r) * t) * Pnorm(d1);
		}

		public double ThetaPut(double S, double K, double t, double sigma, double r = 0.0, double q = 0.0)
		{
			double d1 = CalcD1(S, K, t, sigma, r, q);
			double d2 = CalcD2(d1, t, sigma);
			return (0.0 - Math.Exp((0.0 - q) * t)) * (S * Dnorm(d1) * sigma) / (2.0 * Math.Sqrt(t)) + r * K * Math.Exp((0.0 - r) * t) * Pnorm(0.0 - d2) - q * S * Math.Exp((0.0 - q) * t) * Pnorm(0.0 - d1);
		}

		public double ThetaCall(double S, double K, double t, double sigma, double r = 0.0, double q = 0.0)
		{
			double d1 = CalcD1(S, K, t, sigma, r, q);
			double d2 = CalcD2(d1, t, sigma);
			return (0.0 - Math.Exp((0.0 - q) * t)) * (S * Dnorm(d1) * sigma) / (2.0 * Math.Sqrt(t)) - r * K * Math.Exp((0.0 - r) * t) * Pnorm(d2) + q * S * Math.Exp((0.0 - q) * t) * Pnorm(d1);
		}

		public double RhoPut(double S, double K, double t, double sigma, double r = 0.0, double q = 0.0)
		{
			double d1 = CalcD1(S, K, t, sigma, r, q);
			double d2 = CalcD2(d1, t, sigma);
			return (0.0 - K) * t * Math.Exp((0.0 - r) * t) * Pnorm(0.0 - d2);
		}

		public double RhoCall(double S, double K, double t, double sigma, double r = 0.0, double q = 0.0)
		{
			double d1 = CalcD1(S, K, t, sigma, r, q);
			double d2 = CalcD2(d1, t, sigma);
			return K * t * Math.Exp((0.0 - r) * t) * Pnorm(d2);
		}

		public double Gamma(double S, double K, double t, double sigma, double r = 0.0, double q = 0.0)
		{
			double d1 = CalcD1(S, K, t, sigma, r, q);
			return Math.Exp((0.0 - q) * t) * (Dnorm(d1) / (S * sigma * Math.Sqrt(t)));
		}

		public double Vanna(double S, double K, double t, double sigma, double r = 0.0, double q = 0.0)
		{
			double d1 = CalcD1(S, K, t, sigma, r, q);
			double d2 = CalcD2(d1, t, sigma);
			return (0.0 - Math.Exp((0.0 - q) * t)) * Dnorm(d1) * (d2 / sigma);
		}

		public double CharmPut(double S, double K, double t, double sigma, double r = 0.0, double q = 0.0)
		{
			double d1 = CalcD1(S, K, t, sigma, r, q);
			double d2 = CalcD2(d1, t, sigma);
			return (0.0 - q) * Math.Exp((0.0 - q) * t) * Pnorm(0.0 - d1) - Math.Exp((0.0 - q) * t) * Dnorm(d1) * ((2.0 * (r - q) * t - d2 * sigma * Math.Sqrt(t)) / (2.0 * t * sigma * Math.Sqrt(t)));
		}

		public double CharmCall(double S, double K, double t, double sigma, double r = 0.0, double q = 0.0)
		{
			double d1 = CalcD1(S, K, t, sigma, r, q);
			double d2 = CalcD2(d1, t, sigma);
			return q * Math.Exp((0.0 - q) * t) * Pnorm(d1) - Math.Exp((0.0 - q) * t) * Dnorm(d1) * ((2.0 * (r - q) * t - d2 * sigma * Math.Sqrt(t)) / (2.0 * t * sigma * Math.Sqrt(t)));
		}

		public double Vega(double S, double K, double t, double sigma, double r = 0.0, double q = 0.0)
		{
			double d1 = CalcD1(S, K, t, sigma, r, q);
			return S * Math.Exp((0.0 - q) * t) * Dnorm(d1) * Math.Sqrt(t);
		}

		public double Vomma(double S, double K, double t, double sigma, double r = 0.0, double q = 0.0)
		{
			double d1 = CalcD1(S, K, t, sigma, r, q);
			double d2 = CalcD2(d1, t, sigma);
			double vega = Vega(S, K, r, q, t, sigma);
			return vega * (d1 * d2 / sigma);
		}

		public double Speed(double S, double K, double t, double sigma, double r = 0.0, double q = 0.0)
		{
			double d1 = CalcD1(S, K, t, sigma, r, q);
			double gamma = Gamma(S, K, t, sigma, r, q);
			return (0.0 - gamma / S) * (d1 / (sigma * Math.Sqrt(t)) + 1.0);
		}

		public double Zomma(double S, double K, double t, double sigma, double r = 0.0, double q = 0.0)
		{
			double gamma = Gamma(S, K, t, sigma, r, q);
			double d1 = CalcD1(S, K, t, sigma, r, q);
			double d2 = CalcD2(d1, t, sigma);
			return gamma * ((d1 * d2 - 1.0) / sigma);
		}

		public double Color(double S, double K, double t, double sigma, double r = 0.0, double q = 0.0)
		{
			double d1 = CalcD1(S, K, t, sigma, r, q);
			double d2 = CalcD2(d1, t, sigma);
			return (0.0 - Math.Exp((0.0 - q) * t)) * (Dnorm(d1) / (2.0 * S * t * sigma * Math.Sqrt(t))) * (2.0 * q * t + 1.0 + (2.0 * (r - q) * t - d2 * sigma * Math.Sqrt(t)) / (sigma * Math.Sqrt(t)) * d1);
		}

		public double DvegaDtime(double S, double K, double t, double sigma, double r = 0.0, double q = 0.0)
		{
			double d1 = CalcD1(S, K, t, sigma, r, q);
			double d2 = CalcD2(d1, t, sigma);
			return S * Math.Exp((0.0 - q) * t) * Dnorm(d1) * Math.Sqrt(t) * (q + (r - q) * d1 / (sigma * Math.Sqrt(t)) - (1.0 + d1 * d2) / (2.0 * t));
		}

		public double Ultima(double S, double K, double t, double sigma, double r = 0.0, double q = 0.0)
		{
			double d1 = CalcD1(S, K, t, sigma, r, q);
			double d2 = CalcD2(d1, t, sigma);
			double vega = Vega(S, K, t, sigma, r, q);
			return (0.0 - vega) / Math.Pow(sigma, 2.0) * (d1 * d2 * (1.0 - d1 * d2) + Math.Pow(d1, 2.0) + Math.Pow(d2, 2.0));
		}
	}
}
