using System.Diagnostics;
using System.IO;
using System.Windows.Forms;

namespace OptionFVV
{
	internal class ClassSettings
	{
		public static string gFileName;

		public static string gUpdateTime;

		public static string gColorTheme;

		public static string gBoardQuantity;

		public static string gBoardTheme;

		public static string gBoardBaseAsset;

		public static string gBoardExpirationDate;

		public static string gCurrentStrategy;

		public static string gCurrentTab;

		public static string gChartStepGridX;

		public static string gChartStepGridY;

		public static string gChartIndentUp;

		public static string gChartIndentDn;

		public static string gChartQuantityStandartDeviation;

		public static string gChartQuantityDaysStandartDeviation;

		public static string gChartCheckBoxChartCurrent;

		public static string gChartCheckBoxChartAddD1;

		public static string gChartCheckBoxChartAddD2;

		public static string gChartCheckBoxChartExpiration;

		public static string gChartTextBoxAddD1;

		public static string gChartTextBoxAddD2;

		public static string gChartCheckBoxStepGridYAuto;

		public static string gSmileBaseAsset1;

		public static string gSmileExpirationDate1;

		public static string gSmileDemandSentence1;

		public static string gSmileHistory1;

		public static string gSmileBaseAsset2;

		public static string gSmileExpirationDate2;

		public static string gSmileDemandSentence2;

		public static string gSmileStepGridX;

		public static string gSmileStepGridY;

		public static string gSmileIndentUp;

		public static string gSmileIndentDn;

		public static string gSmileSortMethod;

		public static string gSmileCheckBoxModelSmile;

		public static string gSmileModelSkew;

		public static string gSmileModelKink;

		public static string gSmileModelVolatility;

		public static string gSmileCheckBoxModelVolatility;

		public static string gAccount;

		public static string dde_prefix;

		public static bool abs_whatif;

		public static bool optspot_hedge_fut;

		public static string gSlippageDH;

		public static string gFolderSetupQuik;

		public string FileName
		{
			get
			{
				return gFileName;
			}
			set
			{
				gFileName = value;
			}
		}

		public string UpdateTime
		{
			get
			{
				return gUpdateTime;
			}
			set
			{
				gUpdateTime = value;
			}
		}

		public string ColorTheme
		{
			get
			{
				return gColorTheme;
			}
			set
			{
				gColorTheme = value;
			}
		}

		public string BoardQuantity
		{
			get
			{
				return gBoardQuantity;
			}
			set
			{
				gBoardQuantity = value;
			}
		}

		public string BoardTheme
		{
			get
			{
				return gBoardTheme;
			}
			set
			{
				gBoardTheme = value;
			}
		}

		public string BoardBaseAsset
		{
			get
			{
				return gBoardBaseAsset;
			}
			set
			{
				gBoardBaseAsset = value;
			}
		}

		public string BoardExpirationDate
		{
			get
			{
				return gBoardExpirationDate;
			}
			set
			{
				gBoardExpirationDate = value;
			}
		}

		public string CurrentStrategy
		{
			get
			{
				return gCurrentStrategy;
			}
			set
			{
				gCurrentStrategy = value;
			}
		}

		public string CurrentTab
		{
			get
			{
				return gCurrentTab;
			}
			set
			{
				gCurrentTab = value;
			}
		}

		public string ChartStepGridX
		{
			get
			{
				return gChartStepGridX;
			}
			set
			{
				gChartStepGridX = value;
			}
		}

		public string ChartStepGridY
		{
			get
			{
				return gChartStepGridY;
			}
			set
			{
				gChartStepGridY = value;
			}
		}

		public string ChartIndentUp
		{
			get
			{
				return gChartIndentUp;
			}
			set
			{
				gChartIndentUp = value;
			}
		}

		public string ChartIndentDn
		{
			get
			{
				return gChartIndentDn;
			}
			set
			{
				gChartIndentDn = value;
			}
		}

		public string ChartQuantityStandartDeviation
		{
			get
			{
				return gChartQuantityStandartDeviation;
			}
			set
			{
				gChartQuantityStandartDeviation = value;
			}
		}

		public string ChartQuantityDaysStandartDeviation
		{
			get
			{
				return gChartQuantityDaysStandartDeviation;
			}
			set
			{
				gChartQuantityDaysStandartDeviation = value;
			}
		}

		public string ChartCheckBoxChartCurrent
		{
			get
			{
				return gChartCheckBoxChartCurrent;
			}
			set
			{
				gChartCheckBoxChartCurrent = value;
			}
		}

		public string ChartCheckBoxChartAddD1
		{
			get
			{
				return gChartCheckBoxChartAddD1;
			}
			set
			{
				gChartCheckBoxChartAddD1 = value;
			}
		}

		public string ChartCheckBoxChartAddD2
		{
			get
			{
				return gChartCheckBoxChartAddD2;
			}
			set
			{
				gChartCheckBoxChartAddD2 = value;
			}
		}

		public string ChartCheckBoxChartExpiration
		{
			get
			{
				return gChartCheckBoxChartExpiration;
			}
			set
			{
				gChartCheckBoxChartExpiration = value;
			}
		}

		public string ChartTextBoxAddD1
		{
			get
			{
				return gChartTextBoxAddD1;
			}
			set
			{
				gChartTextBoxAddD1 = value;
			}
		}

		public string ChartTextBoxAddD2
		{
			get
			{
				return gChartTextBoxAddD2;
			}
			set
			{
				gChartTextBoxAddD1 = value;
			}
		}

		public string ChartCheckBoxStepGridYAuto
		{
			get
			{
				return gChartCheckBoxStepGridYAuto;
			}
			set
			{
				gChartCheckBoxStepGridYAuto = value;
			}
		}

		public string SmileBaseAsset1
		{
			get
			{
				return gSmileBaseAsset1;
			}
			set
			{
				gSmileBaseAsset1 = value;
			}
		}

		public string SmileExpirationDate1
		{
			get
			{
				return gSmileExpirationDate1;
			}
			set
			{
				gSmileExpirationDate1 = value;
			}
		}

		public string SmileDemandSentence1
		{
			get
			{
				return gSmileDemandSentence1;
			}
			set
			{
				gSmileDemandSentence1 = value;
			}
		}

		public string SmileHistory1
		{
			get
			{
				return gSmileHistory1;
			}
			set
			{
				gSmileHistory1 = value;
			}
		}

		public string SmileBaseAsset2
		{
			get
			{
				return gSmileBaseAsset2;
			}
			set
			{
				gSmileBaseAsset2 = value;
			}
		}

		public string SmileExpirationDate2
		{
			get
			{
				return gSmileExpirationDate2;
			}
			set
			{
				gSmileExpirationDate2 = value;
			}
		}

		public string SmileDemandSentence2
		{
			get
			{
				return gSmileDemandSentence2;
			}
			set
			{
				gSmileDemandSentence2 = value;
			}
		}

		public string SmileStepGridX
		{
			get
			{
				return gSmileStepGridX;
			}
			set
			{
				gSmileStepGridX = value;
			}
		}

		public string SmileStepGridY
		{
			get
			{
				return gSmileStepGridY;
			}
			set
			{
				gSmileStepGridY = value;
			}
		}

		public string SmileIndentUp
		{
			get
			{
				return gSmileIndentUp;
			}
			set
			{
				gSmileIndentUp = value;
			}
		}

		public string SmileIndentDn
		{
			get
			{
				return gSmileIndentDn;
			}
			set
			{
				gSmileIndentDn = value;
			}
		}

		public string SmileSortMethod
		{
			get
			{
				return gSmileSortMethod;
			}
			set
			{
				gSmileSortMethod = value;
			}
		}

		public string SmileCheckBoxModelSmile
		{
			get
			{
				return gSmileCheckBoxModelSmile;
			}
			set
			{
				gSmileCheckBoxModelSmile = value;
			}
		}

		public string SmileModelSkew
		{
			get
			{
				return gSmileModelSkew;
			}
			set
			{
				gSmileModelSkew = value;
			}
		}

		public string SmileModelKink
		{
			get
			{
				return gSmileModelKink;
			}
			set
			{
				gSmileModelKink = value;
			}
		}

		public string SmileModelVolatility
		{
			get
			{
				return gSmileModelVolatility;
			}
			set
			{
				gSmileModelVolatility = value;
			}
		}

		public string SmileCheckBoxModelVolatility
		{
			get
			{
				return gSmileCheckBoxModelVolatility;
			}
			set
			{
				gSmileCheckBoxModelVolatility = value;
			}
		}

		public string Account
		{
			get
			{
				return gAccount;
			}
			set
			{
				gAccount = value;
			}
		}

		public string DDEPrefix
		{
			get
			{
				return dde_prefix;
			}
			set
			{
				dde_prefix = value;
			}
		}

		public bool AbsWhatIf
		{
			get
			{
				return abs_whatif;
			}
			set
			{
				abs_whatif = value;
			}
		}

		public bool OptspotHedgeFut
		{
			get
			{
				return optspot_hedge_fut;
			}
			set
			{
				optspot_hedge_fut = value;
			}
		}

		public string SlippageDH
		{
			get
			{
				return gSlippageDH;
			}
			set
			{
				gSlippageDH = value;
			}
		}

		public string FolderSetupQuik
		{
			get
			{
				return gFolderSetupQuik;
			}
			set
			{
				gFolderSetupQuik = value;
			}
		}

		public ClassSettings(string str)
		{
			gFileName = str;
			gUpdateTime = "5000";
			gColorTheme = "Витек";
			gBoardQuantity = "";
			gBoardTheme = "";
			gBoardBaseAsset = "";
			gBoardExpirationDate = "";
			gCurrentStrategy = "";
			gCurrentTab = "tabPageBoard";
			gChartStepGridX = "2500";
			gChartStepGridY = "1000";
			gChartIndentUp = "30";
			gChartIndentDn = "30";
			gChartQuantityStandartDeviation = "2";
			gChartQuantityDaysStandartDeviation = "1";
			gChartCheckBoxChartCurrent = "True";
			gChartCheckBoxChartAddD1 = "True";
			gChartCheckBoxChartAddD2 = "True";
			gChartCheckBoxChartExpiration = "True";
			gChartTextBoxAddD1 = "7";
			gChartTextBoxAddD2 = "14";
			gChartCheckBoxStepGridYAuto = "True";
			gSmileBaseAsset1 = "";
			gSmileExpirationDate1 = "";
			gSmileDemandSentence1 = "NULL";
			gSmileHistory1 = "NULL";
			gSmileBaseAsset2 = "";
			gSmileExpirationDate2 = "";
			gSmileDemandSentence2 = "NULL";
			gSmileStepGridX = "2500";
			gSmileStepGridY = "1";
			gSmileIndentUp = "30";
			gSmileIndentDn = "30";
			gSmileSortMethod = "1";
			gSmileCheckBoxModelSmile = "True";
			gSmileModelSkew = "-0,4648";
			gSmileModelKink = "1,5";
			gSmileModelVolatility = "30";
			gSmileCheckBoxModelVolatility = "True";
			gAccount = "";
			abs_whatif = true;
			optspot_hedge_fut = true;
			dde_prefix = "";
			gSlippageDH = "0";
			gFolderSetupQuik = "";
		}

		public bool WriteFileSettings()
		{
			bool flag = true;
			StreamWriter streamWriter = new StreamWriter(gFileName, false);
			streamWriter.WriteLine("UpdateTime;" + gUpdateTime);
			streamWriter.WriteLine("ColorTheme;" + gColorTheme);
			streamWriter.WriteLine("BoardQuantity;" + gBoardQuantity);
			streamWriter.WriteLine("BoardTheme;" + gBoardTheme);
			streamWriter.WriteLine("BoardBaseAsset;" + gBoardBaseAsset);
			streamWriter.WriteLine("BoardExpirationDate;" + gBoardExpirationDate);
			streamWriter.WriteLine("CurrentStrategy;" + gCurrentStrategy);
			streamWriter.WriteLine("CurrentTab;" + gCurrentTab);
			streamWriter.WriteLine("ChartStepGridX;" + gChartStepGridX);
			streamWriter.WriteLine("ChartStepGridY;" + gChartStepGridY);
			streamWriter.WriteLine("ChartIndentUp;" + gChartIndentUp);
			streamWriter.WriteLine("ChartIndentDn;" + gChartIndentDn);
			streamWriter.WriteLine("ChartQuantityStandartDeviation;" + gChartQuantityStandartDeviation);
			streamWriter.WriteLine("ChartQuantityDaysStandartDeviation;" + gChartQuantityDaysStandartDeviation);
			streamWriter.WriteLine("ChartCheckBoxChartCurrent;" + gChartCheckBoxChartCurrent);
			streamWriter.WriteLine("ChartCheckBoxChartAddD1;" + gChartCheckBoxChartAddD1);
			streamWriter.WriteLine("ChartCheckBoxChartAddD2;" + gChartCheckBoxChartAddD2);
			streamWriter.WriteLine("ChartCheckBoxChartExpiration;" + gChartCheckBoxChartExpiration);
			streamWriter.WriteLine("ChartTextBoxAddD1;" + gChartTextBoxAddD1);
			streamWriter.WriteLine("ChartTextBoxAddD2;" + gChartTextBoxAddD2);
			streamWriter.WriteLine("ChartCheckBoxStepGridYAuto;" + gChartCheckBoxStepGridYAuto);
			streamWriter.WriteLine("SmileBaseAsset1;" + gSmileBaseAsset1);
			streamWriter.WriteLine("SmileExpirationDate1;" + gSmileExpirationDate1);
			streamWriter.WriteLine("SmileDemandSentence1;" + gSmileDemandSentence1);
			streamWriter.WriteLine("SmileHistory1;" + gSmileHistory1);
			streamWriter.WriteLine("SmileBaseAsset2;" + gSmileBaseAsset2);
			streamWriter.WriteLine("SmileExpirationDate2;" + gSmileExpirationDate2);
			streamWriter.WriteLine("SmileDemandSentence2;" + gSmileDemandSentence2);
			streamWriter.WriteLine("SmileStepGridX;" + gSmileStepGridX);
			streamWriter.WriteLine("SmileStepGridY;" + gSmileStepGridY);
			streamWriter.WriteLine("SmileIndentUp;" + gSmileIndentUp);
			streamWriter.WriteLine("SmileIndentDn;" + gSmileIndentDn);
			streamWriter.WriteLine("SmileSortMethod;" + gSmileSortMethod);
			streamWriter.WriteLine("SmileCheckBoxModelSmile;" + gSmileCheckBoxModelSmile);
			streamWriter.WriteLine("SmileModelSkew;" + gSmileModelSkew);
			streamWriter.WriteLine("SmileModelKink;" + gSmileModelKink);
			streamWriter.WriteLine("SmileModelVolatility;" + gSmileModelVolatility);
			streamWriter.WriteLine("SmileCheckBoxModelVolatility;" + gSmileCheckBoxModelVolatility);
			streamWriter.WriteLine("Account;" + gAccount);
			streamWriter.WriteLine("DDEPrefix;" + dde_prefix);
			streamWriter.WriteLine("AbsWhatIf;" + abs_whatif);
			streamWriter.WriteLine("OptspotHedgeFut;" + optspot_hedge_fut);
			streamWriter.WriteLine("SlippageDH;" + gSlippageDH);
			streamWriter.WriteLine("FolderSetupQuik;" + gFolderSetupQuik);
			streamWriter.Close();
			return flag;
		}

		public bool ReadFileSettings()
		{
			bool flag = true;
			if (File.Exists(gFileName))
			{
				try
				{
					StreamReader streamReader = new StreamReader(gFileName);
					while (streamReader.Peek() != -1)
					{
						string[] strArray = streamReader.ReadLine().Split(';');
						switch (strArray[0])
						{
						case "Account":
							gAccount = strArray[1];
							break;
						case "DDEPrefix":
							dde_prefix = strArray[1];
							break;
						case "AbsWhatIf":
							abs_whatif = strArray[1].ToLower() == "true";
							break;
						case "OptspotHedgeFut":
							optspot_hedge_fut = strArray[1].ToLower() == "true";
							break;
						case "BoardBaseAsset":
							gBoardBaseAsset = strArray[1];
							break;
						case "BoardExpirationDate":
							gBoardExpirationDate = strArray[1];
							break;
						case "BoardQuantity":
							gBoardQuantity = strArray[1];
							break;
						case "BoardTheme":
							gBoardTheme = strArray[1];
							break;
						case "ChartCheckBoxChartAddD1":
							gChartCheckBoxChartAddD1 = strArray[1];
							break;
						case "ChartCheckBoxChartAddD2":
							gChartCheckBoxChartAddD2 = strArray[1];
							break;
						case "ChartCheckBoxChartCurrent":
							gChartCheckBoxChartCurrent = strArray[1];
							break;
						case "ChartCheckBoxChartExpiration":
							gChartCheckBoxChartExpiration = strArray[1];
							break;
						case "ChartCheckBoxStepGridYAuto":
							gChartCheckBoxStepGridYAuto = strArray[1];
							break;
						case "ChartIndentDn":
							gChartIndentDn = strArray[1];
							break;
						case "ChartIndentUp":
							gChartIndentUp = strArray[1];
							break;
						case "ChartQuantityDaysStandartDeviation":
							gChartQuantityDaysStandartDeviation = strArray[1];
							break;
						case "ChartQuantityStandartDeviation":
							gChartQuantityStandartDeviation = strArray[1];
							break;
						case "ChartStepGridX":
							gChartStepGridX = strArray[1];
							break;
						case "ChartStepGridY":
							gChartStepGridY = strArray[1];
							break;
						case "ChartTextBoxAddD1":
							gChartTextBoxAddD1 = strArray[1];
							break;
						case "ChartTextBoxAddD2":
							gChartTextBoxAddD2 = strArray[1];
							break;
						case "ColorTheme":
							gColorTheme = strArray[1];
							break;
						case "CurrentStrategy":
							gCurrentStrategy = strArray[1];
							break;
						case "CurrentTab":
							gCurrentTab = strArray[1];
							break;
						case "FolderSetupQuik":
							gFolderSetupQuik = strArray[1];
							break;
						case "SlippageDH":
							gSlippageDH = strArray[1];
							break;
						case "SmileBaseAsset1":
							gSmileBaseAsset1 = strArray[1];
							break;
						case "SmileBaseAsset2":
							gSmileBaseAsset2 = strArray[1];
							break;
						case "SmileCheckBoxModelSmile":
							gSmileCheckBoxModelSmile = strArray[1];
							break;
						case "SmileCheckBoxModelVolatility":
							gSmileCheckBoxModelVolatility = strArray[1];
							break;
						case "SmileDemandSentence1":
							gSmileDemandSentence1 = strArray[1];
							break;
						case "SmileDemandSentence2":
							gSmileDemandSentence2 = strArray[1];
							break;
						case "SmileExpirationDate1":
							gSmileExpirationDate1 = strArray[1];
							break;
						case "SmileExpirationDate2":
							gSmileExpirationDate2 = strArray[1];
							break;
						case "SmileHistory1":
							gSmileHistory1 = strArray[1];
							break;
						case "SmileIndentDn":
							gSmileIndentDn = strArray[1];
							break;
						case "SmileIndentUp":
							gSmileIndentUp = strArray[1];
							break;
						case "SmileModelKink":
							gSmileModelKink = strArray[1];
							break;
						case "SmileModelSkew":
							gSmileModelSkew = strArray[1];
							break;
						case "SmileModelVolatility":
							gSmileModelVolatility = strArray[1];
							break;
						case "SmileSortMethod":
							gSmileSortMethod = strArray[1];
							break;
						case "SmileStepGridX":
							gSmileStepGridX = strArray[1];
							break;
						case "SmileStepGridY":
							gSmileStepGridY = strArray[1];
							break;
						case "UpdateTime":
							gUpdateTime = strArray[1];
							break;
						}
					}
				}
				catch
				{
				}
			}
			return flag;
		}

		public void OpenFile()
		{
			if (File.Exists(gFileName))
			{
				try
				{
					Process.Start(gFileName);
					return;
				}
				catch
				{
					return;
				}
			}
			int num = (int)MessageBox.Show("Пока файл не создан");
		}
	}
}
