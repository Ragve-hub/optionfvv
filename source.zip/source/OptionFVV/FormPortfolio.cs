using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Globalization;
using System.IO;
using System.Net;
using System.Text;
using System.Windows.Forms;
using QuikDDE.Data;

namespace OptionFVV
{
	public class FormPortfolio : Form
	{
		private delegate string dGetCurrentStrategy();

		private delegate double dGetDVP();

		private delegate void SetUpdatePortfolio(string fStrategy);

		public struct ModelSmile
		{
			public bool Checked;

			public bool VolatilityChecked;

			public double CurrentStrike;

			public double Volatility;

			public double Skew;

			public double Kink;
		}

		public struct Quotes
		{
			public string paper_code;

			public DateTime expiration_date;

			public string base_asset;

			public double demand;

			public double sentence;

			public double last_price;

			public double strike;

			public string option_type;

			public double volatility;

			public double teoretical_price;

			public double step_price;

			public double decimal_points;

			public bool F;
		}

		public struct Strategy
		{
			public string name_strategy;

			public double profit;

			public double GO;
		}

		public struct Portfolio
		{
			public string paper_code;

			public string base_asset;

			public string option_type;

			public double strike;

			public DateTime expiration_date;

			public DateTime current_date;

			public double volume;

			public double open_price;

			public double open_volatility;

			public double teoretical_price;

			public double futures_price;

			public double profit;

			public double accumulated_profit;

			public double volatility;

			public double delta;

			public double gamma;

			public double vega;

			public double theta;

			public double step_price;

			public int decimal_points;

			public bool check_calculation;

			public bool check;
		}

		public static bool F_Update;

		private Trans2Quik trans_2_quik = new Trans2Quik();

		public static string ClientCode;

		public static bool AbsWhatIf;

		public static double slippage;

		public static double shiftD;

		public static double shiftV1;

		public static double shiftV2;

		public static double shiftP1;

		public static double shiftP2;

		public static int heightPortfolio;

		private string ErrorMessage = "";

		private string symbolDelta = "Δ";

		private string symbolGamma = "Γ";

		private string symbolTheta = "Θ";

		private ClassDataDDE cDataDDE = new ClassDataDDE(false);

		private ClassCalculationOptions cCalculationOptions = new ClassCalculationOptions();

		private FormTransaction fTransaction = new FormTransaction();

		private ClassHistoryDataDDE cHistoryDataDDE = new ClassHistoryDataDDE();

		private ModelSmile ModelSmile1 = default(ModelSmile);

		private Quotes FuturePaper1 = default(Quotes);

		private Quotes FuturePaper2 = default(Quotes);

		public static List<Strategy> StrategyTable = new List<Strategy>();

		private Strategy StrategyPaper = default(Strategy);

		public static List<Portfolio> PortfolioTable = new List<Portfolio>();

		private Portfolio PortfolioPaper = default(Portfolio);

		public static List<Portfolio> PortfolioTableCalculationGO = new List<Portfolio>();

		private Portfolio PortfolioPaperCalculationGO = default(Portfolio);

		public static double FixedProfit = 0.0;

		public static bool CheckFixedProfit = true;

		private IContainer components = null;

		private GroupBox groupBoxPortfolio;

		private ComboBox comboBoxCurrentStrategy;

		private TextBox textBoxPrice;

		private Label label4;

		private TextBox textBoxVola;

		private Label label3;

		private TextBox textBoxDays;

		private Label label2;

		private Button buttonRemoveStrategy;

		private Button buttonCalculateGO;

		private Label labelGO;

		private Button buttonSave;

		private ContextMenuStrip contextMenuStripPortfolio;

		private ToolStripMenuItem ToolStripMenuItemSaveTransaction;

		private TextBox textBoxVola2;

		private Label label5;

		private TextBox textBoxPrice2;

		private Label label6;

		private Label labelP2;

		private Label labelP1;

		private Button buttonHide;

		private DataGridView dataGridViewPortfolio;

		private CheckBox checkBoxDH;

		private NumericUpDown numericUpDownIndentDelta;

		private NumericUpDown numericUpDownDelta;

		private ToolStripMenuItem ToolStripMenuItemGlass;

		private CheckBox checkBoxModelSmile;

		private Button buttonUpdateStrategy;

		private Button buttonApplyStrategy;

		private Label label1;

		public FormPortfolio()
		{
			F_Update = false;
			shiftD = 0.0;
			shiftV1 = 0.0;
			shiftV2 = 0.0;
			shiftP1 = 0.0;
			shiftP2 = 0.0;
			heightPortfolio = 150;
			InitializeComponent();
			StrategyTable.Clear();
			PortfolioTable.Clear();
			PortfolioTableCalculationGO.Clear();
		}

		private void FormPortfolio_Load(object sender, EventArgs e)
		{
			ClientCode = ClassSettings.gAccount;
			CheckFixedProfit = true;
			if (double.TryParse(ClassSettings.gSlippageDH, out slippage))
			{
				if (slippage < 0.0)
				{
					slippage = 0.0;
				}
			}
			else
			{
				slippage = 0.0;
			}
			ModelSmile1.Checked = false;
			ModelSmile1.VolatilityChecked = false;
			ModelSmile1.Volatility = 0.0;
			ModelSmile1.Skew = 0.0;
			ModelSmile1.Kink = 0.0;
			CallBackMy.callbackEventHandlerColorThemeFormPortfolio = PaintColorTheme;
			CallBackMy.callbackEventHandlerAddTransactionFromBoard = AddTransactionFromBoard;
			CallBackMy.callbackEventHandlerCurrentStrategy = GetCurrentStrategy;
			CallBackMy.callbackEventHandlerUpdatePortfolio = UpdatePortfolio;
			CallBackMy.callbackEventHandlerD = GetD;
			CallBackMy.callbackEventHandlerV = GetV;
			CallBackMy.callbackEventHandlerP = GetP;
			base.FormBorderStyle = FormBorderStyle.None;
			Dock = DockStyle.Fill;
			Create();
			dataGridViewPortfolio.EnableHeadersVisualStyles = false;
			dataGridViewPortfolio.AutoGenerateColumns = false;
			dataGridViewPortfolio.SortCompare += grid_SortCompare;
			comboBoxCurrentStrategy.FlatStyle = FlatStyle.System;
			textBoxDays.Text = "0";
			textBoxVola.Text = "0";
			textBoxVola2.Text = "0";
			textBoxPrice.Text = "0";
			textBoxPrice2.Text = "0";
			buttonHide.Text = "_";
			checkBoxDH.Checked = false;
			numericUpDownDelta.Value = 0m;
			numericUpDownIndentDelta.Value = 1m;
			numericUpDownIndentDelta.Minimum = 1m;
			PaintColorTheme();
		}

		private void grid_SortCompare(object sender, DataGridViewSortCompareEventArgs e)
		{
			try
			{
				if (e.RowIndex1 == dataGridViewPortfolio.Rows.Count - 1)
				{
					e.Handled = true;
				}
				if (e.RowIndex2 == dataGridViewPortfolio.Rows.Count - 1)
				{
					e.Handled = true;
				}
			}
			catch (Exception)
			{
			}
		}

		public void Create()
		{
			DataGridViewCheckBoxColumn viewCheckBoxColumn = new DataGridViewCheckBoxColumn();
			viewCheckBoxColumn.HeaderText = "Расчет";
			viewCheckBoxColumn.Name = "Check";
			viewCheckBoxColumn.DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;
			viewCheckBoxColumn.ReadOnly = false;
			viewCheckBoxColumn.Visible = true;
			viewCheckBoxColumn.ToolTipText = "Рассчитывать или нет позицию";
			DataGridViewTextBoxColumn viewTextBoxColumn1 = new DataGridViewTextBoxColumn();
			viewTextBoxColumn1.HeaderText = "Код бумаги";
			viewTextBoxColumn1.Name = "Paper_code";
			viewTextBoxColumn1.DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;
			viewTextBoxColumn1.ReadOnly = true;
			DataGridViewTextBoxColumn viewTextBoxColumn2 = new DataGridViewTextBoxColumn();
			viewTextBoxColumn2.HeaderText = "Тип опциона";
			viewTextBoxColumn2.Name = "Option_type";
			viewTextBoxColumn2.DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;
			viewTextBoxColumn2.ReadOnly = true;
			DataGridViewTextBoxColumn viewTextBoxColumn3 = new DataGridViewTextBoxColumn();
			viewTextBoxColumn3.HeaderText = "Дата погашения";
			viewTextBoxColumn3.Name = "Expiration_date";
			viewTextBoxColumn3.DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;
			viewTextBoxColumn3.ReadOnly = true;
			DataGridViewTextBoxColumn viewTextBoxColumn4 = new DataGridViewTextBoxColumn();
			viewTextBoxColumn4.HeaderText = "Дней до погашения";
			viewTextBoxColumn4.Name = "DaysToExpiration";
			viewTextBoxColumn4.DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;
			viewTextBoxColumn4.ReadOnly = true;
			DataGridViewTextBoxColumn viewTextBoxColumn5 = new DataGridViewTextBoxColumn();
			viewTextBoxColumn5.HeaderText = "Количество";
			viewTextBoxColumn5.Name = "Volume";
			viewTextBoxColumn5.DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;
			viewTextBoxColumn5.ReadOnly = false;
			DataGridViewTextBoxColumn viewTextBoxColumn6 = new DataGridViewTextBoxColumn();
			viewTextBoxColumn6.HeaderText = "Цена открытия";
			viewTextBoxColumn6.Name = "Open_price";
			viewTextBoxColumn6.DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;
			viewTextBoxColumn6.ReadOnly = false;
			DataGridViewTextBoxColumn viewTextBoxColumn7 = new DataGridViewTextBoxColumn();
			viewTextBoxColumn7.HeaderText = "Волатильность открытия";
			viewTextBoxColumn7.Name = "Open_volatility";
			viewTextBoxColumn7.DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;
			viewTextBoxColumn7.ReadOnly = true;
			DataGridViewTextBoxColumn viewTextBoxColumn8 = new DataGridViewTextBoxColumn();
			viewTextBoxColumn8.HeaderText = "Теоретическая цена";
			viewTextBoxColumn8.Name = "Teoretical_price";
			viewTextBoxColumn8.DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;
			viewTextBoxColumn8.ReadOnly = true;
			DataGridViewTextBoxColumn viewTextBoxColumn9 = new DataGridViewTextBoxColumn();
			viewTextBoxColumn9.HeaderText = "Профит";
			viewTextBoxColumn9.Name = "Profit";
			viewTextBoxColumn9.DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;
			viewTextBoxColumn9.ReadOnly = true;
			DataGridViewTextBoxColumn viewTextBoxColumn10 = new DataGridViewTextBoxColumn();
			viewTextBoxColumn10.HeaderText = "Волатильность";
			viewTextBoxColumn10.Name = "Volatility";
			viewTextBoxColumn10.DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;
			viewTextBoxColumn10.ReadOnly = true;
			DataGridViewTextBoxColumn viewTextBoxColumn11 = new DataGridViewTextBoxColumn();
			viewTextBoxColumn11.HeaderText = "Дельта";
			viewTextBoxColumn11.Name = "Delta";
			viewTextBoxColumn11.DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;
			viewTextBoxColumn11.ReadOnly = true;
			DataGridViewTextBoxColumn viewTextBoxColumn12 = new DataGridViewTextBoxColumn();
			viewTextBoxColumn12.HeaderText = "Гамма";
			viewTextBoxColumn12.Name = "Gamma";
			viewTextBoxColumn12.DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;
			viewTextBoxColumn12.ReadOnly = true;
			DataGridViewTextBoxColumn viewTextBoxColumn13 = new DataGridViewTextBoxColumn();
			viewTextBoxColumn13.HeaderText = "Вега";
			viewTextBoxColumn13.Name = "Vega";
			viewTextBoxColumn13.DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;
			viewTextBoxColumn13.ReadOnly = true;
			DataGridViewTextBoxColumn viewTextBoxColumn14 = new DataGridViewTextBoxColumn();
			viewTextBoxColumn14.HeaderText = "Тета";
			viewTextBoxColumn14.Name = "Theta";
			viewTextBoxColumn14.DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;
			viewTextBoxColumn14.ReadOnly = true;
			DataGridViewButtonColumn viewButtonColumn = new DataGridViewButtonColumn();
			viewButtonColumn.HeaderText = "X";
			viewButtonColumn.Name = "Delete";
			viewButtonColumn.DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;
			viewButtonColumn.ReadOnly = true;
			viewButtonColumn.Visible = true;
			viewButtonColumn.ToolTipText = "Удалить позицию";
			viewButtonColumn.Text = "X";
			viewButtonColumn.UseColumnTextForButtonValue = true;
			viewButtonColumn.FlatStyle = FlatStyle.System;
			dataGridViewPortfolio.Columns.Add(viewCheckBoxColumn);
			dataGridViewPortfolio.Columns.Add(viewTextBoxColumn1);
			dataGridViewPortfolio.Columns.Add(viewTextBoxColumn2);
			dataGridViewPortfolio.Columns.Add(viewTextBoxColumn3);
			dataGridViewPortfolio.Columns.Add(viewTextBoxColumn4);
			dataGridViewPortfolio.Columns.Add(viewTextBoxColumn5);
			dataGridViewPortfolio.Columns.Add(viewTextBoxColumn6);
			dataGridViewPortfolio.Columns.Add(viewTextBoxColumn7);
			dataGridViewPortfolio.Columns.Add(viewTextBoxColumn8);
			dataGridViewPortfolio.Columns.Add(viewTextBoxColumn9);
			dataGridViewPortfolio.Columns.Add(viewTextBoxColumn10);
			dataGridViewPortfolio.Columns.Add(viewTextBoxColumn11);
			dataGridViewPortfolio.Columns.Add(viewTextBoxColumn12);
			dataGridViewPortfolio.Columns.Add(viewTextBoxColumn13);
			dataGridViewPortfolio.Columns.Add(viewTextBoxColumn14);
			dataGridViewPortfolio.Columns.Add(viewButtonColumn);
			dataGridViewPortfolio.RowHeadersVisible = false;
			dataGridViewPortfolio.ColumnHeadersDefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;
			viewCheckBoxColumn.AutoSizeMode = DataGridViewAutoSizeColumnMode.None;
			viewCheckBoxColumn.Width = 50;
			viewTextBoxColumn1.AutoSizeMode = DataGridViewAutoSizeColumnMode.Fill;
			viewTextBoxColumn2.AutoSizeMode = DataGridViewAutoSizeColumnMode.DisplayedCells;
			viewTextBoxColumn3.AutoSizeMode = DataGridViewAutoSizeColumnMode.DisplayedCells;
			viewTextBoxColumn4.AutoSizeMode = DataGridViewAutoSizeColumnMode.DisplayedCells;
			viewTextBoxColumn5.AutoSizeMode = DataGridViewAutoSizeColumnMode.DisplayedCells;
			viewTextBoxColumn6.AutoSizeMode = DataGridViewAutoSizeColumnMode.DisplayedCells;
			viewTextBoxColumn7.AutoSizeMode = DataGridViewAutoSizeColumnMode.DisplayedCells;
			viewTextBoxColumn8.AutoSizeMode = DataGridViewAutoSizeColumnMode.DisplayedCells;
			viewTextBoxColumn9.AutoSizeMode = DataGridViewAutoSizeColumnMode.DisplayedCells;
			viewTextBoxColumn10.AutoSizeMode = DataGridViewAutoSizeColumnMode.DisplayedCells;
			viewTextBoxColumn11.AutoSizeMode = DataGridViewAutoSizeColumnMode.DisplayedCells;
			viewTextBoxColumn12.AutoSizeMode = DataGridViewAutoSizeColumnMode.DisplayedCells;
			viewTextBoxColumn13.AutoSizeMode = DataGridViewAutoSizeColumnMode.DisplayedCells;
			viewTextBoxColumn14.AutoSizeMode = DataGridViewAutoSizeColumnMode.DisplayedCells;
			viewButtonColumn.AutoSizeMode = DataGridViewAutoSizeColumnMode.None;
			viewButtonColumn.Width = 25;
			viewTextBoxColumn1.MinimumWidth = 100;
			viewCheckBoxColumn.SortMode = DataGridViewColumnSortMode.NotSortable;
			viewTextBoxColumn1.SortMode = DataGridViewColumnSortMode.Automatic;
			viewTextBoxColumn2.SortMode = DataGridViewColumnSortMode.NotSortable;
			viewTextBoxColumn3.SortMode = DataGridViewColumnSortMode.Automatic;
			viewTextBoxColumn4.SortMode = DataGridViewColumnSortMode.NotSortable;
			viewTextBoxColumn5.SortMode = DataGridViewColumnSortMode.NotSortable;
			viewTextBoxColumn6.SortMode = DataGridViewColumnSortMode.NotSortable;
			viewTextBoxColumn7.SortMode = DataGridViewColumnSortMode.NotSortable;
			viewTextBoxColumn8.SortMode = DataGridViewColumnSortMode.NotSortable;
			viewTextBoxColumn9.SortMode = DataGridViewColumnSortMode.NotSortable;
			viewTextBoxColumn10.SortMode = DataGridViewColumnSortMode.NotSortable;
			viewTextBoxColumn11.SortMode = DataGridViewColumnSortMode.NotSortable;
			viewTextBoxColumn12.SortMode = DataGridViewColumnSortMode.NotSortable;
			viewTextBoxColumn13.SortMode = DataGridViewColumnSortMode.NotSortable;
			viewTextBoxColumn14.SortMode = DataGridViewColumnSortMode.NotSortable;
			viewButtonColumn.SortMode = DataGridViewColumnSortMode.NotSortable;
			dataGridViewPortfolio.ContextMenuStrip = contextMenuStripPortfolio;
		}

		public void CreateStrategyTable()
		{
			StrategyTable.Clear();
			for (int index1 = 0; index1 < FormTransaction.TransactionTable.Count; index1++)
			{
				bool flag = false;
				string strategy = FormTransaction.TransactionTable[index1].strategy;
				if (strategy != "" && StrategyTable.Count == 0)
				{
					StrategyPaper.name_strategy = FormTransaction.TransactionTable[index1].strategy;
					StrategyPaper.profit = 0.0;
					StrategyPaper.GO = 0.0;
					StrategyTable.Add(StrategyPaper);
				}
				else
				{
					if (!(strategy != ""))
					{
						continue;
					}
					for (int i = 0; i < StrategyTable.Count; i++)
					{
						if (strategy == StrategyTable[i].name_strategy)
						{
							flag = true;
							break;
						}
					}
					if (!flag)
					{
						StrategyPaper.name_strategy = FormTransaction.TransactionTable[index1].strategy;
						StrategyPaper.profit = 0.0;
						StrategyPaper.GO = 0.0;
						StrategyTable.Add(StrategyPaper);
					}
				}
			}
		}

		public void FillComboBoxCurrentStrategy(string CurrentStrategy)
		{
			int num = 0;
			bool isFound = false;
			for (int index = 0; index < StrategyTable.Count; index++)
			{
				if (!comboBoxCurrentStrategy.Items.Contains(StrategyTable[index].name_strategy))
				{
					comboBoxCurrentStrategy.Items.Add(StrategyTable[index].name_strategy);
				}
				if (StrategyTable[index].name_strategy == CurrentStrategy)
				{
					num = comboBoxCurrentStrategy.Items.IndexOf(CurrentStrategy);
					isFound = true;
				}
			}
			if (StrategyTable.Count > 0 && isFound)
			{
				comboBoxCurrentStrategy.SelectedIndex = num;
			}
		}

		public void FillSettingsCurrentStrategy()
		{
			ClassSettings.gCurrentStrategy = comboBoxCurrentStrategy.Text;
		}

		private void buttonApplyStrategy_Click(object sender, EventArgs e)
		{
			string text = comboBoxCurrentStrategy.Text;
			if (text != "")
			{
				dataGridViewPortfolio.Rows.Clear();
				CreateTransactionTableFromDDE(text);
				CreatePortfolioTableFromTransaction(text);
				FillPortfolio();
				Tick();
				CallBackMy.callbackEventHandlerTickChart();
			}
		}

		private void UpdatePortfolio(string fStrategy)
		{
			SetUpdatePortfolio setUpdatePortfolio = UpdatePortfolio;
			if (dataGridViewPortfolio.InvokeRequired)
			{
				Invoke(setUpdatePortfolio, fStrategy);
				return;
			}
			string text = comboBoxCurrentStrategy.Text;
			if (text == fStrategy)
			{
				dataGridViewPortfolio.Rows.Clear();
				CreatePortfolioTableFromTransaction(text);
				FillPortfolio();
				UpdatePortfolioTableFromPortfolio();
				FillPortfolioTotal();
				PaintTablePortfolio();
				CallBackMy.callbackEventHandlerTickChart();
			}
		}

		public void CreateTransactionTableFromDDE(string currentStrategy)
		{
			string str = fTransaction.NameInstrument(currentStrategy);
			int num = cDataDDE.QuantityTransaction();
			bool flag1 = false;
			bool flag2 = false;
			for (int iNumber = 1; iNumber <= num; iNumber++)
			{
				if (cDataDDE.SearchTransactionLineNumber(iNumber) && !fTransaction.SearchTransaction(ClassDataDDE.TransactionPaper.number) && (ClassDataDDE.TransactionPaper.paper_code.Remove(2) == str || str == ""))
				{
					FormTransaction.TransactionPaper.number = ClassDataDDE.TransactionPaper.number;
					FormTransaction.TransactionPaper.date = ClassDataDDE.TransactionPaper.date;
					FormTransaction.TransactionPaper.time = ClassDataDDE.TransactionPaper.time;
					FormTransaction.TransactionPaper.paper_code = ClassDataDDE.TransactionPaper.paper_code;
					FormTransaction.TransactionPaper.operation = ClassDataDDE.TransactionPaper.operation;
					FormTransaction.TransactionPaper.price = ClassDataDDE.TransactionPaper.price;
					FormTransaction.TransactionPaper.volume = ClassDataDDE.TransactionPaper.volume;
					FormTransaction.TransactionPaper.strategy = currentStrategy;
					fTransaction.AddTransaction();
					flag1 = true;
					if (Helpers.IsOption(FormTransaction.TransactionPaper.paper_code))
					{
						flag2 = true;
					}
				}
			}
			if (flag1 && flag2)
			{
				cHistoryDataDDE.FileName = comboBoxCurrentStrategy.Text;
				cHistoryDataDDE.WriteFileHistory();
			}
		}

		public void Tick()
		{
			ModelSmile1.Checked = CallBackMy.callbackEventHandlerModelSmileChecked();
			ModelSmile1.VolatilityChecked = CallBackMy.callbackEventHandlerModelSmileVolatilityChecked();
			ModelSmile1.CurrentStrike = CallBackMy.callbackEventHandlerModelSmileCurrentStrike();
			ModelSmile1.Volatility = CallBackMy.callbackEventHandlerModelSmileVolatility();
			ModelSmile1.Skew = CallBackMy.callbackEventHandlerModelSmileSkew();
			ModelSmile1.Kink = CallBackMy.callbackEventHandlerModelSmileKink();
			if (ModelSmile1.Checked && checkBoxModelSmile.Checked)
			{
				label1.Text = CallBackMy.callbackEventHandlerModelSmileName();
			}
			else
			{
				label1.Text = "";
				checkBoxModelSmile.Checked = false;
			}
			if (!F_Update)
			{
				UpdatePortfolioTableFromPortfolio();
				FillPortfolioTotal();
				PaintTablePortfolio();
			}
			else
			{
				UpdatePortfolio(comboBoxCurrentStrategy.Text);
				F_Update = false;
			}
		}

		public void CreatePortfolioTableFromTransaction(string currentStrategy)
		{
			int num1 = 0;
			double num2 = 0.0;
			PortfolioTable.Clear();
			for (int index1 = 0; index1 < FormTransaction.TransactionTable.Count; index1++)
			{
				if (!(currentStrategy == FormTransaction.TransactionTable[index1].strategy))
				{
					continue;
				}
				int num3 = ((FormTransaction.TransactionTable[index1].operation == "Купля") ? 1 : ((FormTransaction.TransactionTable[index1].operation == "Продажа") ? (-1) : 0));
				if (num1 == 0)
				{
					PortfolioPaper.paper_code = FormTransaction.TransactionTable[index1].paper_code;
					PortfolioPaper.volume = (double)num3 * FormTransaction.TransactionTable[index1].volume;
					PortfolioPaper.open_price = FormTransaction.TransactionTable[index1].price;
					PortfolioPaper.accumulated_profit = 0.0;
					PortfolioPaper.check = false;
					PortfolioPaper.check_calculation = true;
					PortfolioTable.Add(PortfolioPaper);
					num1++;
					continue;
				}
				bool flag = false;
				int i;
				for (i = 0; i < PortfolioTable.Count; i++)
				{
					if (FormTransaction.TransactionTable[index1].paper_code == PortfolioTable[i].paper_code)
					{
						flag = true;
						break;
					}
				}
				if (flag)
				{
					int num4 = Convert.ToInt32(PortfolioTable[i].volume);
					int int32 = Convert.ToInt32((double)num4 + (double)num3 * FormTransaction.TransactionTable[index1].volume);
					double num5 = PortfolioTable[i].open_price;
					if (num4 >= 0 && int32 > num4)
					{
						num5 = (num5 * (double)num4 + FormTransaction.TransactionTable[index1].price * (double)num3 * FormTransaction.TransactionTable[index1].volume) / (double)int32;
						num4 = int32;
						num2 = 0.0;
					}
					else if (num4 <= 0 && int32 < num4)
					{
						num5 = (num5 * (double)Math.Abs(num4) + FormTransaction.TransactionTable[index1].price * Math.Abs((double)num3 * FormTransaction.TransactionTable[index1].volume)) / (double)Math.Abs(int32);
						num4 = int32;
						num2 = 0.0;
					}
					else if (num4 >= 0 && int32 < num4)
					{
						if (int32 >= 0)
						{
							num2 = (FormTransaction.TransactionTable[index1].price - num5) * Math.Abs((double)num3 * FormTransaction.TransactionTable[index1].volume);
							num4 = int32;
						}
						else
						{
							num2 = (FormTransaction.TransactionTable[index1].price - num5) * Math.Abs(Math.Abs((double)num3 * FormTransaction.TransactionTable[index1].volume) - (double)Math.Abs(int32));
							num4 = int32;
							num5 = FormTransaction.TransactionTable[index1].price;
						}
					}
					else if (num4 <= 0 && int32 > num4)
					{
						if (int32 <= 0)
						{
							num2 = (num5 - FormTransaction.TransactionTable[index1].price) * Math.Abs((double)num3 * FormTransaction.TransactionTable[index1].volume);
							num4 = int32;
						}
						else
						{
							num2 = (num5 - FormTransaction.TransactionTable[index1].price) * Math.Abs(Math.Abs((double)num3 * FormTransaction.TransactionTable[index1].volume) - (double)Math.Abs(int32));
							num4 = int32;
							num5 = FormTransaction.TransactionTable[index1].price;
						}
					}
					PortfolioPaper = PortfolioTable[i];
					PortfolioPaper.volume = Convert.ToDouble(num4);
					PortfolioPaper.open_price = num5;
					if (num2 != 0.0)
					{
						PortfolioPaper.accumulated_profit += num2;
					}
					PortfolioPaper.check_calculation = true;
					PortfolioTable[i] = PortfolioPaper;
				}
				else
				{
					PortfolioPaper.paper_code = FormTransaction.TransactionTable[index1].paper_code;
					PortfolioPaper.volume = (double)num3 * FormTransaction.TransactionTable[index1].volume;
					PortfolioPaper.open_price = FormTransaction.TransactionTable[index1].price;
					PortfolioPaper.accumulated_profit = 0.0;
					PortfolioPaper.check = false;
					PortfolioPaper.check_calculation = true;
					PortfolioTable.Add(PortfolioPaper);
				}
			}
		}

		public void UpdatePortfolioTableFromPortfolio()
		{
			FuturePaper1.base_asset = "";
			FuturePaper1.last_price = 0.0;
			FuturePaper1.step_price = 0.0;
			FuturePaper1.decimal_points = 0.0;
			FuturePaper1.F = false;
			FuturePaper2.base_asset = "";
			FuturePaper2.last_price = 0.0;
			FuturePaper2.step_price = 0.0;
			FuturePaper2.decimal_points = 0.0;
			FuturePaper2.F = false;
			labelP1.Text = "";
			labelP2.Text = "";
			double result1 = 0.0;
			double result2 = 0.0;
			double result3 = 0.0;
			double result4 = 0.0;
			double result5 = 0.0;
			if (!double.TryParse(textBoxDays.Text, out result1))
			{
				result1 = 0.0;
			}
			shiftD = result1;
			if (shiftD != 0.0)
			{
				textBoxDays.BackColor = ClassColorTheme.SmileModelColor;
				textBoxDays.ForeColor = ClassColorTheme.BackColor;
			}
			else
			{
				textBoxDays.BackColor = ClassColorTheme.BackColor;
				textBoxDays.ForeColor = ClassColorTheme.BackColorFore;
			}
			if (!double.TryParse(textBoxVola.Text, out result2))
			{
				result2 = 0.0;
			}
			shiftV1 = result2;
			if (shiftV1 != 0.0)
			{
				textBoxVola.BackColor = ClassColorTheme.SmileModelColor;
				textBoxVola.ForeColor = ClassColorTheme.BackColor;
			}
			else
			{
				textBoxVola.BackColor = ClassColorTheme.BackColor;
				textBoxVola.ForeColor = ClassColorTheme.BackColorFore;
			}
			if (!double.TryParse(textBoxVola2.Text, out result3))
			{
				result3 = 0.0;
			}
			shiftV2 = result3;
			if (shiftV2 != 0.0)
			{
				textBoxVola2.BackColor = ClassColorTheme.SmileModelColor;
				textBoxVola2.ForeColor = ClassColorTheme.BackColor;
			}
			else
			{
				textBoxVola2.BackColor = ClassColorTheme.BackColor;
				textBoxVola2.ForeColor = ClassColorTheme.BackColorFore;
			}
			if (!double.TryParse(textBoxPrice.Text, out result4))
			{
				result4 = 0.0;
			}
			shiftP1 = result4;
			if (shiftP1 != 0.0)
			{
				textBoxPrice.BackColor = ClassColorTheme.SmileModelColor;
				textBoxPrice.ForeColor = ClassColorTheme.BackColor;
			}
			else
			{
				textBoxPrice.BackColor = ClassColorTheme.BackColor;
				textBoxPrice.ForeColor = ClassColorTheme.BackColorFore;
			}
			if (!double.TryParse(textBoxPrice2.Text, out result5))
			{
				result5 = 0.0;
			}
			shiftP2 = result5;
			if (shiftP2 != 0.0)
			{
				textBoxPrice2.BackColor = ClassColorTheme.SmileModelColor;
				textBoxPrice2.ForeColor = ClassColorTheme.BackColor;
			}
			else
			{
				textBoxPrice2.BackColor = ClassColorTheme.BackColor;
				textBoxPrice2.ForeColor = ClassColorTheme.BackColorFore;
			}
			PortfolioTable.Clear();
			int num = 0;
			for (int index = 0; index < dataGridViewPortfolio.RowCount; index++)
			{
				if (!(Convert.ToString(dataGridViewPortfolio.Rows[index].Cells["Paper_code"].Value) != "FixedProfit") || !(Convert.ToString(dataGridViewPortfolio.Rows[index].Cells["Paper_code"].Value) != "Итого:") || !(Convert.ToString(dataGridViewPortfolio.Rows[index].Cells["Check"].Value) == "True") || !cDataDDE.SearchPaper(Convert.ToString(dataGridViewPortfolio.Rows[index].Cells["Paper_code"].Value)))
				{
					continue;
				}
				if (num == 0)
				{
					FuturePaper1.paper_code = Convert.ToString(dataGridViewPortfolio.Rows[index].Cells["Paper_code"].Value);
					FuturePaper1.base_asset = ClassDataDDE.QuotesPaper.base_asset;
					FuturePaper1.expiration_date = ClassDataDDE.QuotesPaper.expiration_date;
					FuturePaper1.F = true;
					num++;
				}
				else if (ClassDataDDE.QuotesPaper.expiration_date < FuturePaper1.expiration_date)
				{
					if (Helpers.IsOption(FuturePaper1.paper_code))
					{
						FuturePaper2.paper_code = FuturePaper1.paper_code;
						FuturePaper2.base_asset = FuturePaper1.base_asset;
						FuturePaper2.expiration_date = FuturePaper1.expiration_date;
						FuturePaper2.F = FuturePaper1.F;
					}
					FuturePaper1.paper_code = Convert.ToString(dataGridViewPortfolio.Rows[index].Cells["Paper_code"].Value);
					FuturePaper1.base_asset = ClassDataDDE.QuotesPaper.base_asset;
					FuturePaper1.expiration_date = ClassDataDDE.QuotesPaper.expiration_date;
					FuturePaper1.F = true;
				}
				else if (ClassDataDDE.QuotesPaper.expiration_date > FuturePaper1.expiration_date)
				{
					if (Helpers.IsOption(Convert.ToString(dataGridViewPortfolio.Rows[index].Cells["Paper_code"].Value)))
					{
						FuturePaper2.paper_code = Convert.ToString(dataGridViewPortfolio.Rows[index].Cells["Paper_code"].Value);
						FuturePaper2.base_asset = ClassDataDDE.QuotesPaper.base_asset;
						FuturePaper2.expiration_date = ClassDataDDE.QuotesPaper.expiration_date;
						FuturePaper2.F = true;
					}
				}
				else if (ClassDataDDE.QuotesPaper.expiration_date == FuturePaper1.expiration_date && Helpers.IsOption(Convert.ToString(dataGridViewPortfolio.Rows[index].Cells["Paper_code"].Value)))
				{
					FuturePaper1.paper_code = Convert.ToString(dataGridViewPortfolio.Rows[index].Cells["Paper_code"].Value);
					FuturePaper1.base_asset = ClassDataDDE.QuotesPaper.base_asset;
					FuturePaper1.expiration_date = ClassDataDDE.QuotesPaper.expiration_date;
					FuturePaper1.F = true;
				}
			}
			if (FuturePaper1.F && Helpers.IsOption(FuturePaper1.paper_code))
			{
				textBoxDays.Enabled = true;
			}
			else
			{
				textBoxDays.Enabled = false;
			}
			if (FuturePaper1.F && Helpers.IsOption(FuturePaper1.paper_code))
			{
				textBoxVola.Enabled = true;
			}
			else
			{
				textBoxVola.Enabled = false;
			}
			if (FuturePaper2.F && Helpers.IsOption(FuturePaper2.paper_code))
			{
				textBoxVola2.Enabled = true;
			}
			else
			{
				textBoxVola2.Enabled = false;
			}
			if (FuturePaper1.F)
			{
				textBoxPrice.Enabled = true;
			}
			else
			{
				textBoxPrice.Enabled = false;
			}
			if (FuturePaper2.F && FuturePaper2.base_asset != FuturePaper1.base_asset)
			{
				textBoxPrice2.Enabled = true;
			}
			else
			{
				textBoxPrice2.Enabled = false;
			}
			double central_strike_vol_1 = 0.0;
			double central_strike_vol_2 = 0.0;
			if (cDataDDE.SearchPaper(FuturePaper1.base_asset))
			{
				if (AbsWhatIf && result4 > 0.0 && ClassDataDDE.QuotesPaper.last_price / result4 < 10.0)
				{
					result4 -= ClassDataDDE.QuotesPaper.last_price;
				}
				labelP1.Text = Convert.ToString(FuturePaper1.base_asset) + " " + Convert.ToString(ClassDataDDE.QuotesPaper.last_price + result4);
			}
			if (cDataDDE.SearchPaper(FuturePaper2.base_asset))
			{
				if (AbsWhatIf && result5 > 0.0 && ClassDataDDE.QuotesPaper.last_price / result5 < 10.0)
				{
					result5 -= ClassDataDDE.QuotesPaper.last_price;
				}
				labelP2.Text = Convert.ToString(FuturePaper2.base_asset) + " " + Convert.ToString(ClassDataDDE.QuotesPaper.last_price + result5);
			}
			double vDiff1 = 0.0;
			double vDiff2 = 0.0;
			for (int i = 0; i < dataGridViewPortfolio.RowCount; i++)
			{
				if (!(Convert.ToString(dataGridViewPortfolio.Rows[i].Cells["Paper_code"].Value) != "FixedProfit") || !(Convert.ToString(dataGridViewPortfolio.Rows[i].Cells["Paper_code"].Value) != "Итого:"))
				{
					continue;
				}
				double result6;
				if (cDataDDE.SearchPaper(Convert.ToString(dataGridViewPortfolio.Rows[i].Cells["Paper_code"].Value)))
				{
					PortfolioPaper.paper_code = Convert.ToString(dataGridViewPortfolio.Rows[i].Cells["Paper_code"].Value);
					PortfolioPaper.base_asset = (Helpers.IsOption(PortfolioPaper.paper_code) ? ClassDataDDE.QuotesPaper.base_asset : PortfolioPaper.paper_code);
					if (!double.TryParse(Convert.ToString(dataGridViewPortfolio.Rows[i].Cells["Volume"].Value), out result6))
					{
						ErrorMessage = "В портфеле, в колонке объем, строка " + (i + 1) + ", введено не число";
						CallBackMy.callbackEventError eventHandlerError = CallBackMy.callbackEventHandlerError;
						string iTimeDate = DateTime.Now.ToLocalTime().ToString();
						string errorMessage = ErrorMessage;
						eventHandlerError(iTimeDate, errorMessage);
						PortfolioTable.Clear();
						break;
					}
					PortfolioPaper.volume = result6;
					if (!double.TryParse(Convert.ToString(dataGridViewPortfolio.Rows[i].Cells["Open_price"].Value), out result6))
					{
						ErrorMessage = "В портфеле, в колонке цена открытия, строка " + (i + 1) + ", введено не число";
						CallBackMy.callbackEventError eventHandlerError2 = CallBackMy.callbackEventHandlerError;
						string iTimeDate2 = DateTime.Now.ToLocalTime().ToString();
						string errorMessage2 = ErrorMessage;
						eventHandlerError2(iTimeDate2, errorMessage2);
						PortfolioTable.Clear();
						break;
					}
					PortfolioPaper.open_price = result6;
					PortfolioPaper.option_type = ClassDataDDE.QuotesPaper.option_type;
					PortfolioPaper.expiration_date = ClassDataDDE.QuotesPaper.expiration_date;
					PortfolioPaper.accumulated_profit = 0.0;
					if (AbsWhatIf)
					{
						if (PortfolioPaper.base_asset != PortfolioPaper.paper_code && (result2 > 0.0 || result3 > 0.0) && (vDiff1 == 0.0 || vDiff2 == 0.0))
						{
							if (result2 > 0.0 && vDiff1 == 0.0 && PortfolioPaper.base_asset == FuturePaper1.base_asset)
							{
								central_strike_vol_1 = cDataDDE.GetCentralStrikeVol(PortfolioPaper.base_asset, PortfolioPaper.expiration_date);
								vDiff1 = result2 - central_strike_vol_1;
								if (result4 != 0.0)
								{
									double central_strike_vol_new = cDataDDE.GetCentralStrikeVol(PortfolioPaper.base_asset, PortfolioPaper.expiration_date, result4);
									vDiff1 += central_strike_vol_new - central_strike_vol_1;
								}
							}
							if (result3 > 0.0 && vDiff2 == 0.0 && PortfolioPaper.base_asset == FuturePaper2.base_asset)
							{
								central_strike_vol_2 = cDataDDE.GetCentralStrikeVol(PortfolioPaper.base_asset, PortfolioPaper.expiration_date, result5);
								vDiff2 = result3 - central_strike_vol_2;
								if (result5 != 0.0)
								{
									double central_strike_vol2_new = cDataDDE.GetCentralStrikeVol(PortfolioPaper.base_asset, PortfolioPaper.expiration_date, result5);
									vDiff2 += central_strike_vol2_new - central_strike_vol_2;
								}
							}
						}
					}
					else
					{
						vDiff1 = result2;
						vDiff2 = result3;
					}
					PortfolioPaper.volatility = ((PortfolioPaper.expiration_date == FuturePaper1.expiration_date && FuturePaper1.F) ? Math.Round(ClassDataDDE.QuotesPaper.volatility + vDiff1, 2) : ((!(PortfolioPaper.expiration_date == FuturePaper2.expiration_date) || !FuturePaper2.F) ? Math.Round(ClassDataDDE.QuotesPaper.volatility, 2) : Math.Round(ClassDataDDE.QuotesPaper.volatility + vDiff2, 2)));
					PortfolioPaper.step_price = ClassDataDDE.QuotesPaper.step_price;
					PortfolioPaper.decimal_points = ClassDataDDE.QuotesPaper.decimal_points;
					cCalculationOptions.TypeO = PortfolioPaper.option_type;
					cCalculationOptions.Strike = ClassDataDDE.QuotesPaper.strike;
					PortfolioPaper.strike = ClassDataDDE.QuotesPaper.strike;
					cCalculationOptions.DateExp = PortfolioPaper.expiration_date;
					if (AbsWhatIf && result1 > 0.0)
					{
						cCalculationOptions.DateCurrent = cCalculationOptions.DateExp.AddDays(0.0 - result1);
					}
					else
					{
						cCalculationOptions.DateCurrent = DateTime.Now.AddDays(result1);
					}
					PortfolioPaper.current_date = cCalculationOptions.DateCurrent;
					cCalculationOptions.Q = Convert.ToInt32(PortfolioPaper.volume);
					cCalculationOptions.VolaO = PortfolioPaper.volatility;
					if (cDataDDE.SearchPaper(PortfolioPaper.base_asset))
					{
						cCalculationOptions.LastF = ((PortfolioPaper.base_asset == FuturePaper1.base_asset) ? (ClassDataDDE.QuotesPaper.last_price + result4) : ((!(PortfolioPaper.base_asset == FuturePaper2.base_asset)) ? ClassDataDDE.QuotesPaper.last_price : (ClassDataDDE.QuotesPaper.last_price + result5)));
						PortfolioPaper.futures_price = cCalculationOptions.LastF;
						if (ModelSmile1.Checked && checkBoxModelSmile.Checked && Helpers.IsOption(PortfolioPaper.paper_code) && PortfolioPaper.expiration_date == FuturePaper1.expiration_date && FuturePaper1.F)
						{
							PortfolioPaper.volatility = Math.Round(CalculationVolatilityModelSmile(ModelSmile1.Volatility + vDiff1, PortfolioPaper.strike, ModelSmile1.CurrentStrike + result4, PortfolioPaper.expiration_date, ModelSmile1.Skew, ModelSmile1.Kink), 2);
							cCalculationOptions.VolaO = PortfolioPaper.volatility;
						}
						if (cCalculationOptions.CalculationOpt())
						{
							PortfolioPaper.teoretical_price = (Helpers.IsOption(PortfolioPaper.paper_code) ? Math.Round(cCalculationOptions.calcTheoPrice, PortfolioPaper.decimal_points) : PortfolioPaper.futures_price);
							PortfolioPaper.delta = Math.Round(cCalculationOptions.calcDelta, 2);
							PortfolioPaper.gamma = Math.Round(cCalculationOptions.calcGamma, 6);
							PortfolioPaper.vega = Math.Round(cCalculationOptions.calcVega, 2);
							PortfolioPaper.theta = Math.Round(cCalculationOptions.calcTheta, 2);
							PortfolioPaper.profit = ((PortfolioPaper.option_type == "Call") ? ((PortfolioPaper.teoretical_price - PortfolioPaper.open_price) * PortfolioPaper.volume) : ((!(PortfolioPaper.option_type == "Put")) ? ((cCalculationOptions.LastF - PortfolioPaper.open_price) * PortfolioPaper.volume) : ((PortfolioPaper.teoretical_price - PortfolioPaper.open_price) * PortfolioPaper.volume)));
							cCalculationOptions.Theo = PortfolioPaper.open_price;
							PortfolioPaper.open_volatility = ((!Helpers.IsOption(PortfolioPaper.paper_code)) ? 0.0 : ((!cCalculationOptions.CalculationVola()) ? 0.0 : Math.Round(cCalculationOptions.calcVola, 2)));
							PortfolioPaper.check = true;
							PortfolioPaper.check_calculation = Convert.ToString(dataGridViewPortfolio.Rows[i].Cells["Check"].Value) == "True";
						}
						else
						{
							PortfolioPaper.delta = 0.0;
							PortfolioPaper.gamma = 0.0;
							PortfolioPaper.vega = 0.0;
							PortfolioPaper.theta = 0.0;
							PortfolioPaper.profit = 0.0;
							PortfolioPaper.check = false;
							PortfolioPaper.check_calculation = Convert.ToString(dataGridViewPortfolio.Rows[i].Cells["Check"].Value) == "True";
						}
					}
					else
					{
						PortfolioPaper.delta = 0.0;
						PortfolioPaper.gamma = 0.0;
						PortfolioPaper.vega = 0.0;
						PortfolioPaper.theta = 0.0;
						PortfolioPaper.profit = 0.0;
						PortfolioPaper.check = false;
						PortfolioPaper.check_calculation = Convert.ToString(dataGridViewPortfolio.Rows[i].Cells["Check"].Value) == "True";
					}
				}
				else
				{
					PortfolioPaper.paper_code = Convert.ToString(dataGridViewPortfolio.Rows[i].Cells["Paper_code"].Value);
					PortfolioPaper.base_asset = "";
					if (!double.TryParse(Convert.ToString(dataGridViewPortfolio.Rows[i].Cells["Volume"].Value), out result6))
					{
						ErrorMessage = "В портфеле, в колонке объем, строка " + (i + 1) + ", введено не число";
						CallBackMy.callbackEventError eventHandlerError3 = CallBackMy.callbackEventHandlerError;
						string iTimeDate3 = DateTime.Now.ToLocalTime().ToString();
						string errorMessage3 = ErrorMessage;
						eventHandlerError3(iTimeDate3, errorMessage3);
						PortfolioTable.Clear();
						break;
					}
					PortfolioPaper.volume = result6;
					if (!double.TryParse(Convert.ToString(dataGridViewPortfolio.Rows[i].Cells["Open_price"].Value), out result6))
					{
						ErrorMessage = "В портфеле, в колонке цена открытия, строка " + (i + 1) + ", введено не число";
						CallBackMy.callbackEventError eventHandlerError4 = CallBackMy.callbackEventHandlerError;
						string iTimeDate4 = DateTime.Now.ToLocalTime().ToString();
						string errorMessage4 = ErrorMessage;
						eventHandlerError4(iTimeDate4, errorMessage4);
						PortfolioTable.Clear();
						break;
					}
					PortfolioPaper.open_price = result6;
					PortfolioPaper.option_type = "";
					PortfolioPaper.strike = 0.0;
					PortfolioPaper.teoretical_price = 0.0;
					PortfolioPaper.futures_price = 0.0;
					PortfolioPaper.accumulated_profit = 0.0;
					PortfolioPaper.volatility = 0.0;
					PortfolioPaper.step_price = 0.0;
					PortfolioPaper.decimal_points = 0;
					PortfolioPaper.delta = 0.0;
					PortfolioPaper.gamma = 0.0;
					PortfolioPaper.vega = 0.0;
					PortfolioPaper.theta = 0.0;
					PortfolioPaper.profit = 0.0;
					PortfolioPaper.check = false;
					PortfolioPaper.check_calculation = Convert.ToString(dataGridViewPortfolio.Rows[i].Cells["Check"].Value) == "True";
				}
				PortfolioTable.Add(PortfolioPaper);
				if (PortfolioPaper.check)
				{
					dataGridViewPortfolio.Rows[i].Cells["Check"].Value = PortfolioPaper.check_calculation;
					dataGridViewPortfolio.Rows[i].Cells["Paper_code"].Value = PortfolioPaper.paper_code;
					dataGridViewPortfolio.Rows[i].Cells["Option_type"].Value = PortfolioPaper.option_type;
					dataGridViewPortfolio.Rows[i].Cells["Expiration_date"].Value = PortfolioPaper.expiration_date.ToShortDateString();
					dataGridViewPortfolio.Rows[i].Cells["DaysToExpiration"].Value = Convert.ToString(DifferenceInDays(PortfolioPaper.current_date.Date, PortfolioPaper.expiration_date.Date));
					dataGridViewPortfolio.Rows[i].Cells["Volume"].Value = PortfolioPaper.volume;
					dataGridViewPortfolio.Rows[i].Cells["Open_price"].Value = Math.Round(PortfolioPaper.open_price, PortfolioPaper.decimal_points);
					dataGridViewPortfolio.Rows[i].Cells["Open_volatility"].Value = PortfolioPaper.open_volatility;
					dataGridViewPortfolio.Rows[i].Cells["Teoretical_price"].Value = PortfolioPaper.teoretical_price;
					dataGridViewPortfolio.Rows[i].Cells["Profit"].Value = Math.Round(PortfolioPaper.profit, PortfolioPaper.decimal_points);
					dataGridViewPortfolio.Rows[i].Cells["Volatility"].Value = PortfolioPaper.volatility;
					dataGridViewPortfolio.Rows[i].Cells["Delta"].Value = PortfolioPaper.delta;
					dataGridViewPortfolio.Rows[i].Cells["Gamma"].Value = PortfolioPaper.gamma;
					dataGridViewPortfolio.Rows[i].Cells["Vega"].Value = PortfolioPaper.vega;
					dataGridViewPortfolio.Rows[i].Cells["Theta"].Value = PortfolioPaper.theta;
					dataGridViewPortfolio.Rows[i].Cells["Profit"].Style.BackColor = ((!(Math.Round(PortfolioPaper.profit, 2) <= 0.0)) ? ClassColorTheme.TableGreenColor : ((Math.Round(PortfolioPaper.profit, 2) >= 0.0) ? ClassColorTheme.BackColor : ClassColorTheme.TableRedColor));
				}
				else
				{
					dataGridViewPortfolio.Rows[i].Cells["Check"].Value = PortfolioPaper.check_calculation;
					dataGridViewPortfolio.Rows[i].Cells["Paper_code"].Value = PortfolioPaper.paper_code;
					dataGridViewPortfolio.Rows[i].Cells["Option_type"].Value = "";
					dataGridViewPortfolio.Rows[i].Cells["Expiration_date"].Value = "";
					dataGridViewPortfolio.Rows[i].Cells["DaysToExpiration"].Value = "";
					dataGridViewPortfolio.Rows[i].Cells["Volume"].Value = PortfolioPaper.volume;
					dataGridViewPortfolio.Rows[i].Cells["Open_price"].Value = Math.Round(PortfolioPaper.open_price, PortfolioPaper.decimal_points);
					dataGridViewPortfolio.Rows[i].Cells["Open_volatility"].Value = "";
					dataGridViewPortfolio.Rows[i].Cells["Teoretical_price"].Value = "";
					dataGridViewPortfolio.Rows[i].Cells["Profit"].Value = "";
					dataGridViewPortfolio.Rows[i].Cells["Volatility"].Value = "";
					dataGridViewPortfolio.Rows[i].Cells["Delta"].Value = "";
					dataGridViewPortfolio.Rows[i].Cells["Gamma"].Value = "";
					dataGridViewPortfolio.Rows[i].Cells["Vega"].Value = "";
					dataGridViewPortfolio.Rows[i].Cells["Theta"].Value = "";
					dataGridViewPortfolio.Rows[i].Cells["Profit"].Style.BackColor = ClassColorTheme.BackColor;
				}
			}
		}

		private double CalculationVolatilityModelSmile(double f_Volatility, double f_strike, double f_FutLastPrice, DateTime expiration_date, double f_Skew, double f_Kink)
		{
			double num1 = 0.0;
			if (DateTime.Now.AddDays(shiftD) < expiration_date)
			{
				double d = f_CalculationT(DateTime.Now.AddDays(shiftD), expiration_date);
				double num2 = Math.Log(f_strike / f_FutLastPrice) / (f_Volatility / 100.0 * Math.Sqrt(d));
				num1 = 100.0 * (f_Volatility / 100.0) * (1.0 + f_Skew * num2 / 6.0 + f_Kink * num2 * num2 / 24.0);
			}
			return num1;
		}

		private double f_CalculationT(DateTime f_Date, DateTime f_Exp)
		{
			DateTime dateTime1 = new DateTime(f_Exp.Year, 1, 1, 0, 0, 0);
			DateTime dateTime2 = new DateTime(f_Exp.Year, 12, 31, 23, 59, 59);
			return (double)(int)(f_Exp - f_Date).TotalSeconds / (double)(int)(dateTime2 - dateTime1).TotalSeconds;
		}

		public void FillPortfolio()
		{
			int index1 = 0;
			for (int i = 0; i < PortfolioTable.Count; i++)
			{
				if (index1 < dataGridViewPortfolio.RowCount)
				{
					PortfolioPaper = PortfolioTable[i];
					if (PortfolioPaper.volume == 0.0)
					{
						continue;
					}
					if (PortfolioPaper.check)
					{
						dataGridViewPortfolio.Rows[index1].Cells["Check"].Value = PortfolioPaper.check_calculation;
						dataGridViewPortfolio.Rows[index1].Cells["Paper_code"].Value = PortfolioPaper.paper_code;
						dataGridViewPortfolio.Rows[index1].Cells["Option_type"].Value = PortfolioPaper.option_type;
						dataGridViewPortfolio.Rows[index1].Cells["Expiration_date"].Value = PortfolioPaper.expiration_date.ToShortDateString();
						dataGridViewPortfolio.Rows[index1].Cells["DaysToExpiration"].Value = Convert.ToString(DifferenceInDays(PortfolioPaper.current_date.Date, PortfolioPaper.expiration_date.Date));
						dataGridViewPortfolio.Rows[index1].Cells["Volume"].Value = PortfolioPaper.volume;
						dataGridViewPortfolio.Rows[index1].Cells["Open_price"].Value = Math.Round(PortfolioPaper.open_price, PortfolioPaper.decimal_points);
						dataGridViewPortfolio.Rows[index1].Cells["Open_volatility"].Value = PortfolioPaper.open_volatility;
						dataGridViewPortfolio.Rows[index1].Cells["Teoretical_price"].Value = PortfolioPaper.teoretical_price;
						dataGridViewPortfolio.Rows[index1].Cells["Profit"].Value = Math.Round(PortfolioPaper.profit, PortfolioPaper.decimal_points);
						dataGridViewPortfolio.Rows[index1].Cells["Volatility"].Value = PortfolioPaper.volatility;
						dataGridViewPortfolio.Rows[index1].Cells["Delta"].Value = PortfolioPaper.delta;
						dataGridViewPortfolio.Rows[index1].Cells["Gamma"].Value = PortfolioPaper.gamma;
						dataGridViewPortfolio.Rows[index1].Cells["Vega"].Value = PortfolioPaper.vega;
						dataGridViewPortfolio.Rows[index1].Cells["Theta"].Value = PortfolioPaper.theta;
						if (PortfolioPaper.check_calculation)
						{
							dataGridViewPortfolio.Rows[index1].DefaultCellStyle.ForeColor = ClassColorTheme.BackColorPaleFore;
						}
					}
					else
					{
						dataGridViewPortfolio.Rows[index1].Cells["Check"].Value = PortfolioPaper.check_calculation;
						dataGridViewPortfolio.Rows[index1].Cells["Paper_code"].Value = PortfolioPaper.paper_code;
						dataGridViewPortfolio.Rows[index1].Cells["Option_type"].Value = "";
						dataGridViewPortfolio.Rows[index1].Cells["Expiration_date"].Value = "";
						dataGridViewPortfolio.Rows[index1].Cells["DaysToExpiration"].Value = "";
						dataGridViewPortfolio.Rows[index1].Cells["Volume"].Value = PortfolioPaper.volume;
						dataGridViewPortfolio.Rows[index1].Cells["Open_price"].Value = PortfolioPaper.open_price;
						dataGridViewPortfolio.Rows[index1].Cells["Open_volatility"].Value = "";
						dataGridViewPortfolio.Rows[index1].Cells["Teoretical_price"].Value = "";
						dataGridViewPortfolio.Rows[index1].Cells["Profit"].Value = "";
						dataGridViewPortfolio.Rows[index1].Cells["Volatility"].Value = "";
						dataGridViewPortfolio.Rows[index1].Cells["Delta"].Value = "";
						dataGridViewPortfolio.Rows[index1].Cells["Gamma"].Value = "";
						dataGridViewPortfolio.Rows[index1].Cells["Vega"].Value = "";
						dataGridViewPortfolio.Rows[index1].Cells["Theta"].Value = "";
						if (PortfolioPaper.check_calculation)
						{
							dataGridViewPortfolio.Rows[index1].DefaultCellStyle.ForeColor = ClassColorTheme.BackColorPaleFore;
						}
					}
					index1++;
				}
				else
				{
					if (dataGridViewPortfolio.ColumnCount <= 0)
					{
						continue;
					}
					PortfolioPaper = PortfolioTable[i];
					if (PortfolioPaper.volume != 0.0)
					{
						if (PortfolioPaper.check)
						{
							dataGridViewPortfolio.Rows.Add(true, PortfolioPaper.paper_code, PortfolioPaper.option_type, PortfolioPaper.expiration_date.ToShortDateString(), Convert.ToString(DifferenceInDays(PortfolioPaper.current_date.Date, PortfolioPaper.expiration_date.Date)), PortfolioPaper.volume, Math.Round(PortfolioPaper.open_price, PortfolioPaper.decimal_points), PortfolioPaper.open_volatility, PortfolioPaper.teoretical_price, Math.Round(PortfolioPaper.profit, PortfolioPaper.decimal_points), PortfolioPaper.volatility, PortfolioPaper.delta, PortfolioPaper.gamma, PortfolioPaper.vega, PortfolioPaper.theta);
						}
						else
						{
							dataGridViewPortfolio.Rows.Add(true, PortfolioPaper.paper_code, "", "", "", PortfolioPaper.volume, Math.Round(PortfolioPaper.open_price, PortfolioPaper.decimal_points), "", "", "", "", "", "", "", "");
						}
						index1++;
					}
				}
			}
			if (index1 < dataGridViewPortfolio.RowCount)
			{
				int num = dataGridViewPortfolio.RowCount - index1;
				for (int j = 1; j <= num; j++)
				{
					dataGridViewPortfolio.Rows.RemoveAt(index1);
				}
			}
			FillPortfolioFixedProfit();
			FillPortfolioTotal();
			dataGridViewPortfolio.Refresh();
		}

		public void FillPortfolioFixedProfit()
		{
			double num = 0.0;
			int index1 = -1;
			for (int i = 0; i < PortfolioTable.Count; i++)
			{
				PortfolioPaper = PortfolioTable[i];
				double accumulatedProfit = PortfolioPaper.accumulated_profit;
				num += accumulatedProfit;
			}
			FixedProfit = Math.Round(num, PortfolioPaper.decimal_points);
			for (int j = 0; j < dataGridViewPortfolio.RowCount; j++)
			{
				if (Convert.ToString(dataGridViewPortfolio.Rows[j].Cells["Paper_code"].Value) == "FixedProfit")
				{
					index1 = j;
					break;
				}
			}
			if (index1 >= 0)
			{
				dataGridViewPortfolio.Rows[index1].Cells["Profit"].Value = FixedProfit;
				dataGridViewPortfolio.Rows[index1].Cells["Profit"].Style.BackColor = ((!(FixedProfit <= 0.0)) ? ClassColorTheme.TableGreenColor : ((FixedProfit >= 0.0) ? ClassColorTheme.BackColor : ClassColorTheme.TableRedColor));
				if (PortfolioPaper.check_calculation)
				{
					dataGridViewPortfolio.Rows[index1].DefaultCellStyle.ForeColor = ClassColorTheme.BackColorPaleFore;
				}
				return;
			}
			dataGridViewPortfolio.Rows.Add(true, "FixedProfit", "", "", "", "", "", "", "", FixedProfit, "", "", "", "", "");
			dataGridViewPortfolio.Rows[dataGridViewPortfolio.RowCount - 1].Cells["Profit"].Style.BackColor = ((!(FixedProfit <= 0.0)) ? ClassColorTheme.TableGreenColor : ((FixedProfit >= 0.0) ? ClassColorTheme.BackColor : ClassColorTheme.TableRedColor));
		}

		public void FillPortfolioTotal()
		{
			double result1 = 0.0;
			double num1 = 0.0;
			string iText = "";
			bool flag1 = false;
			bool flag2 = false;
			double num2 = 0.0;
			double num3 = 0.0;
			double num4 = 0.0;
			double num5 = 0.0;
			int index1 = -1;
			bool flag3 = true;
			for (int i = 0; i < dataGridViewPortfolio.RowCount; i++)
			{
				if (Convert.ToString(dataGridViewPortfolio.Rows[i].Cells["Paper_code"].Value) == "FixedProfit")
				{
					if (Convert.ToString(dataGridViewPortfolio.Rows[i].Cells["Check"].Value) == "True")
					{
						CheckFixedProfit = true;
						if (!double.TryParse(Convert.ToString(dataGridViewPortfolio.Rows[i].Cells["Profit"].Value), out result1))
						{
							flag3 = false;
							break;
						}
						num1 += result1;
					}
					else
					{
						CheckFixedProfit = false;
					}
				}
				else
				{
					if (Convert.ToString(dataGridViewPortfolio.Rows[i].Cells["Paper_code"].Value) == "Итого:")
					{
						continue;
					}
					string paperCode = Convert.ToString(dataGridViewPortfolio.Rows[i].Cells["Paper_code"].Value);
					if (Helpers.IsFutures(paperCode))
					{
						if (Convert.ToString(dataGridViewPortfolio.Rows[i].Cells["Check"].Value) == "True")
						{
							if (!double.TryParse(Convert.ToString(dataGridViewPortfolio.Rows[i].Cells["Delta"].Value), out result1))
							{
								flag3 = false;
								break;
							}
							num2 += result1;
							if (!double.TryParse(Convert.ToString(dataGridViewPortfolio.Rows[i].Cells["Profit"].Value), out result1))
							{
								flag3 = false;
								break;
							}
							num1 += result1;
						}
					}
					else if (Convert.ToString(dataGridViewPortfolio.Rows[i].Cells[0].Value) == "True")
					{
						if (!double.TryParse(Convert.ToString(dataGridViewPortfolio.Rows[i].Cells["Delta"].Value), out result1))
						{
							flag3 = false;
							break;
						}
						num2 += result1;
						if (!double.TryParse(Convert.ToString(dataGridViewPortfolio.Rows[i].Cells["Gamma"].Value), out result1))
						{
							flag3 = false;
							break;
						}
						num3 += result1;
						if (!double.TryParse(Convert.ToString(dataGridViewPortfolio.Rows[i].Cells["Vega"].Value), out result1))
						{
							flag3 = false;
							break;
						}
						num4 += result1;
						if (!double.TryParse(Convert.ToString(dataGridViewPortfolio.Rows[i].Cells["Theta"].Value), out result1))
						{
							flag3 = false;
							break;
						}
						num5 += result1;
						if (!double.TryParse(Convert.ToString(dataGridViewPortfolio.Rows[i].Cells["Profit"].Value), out result1))
						{
							flag3 = false;
							break;
						}
						num1 += result1;
					}
				}
			}
			for (int j = 0; j < dataGridViewPortfolio.RowCount; j++)
			{
				if (Convert.ToString(dataGridViewPortfolio.Rows[j].Cells["Paper_code"].Value) == "Итого:")
				{
					index1 = j;
					break;
				}
			}
			if (index1 >= 0)
			{
				if (flag3)
				{
					dataGridViewPortfolio.Rows[index1].Cells["Profit"].Value = Math.Round(num1, 3);
					dataGridViewPortfolio.Rows[index1].Cells["Delta"].Value = Math.Round(num2, 2);
					dataGridViewPortfolio.Rows[index1].Cells["Gamma"].Value = Math.Round(num3, 6);
					dataGridViewPortfolio.Rows[index1].Cells["Vega"].Value = Math.Round(num4, 2);
					dataGridViewPortfolio.Rows[index1].Cells["Theta"].Value = Math.Round(num5, 2);
					if (checkBoxDH.Checked && FormMain.F_DllConnected && FormMain.F_QuikConnected && FormMain.F_WorkingTime && FormMain.orderLotDH == 0)
					{
						int num6 = 0;
						double result2 = 0.0;
						double result3 = 0.0;
						flag1 = false;
						flag2 = false;
						if (double.TryParse(Convert.ToString(numericUpDownDelta.Value), out result2) & double.TryParse(Convert.ToString(numericUpDownIndentDelta.Value), out result3))
						{
							if (Math.Round(num2, 3) > result2 + result3)
							{
								if (Helpers.IsFutures(FuturePaper1.paper_code))
								{
									if (cDataDDE.SearchPaper(FuturePaper1.paper_code) && ClassDataDDE.QuotesPaper.demand > 0.0 && ClassDataDDE.QuotesPaper.demand - slippage * ClassDataDDE.QuotesPaper.step_price > 0.0)
									{
										string transactionString = FillStrApplication(FuturePaper1.paper_code, "S", Convert.ToString(ClassDataDDE.QuotesPaper.demand - slippage * ClassDataDDE.QuotesPaper.step_price), Convert.ToString(Math.Abs(Math.Round(num2 - result2, 0))));
										if (transactionString.Length > 0)
										{
											FormMain.orderLotDH = -1 * Convert.ToInt32(Math.Abs(Math.Round(num2 - result2, 0)));
											num6 = trans_2_quik.send_async_transaction_test(transactionString);
										}
									}
								}
								else if (Helpers.IsOption(FuturePaper1.paper_code) && cDataDDE.SearchPaper(FuturePaper1.base_asset) && ClassDataDDE.QuotesPaper.demand > 0.0 && ClassDataDDE.QuotesPaper.demand - slippage * ClassDataDDE.QuotesPaper.step_price > 0.0)
								{
									string transactionString2 = FillStrApplication(FuturePaper1.base_asset, "S", Convert.ToString(ClassDataDDE.QuotesPaper.demand - slippage * ClassDataDDE.QuotesPaper.step_price), Convert.ToString(Math.Abs(Math.Round(num2 - result2, 0))));
									if (transactionString2.Length > 0)
									{
										FormMain.orderLotDH = -1 * Convert.ToInt32(Math.Abs(Math.Round(num2 - result2, 0)));
										num6 = trans_2_quik.send_async_transaction_test(transactionString2);
									}
								}
							}
							else if (Math.Round(num2, 2) < result2 - result3)
							{
								if (Helpers.IsFutures(FuturePaper1.paper_code))
								{
									if (cDataDDE.SearchPaper(FuturePaper1.paper_code) && ClassDataDDE.QuotesPaper.sentence > 0.0 && ClassDataDDE.QuotesPaper.sentence + slippage * ClassDataDDE.QuotesPaper.step_price > 0.0)
									{
										string transactionString3 = FillStrApplication(FuturePaper1.paper_code, "B", Convert.ToString(ClassDataDDE.QuotesPaper.sentence + slippage * ClassDataDDE.QuotesPaper.step_price), Convert.ToString(Math.Abs(Math.Round(num2 - result2, 0))));
										if (transactionString3.Length > 0)
										{
											FormMain.orderLotDH = Convert.ToInt32(Math.Abs(Math.Round(num2 - result2, 0)));
											num6 = trans_2_quik.send_async_transaction_test(transactionString3);
										}
									}
								}
								else if (Helpers.IsOption(FuturePaper1.paper_code) && cDataDDE.SearchPaper(FuturePaper1.base_asset) && ClassDataDDE.QuotesPaper.sentence > 0.0 && ClassDataDDE.QuotesPaper.sentence + slippage * ClassDataDDE.QuotesPaper.step_price > 0.0)
								{
									string transactionString4 = FillStrApplication(FuturePaper1.base_asset, "B", Convert.ToString(ClassDataDDE.QuotesPaper.sentence + slippage * ClassDataDDE.QuotesPaper.step_price), Convert.ToString(Math.Abs(Math.Round(num2 - result2, 0))));
									if (transactionString4.Length > 0)
									{
										FormMain.orderLotDH = Convert.ToInt32(Math.Abs(Math.Round(num2 - result2, 0)));
										num6 = trans_2_quik.send_async_transaction_test(transactionString4);
									}
								}
							}
						}
					}
					dataGridViewPortfolio.Rows[index1].Cells["Profit"].Style.BackColor = ((!(Math.Round(num1, 2) <= 0.0)) ? ClassColorTheme.TableGreenColor : ((Math.Round(num1, 2) >= 0.0) ? ClassColorTheme.BackColor : ClassColorTheme.TableRedColor));
				}
				else
				{
					dataGridViewPortfolio.Rows[index1].Cells["Profit"].Value = "";
					dataGridViewPortfolio.Rows[index1].Cells["Delta"].Value = "";
					dataGridViewPortfolio.Rows[index1].Cells["Gamma"].Value = "";
					dataGridViewPortfolio.Rows[index1].Cells["Vega"].Value = "";
					dataGridViewPortfolio.Rows[index1].Cells["Theta"].Value = "";
					dataGridViewPortfolio.Rows[index1].Cells["Profit"].Style.BackColor = ClassColorTheme.BackColor;
				}
				iText = "Profit=" + Convert.ToString(dataGridViewPortfolio.Rows[index1].Cells["Profit"].Value) + " Delta(" + symbolDelta + ")=" + Convert.ToString(dataGridViewPortfolio.Rows[index1].Cells["Delta"].Value) + " Gamma(" + symbolGamma + ")=" + Convert.ToString(dataGridViewPortfolio.Rows[index1].Cells["Gamma"].Value) + " Vega=" + Convert.ToString(dataGridViewPortfolio.Rows[index1].Cells["Vega"].Value) + " Theta(" + symbolTheta + ")=" + Convert.ToString(dataGridViewPortfolio.Rows[index1].Cells["Theta"].Value);
			}
			else if (dataGridViewPortfolio.RowCount > 0)
			{
				if (flag3)
				{
					dataGridViewPortfolio.Rows.Add(true, "Итого:", "", "", "", "", "", "", "", Math.Round(num1, 2), "", Math.Round(num2, 2), Math.Round(num3, 6), Math.Round(num4, 2), Math.Round(num5, 2));
					dataGridViewPortfolio.Rows[dataGridViewPortfolio.RowCount - 1].Cells["Profit"].Style.BackColor = ((!(Math.Round(num1, 2) <= 0.0)) ? ClassColorTheme.TableGreenColor : ((Math.Round(num1, 2) >= 0.0) ? ClassColorTheme.BackColor : ClassColorTheme.TableRedColor));
					iText = "Profit=" + Convert.ToString(dataGridViewPortfolio.Rows[dataGridViewPortfolio.RowCount - 1].Cells["Profit"].Value) + " Delta(" + symbolDelta + ")=" + Convert.ToString(dataGridViewPortfolio.Rows[dataGridViewPortfolio.RowCount - 1].Cells["Delta"].Value) + " Gamma(" + symbolGamma + ")=" + Convert.ToString(dataGridViewPortfolio.Rows[dataGridViewPortfolio.RowCount - 1].Cells["Gamma"].Value) + " Vega=" + Convert.ToString(dataGridViewPortfolio.Rows[dataGridViewPortfolio.RowCount - 1].Cells["Vega"].Value) + " Theta(" + symbolTheta + ")=" + Convert.ToString(dataGridViewPortfolio.Rows[dataGridViewPortfolio.RowCount - 1].Cells["Theta"].Value);
				}
				else
				{
					dataGridViewPortfolio.Rows.Add(true, "Итого:", "", "", "", "", "", "", "", "", "", "", "", "", "");
					dataGridViewPortfolio.Rows[dataGridViewPortfolio.RowCount - 1].Cells["Profit"].Style.BackColor = ClassColorTheme.BackColor;
					iText = "Profit=  Delta(" + symbolDelta + ")=Gamma(" + symbolGamma + ")= Vega=  Theta(" + symbolTheta + ")=";
				}
			}
			CallBackMy.callbackEventHandlerStatusLabelInfoWrite(iText);
		}

		public double D()
		{
			double result = 0.0;
			if (!double.TryParse(textBoxDays.Text, out result))
			{
				result = 0.0;
			}
			return result;
		}

		public double V()
		{
			double result = 0.0;
			if (!double.TryParse(textBoxVola.Text, out result))
			{
				result = 0.0;
			}
			return result;
		}

		public double P()
		{
			double result = 0.0;
			if (!double.TryParse(textBoxPrice.Text, out result))
			{
				result = 0.0;
			}
			return result;
		}

		private void PaintColorTheme()
		{
			BackColor = ClassColorTheme.BackColor;
			ForeColor = ClassColorTheme.HeadersColorFore;
			groupBoxPortfolio.BackColor = ClassColorTheme.BackColor;
			groupBoxPortfolio.ForeColor = ClassColorTheme.BackColorFore;
			dataGridViewPortfolio.ColumnHeadersDefaultCellStyle.BackColor = ClassColorTheme.HeadersColor;
			dataGridViewPortfolio.BackgroundColor = ClassColorTheme.BackColor;
			dataGridViewPortfolio.DefaultCellStyle.BackColor = ClassColorTheme.BackColor;
			dataGridViewPortfolio.DefaultCellStyle.ForeColor = ClassColorTheme.BackColorFore;
			dataGridViewPortfolio.ForeColor = ClassColorTheme.BackColorFore;
			dataGridViewPortfolio.ColumnHeadersDefaultCellStyle.ForeColor = ClassColorTheme.HeadersColorFore;
			dataGridViewPortfolio.GridColor = ClassColorTheme.GridColor;
			for (int index = 0; index < dataGridViewPortfolio.RowCount; index++)
			{
				if (!(Convert.ToString(dataGridViewPortfolio.Rows[index].Cells["Check"].Value) == "True"))
				{
					dataGridViewPortfolio.Rows[index].DefaultCellStyle.ForeColor = ClassColorTheme.BackColorPaleFore;
				}
			}
			PaintTablePortfolio();
		}

		public void AddTransactionFromBoard(string paper_code, double volume, double open_price)
		{
			string str = fTransaction.NameInstrument(comboBoxCurrentStrategy.Text);
			if (paper_code.Remove(2) == str || str == "" || paper_code.Contains("_CLT") || Helpers.IsSpotOption(paper_code))
			{
				checkBoxDH.Checked = false;
				dataGridViewPortfolio.Rows.Insert(0, true, paper_code, "", "", "", volume, open_price, "", "", "", "", "", "", "", "");
				Tick();
			}
			else
			{
				int num = (int)MessageBox.Show("Я немогу добавить сделку в портфель, код инструмента должен начинаться с " + str);
			}
		}

		private void comboBoxCurrentStrategy_Click(object sender, EventArgs e)
		{
			string text = comboBoxCurrentStrategy.Text;
			CreateStrategyTable();
			FillComboBoxCurrentStrategy(text);
		}

		private void buttonUpdateStrategy_Click(object sender, EventArgs e)
		{
			CreateStrategyTable();
			string text = comboBoxCurrentStrategy.Text;
			FillComboBoxCurrentStrategy(text);
			UpdatePortfolio(comboBoxCurrentStrategy.Text);
		}

		private void buttonRemoveStrategy_Click(object sender, EventArgs e)
		{
			checkBoxDH.Checked = false;
			string text = comboBoxCurrentStrategy.Text;
			if (MessageBox.Show("Вы действительно хотите удалить стратегию " + text + " ?", "Удаление стратегии " + text, MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
			{
				int num = (int)MessageBox.Show("Стратегия " + text + " успешно удалена.");
				cHistoryDataDDE.FileName = comboBoxCurrentStrategy.Text;
				cHistoryDataDDE.DeleteFile();
				FormTransaction.TransactionTable.RemoveAll((Transaction s) => s.strategy == text);
				StrategyTable.RemoveAll((Strategy s) => s.name_strategy == text);
				comboBoxCurrentStrategy.Items.Remove(text);
				FillComboBoxCurrentStrategy("");
				comboBoxCurrentStrategy.Text = "";
				CreatePortfolioTableFromTransaction(comboBoxCurrentStrategy.Text);
				FillPortfolio();
				Tick();
			}
		}

		private void PaintTablePortfolio()
		{
			double result = 0.0;
			for (int index = 0; index < dataGridViewPortfolio.RowCount; index++)
			{
				dataGridViewPortfolio.Rows[index].Cells["Profit"].Style.BackColor = ((!double.TryParse(Convert.ToString(dataGridViewPortfolio.Rows[index].Cells["Profit"].Value), out result)) ? ClassColorTheme.BackColor : ((result <= 0.0) ? ((result >= 0.0) ? ClassColorTheme.BackColor : ClassColorTheme.TableRedColor) : ClassColorTheme.TableGreenColor));
			}
		}

		private void buttonSave_Click(object sender, EventArgs e)
		{
			string text = comboBoxCurrentStrategy.Text;
			bool flag = false;
			int result = 0;
			int val2 = 0;
			string str = "";
			str = "";
			for (int index = 0; index < FormTransaction.TransactionTable.Count; index++)
			{
				if (FormTransaction.TransactionTable[index].number.Substring(0, 4) == "Demo" && int.TryParse(FormTransaction.TransactionTable[index].number.Substring(4, FormTransaction.TransactionTable[index].number.Length - 4), out result))
				{
					val2 = Math.Max(result, val2);
				}
				if (FormTransaction.TransactionTable[index].strategy == text)
				{
					flag = true;
					int num = (int)MessageBox.Show("Стратегия " + text + " в базе уже есть, сохранить не получится");
					break;
				}
			}
			if (flag)
			{
				return;
			}
			for (int i = 0; i < dataGridViewPortfolio.RowCount; i++)
			{
				if (!(Convert.ToString(dataGridViewPortfolio.Rows[i].Cells["Paper_code"].Value) != "FixedProfit") || !(Convert.ToString(dataGridViewPortfolio.Rows[i].Cells["Paper_code"].Value) != "Итого:") || !(Convert.ToString(dataGridViewPortfolio.Rows[i].Cells["Check"].Value) == "True"))
				{
					continue;
				}
				val2++;
				FormTransaction.TransactionPaper.number = Convert.ToString("Demo" + Convert.ToString(val2));
				DateTime dateTime1 = Convert.ToDateTime(DateTime.Now.ToShortDateString());
				FormTransaction.TransactionPaper.date = dateTime1;
				DateTime dateTime2 = Convert.ToDateTime(DateTime.Now.ToShortTimeString());
				FormTransaction.TransactionPaper.time = dateTime2;
				FormTransaction.TransactionPaper.paper_code = Convert.ToString(dataGridViewPortfolio.Rows[i].Cells["Paper_code"].Value);
				if (double.TryParse(Convert.ToString(dataGridViewPortfolio.Rows[i].Cells["Volume"].Value), out FormTransaction.TransactionPaper.volume))
				{
					if (FormTransaction.TransactionPaper.volume < 0.0)
					{
						FormTransaction.TransactionPaper.volume = Math.Abs(FormTransaction.TransactionPaper.volume);
						FormTransaction.TransactionPaper.operation = "Продажа";
					}
					else
					{
						FormTransaction.TransactionPaper.volume = Math.Abs(FormTransaction.TransactionPaper.volume);
						FormTransaction.TransactionPaper.operation = "Купля";
					}
				}
				else
				{
					FormTransaction.TransactionPaper.volume = 0.0;
				}
				if (double.TryParse(Convert.ToString(dataGridViewPortfolio.Rows[i].Cells["Open_price"].Value), out FormTransaction.TransactionPaper.price))
				{
					if (FormTransaction.TransactionPaper.price < 0.0)
					{
						FormTransaction.TransactionPaper.price = 0.0;
					}
				}
				else
				{
					FormTransaction.TransactionPaper.price = 0.0;
				}
				FormTransaction.TransactionPaper.strategy = text;
				FormTransaction.TransactionTable.Add(FormTransaction.TransactionPaper);
			}
			int num2 = (int)MessageBox.Show("Стратегия " + text + " сохранена в базу");
		}

		private void ToolStripMenuItemSaveTransaction_Click(object sender, EventArgs e)
		{
			string text = comboBoxCurrentStrategy.Text;
			int result = 0;
			int val2 = 0;
			string str1 = "";
			str1 = "";
			int rowIndex = dataGridViewPortfolio.SelectedCells[0].RowIndex;
			string str2 = fTransaction.NameInstrument(text);
			for (int index = 0; index < FormTransaction.TransactionTable.Count; index++)
			{
				if (FormTransaction.TransactionTable[index].number.Substring(0, 4) == "Demo" && int.TryParse(FormTransaction.TransactionTable[index].number.Substring(4, FormTransaction.TransactionTable[index].number.Length - 4), out result))
				{
					val2 = Math.Max(result, val2);
				}
			}
			string paperCode = Convert.ToString(dataGridViewPortfolio.Rows[rowIndex].Cells["Paper_code"].Value);
			if (paperCode != "FixedProfit" && paperCode != "Итого:" && Convert.ToString(dataGridViewPortfolio.Rows[rowIndex].Cells["Check"].Value) == "True")
			{
				if (paperCode.Remove(2) == str2 || str2 == "" || paperCode.Contains("_CLT") || Helpers.IsSpotOption(paperCode))
				{
					int num1 = val2 + 1;
					FormTransaction.TransactionPaper.number = Convert.ToString("Demo" + Convert.ToString(num1));
					FormTransaction.TransactionPaper.date = Convert.ToDateTime(DateTime.Now.ToShortDateString());
					FormTransaction.TransactionPaper.time = Convert.ToDateTime(DateTime.Now.ToShortTimeString());
					FormTransaction.TransactionPaper.paper_code = Convert.ToString(dataGridViewPortfolio.Rows[rowIndex].Cells["Paper_code"].Value);
					if (double.TryParse(Convert.ToString(dataGridViewPortfolio.Rows[rowIndex].Cells["Volume"].Value), out FormTransaction.TransactionPaper.volume))
					{
						if (FormTransaction.TransactionPaper.volume < 0.0)
						{
							FormTransaction.TransactionPaper.volume = Math.Abs(FormTransaction.TransactionPaper.volume);
							FormTransaction.TransactionPaper.operation = "Продажа";
						}
						else
						{
							FormTransaction.TransactionPaper.volume = Math.Abs(FormTransaction.TransactionPaper.volume);
							FormTransaction.TransactionPaper.operation = "Купля";
						}
					}
					else
					{
						FormTransaction.TransactionPaper.volume = 0.0;
					}
					if (double.TryParse(Convert.ToString(dataGridViewPortfolio.Rows[rowIndex].Cells["Open_price"].Value), out FormTransaction.TransactionPaper.price))
					{
						if (FormTransaction.TransactionPaper.price < 0.0)
						{
							FormTransaction.TransactionPaper.price = 0.0;
						}
					}
					else
					{
						FormTransaction.TransactionPaper.price = 0.0;
					}
					FormTransaction.TransactionPaper.strategy = text;
					FormTransaction.TransactionTable.Add(FormTransaction.TransactionPaper);
					int num2 = (int)MessageBox.Show("Сделка с кодом бумаги " + FormTransaction.TransactionPaper.paper_code + " сохранена под номером " + FormTransaction.TransactionPaper.number);
				}
				else
				{
					int num3 = (int)MessageBox.Show("Я немогу сохранить сделку, код инструмента должен начинаться с " + str2);
				}
			}
			else
			{
				int num4 = (int)MessageBox.Show("Я немогу сохранить сделку с кодом FixedProfit или Итого: или со снятым чекбоксом");
			}
		}

		private double CalculationGO()
		{
			double num1 = 0.0;
			FuturePaper1.base_asset = "";
			FuturePaper1.last_price = 0.0;
			FuturePaper1.step_price = 0.0;
			FuturePaper1.decimal_points = 0.0;
			FuturePaper1.F = false;
			FuturePaper2.base_asset = "";
			FuturePaper2.last_price = 0.0;
			FuturePaper2.step_price = 0.0;
			FuturePaper2.decimal_points = 0.0;
			FuturePaper2.F = false;
			for (int index = 0; index < PortfolioTable.Count; index++)
			{
				if (index == 0 && PortfolioTable[index].futures_price != 0.0)
				{
					FuturePaper1.paper_code = PortfolioTable[index].paper_code;
					FuturePaper1.base_asset = PortfolioTable[index].base_asset;
					FuturePaper1.last_price = PortfolioTable[index].futures_price;
					FuturePaper1.expiration_date = PortfolioTable[index].expiration_date;
					FuturePaper1.step_price = PortfolioTable[index].step_price;
					FuturePaper1.decimal_points = PortfolioTable[index].decimal_points;
					FuturePaper1.F = true;
				}
				else
				{
					if (PortfolioTable[index].futures_price == 0.0)
					{
						continue;
					}
					if (PortfolioTable[index].expiration_date < FuturePaper1.expiration_date)
					{
						if (Helpers.IsOption(FuturePaper1.paper_code))
						{
							FuturePaper2.paper_code = FuturePaper1.paper_code;
							FuturePaper2.base_asset = FuturePaper1.base_asset;
							FuturePaper2.last_price = FuturePaper1.last_price;
							FuturePaper2.expiration_date = FuturePaper1.expiration_date;
							FuturePaper2.step_price = FuturePaper1.step_price;
							FuturePaper2.decimal_points = FuturePaper1.decimal_points;
							FuturePaper2.F = FuturePaper1.F;
						}
						FuturePaper1.paper_code = PortfolioTable[index].paper_code;
						FuturePaper1.base_asset = PortfolioTable[index].base_asset;
						FuturePaper1.last_price = PortfolioTable[index].futures_price;
						FuturePaper1.expiration_date = PortfolioTable[index].expiration_date;
						FuturePaper1.step_price = PortfolioTable[index].step_price;
						FuturePaper1.decimal_points = PortfolioTable[index].decimal_points;
						FuturePaper1.F = true;
					}
					else if (PortfolioTable[index].expiration_date > FuturePaper1.expiration_date && Helpers.IsOption(PortfolioTable[index].paper_code))
					{
						FuturePaper2.paper_code = PortfolioTable[index].paper_code;
						FuturePaper2.base_asset = PortfolioTable[index].base_asset;
						FuturePaper2.last_price = PortfolioTable[index].futures_price;
						FuturePaper2.expiration_date = PortfolioTable[index].expiration_date;
						FuturePaper2.step_price = PortfolioTable[index].step_price;
						FuturePaper2.decimal_points = PortfolioTable[index].decimal_points;
						FuturePaper2.F = true;
					}
				}
			}
			double num2 = ((!FuturePaper1.F || !FuturePaper2.F) ? 0.0 : (FuturePaper2.last_price - FuturePaper1.last_price));
			double val2 = 0.0;
			double num3 = 10.0;
			double num4 = 35.0;
			double num5 = 30.0;
			double num6 = 1.0;
			double num7 = 1.0 * num3 * FuturePaper1.last_price / 100.0;
			int num8 = 10;
			if (FuturePaper1.F && !FuturePaper2.F)
			{
				for (int i = -1; i <= 1; i++)
				{
					for (int j = -num8; j <= num8; j++)
					{
						if (j != 0)
						{
						}
						double num9 = Convert.ToDouble(i);
						double num10 = Convert.ToDouble(j) / (double)num8 * num7;
						PortfolioTableCalculationGO.Clear();
						for (int k = 0; k < PortfolioTable.Count; k++)
						{
							PortfolioPaperCalculationGO.paper_code = PortfolioTable[k].paper_code;
							PortfolioPaperCalculationGO.base_asset = PortfolioTable[k].base_asset;
							PortfolioPaperCalculationGO.volume = PortfolioTable[k].volume;
							PortfolioPaperCalculationGO.open_price = PortfolioTable[k].open_price;
							PortfolioPaperCalculationGO.option_type = PortfolioTable[k].option_type;
							PortfolioPaperCalculationGO.strike = PortfolioTable[k].strike;
							PortfolioPaperCalculationGO.expiration_date = PortfolioTable[k].expiration_date;
							PortfolioPaperCalculationGO.current_date = ((!(PortfolioTable[k].current_date <= FuturePaper1.expiration_date)) ? FuturePaper1.expiration_date : PortfolioTable[k].current_date);
							PortfolioPaperCalculationGO.accumulated_profit = 0.0;
							PortfolioPaperCalculationGO.volatility = PortfolioTable[k].volatility + PortfolioTable[k].volatility * num9 * num4 / 100.0;
							PortfolioPaperCalculationGO.step_price = PortfolioTable[k].step_price;
							PortfolioPaperCalculationGO.decimal_points = PortfolioTable[k].decimal_points;
							if (PortfolioPaperCalculationGO.base_asset == FuturePaper1.base_asset)
							{
								PortfolioPaperCalculationGO.futures_price = FuturePaper1.last_price + num10;
							}
							else if (PortfolioPaperCalculationGO.base_asset == FuturePaper2.base_asset)
							{
								PortfolioPaperCalculationGO.futures_price = FuturePaper1.last_price + num10 + num2;
							}
							cCalculationOptions.TypeO = PortfolioPaperCalculationGO.option_type;
							cCalculationOptions.Strike = PortfolioPaperCalculationGO.strike;
							cCalculationOptions.DateExp = PortfolioPaperCalculationGO.expiration_date;
							cCalculationOptions.DateCurrent = PortfolioPaperCalculationGO.current_date;
							cCalculationOptions.Q = Convert.ToInt32(PortfolioPaperCalculationGO.volume);
							cCalculationOptions.VolaO = PortfolioTable[k].volatility;
							if (PortfolioPaperCalculationGO.base_asset == FuturePaper1.base_asset)
							{
								cCalculationOptions.LastF = FuturePaper1.last_price;
							}
							else if (PortfolioPaperCalculationGO.base_asset == FuturePaper2.base_asset)
							{
								cCalculationOptions.LastF = FuturePaper1.last_price + num2;
							}
							if (cCalculationOptions.CalculationOpt())
							{
								PortfolioPaperCalculationGO.open_price = (Helpers.IsOption(PortfolioPaperCalculationGO.paper_code) ? Math.Round(cCalculationOptions.calcTheoPrice, PortfolioPaperCalculationGO.decimal_points) : cCalculationOptions.LastF);
							}
							cCalculationOptions.DateCurrent = PortfolioPaperCalculationGO.current_date.AddDays(1.0);
							cCalculationOptions.VolaO = PortfolioPaperCalculationGO.volatility;
							cCalculationOptions.LastF = PortfolioPaperCalculationGO.futures_price;
							if (cCalculationOptions.CalculationOpt())
							{
								PortfolioPaperCalculationGO.teoretical_price = (Helpers.IsOption(PortfolioPaperCalculationGO.paper_code) ? Math.Round(cCalculationOptions.calcTheoPrice, PortfolioPaperCalculationGO.decimal_points) : PortfolioPaperCalculationGO.futures_price);
								PortfolioPaperCalculationGO.delta = Math.Round(cCalculationOptions.calcDelta, 2);
								PortfolioPaperCalculationGO.gamma = Math.Round(cCalculationOptions.calcGamma, 6);
								PortfolioPaperCalculationGO.vega = Math.Round(cCalculationOptions.calcVega, 2);
								PortfolioPaperCalculationGO.theta = Math.Round(cCalculationOptions.calcTheta, 2);
								PortfolioPaperCalculationGO.profit = (PortfolioPaperCalculationGO.teoretical_price - PortfolioPaperCalculationGO.open_price) * PortfolioPaperCalculationGO.volume;
								PortfolioPaperCalculationGO.check = true;
							}
							else
							{
								PortfolioPaperCalculationGO.delta = 0.0;
								PortfolioPaperCalculationGO.gamma = 0.0;
								PortfolioPaperCalculationGO.vega = 0.0;
								PortfolioPaperCalculationGO.theta = 0.0;
								PortfolioPaperCalculationGO.profit = 0.0;
								PortfolioPaperCalculationGO.check = false;
							}
							PortfolioTableCalculationGO.Add(PortfolioPaperCalculationGO);
						}
						double val3 = 0.0;
						for (int l = 0; l < PortfolioTableCalculationGO.Count; l++)
						{
							val3 += PortfolioTableCalculationGO[l].profit;
						}
						val2 = Math.Min(val3, val2);
					}
				}
				num1 = val2;
			}
			else if (FuturePaper1.F && FuturePaper2.F && FuturePaper1.base_asset == FuturePaper2.base_asset)
			{
				for (int m = -1; m <= 1; m++)
				{
					for (int n = -num8; n <= num8; n++)
					{
						for (int num11 = -1; num11 <= 1; num11++)
						{
							for (int num12 = 0; num12 <= 2; num12++)
							{
								if (n != 0)
								{
								}
								double num13 = Convert.ToDouble(m);
								double num14 = Convert.ToDouble(n) / (double)num8 * num7;
								PortfolioTableCalculationGO.Clear();
								for (int num15 = 0; num15 < PortfolioTable.Count; num15++)
								{
									PortfolioPaperCalculationGO.paper_code = PortfolioTable[num15].paper_code;
									PortfolioPaperCalculationGO.base_asset = PortfolioTable[num15].base_asset;
									PortfolioPaperCalculationGO.volume = PortfolioTable[num15].volume;
									PortfolioPaperCalculationGO.open_price = PortfolioTable[num15].open_price;
									PortfolioPaperCalculationGO.option_type = PortfolioTable[num15].option_type;
									PortfolioPaperCalculationGO.strike = PortfolioTable[num15].strike;
									PortfolioPaperCalculationGO.expiration_date = PortfolioTable[num15].expiration_date;
									PortfolioPaperCalculationGO.current_date = ((!(PortfolioTable[num15].current_date <= FuturePaper1.expiration_date)) ? FuturePaper1.expiration_date : PortfolioTable[num15].current_date);
									PortfolioPaperCalculationGO.accumulated_profit = 0.0;
									PortfolioPaperCalculationGO.volatility = PortfolioTable[num15].volatility + PortfolioTable[num15].volatility * num13 * num4 / 100.0;
									PortfolioPaperCalculationGO.step_price = PortfolioTable[num15].step_price;
									PortfolioPaperCalculationGO.decimal_points = PortfolioTable[num15].decimal_points;
									if (PortfolioPaperCalculationGO.base_asset == FuturePaper1.base_asset)
									{
										switch (num12)
										{
										case 0:
											PortfolioPaperCalculationGO.volatility += PortfolioPaperCalculationGO.volatility * Convert.ToDouble(num11) * num5 / 200.0;
											break;
										case 1:
											PortfolioPaperCalculationGO.volatility += PortfolioPaperCalculationGO.volatility * Convert.ToDouble(num11) * num5 / 100.0;
											break;
										}
										PortfolioPaperCalculationGO.futures_price = FuturePaper1.last_price + num14;
									}
									else if (PortfolioPaperCalculationGO.base_asset == FuturePaper2.base_asset)
									{
										switch (num12)
										{
										case 0:
											PortfolioPaperCalculationGO.volatility -= PortfolioPaperCalculationGO.volatility * Convert.ToDouble(num11) * num5 / 200.0;
											break;
										case 2:
											PortfolioPaperCalculationGO.volatility += PortfolioPaperCalculationGO.volatility * Convert.ToDouble(num11) * num5 / 100.0;
											break;
										}
										PortfolioPaperCalculationGO.futures_price = FuturePaper1.last_price + num14 + num2;
									}
									cCalculationOptions.TypeO = PortfolioPaperCalculationGO.option_type;
									cCalculationOptions.Strike = PortfolioPaperCalculationGO.strike;
									cCalculationOptions.DateExp = PortfolioPaperCalculationGO.expiration_date;
									cCalculationOptions.DateCurrent = PortfolioPaperCalculationGO.current_date;
									cCalculationOptions.Q = Convert.ToInt32(PortfolioPaperCalculationGO.volume);
									cCalculationOptions.VolaO = PortfolioTable[num15].volatility;
									if (PortfolioPaperCalculationGO.base_asset == FuturePaper1.base_asset)
									{
										cCalculationOptions.LastF = FuturePaper1.last_price;
									}
									else if (PortfolioPaperCalculationGO.base_asset == FuturePaper2.base_asset)
									{
										cCalculationOptions.LastF = FuturePaper1.last_price + num2;
									}
									if (cCalculationOptions.CalculationOpt())
									{
										PortfolioPaperCalculationGO.open_price = (Helpers.IsOption(PortfolioPaperCalculationGO.paper_code) ? Math.Round(cCalculationOptions.calcTheoPrice, PortfolioPaperCalculationGO.decimal_points) : cCalculationOptions.LastF);
									}
									cCalculationOptions.DateCurrent = PortfolioPaperCalculationGO.current_date.AddDays(1.0);
									cCalculationOptions.VolaO = PortfolioPaperCalculationGO.volatility;
									cCalculationOptions.LastF = PortfolioPaperCalculationGO.futures_price;
									if (cCalculationOptions.CalculationOpt())
									{
										PortfolioPaperCalculationGO.teoretical_price = (Helpers.IsOption(PortfolioPaperCalculationGO.paper_code) ? Math.Round(cCalculationOptions.calcTheoPrice, PortfolioPaperCalculationGO.decimal_points) : PortfolioPaperCalculationGO.futures_price);
										PortfolioPaperCalculationGO.delta = Math.Round(cCalculationOptions.calcDelta, 2);
										PortfolioPaperCalculationGO.gamma = Math.Round(cCalculationOptions.calcGamma, 6);
										PortfolioPaperCalculationGO.vega = Math.Round(cCalculationOptions.calcVega, 2);
										PortfolioPaperCalculationGO.theta = Math.Round(cCalculationOptions.calcTheta, 2);
										PortfolioPaperCalculationGO.profit = (PortfolioPaperCalculationGO.teoretical_price - PortfolioPaperCalculationGO.open_price) * PortfolioPaperCalculationGO.volume;
										PortfolioPaperCalculationGO.check = true;
									}
									else
									{
										PortfolioPaperCalculationGO.delta = 0.0;
										PortfolioPaperCalculationGO.gamma = 0.0;
										PortfolioPaperCalculationGO.vega = 0.0;
										PortfolioPaperCalculationGO.theta = 0.0;
										PortfolioPaperCalculationGO.profit = 0.0;
										PortfolioPaperCalculationGO.check = false;
									}
									PortfolioTableCalculationGO.Add(PortfolioPaperCalculationGO);
								}
								double val4 = 0.0;
								for (int num16 = 0; num16 < PortfolioTableCalculationGO.Count; num16++)
								{
									val4 += PortfolioTableCalculationGO[num16].profit;
								}
								val2 = Math.Min(val4, val2);
							}
						}
					}
				}
				num1 = val2;
			}
			else if (FuturePaper1.F && FuturePaper2.F && FuturePaper1.base_asset != FuturePaper2.base_asset)
			{
				for (int num17 = -1; num17 <= 1; num17++)
				{
					for (int num18 = -num8; num18 <= num8; num18++)
					{
						for (int num19 = -1; num19 <= 1; num19++)
						{
							for (int num20 = 0; num20 <= 2; num20++)
							{
								for (int num21 = -1; num21 <= 1; num21++)
								{
									for (int num22 = 0; num22 <= 2; num22++)
									{
										if (num18 != 0)
										{
										}
										double num23 = Convert.ToDouble(num17);
										double num24 = Convert.ToDouble(num18) / (double)num8 * num7;
										PortfolioTableCalculationGO.Clear();
										for (int num25 = 0; num25 < PortfolioTable.Count; num25++)
										{
											PortfolioPaperCalculationGO.paper_code = PortfolioTable[num25].paper_code;
											PortfolioPaperCalculationGO.base_asset = PortfolioTable[num25].base_asset;
											PortfolioPaperCalculationGO.volume = PortfolioTable[num25].volume;
											PortfolioPaperCalculationGO.open_price = PortfolioTable[num25].open_price;
											PortfolioPaperCalculationGO.option_type = PortfolioTable[num25].option_type;
											PortfolioPaperCalculationGO.strike = PortfolioTable[num25].strike;
											PortfolioPaperCalculationGO.expiration_date = PortfolioTable[num25].expiration_date;
											PortfolioPaperCalculationGO.current_date = ((!(PortfolioTable[num25].current_date <= FuturePaper1.expiration_date)) ? FuturePaper1.expiration_date : PortfolioTable[num25].current_date);
											PortfolioPaperCalculationGO.accumulated_profit = 0.0;
											PortfolioPaperCalculationGO.volatility = PortfolioTable[num25].volatility + PortfolioTable[num25].volatility * num23 * num4 / 100.0;
											PortfolioPaperCalculationGO.step_price = PortfolioTable[num25].step_price;
											PortfolioPaperCalculationGO.decimal_points = PortfolioTable[num25].decimal_points;
											if (PortfolioPaperCalculationGO.base_asset == FuturePaper1.base_asset)
											{
												switch (num20)
												{
												case 0:
													PortfolioPaperCalculationGO.volatility += PortfolioPaperCalculationGO.volatility * Convert.ToDouble(num19) * num5 / 200.0;
													break;
												case 1:
													PortfolioPaperCalculationGO.volatility += PortfolioPaperCalculationGO.volatility * Convert.ToDouble(num19) * num5 / 100.0;
													break;
												}
												PortfolioPaperCalculationGO.futures_price = FuturePaper1.last_price + num24;
												switch (num22)
												{
												case 0:
													PortfolioPaperCalculationGO.futures_price = cCalculationOptions.RoundStepPrice(PortfolioPaperCalculationGO.futures_price + PortfolioPaperCalculationGO.futures_price * Convert.ToDouble(num21) * num6 / 200.0, FuturePaper1.step_price);
													break;
												case 1:
													PortfolioPaperCalculationGO.futures_price = cCalculationOptions.RoundStepPrice(PortfolioPaperCalculationGO.futures_price + PortfolioPaperCalculationGO.futures_price * Convert.ToDouble(num21) * num6 / 100.0, FuturePaper1.step_price);
													break;
												}
											}
											else if (PortfolioPaperCalculationGO.base_asset == FuturePaper2.base_asset)
											{
												switch (num20)
												{
												case 0:
													PortfolioPaperCalculationGO.volatility -= PortfolioPaperCalculationGO.volatility * Convert.ToDouble(num19) * num5 / 200.0;
													break;
												case 2:
													PortfolioPaperCalculationGO.volatility += PortfolioPaperCalculationGO.volatility * Convert.ToDouble(num19) * num5 / 100.0;
													break;
												}
												PortfolioPaperCalculationGO.futures_price = FuturePaper1.last_price + num24 + num2;
												switch (num22)
												{
												case 0:
													PortfolioPaperCalculationGO.futures_price = cCalculationOptions.RoundStepPrice(PortfolioPaperCalculationGO.futures_price - PortfolioPaperCalculationGO.futures_price * Convert.ToDouble(num21) * num6 / 200.0, FuturePaper2.step_price);
													break;
												case 2:
													PortfolioPaperCalculationGO.futures_price = cCalculationOptions.RoundStepPrice(PortfolioPaperCalculationGO.futures_price + PortfolioPaperCalculationGO.futures_price * Convert.ToDouble(num21) * num6 / 100.0, FuturePaper2.step_price);
													break;
												}
											}
											cCalculationOptions.TypeO = PortfolioPaperCalculationGO.option_type;
											cCalculationOptions.Strike = PortfolioPaperCalculationGO.strike;
											cCalculationOptions.DateExp = PortfolioPaperCalculationGO.expiration_date;
											cCalculationOptions.DateCurrent = PortfolioPaperCalculationGO.current_date;
											cCalculationOptions.Q = Convert.ToInt32(PortfolioPaperCalculationGO.volume);
											cCalculationOptions.VolaO = PortfolioTable[num25].volatility;
											if (PortfolioPaperCalculationGO.base_asset == FuturePaper1.base_asset)
											{
												cCalculationOptions.LastF = FuturePaper1.last_price;
											}
											else if (PortfolioPaperCalculationGO.base_asset == FuturePaper2.base_asset)
											{
												cCalculationOptions.LastF = FuturePaper1.last_price + num2;
											}
											if (cCalculationOptions.CalculationOpt())
											{
												PortfolioPaperCalculationGO.open_price = (Helpers.IsOption(PortfolioPaperCalculationGO.paper_code) ? Math.Round(cCalculationOptions.calcTheoPrice, PortfolioPaperCalculationGO.decimal_points) : cCalculationOptions.LastF);
											}
											cCalculationOptions.DateCurrent = PortfolioPaperCalculationGO.current_date.AddDays(1.0);
											cCalculationOptions.VolaO = PortfolioPaperCalculationGO.volatility;
											cCalculationOptions.LastF = PortfolioPaperCalculationGO.futures_price;
											if (cCalculationOptions.CalculationOpt())
											{
												PortfolioPaperCalculationGO.teoretical_price = (Helpers.IsOption(PortfolioPaperCalculationGO.paper_code) ? Math.Round(cCalculationOptions.calcTheoPrice, PortfolioPaperCalculationGO.decimal_points) : PortfolioPaperCalculationGO.futures_price);
												PortfolioPaperCalculationGO.delta = Math.Round(cCalculationOptions.calcDelta, 2);
												PortfolioPaperCalculationGO.gamma = Math.Round(cCalculationOptions.calcGamma, 6);
												PortfolioPaperCalculationGO.vega = Math.Round(cCalculationOptions.calcVega, 2);
												PortfolioPaperCalculationGO.theta = Math.Round(cCalculationOptions.calcTheta, 2);
												PortfolioPaperCalculationGO.profit = (PortfolioPaperCalculationGO.teoretical_price - PortfolioPaperCalculationGO.open_price) * PortfolioPaperCalculationGO.volume;
												PortfolioPaperCalculationGO.check = true;
											}
											else
											{
												PortfolioPaperCalculationGO.delta = 0.0;
												PortfolioPaperCalculationGO.gamma = 0.0;
												PortfolioPaperCalculationGO.vega = 0.0;
												PortfolioPaperCalculationGO.theta = 0.0;
												PortfolioPaperCalculationGO.profit = 0.0;
												PortfolioPaperCalculationGO.check = false;
											}
											PortfolioTableCalculationGO.Add(PortfolioPaperCalculationGO);
										}
										double val5 = 0.0;
										for (int num26 = 0; num26 < PortfolioTableCalculationGO.Count; num26++)
										{
											val5 += PortfolioTableCalculationGO[num26].profit;
										}
										val2 = Math.Min(val5, val2);
									}
								}
							}
						}
					}
				}
				num1 = val2;
			}
			return num1;
		}

		private double CalculationMarginMoex()
		{
			double initMargin = 0.0;
			string url = "https://iss.moex.com/iss/apps/option-calc/v1/portfolio/initial_margin";
			string json = "[";
			List<string> positionElements = new List<string>();
			List<Portfolio> selected = PortfolioTable.FindAll((Portfolio r) => r.check && r.check_calculation);
			if (selected.Count == 0)
			{
				return initMargin;
			}
			for (int index = 0; index < selected.Count; index++)
			{
				Portfolio positionElement = selected[index];
				string queryStringForElement = "{\"secid\":\"" + positionElement.paper_code + "\",\"quantity\":" + Convert.ToString(positionElement.volume) + ",\"price\":" + Convert.ToString(positionElement.open_price).Replace(",", ".") + "}";
				json += queryStringForElement;
				if (index < selected.Count - 1)
				{
					json += ",";
				}
			}
			json += "]";
			try
			{
				WebRequest request = WebRequest.Create(url);
				request.Method = "POST";
				byte[] byteArray = Encoding.UTF8.GetBytes(json);
				request.ContentType = "application/json";
				request.ContentLength = byteArray.Length;
				using (Stream dataStream = request.GetRequestStream())
				{
					dataStream.Write(byteArray, 0, byteArray.Length);
				}
				using (WebResponse response = request.GetResponse())
				{
					using (Stream responseStream = response.GetResponseStream())
					{
						using (StreamReader reader = new StreamReader(responseStream))
						{
							string responseFromServer = reader.ReadToEnd();
							if (responseFromServer.Length == 0)
							{
								MessageBox.Show("Ошибка: сервер iss.moex не отдал данные");
								return initMargin;
							}
							return double.Parse(responseFromServer, CultureInfo.InvariantCulture);
						}
					}
				}
			}
			catch (Exception ex)
			{
				MessageBox.Show("Ошибка: " + ex.Message);
			}
			return initMargin;
		}

		private void buttonCalculateGO_Click(object sender, EventArgs e)
		{
			labelGO.Text = "";
			labelGO.Text = Convert.ToString(Math.Round(CalculationMarginMoex(), 2));
		}

		public static int DifferenceInDays(DateTime oldDate, DateTime newDate)
		{
			return (newDate - oldDate).Days;
		}

		private void dataGridViewPortfolio_CellContentClick(object sender, DataGridViewCellEventArgs e)
		{
			if (e.ColumnIndex == 15)
			{
				if (e.RowIndex >= 0)
				{
					if (Convert.ToString(dataGridViewPortfolio.Rows[e.RowIndex].Cells["Paper_code"].Value) == "Итого:")
					{
						dataGridViewPortfolio.Rows.Clear();
						FixedProfit = 0.0;
					}
					else if (Convert.ToString(dataGridViewPortfolio.Rows[e.RowIndex].Cells["Paper_code"].Value) == "FixedProfit")
					{
						dataGridViewPortfolio.Rows.RemoveAt(e.RowIndex);
						FixedProfit = 0.0;
					}
					else
					{
						dataGridViewPortfolio.Rows.RemoveAt(e.RowIndex);
					}
				}
				Tick();
				CallBackMy.callbackEventHandlerTickChart();
			}
			if (e.ColumnIndex != 0)
			{
				return;
			}
			if (e.RowIndex >= 0)
			{
				if (Convert.ToString(dataGridViewPortfolio.Rows[e.RowIndex].Cells["Check"].Value) == "True")
				{
					dataGridViewPortfolio.Rows[e.RowIndex].Cells["Check"].Value = false;
					dataGridViewPortfolio.Rows[e.RowIndex].DefaultCellStyle.ForeColor = ClassColorTheme.BackColorPaleFore;
				}
				else
				{
					dataGridViewPortfolio.Rows[e.RowIndex].Cells["Check"].Value = true;
					dataGridViewPortfolio.Rows[e.RowIndex].DefaultCellStyle.ForeColor = ClassColorTheme.BackColorFore;
				}
			}
			Tick();
			CallBackMy.callbackEventHandlerTickChart();
		}

		private void comboBoxCurrentStrategy_SelectedIndexChanged(object sender, EventArgs e)
		{
			UpdatePortfolio(comboBoxCurrentStrategy.Text);
		}

		private void buttonHide_Click(object sender, EventArgs e)
		{
			int iHeightPortfolio = 75;
			string str = "☐";
			if (buttonHide.Text == "_")
			{
				heightPortfolio = base.Height + 4;
				CallBackMy.callbackEventHandlerHeightPortfolio(iHeightPortfolio);
				buttonHide.Text = str;
			}
			else
			{
				CallBackMy.callbackEventHandlerHeightPortfolio(heightPortfolio);
				buttonHide.Text = "_";
			}
		}

		public string GetCurrentStrategy()
		{
			dGetCurrentStrategy getCurrentStrategy = GetCurrentStrategy;
			return (!comboBoxCurrentStrategy.InvokeRequired) ? comboBoxCurrentStrategy.Text : Convert.ToString(Invoke(getCurrentStrategy, new object[0]));
		}

		public double GetD()
		{
			dGetDVP dGetDvp = GetD;
			double result = 0.0;
			if (!double.TryParse((!textBoxDays.InvokeRequired) ? textBoxDays.Text : Convert.ToString(Invoke(dGetDvp, new object[0])), out result))
			{
				result = 0.0;
			}
			return result;
		}

		public double GetV()
		{
			dGetDVP dGetDvp = GetV;
			double result = 0.0;
			if (!double.TryParse((!textBoxVola.InvokeRequired) ? textBoxVola.Text : Convert.ToString(Invoke(dGetDvp, new object[0])), out result))
			{
				result = 0.0;
			}
			return result;
		}

		public double GetP()
		{
			dGetDVP dGetDvp = GetP;
			double result = 0.0;
			if (!double.TryParse((!textBoxPrice.InvokeRequired) ? textBoxPrice.Text : Convert.ToString(Invoke(dGetDvp, new object[0])), out result))
			{
				result = 0.0;
			}
			return result;
		}

		private string FillStrApplication(string fClassCode, string fOperation, string fPrice, string fLots)
		{
			string clientCode = ClientCode;
			string str1 = Convert.ToString(FormMain.idDH);
			string str2 = "SPBFUT";
			string str3 = "L";
			string str5 = "NEW_ORDER";
			return "ACCOUNT=" + clientCode + ";TYPE=" + str3 + ";TRANS_ID=" + str1 + ";CLASSCODE=" + str2 + ";SECCODE=" + fClassCode + ";ACTION=" + str5 + ";OPERATION=" + fOperation + ";PRICE=" + fPrice + ";QUANTITY=" + fLots + ";";
		}

		private void ToolStripMenuItemGlass_Click(object sender, EventArgs e)
		{
			bool flag = true;
			string iText = "";
			if (dataGridViewPortfolio.SelectedCells[0].RowIndex >= 0)
			{
				if (dataGridViewPortfolio.SelectedCells[0].ColumnIndex > 0 && dataGridViewPortfolio.SelectedCells[0].ColumnIndex < 15 && Convert.ToString(dataGridViewPortfolio.Rows[dataGridViewPortfolio.SelectedCells[0].RowIndex].Cells[1].Value) != "FixedProfit" && Convert.ToString(dataGridViewPortfolio.Rows[dataGridViewPortfolio.SelectedCells[0].RowIndex].Cells[1].Value) != "Итого:")
				{
					iText = Convert.ToString(dataGridViewPortfolio.Rows[dataGridViewPortfolio.SelectedCells[0].RowIndex].Cells[1].Value);
				}
				else
				{
					int num = (int)MessageBox.Show("Необходимо выделять правильные ячейки");
					flag = false;
				}
				if (flag)
				{
					CallBackMy.callbackEventHandlerOpenGlass(iText);
				}
			}
		}

		protected override void Dispose(bool disposing)
		{
			if (disposing && components != null)
			{
				components.Dispose();
			}
			base.Dispose(disposing);
		}

		private void InitializeComponent()
		{
			this.components = new System.ComponentModel.Container();
			System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(OptionFVV.FormPortfolio));
			this.groupBoxPortfolio = new System.Windows.Forms.GroupBox();
			this.buttonUpdateStrategy = new System.Windows.Forms.Button();
			this.label1 = new System.Windows.Forms.Label();
			this.numericUpDownIndentDelta = new System.Windows.Forms.NumericUpDown();
			this.numericUpDownDelta = new System.Windows.Forms.NumericUpDown();
			this.checkBoxModelSmile = new System.Windows.Forms.CheckBox();
			this.checkBoxDH = new System.Windows.Forms.CheckBox();
			this.dataGridViewPortfolio = new System.Windows.Forms.DataGridView();
			this.buttonHide = new System.Windows.Forms.Button();
			this.labelP2 = new System.Windows.Forms.Label();
			this.labelP1 = new System.Windows.Forms.Label();
			this.textBoxPrice2 = new System.Windows.Forms.TextBox();
			this.label6 = new System.Windows.Forms.Label();
			this.textBoxVola2 = new System.Windows.Forms.TextBox();
			this.label5 = new System.Windows.Forms.Label();
			this.buttonSave = new System.Windows.Forms.Button();
			this.labelGO = new System.Windows.Forms.Label();
			this.buttonCalculateGO = new System.Windows.Forms.Button();
			this.buttonRemoveStrategy = new System.Windows.Forms.Button();
			this.textBoxPrice = new System.Windows.Forms.TextBox();
			this.label4 = new System.Windows.Forms.Label();
			this.textBoxVola = new System.Windows.Forms.TextBox();
			this.label3 = new System.Windows.Forms.Label();
			this.textBoxDays = new System.Windows.Forms.TextBox();
			this.label2 = new System.Windows.Forms.Label();
			this.comboBoxCurrentStrategy = new System.Windows.Forms.ComboBox();
			this.contextMenuStripPortfolio = new System.Windows.Forms.ContextMenuStrip(this.components);
			this.ToolStripMenuItemSaveTransaction = new System.Windows.Forms.ToolStripMenuItem();
			this.ToolStripMenuItemGlass = new System.Windows.Forms.ToolStripMenuItem();
			this.buttonApplyStrategy = new System.Windows.Forms.Button();
			this.groupBoxPortfolio.SuspendLayout();
			((System.ComponentModel.ISupportInitialize)this.numericUpDownIndentDelta).BeginInit();
			((System.ComponentModel.ISupportInitialize)this.numericUpDownDelta).BeginInit();
			((System.ComponentModel.ISupportInitialize)this.dataGridViewPortfolio).BeginInit();
			this.contextMenuStripPortfolio.SuspendLayout();
			base.SuspendLayout();
			this.groupBoxPortfolio.Controls.Add(this.buttonApplyStrategy);
			this.groupBoxPortfolio.Controls.Add(this.buttonUpdateStrategy);
			this.groupBoxPortfolio.Controls.Add(this.label1);
			this.groupBoxPortfolio.Controls.Add(this.numericUpDownIndentDelta);
			this.groupBoxPortfolio.Controls.Add(this.numericUpDownDelta);
			this.groupBoxPortfolio.Controls.Add(this.checkBoxModelSmile);
			this.groupBoxPortfolio.Controls.Add(this.checkBoxDH);
			this.groupBoxPortfolio.Controls.Add(this.dataGridViewPortfolio);
			this.groupBoxPortfolio.Controls.Add(this.buttonHide);
			this.groupBoxPortfolio.Controls.Add(this.labelP2);
			this.groupBoxPortfolio.Controls.Add(this.labelP1);
			this.groupBoxPortfolio.Controls.Add(this.textBoxPrice2);
			this.groupBoxPortfolio.Controls.Add(this.label6);
			this.groupBoxPortfolio.Controls.Add(this.textBoxVola2);
			this.groupBoxPortfolio.Controls.Add(this.label5);
			this.groupBoxPortfolio.Controls.Add(this.buttonSave);
			this.groupBoxPortfolio.Controls.Add(this.labelGO);
			this.groupBoxPortfolio.Controls.Add(this.buttonCalculateGO);
			this.groupBoxPortfolio.Controls.Add(this.buttonRemoveStrategy);
			this.groupBoxPortfolio.Controls.Add(this.textBoxPrice);
			this.groupBoxPortfolio.Controls.Add(this.label4);
			this.groupBoxPortfolio.Controls.Add(this.textBoxVola);
			this.groupBoxPortfolio.Controls.Add(this.label3);
			this.groupBoxPortfolio.Controls.Add(this.textBoxDays);
			this.groupBoxPortfolio.Controls.Add(this.label2);
			this.groupBoxPortfolio.Controls.Add(this.comboBoxCurrentStrategy);
			this.groupBoxPortfolio.Dock = System.Windows.Forms.DockStyle.Fill;
			this.groupBoxPortfolio.Location = new System.Drawing.Point(0, 0);
			this.groupBoxPortfolio.Name = "groupBoxPortfolio";
			this.groupBoxPortfolio.Size = new System.Drawing.Size(1275, 262);
			this.groupBoxPortfolio.TabIndex = 0;
			this.groupBoxPortfolio.TabStop = false;
			this.groupBoxPortfolio.Text = "Портфель";
			this.buttonUpdateStrategy.Location = new System.Drawing.Point(131, 20);
			this.buttonUpdateStrategy.Name = "buttonUpdateStrategy";
			this.buttonUpdateStrategy.FlatStyle = System.Windows.Forms.FlatStyle.System;
			this.buttonUpdateStrategy.Size = new System.Drawing.Size(72, 23);
			this.buttonUpdateStrategy.TabIndex = 26;
			this.buttonUpdateStrategy.Text = "Обновить";
			this.buttonUpdateStrategy.UseVisualStyleBackColor = true;
			this.buttonUpdateStrategy.Click += new System.EventHandler(buttonUpdateStrategy_Click);
			this.label1.AutoSize = true;
			this.label1.Location = new System.Drawing.Point(521, 25);
			this.label1.Name = "label1";
			this.label1.Size = new System.Drawing.Size(35, 13);
			this.label1.TabIndex = 25;
			this.label1.Text = "label1";
			this.numericUpDownIndentDelta.Location = new System.Drawing.Point(439, 23);
			this.numericUpDownIndentDelta.Name = "numericUpDownIndentDelta";
			this.numericUpDownIndentDelta.ReadOnly = true;
			this.numericUpDownIndentDelta.Size = new System.Drawing.Size(33, 20);
			this.numericUpDownIndentDelta.TabIndex = 24;
			this.numericUpDownDelta.Location = new System.Drawing.Point(400, 23);
			this.numericUpDownDelta.Minimum = new decimal(new int[4] { 100, 0, 0, -2147483648 });
			this.numericUpDownDelta.Name = "numericUpDownDelta";
			this.numericUpDownDelta.ReadOnly = true;
			this.numericUpDownDelta.Size = new System.Drawing.Size(33, 20);
			this.numericUpDownDelta.TabIndex = 23;
			this.checkBoxModelSmile.AutoSize = true;
			this.checkBoxModelSmile.Location = new System.Drawing.Point(478, 24);
			this.checkBoxModelSmile.Name = "checkBoxModelSmile";
			this.checkBoxModelSmile.Size = new System.Drawing.Size(35, 17);
			this.checkBoxModelSmile.TabIndex = 22;
			this.checkBoxModelSmile.Text = "M";
			this.checkBoxModelSmile.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
			this.checkBoxModelSmile.UseVisualStyleBackColor = true;
			this.checkBoxDH.AutoSize = true;
			this.checkBoxDH.Enabled = false;
			this.checkBoxDH.Location = new System.Drawing.Point(352, 25);
			this.checkBoxDH.Name = "checkBoxDH";
			this.checkBoxDH.Size = new System.Drawing.Size(42, 17);
			this.checkBoxDH.TabIndex = 22;
			this.checkBoxDH.Text = "DH";
			this.checkBoxDH.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
			this.checkBoxDH.UseVisualStyleBackColor = true;
			this.dataGridViewPortfolio.AllowUserToAddRows = false;
			this.dataGridViewPortfolio.AllowUserToDeleteRows = false;
			this.dataGridViewPortfolio.Anchor = System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left | System.Windows.Forms.AnchorStyles.Right;
			this.dataGridViewPortfolio.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
			this.dataGridViewPortfolio.Location = new System.Drawing.Point(6, 49);
			this.dataGridViewPortfolio.Name = "dataGridViewPortfolio";
			this.dataGridViewPortfolio.Size = new System.Drawing.Size(1263, 207);
			this.dataGridViewPortfolio.TabIndex = 21;
			this.dataGridViewPortfolio.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(dataGridViewPortfolio_CellContentClick);
			this.buttonHide.Anchor = System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right;
			this.buttonHide.Location = new System.Drawing.Point(1245, 19);
			this.buttonHide.Name = "buttonHide";
			this.buttonHide.Size = new System.Drawing.Size(24, 23);
			this.buttonHide.TabIndex = 20;
			this.buttonHide.Text = "_";
			this.buttonHide.UseVisualStyleBackColor = true;
			this.buttonHide.Click += new System.EventHandler(buttonHide_Click);
			this.labelP2.AutoSize = true;
			this.labelP2.Location = new System.Drawing.Point(1014, 26);
			this.labelP2.Name = "labelP2";
			this.labelP2.Size = new System.Drawing.Size(10, 13);
			this.labelP2.TabIndex = 19;
			this.labelP2.Text = " ";
			this.labelP1.AutoSize = true;
			this.labelP1.Location = new System.Drawing.Point(851, 25);
			this.labelP1.Name = "labelP1";
			this.labelP1.Size = new System.Drawing.Size(10, 13);
			this.labelP1.TabIndex = 18;
			this.labelP1.Text = " ";
			this.textBoxPrice2.Location = new System.Drawing.Point(951, 23);
			this.textBoxPrice2.Name = "textBoxPrice2";
			this.textBoxPrice2.Size = new System.Drawing.Size(57, 20);
			this.textBoxPrice2.TabIndex = 17;
			this.textBoxPrice2.Text = "0";
			this.textBoxPrice2.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
			this.label6.AutoSize = true;
			this.label6.Location = new System.Drawing.Point(922, 26);
			this.label6.Name = "label6";
			this.label6.Size = new System.Drawing.Size(20, 13);
			this.label6.TabIndex = 16;
			this.label6.Text = "P2";
			this.textBoxVola2.Location = new System.Drawing.Point(707, 22);
			this.textBoxVola2.Name = "textBoxVola2";
			this.textBoxVola2.Size = new System.Drawing.Size(32, 20);
			this.textBoxVola2.TabIndex = 15;
			this.textBoxVola2.Text = "0";
			this.textBoxVola2.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
			this.label5.AutoSize = true;
			this.label5.Location = new System.Drawing.Point(681, 25);
			this.label5.Name = "label5";
			this.label5.Size = new System.Drawing.Size(20, 13);
			this.label5.TabIndex = 14;
			this.label5.Text = "V2";
			this.buttonSave.Location = new System.Drawing.Point(271, 20);
			this.buttonSave.Name = "buttonSave";
			this.buttonSave.FlatStyle = System.Windows.Forms.FlatStyle.System;
			this.buttonSave.Size = new System.Drawing.Size(72, 23);
			this.buttonSave.TabIndex = 13;
			this.buttonSave.Text = "Сохранить";
			this.buttonSave.UseVisualStyleBackColor = true;
			this.buttonSave.Click += new System.EventHandler(buttonSave_Click);
			this.labelGO.AutoSize = true;
			this.labelGO.Location = new System.Drawing.Point(1189, 26);
			this.labelGO.Name = "labelGO";
			this.labelGO.Size = new System.Drawing.Size(10, 13);
			this.labelGO.TabIndex = 12;
			this.labelGO.Text = " ";
			this.buttonCalculateGO.Location = new System.Drawing.Point(1079, 19);
			this.buttonCalculateGO.Name = "buttonCalculateGO";
			this.buttonCalculateGO.Size = new System.Drawing.Size(95, 23);
			this.buttonCalculateGO.FlatStyle = System.Windows.Forms.FlatStyle.System;
			this.buttonCalculateGO.TabIndex = 11;
			this.buttonCalculateGO.Text = "Рассчитать ГО";
			this.buttonCalculateGO.UseVisualStyleBackColor = true;
			this.buttonCalculateGO.Click += new System.EventHandler(buttonCalculateGO_Click);
			this.buttonRemoveStrategy.BackColor = System.Drawing.Color.DarkRed;
			this.buttonRemoveStrategy.FlatAppearance.BorderColor = System.Drawing.Color.Salmon;
			this.buttonRemoveStrategy.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Salmon;
			this.buttonRemoveStrategy.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Salmon;
			this.buttonRemoveStrategy.FlatStyle = System.Windows.Forms.FlatStyle.System;
			this.buttonRemoveStrategy.Location = new System.Drawing.Point(208, 20);
			this.buttonRemoveStrategy.Name = "buttonRemoveStrategy";
			this.buttonRemoveStrategy.Size = new System.Drawing.Size(57, 23);
			this.buttonRemoveStrategy.TabIndex = 10;
			this.buttonRemoveStrategy.Text = "Удалить";
			this.buttonRemoveStrategy.UseVisualStyleBackColor = false;
			this.buttonRemoveStrategy.Click += new System.EventHandler(buttonRemoveStrategy_Click);
			this.textBoxPrice.Location = new System.Drawing.Point(790, 22);
			this.textBoxPrice.Name = "textBoxPrice";
			this.textBoxPrice.Size = new System.Drawing.Size(55, 20);
			this.textBoxPrice.TabIndex = 9;
			this.textBoxPrice.Text = "0";
			this.textBoxPrice.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
			this.label4.AutoSize = true;
			this.label4.Location = new System.Drawing.Point(770, 25);
			this.label4.Name = "label4";
			this.label4.Size = new System.Drawing.Size(20, 13);
			this.label4.TabIndex = 8;
			this.label4.Text = "P1";
			this.textBoxVola.Location = new System.Drawing.Point(644, 22);
			this.textBoxVola.Name = "textBoxVola";
			this.textBoxVola.Size = new System.Drawing.Size(31, 20);
			this.textBoxVola.TabIndex = 7;
			this.textBoxVola.Text = "0";
			this.textBoxVola.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
			this.label3.AutoSize = true;
			this.label3.Location = new System.Drawing.Point(618, 25);
			this.label3.Name = "label3";
			this.label3.Size = new System.Drawing.Size(20, 13);
			this.label3.TabIndex = 6;
			this.label3.Text = "V1";
			this.textBoxDays.Location = new System.Drawing.Point(581, 22);
			this.textBoxDays.Name = "textBoxDays";
			this.textBoxDays.Size = new System.Drawing.Size(31, 20);
			this.textBoxDays.TabIndex = 5;
			this.textBoxDays.Text = "0";
			this.textBoxDays.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
			this.label2.AutoSize = true;
			this.label2.Location = new System.Drawing.Point(560, 25);
			this.label2.Name = "label2";
			this.label2.Size = new System.Drawing.Size(15, 13);
			this.label2.TabIndex = 4;
			this.label2.Text = "D";
			this.comboBoxCurrentStrategy.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend;
			this.comboBoxCurrentStrategy.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems;
			this.comboBoxCurrentStrategy.BackColor = System.Drawing.SystemColors.Window;
			this.comboBoxCurrentStrategy.FormattingEnabled = true;
			this.comboBoxCurrentStrategy.Location = new System.Drawing.Point(6, 22);
			this.comboBoxCurrentStrategy.Name = "comboBoxCurrentStrategy";
			this.comboBoxCurrentStrategy.Size = new System.Drawing.Size(92, 21);
			this.comboBoxCurrentStrategy.TabIndex = 2;
			this.comboBoxCurrentStrategy.SelectedIndexChanged += new System.EventHandler(comboBoxCurrentStrategy_SelectedIndexChanged);
			this.comboBoxCurrentStrategy.TextChanged += new System.EventHandler(comboBoxCurrentStrategy_Click);
			this.contextMenuStripPortfolio.Items.AddRange(new System.Windows.Forms.ToolStripItem[2] { this.ToolStripMenuItemSaveTransaction, this.ToolStripMenuItemGlass });
			this.contextMenuStripPortfolio.Name = "contextMenuStripPortfolio";
			this.contextMenuStripPortfolio.Size = new System.Drawing.Size(173, 48);
			this.contextMenuStripPortfolio.Text = "Меню портфеля";
			this.ToolStripMenuItemSaveTransaction.Image = (System.Drawing.Image)resources.GetObject("ToolStripMenuItemSaveTransaction.Image");
			this.ToolStripMenuItemSaveTransaction.Name = "ToolStripMenuItemSaveTransaction";
			this.ToolStripMenuItemSaveTransaction.Size = new System.Drawing.Size(172, 22);
			this.ToolStripMenuItemSaveTransaction.Text = "Сохранить сделку";
			this.ToolStripMenuItemSaveTransaction.Click += new System.EventHandler(ToolStripMenuItemSaveTransaction_Click);
			this.ToolStripMenuItemGlass.Name = "ToolStripMenuItemGlass";
			this.ToolStripMenuItemGlass.Size = new System.Drawing.Size(172, 22);
			this.ToolStripMenuItemGlass.Text = "Стакан";
			this.ToolStripMenuItemGlass.Click += new System.EventHandler(ToolStripMenuItemGlass_Click);
			this.buttonApplyStrategy.Location = new System.Drawing.Point(105, 21);
			this.buttonApplyStrategy.Name = "buttonApplyStrategy";
			this.buttonApplyStrategy.Size = new System.Drawing.Size(21, 23);
			this.buttonApplyStrategy.FlatStyle = System.Windows.Forms.FlatStyle.System;
			this.buttonApplyStrategy.TabIndex = 27;
			this.buttonApplyStrategy.Text = "+";
			this.buttonApplyStrategy.UseVisualStyleBackColor = true;
			this.buttonApplyStrategy.Click += new System.EventHandler(buttonApplyStrategy_Click);
			base.AutoScaleDimensions = new System.Drawing.SizeF(6f, 13f);
			base.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
			base.ClientSize = new System.Drawing.Size(1275, 262);
			base.Controls.Add(this.groupBoxPortfolio);
			base.Name = "FormPortfolio";
			base.Load += new System.EventHandler(FormPortfolio_Load);
			this.groupBoxPortfolio.ResumeLayout(false);
			this.groupBoxPortfolio.PerformLayout();
			((System.ComponentModel.ISupportInitialize)this.numericUpDownIndentDelta).EndInit();
			((System.ComponentModel.ISupportInitialize)this.numericUpDownDelta).EndInit();
			((System.ComponentModel.ISupportInitialize)this.dataGridViewPortfolio).EndInit();
			this.contextMenuStripPortfolio.ResumeLayout(false);
			base.ResumeLayout(false);
		}
	}
}
