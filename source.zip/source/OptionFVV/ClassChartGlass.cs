using System.Drawing;

namespace OptionFVV
{
	internal class ClassChartGlass
	{
		private Bitmap bmp = null;

		private Graphics graph = null;

		private Font objFont = new Font("Arial", 8f, FontStyle.Bold);

		private Brush objBrush = Brushes.Black;

		private Pen objPenLine = new Pen(Color.Black, 1f);

		private int canvasSixeX = 200;

		private int canvasSixeY = 100;

		public ClassChartGlass(int x, int y)
		{
			bmp = new Bitmap(x, y);
			graph = Graphics.FromImage(bmp);
			canvasSixeX = x;
			canvasSixeY = y;
			graph.Clear(ClassColorTheme.BackColor);
		}
	}
}
