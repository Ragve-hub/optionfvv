using System;
using System.ComponentModel;
using System.Drawing;
using System.Windows.Forms;
using OptionFVV.Properties;

namespace OptionFVV
{
	public class FormSettings : Form
	{
		private IContainer components = null;

		private TabControl tabControlSettings;

		private TabPage tabPageView;

		private Button buttonApply;

		private ComboBox comboBoxColorTheme;

		private Label label1;

		private TabPage tabPageGeneral;

		private Label label3;

		private ComboBox comboBoxUpdateTime;

		private Label label2;

		private TabPage tabPageTrade;

		private NumericUpDown numericUpDownSlippageDH;

		private Label label5;

		private TextBox textBoxAccount;

		private Label label4;

		private Label label6;

		private FolderBrowserDialog folderBrowserDialogSetupQuik;

		private Button buttonFolderQuik;

		private TextBox textBoxDDE;

		private Label label7;

		private Label label8;

		private CheckBox cbAbsWhatIf;

		private CheckBox cbOptspotHedgeFut;

		private Label label9;

		private TextBox textBoxFolderQuik;

		public FormSettings()
		{
			InitializeComponent();
		}

		private void FormSettings_Load(object sender, EventArgs e)
		{
			decimal result = default(decimal);
			textBoxFolderQuik.Text = ClassSettings.gFolderSetupQuik;
			folderBrowserDialogSetupQuik.SelectedPath = textBoxFolderQuik.Text;
			comboBoxColorTheme.Items.Clear();
			comboBoxColorTheme.Items.Add("Темный шоколад");
			comboBoxColorTheme.Items.Add("Угли с золой");
			comboBoxColorTheme.Items.Add("Витек");
			comboBoxColorTheme.Items.Add("Небо с облаками");
			comboBoxColorTheme.Items.Add("Кофе с молоком");
			comboBoxColorTheme.Items.Add("Ocean Dark");
			for (int index = 0; index < 6; index++)
			{
				if (ClassColorTheme.ColorTheme == "Темный шоколад")
				{
					comboBoxColorTheme.SelectedIndex = 0;
				}
				else if (ClassColorTheme.ColorTheme == "Угли с золой")
				{
					comboBoxColorTheme.SelectedIndex = 1;
				}
				else if (ClassColorTheme.ColorTheme == "Витек")
				{
					comboBoxColorTheme.SelectedIndex = 2;
				}
				else if (ClassColorTheme.ColorTheme == "Небо с облаками")
				{
					comboBoxColorTheme.SelectedIndex = 3;
				}
				else if (ClassColorTheme.ColorTheme == "Кофе с молоком")
				{
					comboBoxColorTheme.SelectedIndex = 4;
				}
				else if (ClassColorTheme.ColorTheme == "Ocean Dark")
				{
					comboBoxColorTheme.SelectedIndex = 5;
				}
				else
				{
					comboBoxColorTheme.SelectedIndex = 2;
				}
			}
			comboBoxUpdateTime.Items.Clear();
			comboBoxUpdateTime.Items.Add("1");
			comboBoxUpdateTime.Items.Add("2");
			comboBoxUpdateTime.Items.Add("5");
			comboBoxUpdateTime.Items.Add("10");
			for (int i = 0; i < 4; i++)
			{
				if (ClassSettings.gUpdateTime == "1000")
				{
					comboBoxUpdateTime.SelectedIndex = 0;
				}
				else if (ClassSettings.gUpdateTime == "2000")
				{
					comboBoxUpdateTime.SelectedIndex = 1;
				}
				else if (ClassSettings.gUpdateTime == "5000")
				{
					comboBoxUpdateTime.SelectedIndex = 2;
				}
				else if (ClassSettings.gUpdateTime == "10000")
				{
					comboBoxUpdateTime.SelectedIndex = 3;
				}
				else
				{
					comboBoxUpdateTime.SelectedIndex = 2;
				}
			}
			textBoxAccount.Text = ClassSettings.gAccount;
			textBoxDDE.Text = ClassDataDDE.dde_prefix;
			cbAbsWhatIf.Checked = ClassSettings.abs_whatif;
			cbOptspotHedgeFut.Checked = ClassSettings.optspot_hedge_fut;
			if (decimal.TryParse(ClassSettings.gSlippageDH, out result))
			{
				if (result < 0m)
				{
					result = default(decimal);
				}
			}
			else
			{
				result = default(decimal);
			}
			numericUpDownSlippageDH.Value = result;
			PaintColorTheme();
		}

		private void PaintColorTheme()
		{
			BackColor = ClassColorTheme.BackColor;
			ForeColor = ClassColorTheme.HeadersColorFore;
			tabPageView.BackColor = ClassColorTheme.BackColor;
			tabPageGeneral.BackColor = ClassColorTheme.BackColor;
			tabPageTrade.BackColor = ClassColorTheme.BackColor;
			tabPageView.ForeColor = ClassColorTheme.HeadersColorFore;
			tabPageGeneral.ForeColor = ClassColorTheme.HeadersColorFore;
			tabPageTrade.ForeColor = ClassColorTheme.HeadersColorFore;
			label1.BackColor = ClassColorTheme.BackColor;
			label1.ForeColor = ClassColorTheme.BackColorFore;
			label2.BackColor = ClassColorTheme.BackColor;
			label2.ForeColor = ClassColorTheme.BackColorFore;
			label3.BackColor = ClassColorTheme.BackColor;
			label3.ForeColor = ClassColorTheme.BackColorFore;
			label4.BackColor = ClassColorTheme.BackColor;
			label4.ForeColor = ClassColorTheme.BackColorFore;
			label5.BackColor = ClassColorTheme.BackColor;
			label5.ForeColor = ClassColorTheme.BackColorFore;
			buttonApply.FlatStyle = FlatStyle.System;
			comboBoxColorTheme.FlatStyle = FlatStyle.System;
			comboBoxUpdateTime.FlatStyle = FlatStyle.System;
		}

		private void buttonApply_Click(object sender, EventArgs e)
		{
			ClassSettings.gColorTheme = comboBoxColorTheme.Text;
			ClassColorTheme.FillColorVariables(comboBoxColorTheme.Text);
			CallBackMy.callbackEventHandlerColorThemeFormChart();
			CallBackMy.callbackEventHandlerColorThemeFormMain();
			CallBackMy.callbackEventHandlerColorThemeFormPortfolio();
			CallBackMy.callbackEventHandlerColorThemeFormBoard();
			CallBackMy.callbackEventHandlerColorThemeFormSmile();
			CallBackMy.callbackEventHandlerColorThemeFormCalculator();
			CallBackMy.callbackEventHandlerColorThemeFormData();
			CallBackMy.callbackEventHandlerColorThemeFormLog();
			CallBackMy.callbackEventHandlerColorThemeFormTransaction();
			CallBackMy.callbackEventHandlerUpdateTime(Convert.ToInt32(comboBoxUpdateTime.Text));
			ClassSettings.gAccount = textBoxAccount.Text;
			ClassSettings.gSlippageDH = Convert.ToString(numericUpDownSlippageDH.Value);
			FormMain.ClientCode = textBoxAccount.Text;
			FormPortfolio.ClientCode = textBoxAccount.Text;
			FormGlass.gAccount = textBoxAccount.Text;
			ClassSettings.gFolderSetupQuik = textBoxFolderQuik.Text;
			Trans2Quik.PATH_2_QUIK = textBoxFolderQuik.Text;
			ClassSettings.dde_prefix = textBoxDDE.Text;
			ClassDataDDE.dde_prefix = textBoxDDE.Text;
			ClassSettings.abs_whatif = cbAbsWhatIf.Checked;
			ClassSettings.optspot_hedge_fut = cbOptspotHedgeFut.Checked;
			ClassCalculationPortfolio.AbsWhatIf = cbAbsWhatIf.Checked;
			FormPortfolio.AbsWhatIf = cbAbsWhatIf.Checked;
			Close();
		}

		private void buttonFolderQuik_Click(object sender, EventArgs e)
		{
			DialogResult dialogResult = folderBrowserDialogSetupQuik.ShowDialog();
			folderBrowserDialogSetupQuik.Description = "Открыть папку куда установлен КВИК";
			string str = "";
			if (dialogResult == DialogResult.OK)
			{
				str = folderBrowserDialogSetupQuik.SelectedPath;
			}
			textBoxFolderQuik.Text = str;
		}

		protected override void Dispose(bool disposing)
		{
			if (disposing && components != null)
			{
				components.Dispose();
			}
			base.Dispose(disposing);
		}

		private void InitializeComponent()
		{
			System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(OptionFVV.FormSettings));
			this.tabControlSettings = new System.Windows.Forms.TabControl();
			this.tabPageView = new System.Windows.Forms.TabPage();
			this.comboBoxColorTheme = new System.Windows.Forms.ComboBox();
			this.label1 = new System.Windows.Forms.Label();
			this.tabPageGeneral = new System.Windows.Forms.TabPage();
			this.cbAbsWhatIf = new System.Windows.Forms.CheckBox();
			this.label8 = new System.Windows.Forms.Label();
			this.textBoxDDE = new System.Windows.Forms.TextBox();
			this.label7 = new System.Windows.Forms.Label();
			this.label3 = new System.Windows.Forms.Label();
			this.comboBoxUpdateTime = new System.Windows.Forms.ComboBox();
			this.label2 = new System.Windows.Forms.Label();
			this.tabPageTrade = new System.Windows.Forms.TabPage();
			this.buttonFolderQuik = new System.Windows.Forms.Button();
			this.textBoxFolderQuik = new System.Windows.Forms.TextBox();
			this.label6 = new System.Windows.Forms.Label();
			this.numericUpDownSlippageDH = new System.Windows.Forms.NumericUpDown();
			this.label5 = new System.Windows.Forms.Label();
			this.textBoxAccount = new System.Windows.Forms.TextBox();
			this.label4 = new System.Windows.Forms.Label();
			this.buttonApply = new System.Windows.Forms.Button();
			this.folderBrowserDialogSetupQuik = new System.Windows.Forms.FolderBrowserDialog();
			this.cbOptspotHedgeFut = new System.Windows.Forms.CheckBox();
			this.label9 = new System.Windows.Forms.Label();
			this.tabControlSettings.SuspendLayout();
			this.tabPageView.SuspendLayout();
			this.tabPageGeneral.SuspendLayout();
			this.tabPageTrade.SuspendLayout();
			((System.ComponentModel.ISupportInitialize)this.numericUpDownSlippageDH).BeginInit();
			base.SuspendLayout();
			this.tabControlSettings.Anchor = System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left | System.Windows.Forms.AnchorStyles.Right;
			this.tabControlSettings.Controls.Add(this.tabPageView);
			this.tabControlSettings.Controls.Add(this.tabPageGeneral);
			this.tabControlSettings.Controls.Add(this.tabPageTrade);
			this.tabControlSettings.Location = new System.Drawing.Point(0, 0);
			this.tabControlSettings.Name = "tabControlSettings";
			this.tabControlSettings.SelectedIndex = 0;
			this.tabControlSettings.Size = new System.Drawing.Size(242, 159);
			this.tabControlSettings.TabIndex = 0;
			this.tabPageView.Controls.Add(this.comboBoxColorTheme);
			this.tabPageView.Controls.Add(this.label1);
			this.tabPageView.Location = new System.Drawing.Point(4, 22);
			this.tabPageView.Name = "tabPageView";
			this.tabPageView.Padding = new System.Windows.Forms.Padding(3);
			this.tabPageView.Size = new System.Drawing.Size(234, 96);
			this.tabPageView.TabIndex = 0;
			this.tabPageView.Text = "Вид";
			this.tabPageView.UseVisualStyleBackColor = true;
			this.comboBoxColorTheme.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
			this.comboBoxColorTheme.FormattingEnabled = true;
			this.comboBoxColorTheme.Items.AddRange(new object[5] { "Витек", "Темный шоколад", "Угли с золой", "Небо с облаками", "Кофе с молоком" });
			this.comboBoxColorTheme.Location = new System.Drawing.Point(98, 6);
			this.comboBoxColorTheme.Name = "comboBoxColorTheme";
			this.comboBoxColorTheme.Size = new System.Drawing.Size(127, 21);
			this.comboBoxColorTheme.TabIndex = 1;
			this.label1.AutoSize = true;
			this.label1.Location = new System.Drawing.Point(8, 9);
			this.label1.Name = "label1";
			this.label1.Size = new System.Drawing.Size(84, 13);
			this.label1.TabIndex = 0;
			this.label1.Text = "Цветовая тема";
			this.tabPageGeneral.Controls.Add(this.cbOptspotHedgeFut);
			this.tabPageGeneral.Controls.Add(this.label9);
			this.tabPageGeneral.Controls.Add(this.cbAbsWhatIf);
			this.tabPageGeneral.Controls.Add(this.label8);
			this.tabPageGeneral.Controls.Add(this.textBoxDDE);
			this.tabPageGeneral.Controls.Add(this.label7);
			this.tabPageGeneral.Controls.Add(this.label3);
			this.tabPageGeneral.Controls.Add(this.comboBoxUpdateTime);
			this.tabPageGeneral.Controls.Add(this.label2);
			this.tabPageGeneral.Location = new System.Drawing.Point(4, 22);
			this.tabPageGeneral.Name = "tabPageGeneral";
			this.tabPageGeneral.Size = new System.Drawing.Size(234, 133);
			this.tabPageGeneral.TabIndex = 1;
			this.tabPageGeneral.Text = "Общие";
			this.tabPageGeneral.UseVisualStyleBackColor = true;
			this.cbAbsWhatIf.AutoSize = true;
			this.cbAbsWhatIf.Location = new System.Drawing.Point(182, 68);
			this.cbAbsWhatIf.Name = "cbAbsWhatIf";
			this.cbAbsWhatIf.Size = new System.Drawing.Size(15, 14);
			this.cbAbsWhatIf.TabIndex = 6;
			this.cbAbsWhatIf.UseVisualStyleBackColor = true;
			this.label8.AutoSize = true;
			this.label8.Location = new System.Drawing.Point(8, 68);
			this.label8.Name = "label8";
			this.label8.Size = new System.Drawing.Size(82, 13);
			this.label8.TabIndex = 5;
			this.label8.Text = "Абс \"что если\"";
			this.textBoxDDE.Location = new System.Drawing.Point(117, 38);
			this.textBoxDDE.Name = "textBoxDDE";
			this.textBoxDDE.Size = new System.Drawing.Size(108, 20);
			this.textBoxDDE.TabIndex = 4;
			this.label7.AutoSize = true;
			this.label7.Location = new System.Drawing.Point(7, 41);
			this.label7.Name = "label7";
			this.label7.Size = new System.Drawing.Size(69, 13);
			this.label7.TabIndex = 3;
			this.label7.Text = "DDE-сервер";
			this.label3.AutoSize = true;
			this.label3.Location = new System.Drawing.Point(167, 11);
			this.label3.Name = "label3";
			this.label3.Size = new System.Drawing.Size(42, 13);
			this.label3.TabIndex = 2;
			this.label3.Text = "секунд";
			this.comboBoxUpdateTime.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
			this.comboBoxUpdateTime.FlatStyle = System.Windows.Forms.FlatStyle.System;
			this.comboBoxUpdateTime.FormattingEnabled = true;
			this.comboBoxUpdateTime.Items.AddRange(new object[4] { "1", "2", "5", "10" });
			this.comboBoxUpdateTime.Location = new System.Drawing.Point(117, 8);
			this.comboBoxUpdateTime.Name = "comboBoxUpdateTime";
			this.comboBoxUpdateTime.Size = new System.Drawing.Size(44, 21);
			this.comboBoxUpdateTime.TabIndex = 1;
			this.label2.AutoSize = true;
			this.label2.Location = new System.Drawing.Point(8, 11);
			this.label2.Name = "label2";
			this.label2.Size = new System.Drawing.Size(103, 13);
			this.label2.TabIndex = 0;
			this.label2.Text = "Время обновления";
			this.tabPageTrade.Controls.Add(this.buttonFolderQuik);
			this.tabPageTrade.Controls.Add(this.textBoxFolderQuik);
			this.tabPageTrade.Controls.Add(this.label6);
			this.tabPageTrade.Controls.Add(this.numericUpDownSlippageDH);
			this.tabPageTrade.Controls.Add(this.label5);
			this.tabPageTrade.Controls.Add(this.textBoxAccount);
			this.tabPageTrade.Controls.Add(this.label4);
			this.tabPageTrade.Location = new System.Drawing.Point(4, 22);
			this.tabPageTrade.Name = "tabPageTrade";
			this.tabPageTrade.Size = new System.Drawing.Size(234, 96);
			this.tabPageTrade.TabIndex = 2;
			this.tabPageTrade.Text = "Торговля";
			this.tabPageTrade.UseVisualStyleBackColor = true;
			this.buttonFolderQuik.Image = OptionFVV.Properties.Resources.folder_horizontal_open;
			this.buttonFolderQuik.Location = new System.Drawing.Point(202, 59);
			this.buttonFolderQuik.Name = "buttonFolderQuik";
			this.buttonFolderQuik.Size = new System.Drawing.Size(21, 23);
			this.buttonFolderQuik.TabIndex = 6;
			this.buttonFolderQuik.UseVisualStyleBackColor = true;
			this.buttonFolderQuik.Click += new System.EventHandler(buttonFolderQuik_Click);
			this.textBoxFolderQuik.Enabled = false;
			this.textBoxFolderQuik.Location = new System.Drawing.Point(87, 59);
			this.textBoxFolderQuik.Name = "textBoxFolderQuik";
			this.textBoxFolderQuik.Size = new System.Drawing.Size(109, 20);
			this.textBoxFolderQuik.TabIndex = 5;
			this.label6.AutoSize = true;
			this.label6.Location = new System.Drawing.Point(3, 62);
			this.label6.Name = "label6";
			this.label6.Size = new System.Drawing.Size(78, 13);
			this.label6.TabIndex = 4;
			this.label6.Text = "Путь до КВИК";
			this.numericUpDownSlippageDH.Location = new System.Drawing.Point(186, 33);
			this.numericUpDownSlippageDH.Name = "numericUpDownSlippageDH";
			this.numericUpDownSlippageDH.Size = new System.Drawing.Size(37, 20);
			this.numericUpDownSlippageDH.TabIndex = 3;
			this.label5.AutoSize = true;
			this.label5.Location = new System.Drawing.Point(3, 35);
			this.label5.Name = "label5";
			this.label5.Size = new System.Drawing.Size(155, 13);
			this.label5.TabIndex = 2;
			this.label5.Text = "Проскальзывание DH, тиков";
			this.textBoxAccount.Location = new System.Drawing.Point(134, 7);
			this.textBoxAccount.Name = "textBoxAccount";
			this.textBoxAccount.Size = new System.Drawing.Size(89, 20);
			this.textBoxAccount.TabIndex = 1;
			this.label4.AutoSize = true;
			this.label4.Location = new System.Drawing.Point(3, 10);
			this.label4.Name = "label4";
			this.label4.Size = new System.Drawing.Size(72, 13);
			this.label4.TabIndex = 0;
			this.label4.Text = "Номер счета";
			this.buttonApply.Anchor = System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left;
			this.buttonApply.Location = new System.Drawing.Point(84, 165);
			this.buttonApply.Name = "buttonApply";
			this.buttonApply.Size = new System.Drawing.Size(75, 23);
			this.buttonApply.TabIndex = 2;
			this.buttonApply.Text = "Применить";
			this.buttonApply.UseVisualStyleBackColor = true;
			this.buttonApply.Click += new System.EventHandler(buttonApply_Click);
			this.cbOptspotHedgeFut.AutoSize = true;
			this.cbOptspotHedgeFut.Location = new System.Drawing.Point(182, 96);
			this.cbOptspotHedgeFut.Name = "cbOptspotHedgeFut";
			this.cbOptspotHedgeFut.Size = new System.Drawing.Size(15, 14);
			this.cbOptspotHedgeFut.TabIndex = 8;
			this.cbOptspotHedgeFut.UseVisualStyleBackColor = true;
			this.label9.AutoSize = true;
			this.label9.Location = new System.Drawing.Point(8, 96);
			this.label9.Name = "label9";
			this.label9.Size = new System.Drawing.Size(146, 13);
			this.label9.TabIndex = 7;
			this.label9.Text = "Хедж прем.опц фьючерсом";
			base.AutoScaleDimensions = new System.Drawing.SizeF(6f, 13f);
			base.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
			base.ClientSize = new System.Drawing.Size(241, 200);
			base.Controls.Add(this.buttonApply);
			base.Controls.Add(this.tabControlSettings);
			base.Icon = (System.Drawing.Icon)resources.GetObject("$this.Icon");
			base.Name = "FormSettings";
			this.Text = "Настройки";
			base.Load += new System.EventHandler(FormSettings_Load);
			this.tabControlSettings.ResumeLayout(false);
			this.tabPageView.ResumeLayout(false);
			this.tabPageView.PerformLayout();
			this.tabPageGeneral.ResumeLayout(false);
			this.tabPageGeneral.PerformLayout();
			this.tabPageTrade.ResumeLayout(false);
			this.tabPageTrade.PerformLayout();
			((System.ComponentModel.ISupportInitialize)this.numericUpDownSlippageDH).EndInit();
			base.ResumeLayout(false);
		}
	}
}
