using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.IO;
using System.Runtime.InteropServices;
using System.Text;
using System.Windows.Forms;
using FORTSTerminal;
using QuikDDE;
using QuikDDE.Data;

namespace OptionFVV
{
	public class FormMain : Form
	{
		public struct Trans
		{
			public string number;

			public double order_number;

			public DateTime date;

			public DateTime time;

			public string paper_code;

			public string operation;

			public double price;

			public double volume;

			public string strategy;
		}

		public static bool F_DllConnected;

		public static bool F_QuikConnected;

		public static bool F_WorkingTime;

		public static string ClientCode;

		public static int idDH;

		public static int orderLotDH;

		private string CacheQuotesTableNumber;

		private Trans2Quik trans_2_quik = new Trans2Quik();

		private Trans2Quik.OrderStatusHandler order_callback = null;

		private Trans2Quik.TradeStatusHandler trade_callback = null;

		private Trans2Quik.ConnectionStatusHandler conn_cb = null;

		private Trans2Quik.TransactionStatusHandler trans_callback = null;

		private TransactionsTable transactions_table_dde_server;

		private QuotesTable quotes_table_dde_server;

		private List<Transaction> transactions_table_string_list = new List<Transaction>(50000);

		private List<Quotes> quotes_table_string_list = new List<Quotes>(50000);

		private MainFormSettings main_form_settings = null;

		private TerminalSettings terminal_settings = null;

		private string BoardTheme = "";

		private string CurrentDirectory = "";

		public static int TransID;

		public List<Quotes> qQuotesTable = new List<Quotes>();

		public Quotes qQuotesPaper = default(Quotes);

		private List<Trans> tTransactionTable = new List<Trans>();

		private Trans TransPaper = default(Trans);

		private Transaction tTransactionPaper = default(Transaction);

		private List<Order> ApplicationTable = new List<Order>();

		private Order ApplicationPaper = default(Order);

		private Order ApplicationPaperLast = default(Order);

		private List<FormGlass> fGlass = new List<FormGlass>();

		private FormBoard fBoard = new FormBoard();

		private FormCalculator fCalculator = new FormCalculator();

		private FormLog fLog = new FormLog();

		private FormData fData = new FormData();

		private FormTransaction fTransaction = new FormTransaction();

		private FormPortfolio fPortfolio = new FormPortfolio();

		private FormChart fChart = new FormChart();

		private FormSmile fSmile = new FormSmile();

		private ClassSettings cSettings = new ClassSettings("");

		private ClassDataDDE cDataDDE;

		private ClassHistoryDataDDE cHistoryDataDDE = new ClassHistoryDataDDE();

		private IContainer components = null;

		private MenuStrip menuStripMain;

		private ToolStripMenuItem файлToolStripMenuItem;

		private ToolStripMenuItem настройкиToolStripMenuItem;

		private ToolStripMenuItem оПрограммеToolStripMenuItem;

		private SplitContainer splitContainerMain;

		private TabControl tabControlMain;

		private TabPage tabPageBoard;

		private TabPage tabPageCalculator;

		private StatusStrip statusStripMain;

		private ToolStripStatusLabel toolStripStatusLabelTimeCalculation;

		private Timer timerMain;

		private TabPage tabPageLog;

		private TabPage tabPageData;

		private TabPage tabPageTransaction;

		private TabPage tabPageChart;

		private TabPage tabPageSmile;

		private ToolStripStatusLabel toolStripStatusLabelInfo;

		private ToolStripMenuItem ToolStripMenuItemOpenTransaction;

		private ToolStripMenuItem ToolStripMenuItemOpenSettings;

		private ToolStripMenuItem ToolStripMenuItemSaveTransaction;

		private ToolStripMenuItem ToolStripMenuItemSaveSettings;

		private ToolStripMenuItem ToolStripMenuItemImportTransaction;

		private OpenFileDialog openFileDialogImportTransaction;

		private ToolStripMenuItem торговляToolStripMenuItem;

		private ToolStripMenuItem ведущийСтаканToolStripMenuItem;

		private ToolStripMenuItem ведомыйСтаканToolStripMenuItem;

		private ToolStripMenuItem окноToolStripMenuItem;

		private ToolStripMenuItem topMostWindowToolStripMenuItem;

		public FormMain()
		{
			CacheQuotesTableNumber = "";
			F_DllConnected = false;
			F_QuikConnected = false;
			idDH = 5000;
			TransID = 1;
			ApplicationTable.Clear();
			tTransactionTable.Clear();
			CallBackMy.callbackEventHandlerColorThemeFormMain = PaintColorTheme;
			CallBackMy.callbackEventHandlerOpenGlass = OpenGlass;
			InitializeComponent();
			if (!Directory.Exists(Directory.GetCurrentDirectory() + Path.DirectorySeparatorChar + "Settings"))
			{
				Directory.CreateDirectory(Directory.GetCurrentDirectory() + Path.DirectorySeparatorChar + "Settings");
			}
			if (!Directory.Exists(Directory.GetCurrentDirectory() + Path.DirectorySeparatorChar + "Settings" + Path.DirectorySeparatorChar + "Symbols"))
			{
				string[] strArray = new string[5]
				{
					Directory.GetCurrentDirectory(),
					null,
					null,
					null,
					null
				};
				strArray[1] = Path.DirectorySeparatorChar.ToString();
				strArray[2] = "Settings";
				strArray[3] = Path.DirectorySeparatorChar.ToString();
				strArray[4] = "Symbols";
				Directory.CreateDirectory(string.Concat(strArray));
			}
			main_form_settings = new MainFormSettings();
			terminal_settings = new TerminalSettings();
			SetDefaultSettings();
			CurrentDirectory = Application.StartupPath + "\\Settings.txt";
			cSettings.FileName = CurrentDirectory;
			cSettings.ReadFileSettings();
			Trans2Quik.PATH_2_QUIK = cSettings.FolderSetupQuik;
			ClassDataDDE.dde_prefix = cSettings.DDEPrefix;
			ClassDataDDE.optspot_hedge_fut = cSettings.OptspotHedgeFut;
			ClassSettings.abs_whatif = cSettings.AbsWhatIf;
			ClassSettings.optspot_hedge_fut = cSettings.OptspotHedgeFut;
			ClassCalculationPortfolio.AbsWhatIf = cSettings.AbsWhatIf;
			FormPortfolio.AbsWhatIf = cSettings.AbsWhatIf;
			cDataDDE = new ClassDataDDE(true);
		}

		public void SetDefaultSettings()
		{
			main_form_settings.MainFormLocation = new Point(100, 100);
			main_form_settings.MainFormWindowState = FormWindowState.Normal;
			main_form_settings.MainFormTopMost = false;
			main_form_settings.MainFormSize = new Size(900, 639);
		}

		public void setBoardTheme(string str)
		{
			BoardTheme = str;
		}

		private void timerMain_Tick(object sender, EventArgs e)
		{
			long ticks = DateTime.Now.Ticks;
			if (F_DllConnected)
			{
			}
			F_WorkingTime = CheckWorkingTime();
			if (fGlass.Count > 0)
			{
				for (int index = 0; index < fGlass.Count; index++)
				{
					if (fGlass[index].Created)
					{
						fGlass[index].Tick();
					}
				}
			}
			fPortfolio.Tick();
			if (tabControlMain.SelectedTab.Name == "tabPageData")
			{
				fData.Tick();
			}
			else if (tabControlMain.SelectedTab.Name == "tabPageBoard")
			{
				fBoard.Tick();
			}
			else if (tabControlMain.SelectedTab.Name == "tabPageTransaction")
			{
				fTransaction.Tick();
			}
			else if (tabControlMain.SelectedTab.Name == "tabPageChart")
			{
				fChart.Tick();
			}
			else if (tabControlMain.SelectedTab.Name == "tabPageSmile")
			{
				fSmile.Tick();
			}
			toolStripStatusLabelTimeCalculation.Text = "Время обновления " + Math.Round((double)(DateTime.Now.Ticks - ticks) / 10000.0) + " мс";
		}

		private void FormMain_FormClosing(object sender, FormClosingEventArgs e)
		{
			main_form_settings.MainFormLocation = base.DesktopLocation;
			main_form_settings.MainFormWindowState = base.WindowState;
			main_form_settings.MainFormTopMost = base.TopMost;
			main_form_settings.MainFormSize = base.Size;
			terminal_settings.SaveMainFormSettings(main_form_settings);
			SaveSettings();
			fTransaction.WriteFileTransaction();
		}

		private void FormMain_Load(object sender, EventArgs e)
		{
			Text = "OptionVictory (OptionFVV) версия 2.5";
			orderLotDH = 0;
			if (terminal_settings.LoadMainFormSettings())
			{
				main_form_settings = terminal_settings.GetMainFormSettings();
			}
			SetDesktopLocation(main_form_settings.MainFormLocation.X, main_form_settings.MainFormLocation.Y);
			base.Size = main_form_settings.MainFormSize;
			base.WindowState = main_form_settings.MainFormWindowState;
			base.TopMost = main_form_settings.MainFormTopMost;
			topMostWindowToolStripMenuItem.Checked = main_form_settings.MainFormTopMost;
			CallBackMy.callbackEventHandlerUpdateTime = SetUpdateTime;
			CallBackMy.callbackEventHandlerHeightPortfolio = HeightPortfolio;
			CallBackMy.callbackEventHandlerStatusLabelInfoWrite = StatusLabelInfoWrite;
			toolStripStatusLabelInfo.Text = "";
			CurrentDirectory = Application.StartupPath + "\\Settings.txt";
			cSettings.FileName = CurrentDirectory;
			cSettings.ReadFileSettings();
			Trans2Quik.PATH_2_QUIK = cSettings.FolderSetupQuik;
			ClassDataDDE.dde_prefix = cSettings.DDEPrefix;
			ClassDataDDE.optspot_hedge_fut = cSettings.OptspotHedgeFut;
			ClassSettings.abs_whatif = cSettings.AbsWhatIf;
			ClassSettings.optspot_hedge_fut = cSettings.OptspotHedgeFut;
			ClassCalculationPortfolio.AbsWhatIf = cSettings.AbsWhatIf;
			FormPortfolio.AbsWhatIf = cSettings.AbsWhatIf;
			ClassColorTheme.FillColorVariables(cSettings.ColorTheme);
			fLog.MdiParent = this;
			tabPageLog.Controls.Add(fLog);
			fLog.Show();
			fBoard.MdiParent = this;
			fBoard.setBoardTheme(cSettings.BoardTheme);
			tabPageBoard.Controls.Add(fBoard);
			fBoard.Show();
			fChart.MdiParent = this;
			tabPageChart.Controls.Add(fChart);
			fChart.Show();
			fCalculator.MdiParent = this;
			tabPageCalculator.Controls.Add(fCalculator);
			fCalculator.Show();
			fTransaction.MdiParent = this;
			tabPageTransaction.Controls.Add(fTransaction);
			fTransaction.Show();
			fData.MdiParent = this;
			tabPageData.Controls.Add(fData);
			fData.Show();
			fPortfolio.MdiParent = this;
			splitContainerMain.Panel2.Controls.Add(fPortfolio);
			fPortfolio.Show();
			fSmile.MdiParent = this;
			tabPageSmile.Controls.Add(fSmile);
			fSmile.Show();
			timerMain.Interval = Convert.ToInt32(ClassSettings.gUpdateTime);
			timerMain.Enabled = true;
			splitContainerMain.BorderStyle = BorderStyle.None;
			tabPageSmile.BorderStyle = BorderStyle.None;
			tabPageCalculator.BorderStyle = BorderStyle.None;
			tabPageChart.BorderStyle = BorderStyle.None;
			tabPageData.BorderStyle = BorderStyle.None;
			tabPageLog.BorderStyle = BorderStyle.None;
			tabPageTransaction.BorderStyle = BorderStyle.None;
			tabPageBoard.BorderStyle = BorderStyle.None;
			PaintColorTheme();
		}

		private void PaintColorTheme()
		{
			BackColor = ClassColorTheme.BackColor;
			ForeColor = ClassColorTheme.HeadersColorFore;
			tabPageSmile.BackColor = ClassColorTheme.BackColor;
			tabPageSmile.ForeColor = ClassColorTheme.HeadersColorFore;
			splitContainerMain.BackColor = ClassColorTheme.HeadersColor;
			splitContainerMain.Panel1.BackColor = ClassColorTheme.BackColor;
			splitContainerMain.Panel2.BackColor = ClassColorTheme.BackColor;
			tabPageSmile.BackColor = ClassColorTheme.BackColor;
			tabPageCalculator.BackColor = ClassColorTheme.BackColor;
			tabPageChart.BackColor = ClassColorTheme.BackColor;
			tabPageData.BackColor = ClassColorTheme.BackColor;
			tabPageLog.BackColor = ClassColorTheme.BackColor;
			tabPageTransaction.BackColor = ClassColorTheme.BackColor;
			tabPageBoard.BackColor = ClassColorTheme.BackColor;
			menuStripMain.BackColor = ClassColorTheme.HeadersColor;
			menuStripMain.ForeColor = ClassColorTheme.HeadersColorFore;
			statusStripMain.BackColor = ClassColorTheme.HeadersColor;
			statusStripMain.ForeColor = ClassColorTheme.HeadersColorFore;
		}

		private void FormMain_Shown(object sender, EventArgs e)
		{
			tabControlMain.SelectTab("tabPageLog");
			tabControlMain.SelectTab("tabPageBoard");
			tabControlMain.SelectTab("tabPageChart");
			tabControlMain.SelectTab("tabPageTransaction");
			tabControlMain.SelectTab("tabPageCalculator");
			tabControlMain.SelectTab("tabPageData");
			tabControlMain.SelectTab("tabPageSmile");
			tabControlMain.SelectTab(ClassSettings.gCurrentTab);
			fPortfolio.CreateStrategyTable();
			fPortfolio.FillComboBoxCurrentStrategy(ClassSettings.gCurrentStrategy);
			ClientCode = ClassSettings.gAccount;
			order_callback = order_status_callback_impl;
			trade_callback = trade_status_callback_impl;
			conn_cb = connection_status_callback_Report;
			trans_callback = transaction_reply_callback_impl;
		}

		private void tabPageBoard_Enter(object sender, EventArgs e)
		{
			if (!ClassDataDDE.F_ErrorOpenFile)
			{
				fBoard.FillcomboBoxQuantity(ClassSettings.gBoardQuantity);
				fBoard.FillcomboBoxThemeBoard(ClassSettings.gBoardTheme);
				fBoard.FillcomboBoxBaseAsset(cSettings.BoardBaseAsset);
				fBoard.FillcomboBoxExpirationDate(cSettings.BoardBaseAsset, cSettings.BoardExpirationDate);
				fBoard.Tick();
			}
			else
			{
				fBoard.FillcomboBoxQuantity(ClassSettings.gBoardQuantity);
				fBoard.FillcomboBoxThemeBoard(ClassSettings.gBoardTheme);
				fBoard.FillcomboBoxBaseAsset(cSettings.BoardBaseAsset);
				fBoard.FillcomboBoxExpirationDate(cSettings.BoardBaseAsset, cSettings.BoardExpirationDate);
			}
		}

		private void tabPageData_Enter(object sender, EventArgs e)
		{
			if (!ClassDataDDE.F_ErrorOpenFile)
			{
				fData.Tick();
			}
		}

		private void tabPageTransaction_Enter(object sender, EventArgs e)
		{
			if (!ClassDataDDE.F_ErrorOpenFile)
			{
				fTransaction.CreateStrategyTable();
				fTransaction.FillComboBoxCurrentStrategy(ClassSettings.gCurrentStrategy);
				fTransaction.Tick();
			}
			else
			{
				fTransaction.CreateStrategyTable();
				fTransaction.FillComboBoxCurrentStrategy(ClassSettings.gCurrentStrategy);
				fTransaction.Tick();
			}
		}

		private void настройкиToolStripMenuItem_Click(object sender, EventArgs e)
		{
			FormSettings formSettings = new FormSettings();
			formSettings.TopMost = base.TopMost;
			int num = (int)formSettings.ShowDialog();
		}

		private void оПрограммеToolStripMenuItem_Click(object sender, EventArgs e)
		{
			FormAboutProgram formAboutProgram = new FormAboutProgram();
			formAboutProgram.TopMost = base.TopMost;
			int num = (int)formAboutProgram.ShowDialog();
		}

		private void tabPageBoard_Leave(object sender, EventArgs e)
		{
			fBoard.FillSettingsBoardQuantity();
			fBoard.FillSettingsBoardTheme();
			fBoard.FillSettingsBoardBaseAsset();
			fBoard.FillSettingsBoardExpirationDate();
		}

		private void ToolStripMenuItemOpenTransaction_Click(object sender, EventArgs e)
		{
			fTransaction.OpenFile();
		}

		private void ToolStripMenuItemSaveTransaction_Click(object sender, EventArgs e)
		{
			fTransaction.WriteFileTransaction();
			toolStripStatusLabelInfo.Text = "Сохранили сделки в файл Transaction.txt";
		}

		private void ToolStripMenuItemSaveSettings_Click(object sender, EventArgs e)
		{
			SaveSettings();
			toolStripStatusLabelInfo.Text = "Сохранили настройки в файл Settings.txt";
		}

		private void SaveSettings()
		{
			fPortfolio.FillSettingsCurrentStrategy();
			fBoard.FillSettingsBoardQuantity();
			fBoard.FillSettingsBoardTheme();
			fBoard.FillSettingsBoardBaseAsset();
			fBoard.FillSettingsBoardExpirationDate();
			ClassSettings.gCurrentTab = tabControlMain.SelectedTab.Name;
			fChart.FillSettings();
			fSmile.FillSettings();
			cSettings.WriteFileSettings();
		}

		private void ToolStripMenuItemOpenSettings_Click(object sender, EventArgs e)
		{
			cSettings.OpenFile();
		}

		private void ToolStripMenuItemImportTransaction_Click(object sender, EventArgs e)
		{
			string startupPath = Application.StartupPath;
			openFileDialogImportTransaction.Filter = "Text files(*.txt)|*.txt";
			openFileDialogImportTransaction.InitialDirectory = startupPath;
			if (openFileDialogImportTransaction.ShowDialog() == DialogResult.OK)
			{
				string fileName = openFileDialogImportTransaction.FileName;
				if (fileName.Length > 1)
				{
					fTransaction.ReadFile(fileName);
					toolStripStatusLabelInfo.Text = "Импортировали сделки из файла " + fileName;
				}
				else
				{
					toolStripStatusLabelInfo.Text = "Импортировали файла : вы невыбрали сам файл";
				}
			}
		}

		private void OpenGlass(string paper_code)
		{
			fGlass.Add(new FormGlass(paper_code, TransID));
			if (fGlass.Count - 1 >= 0)
			{
				fGlass[fGlass.Count - 1].Show();
				TransID++;
				if (TransID == idDH)
				{
					TransID++;
				}
			}
		}

		private void ведущийСтаканToolStripMenuItem_Click(object sender, EventArgs e)
		{
			fGlass.Add(new FormGlass("", TransID));
			if (fGlass.Count - 1 >= 0)
			{
				fGlass[fGlass.Count - 1].Show();
				TransID++;
				if (TransID == idDH)
				{
					TransID++;
				}
			}
		}

		private void SetUpdateTime(int updatetime)
		{
			timerMain.Enabled = false;
			timerMain.Interval = updatetime * 1000;
			ClassSettings.gUpdateTime = Convert.ToString(updatetime * 1000);
			timerMain.Enabled = true;
		}

		private void HeightPortfolio(int f_heightPortfolio)
		{
			int height = splitContainerMain.Height;
			if (height > f_heightPortfolio)
			{
				splitContainerMain.SplitterDistance = height - f_heightPortfolio;
			}
		}

		private void StatusLabelInfoWrite(string f_text)
		{
			toolStripStatusLabelInfo.Text = f_text;
		}

		public void ConnectToTrans2Quik()
		{
			byte[] lpstrErrorMessage = new byte[50];
			uint dwErrorMessageSize = 50u;
			uint pnExtendedErrorCode = 0u;
			switch (trans_2_quik.connect_test1())
			{
			case 0:
			{
				F_DllConnected = true;
				string str1 = "Dll is connected!";
				CallBackMy.callbackEventError eventHandlerError1 = CallBackMy.callbackEventHandlerError;
				string iTimeDate1 = DateTime.Now.ToLocalTime().ToString();
				string iMessage10 = str1;
				eventHandlerError1(iTimeDate1, iMessage10);
				if (trans_2_quik.IsQuikConnected())
				{
					F_QuikConnected = true;
					string str2 = "Quik is connected!";
					CallBackMy.callbackEventError eventHandlerError2 = CallBackMy.callbackEventHandlerError;
					string iTimeDate2 = DateTime.Now.ToLocalTime().ToString();
					string iMessage11 = str2;
					eventHandlerError2(iTimeDate2, iMessage11);
				}
				Trans2Quik.set_connection_status_callback(conn_cb, pnExtendedErrorCode, lpstrErrorMessage, dwErrorMessageSize);
				Trans2Quik.subscribe_trades("", "");
				Trans2Quik.start_trades(trade_callback);
				Trans2Quik.subscribe_orders("", "");
				Trans2Quik.start_orders(order_callback);
				break;
			}
			case 1:
			{
				string iMessage9 = "Dll is not connected!";
				CallBackMy.callbackEventHandlerError(DateTime.Now.ToLocalTime().ToString(), iMessage9);
				break;
			}
			case 2:
			{
				string iMessage8 = "Соединение с КВИК не запущено, или отсутствует INFO.exe или не запущены внешние транзакции в КВИК";
				CallBackMy.callbackEventHandlerError(DateTime.Now.ToLocalTime().ToString(), iMessage8);
				break;
			}
			case 3:
			{
				string iMessage7 = "Соединение с КВИК не запущено, версия Trans2Quik.dll не поддерживается КВИК";
				CallBackMy.callbackEventHandlerError(DateTime.Now.ToLocalTime().ToString(), iMessage7);
				break;
			}
			case 4:
			{
				string iMessage6 = "Соединение с КВИК уже есть";
				CallBackMy.callbackEventHandlerError(DateTime.Now.ToLocalTime().ToString(), iMessage6);
				break;
			}
			}
		}

		public void order_status_callback_impl(int nMode, int dwTransID, double dNumber, string ClassCode, string SecCode, double dPrice, int nBalance, double dValue, int nIsSell, int nStatus, int nOrderDescriptor)
		{
			bool flag1 = false;
			bool flag2 = false;
			bool flag3 = false;
			flag2 = false;
			flag3 = false;
			string str1 = "Mode=" + nMode + " TransId=" + dwTransID + " Num=" + dNumber + " Class=" + ClassCode + " Sec=" + SecCode + " Price=" + dPrice + " Balance=" + nBalance + " Value=" + dValue + " IsSell=" + nIsSell + " Status=" + nStatus;
			string str2 = "";
			string str3 = "";
			try
			{
				str3 = Trans2Quik.TRANS2QUIK_ORDER_CLIENT_CODE(nOrderDescriptor);
			}
			catch (AccessViolationException ex)
			{
				using (StreamWriter streamWriter = new StreamWriter("errors.log"))
				{
					streamWriter.WriteLine(ex.ToString());
				}
			}
			try
			{
				using (StreamWriter streamWriter2 = new StreamWriter("orders.log", true, Encoding.GetEncoding(1251)))
				{
					string str4 = str1 + str2 + str3;
					streamWriter2.WriteLine(str4);
					streamWriter2.Close();
				}
			}
			catch (Exception)
			{
			}
			if (!(ClientCode == str3) || nMode != 0)
			{
				return;
			}
			ApplicationPaper.number = dNumber;
			ApplicationPaper.paper_code = SecCode;
			ApplicationPaper.operation = nIsSell;
			ApplicationPaper.price = dPrice;
			ApplicationPaper.volume = nBalance;
			ApplicationPaper.status = nStatus;
			ApplicationPaper.ID = dwTransID;
			if (fGlass.Count > 0)
			{
				for (int index = 0; index < fGlass.Count; index++)
				{
					if (fGlass[index].Created && fGlass[index].gTransID == Convert.ToString(ApplicationPaper.ID))
					{
						fGlass[index].NewApplication(ApplicationPaper);
						break;
					}
				}
			}
			bool flag4 = false;
			for (int i = 0; i < ApplicationTable.Count; i++)
			{
				if (ApplicationPaper.number == ApplicationTable[i].number)
				{
					ApplicationTable[i] = ApplicationPaper;
					flag4 = true;
					break;
				}
			}
			if (!flag4)
			{
				ApplicationTable.Add(ApplicationPaper);
			}
			flag1 = false;
			for (int j = 0; j < tTransactionTable.Count; j++)
			{
				if (tTransactionTable[j].order_number != ApplicationPaper.number)
				{
					continue;
				}
				if (tTransactionTable[j].number == CacheQuotesTableNumber)
				{
					break;
				}
				if (!fTransaction.SearchTransaction(Convert.ToString(tTransactionTable[j].number)))
				{
					if (ApplicationPaper.ID == idDH)
					{
						string str5 = CallBackMy.callbackEventHandlerCurrentStrategy();
						FormTransaction.TransactionPaper.number = tTransactionTable[j].number;
						FormTransaction.TransactionPaper.date = tTransactionTable[j].date;
						FormTransaction.TransactionPaper.time = tTransactionTable[j].time;
						FormTransaction.TransactionPaper.paper_code = tTransactionTable[j].paper_code;
						FormTransaction.TransactionPaper.operation = tTransactionTable[j].operation;
						FormTransaction.TransactionPaper.price = tTransactionTable[j].price;
						FormTransaction.TransactionPaper.volume = tTransactionTable[j].volume;
						FormTransaction.TransactionPaper.strategy = str5;
						fTransaction.AddTransaction();
						CacheQuotesTableNumber = tTransactionTable[j].number;
						if (tTransactionTable[j].operation == "Купля")
						{
							orderLotDH -= Convert.ToInt32(tTransactionTable[j].volume);
						}
						else
						{
							orderLotDH += Convert.ToInt32(tTransactionTable[j].volume);
						}
						tTransactionTable.RemoveAt(j);
						FormPortfolio.F_Update = true;
						break;
					}
					flag2 = false;
					bool flag5 = false;
					if (fGlass.Count <= 0)
					{
						break;
					}
					for (int k = 0; k < fGlass.Count; k++)
					{
						if (fGlass[k].Created && fGlass[k].gTransID == Convert.ToString(ApplicationPaper.ID))
						{
							string gStrategy = fGlass[k].gStrategy;
							FormTransaction.TransactionPaper.number = tTransactionTable[j].number;
							FormTransaction.TransactionPaper.date = tTransactionTable[j].date;
							FormTransaction.TransactionPaper.time = tTransactionTable[j].time;
							FormTransaction.TransactionPaper.paper_code = tTransactionTable[j].paper_code;
							FormTransaction.TransactionPaper.operation = tTransactionTable[j].operation;
							FormTransaction.TransactionPaper.price = tTransactionTable[j].price;
							FormTransaction.TransactionPaper.volume = tTransactionTable[j].volume;
							FormTransaction.TransactionPaper.strategy = gStrategy;
							fTransaction.AddTransaction();
							CacheQuotesTableNumber = tTransactionTable[j].number;
							tTransactionTable.RemoveAt(j);
							bool flag6 = true;
							if (Helpers.IsOption(FormTransaction.TransactionPaper.paper_code))
							{
								flag5 = true;
							}
							FormPortfolio.F_Update = true;
							if (flag6 && flag5)
							{
								cHistoryDataDDE.FileName = gStrategy;
								cHistoryDataDDE.WriteFileHistory();
							}
							break;
						}
					}
				}
				else
				{
					tTransactionTable.RemoveAt(j);
				}
				break;
			}
			string str6 = "Ордер в КВИК, номер=" + ApplicationPaper.number + " Код бумаги=" + ApplicationPaper.paper_code + " Цена=" + Convert.ToString(ApplicationPaper.price) + " Количество=" + Convert.ToString(ApplicationPaper.volume) + " Операция=" + Convert.ToString(ApplicationPaper.operation) + " Статус заявки=" + Convert.ToString(ApplicationPaper.status) + " ID заявки=" + Convert.ToString(ApplicationPaper.ID);
			CallBackMy.callbackEventError eventHandlerError = CallBackMy.callbackEventHandlerError;
			string iTimeDate = DateTime.Now.ToLocalTime().ToString();
			string iMessage = str6;
			eventHandlerError(iTimeDate, iMessage);
		}

		public void trade_status_callback_impl(int nMode, double dNumber, double dOrderNumber, string ClassCode, string SecCode, double dPrice, int nQty, double dValue, int nIsSell, int nTradeDescriptor)
		{
			bool flag1 = false;
			bool flag2 = false;
			flag1 = false;
			flag2 = false;
			string str1 = "Mode=" + nMode + " TradeNum=" + dNumber + " OrderNum=" + dOrderNumber + " Class=" + ClassCode + " Sec=" + SecCode + " Price=" + dPrice + " Volume=" + nQty + " Value=" + dValue + " IsSell=" + nIsSell;
			string str2 = " SettleDate=" + Trans2Quik.TRANS2QUIK_TRADE_SETTLE_DATE(nTradeDescriptor) + " TradeDate=" + Trans2Quik.TRANS2QUIK_TRADE_DATE(nTradeDescriptor) + " TradeTime=" + Trans2Quik.TRANS2QUIK_TRADE_TIME(nTradeDescriptor) + " TradeTimeMicroSec=" + Trans2Quik.TRANS2QUIK_TRADE_DATE_TIME(nTradeDescriptor, 2) + " IsMarginal=" + Trans2Quik.TRANS2QUIK_TRADE_IS_MARGINAL(nTradeDescriptor) + " AccruedInt=" + Trans2Quik.TRANS2QUIK_TRADE_ACCRUED_INT(nTradeDescriptor) + " Yield=" + Trans2Quik.TRANS2QUIK_TRADE_YIELD(nTradeDescriptor) + " ClearingComm=" + Trans2Quik.TRANS2QUIK_TRADE_CLEARING_CENTER_COMMISSION(nTradeDescriptor) + " ExchangeComm=" + Trans2Quik.TRANS2QUIK_TRADE_EXCHANGE_COMMISSION(nTradeDescriptor) + " TSComm=" + Trans2Quik.TRANS2QUIK_TRADE_TS_COMMISSION(nTradeDescriptor) + " TradingSysComm=" + Trans2Quik.TRANS2QUIK_TRADE_TRADING_SYSTEM_COMMISSION(nTradeDescriptor) + " Price2=" + Trans2Quik.TRANS2QUIK_TRADE_PRICE2(nTradeDescriptor) + " RepoRate=" + Trans2Quik.TRANS2QUIK_TRADE_REPO_RATE(nTradeDescriptor) + " Repo2Value=" + Trans2Quik.TRANS2QUIK_TRADE_REPO2_VALUE(nTradeDescriptor) + " AccruedInt2=" + Trans2Quik.TRANS2QUIK_TRADE_ACCRUED_INT2(nTradeDescriptor) + " RepoTerm=" + Trans2Quik.TRANS2QUIK_TRADE_REPO_TERM(nTradeDescriptor) + " StartDisc=" + Trans2Quik.TRANS2QUIK_TRADE_START_DISCOUNT(nTradeDescriptor) + " LowerDisc=" + Trans2Quik.TRANS2QUIK_TRADE_LOWER_DISCOUNT(nTradeDescriptor) + " UpperDisc=" + Trans2Quik.TRANS2QUIK_TRADE_UPPER_DISCOUNT(nTradeDescriptor) + " BlockSec=" + Trans2Quik.TRANS2QUIK_TRADE_BLOCK_SECURITIES(nTradeDescriptor) + " Period=" + Trans2Quik.TRANS2QUIK_TRADE_PERIOD(nTradeDescriptor) + " Kind=" + Trans2Quik.TRANS2QUIK_TRADE_KIND(nTradeDescriptor);
			string str3 = Trans2Quik.TRANS2QUIK_TRADE_CLIENT_CODE(nTradeDescriptor);
			try
			{
				using (StreamWriter streamWriter = new StreamWriter("trades.log", true, Encoding.GetEncoding(1251)))
				{
					streamWriter.WriteLine(str1 + str2 + str3);
					streamWriter.Close();
				}
			}
			catch (Exception)
			{
			}
			if (!(ClientCode == str3) || nMode != 0)
			{
				return;
			}
			string iNumber = Convert.ToString(dNumber);
			if (iNumber == CacheQuotesTableNumber || fTransaction.SearchTransaction(iNumber))
			{
				return;
			}
			string str4 = "";
			for (int index = ApplicationTable.Count - 1; index >= 0; index--)
			{
				if (dOrderNumber == ApplicationTable[index].number)
				{
					str4 = Convert.ToString(ApplicationTable[index].ID);
					break;
				}
			}
			if (str4 == "")
			{
				bool flag3 = false;
				for (int index2 = tTransactionTable.Count - 1; index2 >= 0; index2--)
				{
					if (iNumber == tTransactionTable[index2].number)
					{
						flag3 = false;
						break;
					}
				}
				if (!flag3)
				{
					TransPaper.number = iNumber;
					TransPaper.order_number = dOrderNumber;
					TransPaper.date = DateTime.Now.Date;
					TransPaper.time = DateTime.Now.ToLocalTime();
					TransPaper.paper_code = SecCode;
					TransPaper.operation = ((nIsSell != 0) ? "Продажа" : "Купля");
					TransPaper.price = dPrice;
					TransPaper.volume = Convert.ToDouble(nQty);
					tTransactionTable.Add(TransPaper);
				}
				return;
			}
			if (str4 == "0")
			{
				if (!cDataDDE.SearchTransaction(iNumber))
				{
					tTransactionPaper.number = iNumber;
					tTransactionPaper.date = DateTime.Now.Date;
					tTransactionPaper.time = DateTime.Now.ToLocalTime();
					tTransactionPaper.paper_code = SecCode;
					tTransactionPaper.operation = ((nIsSell != 0) ? "Продажа" : "Купля");
					tTransactionPaper.price = dPrice;
					tTransactionPaper.volume = Convert.ToDouble(nQty);
					cDataDDE.AddTransaction(tTransactionPaper);
				}
				return;
			}
			if (str4 == Convert.ToString(idDH))
			{
				string str5 = CallBackMy.callbackEventHandlerCurrentStrategy();
				FormTransaction.TransactionPaper.number = iNumber;
				DateTime date = DateTime.Now.Date;
				FormTransaction.TransactionPaper.date = date;
				DateTime localTime = DateTime.Now.ToLocalTime();
				FormTransaction.TransactionPaper.time = localTime;
				FormTransaction.TransactionPaper.paper_code = SecCode;
				FormTransaction.TransactionPaper.operation = ((nIsSell != 0) ? "Продажа" : "Купля");
				FormTransaction.TransactionPaper.price = dPrice;
				FormTransaction.TransactionPaper.volume = Convert.ToDouble(nQty);
				FormTransaction.TransactionPaper.strategy = str5;
				fTransaction.AddTransaction();
				CacheQuotesTableNumber = iNumber;
				if (nIsSell == 0)
				{
					orderLotDH -= nQty;
				}
				else
				{
					orderLotDH += nQty;
				}
				flag1 = true;
				if (Helpers.IsOption(FormTransaction.TransactionPaper.paper_code))
				{
					flag2 = true;
				}
				FormPortfolio.F_Update = true;
				return;
			}
			flag1 = false;
			bool flag4 = false;
			if (fGlass.Count <= 0)
			{
				return;
			}
			for (int i = 0; i < fGlass.Count; i++)
			{
				if (fGlass[i].Created && fGlass[i].gTransID == str4)
				{
					string gStrategy = fGlass[i].gStrategy;
					FormTransaction.TransactionPaper.number = iNumber;
					FormTransaction.TransactionPaper.date = DateTime.Now.Date;
					FormTransaction.TransactionPaper.time = DateTime.Now.ToLocalTime();
					FormTransaction.TransactionPaper.paper_code = SecCode;
					FormTransaction.TransactionPaper.operation = ((nIsSell != 0) ? "Продажа" : "Купля");
					FormTransaction.TransactionPaper.price = dPrice;
					FormTransaction.TransactionPaper.volume = Convert.ToDouble(nQty);
					FormTransaction.TransactionPaper.strategy = gStrategy;
					fTransaction.AddTransaction();
					CacheQuotesTableNumber = iNumber;
					bool flag5 = true;
					if (Helpers.IsOption(FormTransaction.TransactionPaper.paper_code))
					{
						flag4 = true;
					}
					FormPortfolio.F_Update = true;
					if (flag5 && flag4)
					{
						cHistoryDataDDE.FileName = gStrategy;
						cHistoryDataDDE.WriteFileHistory();
					}
					break;
				}
			}
		}

		public void connection_status_callback_Report(int nConnectionEvent, uint nExtendedErrorCode, byte[] lpstrInfoMessage)
		{
			switch (nConnectionEvent)
			{
			case 8:
			{
				F_QuikConnected = true;
				string str7 = "Соединился КВИК с сервером";
				CallBackMy.callbackEventError eventHandlerError7 = CallBackMy.callbackEventHandlerError;
				string iTimeDate7 = DateTime.Now.ToLocalTime().ToString();
				string iMessage7 = str7;
				eventHandlerError7(iTimeDate7, iMessage7);
				break;
			}
			case 9:
			{
				F_QuikConnected = false;
				string str6 = "Разъединился КВИК с сервером";
				CallBackMy.callbackEventError eventHandlerError6 = CallBackMy.callbackEventHandlerError;
				string iTimeDate6 = DateTime.Now.ToLocalTime().ToString();
				string iMessage6 = str6;
				eventHandlerError6(iTimeDate6, iMessage6);
				break;
			}
			case 10:
			{
				F_DllConnected = true;
				string str5 = "Соединился длл и КВИК";
				CallBackMy.callbackEventError eventHandlerError5 = CallBackMy.callbackEventHandlerError;
				string iTimeDate5 = DateTime.Now.ToLocalTime().ToString();
				string iMessage5 = str5;
				eventHandlerError5(iTimeDate5, iMessage5);
				break;
			}
			case 11:
			{
				F_DllConnected = false;
				string str4 = "Разъединился длл и КВИК";
				CallBackMy.callbackEventError eventHandlerError4 = CallBackMy.callbackEventHandlerError;
				string iTimeDate4 = DateTime.Now.ToLocalTime().ToString();
				string iMessage4 = str4;
				eventHandlerError4(iTimeDate4, iMessage4);
				break;
			}
			}
		}

		public void transaction_reply_callback_impl(int nTransactionResult, int nTransactionExtendedErrorCode, int nTransactionReplyCode, uint dwTransId, double dOrderNum, [MarshalAs(UnmanagedType.LPStr)] string TransactionReplyMessage)
		{
			string str = "TrRes=" + nTransactionResult + " TrResStr=" + trans_2_quik.ResultToString(nTransactionResult & 0xFF) + " TrExErrCode=" + nTransactionExtendedErrorCode + " TrReplyCode=" + nTransactionReplyCode + " TrID=" + dwTransId + " OrderNum=" + dOrderNum + " ResMsg=" + TransactionReplyMessage;
			try
			{
				using (StreamWriter streamWriter = new StreamWriter("async_trans.log", true, Encoding.GetEncoding(1251)))
				{
					streamWriter.WriteLine(str);
				}
			}
			catch (Exception)
			{
			}
		}

		private void topMostWindowToolStripMenuItem_Click(object sender, EventArgs e)
		{
			topMostWindowToolStripMenuItem.Checked = !topMostWindowToolStripMenuItem.Checked;
			base.TopMost = topMostWindowToolStripMenuItem.Checked;
		}

		private bool CheckWorkingTime()
		{
			DateTime dateTime1 = Convert.ToDateTime(DateTime.Now.ToShortDateString() + " 10:01");
			DateTime dateTime2 = Convert.ToDateTime(DateTime.Now.ToShortDateString() + " 13:58");
			DateTime dateTime3 = Convert.ToDateTime(DateTime.Now.ToShortDateString() + " 14:04");
			DateTime dateTime4 = Convert.ToDateTime(DateTime.Now.ToShortDateString() + " 18:49");
			DateTime dateTime5 = Convert.ToDateTime(DateTime.Now.ToShortDateString() + " 19:01");
			DateTime dateTime6 = Convert.ToDateTime(DateTime.Now.ToShortDateString() + " 23:49");
			DateTime now = DateTime.Now;
			bool flag = false;
			if ((now > dateTime1 && now < dateTime2) || (now > dateTime3 && now < dateTime4) || (now > dateTime5 && now < dateTime6))
			{
				flag = true;
			}
			return flag;
		}

		protected override void Dispose(bool disposing)
		{
			if (disposing && components != null)
			{
				components.Dispose();
			}
			base.Dispose(disposing);
		}

		private void InitializeComponent()
		{
			this.components = new System.ComponentModel.Container();
			System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(OptionFVV.FormMain));
			this.menuStripMain = new System.Windows.Forms.MenuStrip();
			this.файлToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
			this.ToolStripMenuItemOpenTransaction = new System.Windows.Forms.ToolStripMenuItem();
			this.ToolStripMenuItemOpenSettings = new System.Windows.Forms.ToolStripMenuItem();
			this.ToolStripMenuItemSaveTransaction = new System.Windows.Forms.ToolStripMenuItem();
			this.ToolStripMenuItemSaveSettings = new System.Windows.Forms.ToolStripMenuItem();
			this.ToolStripMenuItemImportTransaction = new System.Windows.Forms.ToolStripMenuItem();
			this.торговляToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
			this.ведущийСтаканToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
			this.ведомыйСтаканToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
			this.настройкиToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
			this.оПрограммеToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
			this.окноToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
			this.topMostWindowToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
			this.splitContainerMain = new System.Windows.Forms.SplitContainer();
			this.tabControlMain = new System.Windows.Forms.TabControl();
			this.tabPageBoard = new System.Windows.Forms.TabPage();
			this.tabPageChart = new System.Windows.Forms.TabPage();
			this.tabPageSmile = new System.Windows.Forms.TabPage();
			this.tabPageCalculator = new System.Windows.Forms.TabPage();
			this.tabPageLog = new System.Windows.Forms.TabPage();
			this.tabPageData = new System.Windows.Forms.TabPage();
			this.tabPageTransaction = new System.Windows.Forms.TabPage();
			this.statusStripMain = new System.Windows.Forms.StatusStrip();
			this.toolStripStatusLabelTimeCalculation = new System.Windows.Forms.ToolStripStatusLabel();
			this.toolStripStatusLabelInfo = new System.Windows.Forms.ToolStripStatusLabel();
			this.timerMain = new System.Windows.Forms.Timer(this.components);
			this.openFileDialogImportTransaction = new System.Windows.Forms.OpenFileDialog();
			this.menuStripMain.SuspendLayout();
			this.splitContainerMain.BeginInit();
			this.splitContainerMain.Panel1.SuspendLayout();
			this.splitContainerMain.SuspendLayout();
			this.tabControlMain.SuspendLayout();
			this.statusStripMain.SuspendLayout();
			base.SuspendLayout();
			this.menuStripMain.Items.AddRange(new System.Windows.Forms.ToolStripItem[5] { this.файлToolStripMenuItem, this.торговляToolStripMenuItem, this.настройкиToolStripMenuItem, this.оПрограммеToolStripMenuItem, this.окноToolStripMenuItem });
			this.menuStripMain.Location = new System.Drawing.Point(0, 0);
			this.menuStripMain.Name = "menuStripMain";
			this.menuStripMain.Size = new System.Drawing.Size(921, 24);
			this.menuStripMain.TabIndex = 1;
			this.menuStripMain.Text = "menuStrip1";
			this.файлToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[5] { this.ToolStripMenuItemOpenTransaction, this.ToolStripMenuItemOpenSettings, this.ToolStripMenuItemSaveTransaction, this.ToolStripMenuItemSaveSettings, this.ToolStripMenuItemImportTransaction });
			this.файлToolStripMenuItem.Name = "файлToolStripMenuItem";
			this.файлToolStripMenuItem.Size = new System.Drawing.Size(48, 20);
			this.файлToolStripMenuItem.Text = "Файл";
			this.ToolStripMenuItemOpenTransaction.Image = (System.Drawing.Image)resources.GetObject("ToolStripMenuItemOpenTransaction.Image");
			this.ToolStripMenuItemOpenTransaction.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
			this.ToolStripMenuItemOpenTransaction.Name = "ToolStripMenuItemOpenTransaction";
			this.ToolStripMenuItemOpenTransaction.Size = new System.Drawing.Size(193, 22);
			this.ToolStripMenuItemOpenTransaction.Text = "Открыть сделки";
			this.ToolStripMenuItemOpenTransaction.Click += new System.EventHandler(ToolStripMenuItemOpenTransaction_Click);
			this.ToolStripMenuItemOpenSettings.Image = (System.Drawing.Image)resources.GetObject("ToolStripMenuItemOpenSettings.Image");
			this.ToolStripMenuItemOpenSettings.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
			this.ToolStripMenuItemOpenSettings.Name = "ToolStripMenuItemOpenSettings";
			this.ToolStripMenuItemOpenSettings.Size = new System.Drawing.Size(193, 22);
			this.ToolStripMenuItemOpenSettings.Text = "Открыть настройки";
			this.ToolStripMenuItemOpenSettings.Click += new System.EventHandler(ToolStripMenuItemOpenSettings_Click);
			this.ToolStripMenuItemSaveTransaction.Image = (System.Drawing.Image)resources.GetObject("ToolStripMenuItemSaveTransaction.Image");
			this.ToolStripMenuItemSaveTransaction.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
			this.ToolStripMenuItemSaveTransaction.Name = "ToolStripMenuItemSaveTransaction";
			this.ToolStripMenuItemSaveTransaction.Size = new System.Drawing.Size(193, 22);
			this.ToolStripMenuItemSaveTransaction.Text = "Сохранить сделки";
			this.ToolStripMenuItemSaveTransaction.Click += new System.EventHandler(ToolStripMenuItemSaveTransaction_Click);
			this.ToolStripMenuItemSaveSettings.Image = (System.Drawing.Image)resources.GetObject("ToolStripMenuItemSaveSettings.Image");
			this.ToolStripMenuItemSaveSettings.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
			this.ToolStripMenuItemSaveSettings.Name = "ToolStripMenuItemSaveSettings";
			this.ToolStripMenuItemSaveSettings.Size = new System.Drawing.Size(193, 22);
			this.ToolStripMenuItemSaveSettings.Text = "Сохранить настройки";
			this.ToolStripMenuItemSaveSettings.Click += new System.EventHandler(ToolStripMenuItemSaveSettings_Click);
			this.ToolStripMenuItemImportTransaction.Image = (System.Drawing.Image)resources.GetObject("ToolStripMenuItemImportTransaction.Image");
			this.ToolStripMenuItemImportTransaction.Name = "ToolStripMenuItemImportTransaction";
			this.ToolStripMenuItemImportTransaction.Size = new System.Drawing.Size(193, 22);
			this.ToolStripMenuItemImportTransaction.Text = "Импорт сделок";
			this.ToolStripMenuItemImportTransaction.Click += new System.EventHandler(ToolStripMenuItemImportTransaction_Click);
			this.торговляToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[2] { this.ведущийСтаканToolStripMenuItem, this.ведомыйСтаканToolStripMenuItem });
			this.торговляToolStripMenuItem.Name = "торговляToolStripMenuItem";
			this.торговляToolStripMenuItem.Size = new System.Drawing.Size(71, 20);
			this.торговляToolStripMenuItem.Text = "Торговля";
			this.ведущийСтаканToolStripMenuItem.Name = "ведущийСтаканToolStripMenuItem";
			this.ведущийСтаканToolStripMenuItem.Size = new System.Drawing.Size(164, 22);
			this.ведущийСтаканToolStripMenuItem.Text = "Ведущий стакан";
			this.ведущийСтаканToolStripMenuItem.Click += new System.EventHandler(ведущийСтаканToolStripMenuItem_Click);
			this.ведомыйСтаканToolStripMenuItem.Enabled = false;
			this.ведомыйСтаканToolStripMenuItem.Name = "ведомыйСтаканToolStripMenuItem";
			this.ведомыйСтаканToolStripMenuItem.Size = new System.Drawing.Size(164, 22);
			this.ведомыйСтаканToolStripMenuItem.Text = "Ведомый стакан";
			this.настройкиToolStripMenuItem.Name = "настройкиToolStripMenuItem";
			this.настройкиToolStripMenuItem.Size = new System.Drawing.Size(79, 20);
			this.настройкиToolStripMenuItem.Text = "Настройки";
			this.настройкиToolStripMenuItem.Click += new System.EventHandler(настройкиToolStripMenuItem_Click);
			this.оПрограммеToolStripMenuItem.Alignment = System.Windows.Forms.ToolStripItemAlignment.Right;
			this.оПрограммеToolStripMenuItem.Name = "оПрограммеToolStripMenuItem";
			this.оПрограммеToolStripMenuItem.Size = new System.Drawing.Size(94, 20);
			this.оПрограммеToolStripMenuItem.Text = "О программе";
			this.оПрограммеToolStripMenuItem.Click += new System.EventHandler(оПрограммеToolStripMenuItem_Click);
			this.окноToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[1] { this.topMostWindowToolStripMenuItem });
			this.окноToolStripMenuItem.Name = "окноToolStripMenuItem";
			this.окноToolStripMenuItem.Size = new System.Drawing.Size(48, 20);
			this.окноToolStripMenuItem.Text = "Окно";
			this.topMostWindowToolStripMenuItem.Name = "topMostWindowToolStripMenuItem";
			this.topMostWindowToolStripMenuItem.ShortcutKeys = System.Windows.Forms.Keys.M | System.Windows.Forms.Keys.Control;
			this.topMostWindowToolStripMenuItem.Size = new System.Drawing.Size(215, 22);
			this.topMostWindowToolStripMenuItem.Text = "Поверх всех окон";
			this.topMostWindowToolStripMenuItem.Click += new System.EventHandler(topMostWindowToolStripMenuItem_Click);
			this.splitContainerMain.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
			this.splitContainerMain.Dock = System.Windows.Forms.DockStyle.Fill;
			this.splitContainerMain.Location = new System.Drawing.Point(0, 24);
			this.splitContainerMain.Name = "splitContainerMain";
			this.splitContainerMain.Orientation = System.Windows.Forms.Orientation.Horizontal;
			this.splitContainerMain.Panel1.Controls.Add(this.tabControlMain);
			this.splitContainerMain.Panel2.BackColor = System.Drawing.SystemColors.Control;
			this.splitContainerMain.Size = new System.Drawing.Size(921, 432);
			this.splitContainerMain.SplitterDistance = 236;
			this.splitContainerMain.TabIndex = 3;
			this.tabControlMain.Controls.Add(this.tabPageBoard);
			this.tabControlMain.Controls.Add(this.tabPageChart);
			this.tabControlMain.Controls.Add(this.tabPageSmile);
			this.tabControlMain.Controls.Add(this.tabPageCalculator);
			this.tabControlMain.Controls.Add(this.tabPageLog);
			this.tabControlMain.Controls.Add(this.tabPageData);
			this.tabControlMain.Controls.Add(this.tabPageTransaction);
			this.tabControlMain.Dock = System.Windows.Forms.DockStyle.Fill;
			this.tabControlMain.Location = new System.Drawing.Point(0, 0);
			this.tabControlMain.Name = "tabControlMain";
			this.tabControlMain.SelectedIndex = 0;
			this.tabControlMain.Size = new System.Drawing.Size(919, 234);
			this.tabControlMain.TabIndex = 0;
			this.tabPageBoard.Location = new System.Drawing.Point(4, 22);
			this.tabPageBoard.Name = "tabPageBoard";
			this.tabPageBoard.Padding = new System.Windows.Forms.Padding(3);
			this.tabPageBoard.Size = new System.Drawing.Size(911, 208);
			this.tabPageBoard.TabIndex = 0;
			this.tabPageBoard.Text = "Доска";
			this.tabPageBoard.UseVisualStyleBackColor = true;
			this.tabPageBoard.Enter += new System.EventHandler(tabPageBoard_Enter);
			this.tabPageBoard.Leave += new System.EventHandler(tabPageBoard_Leave);
			this.tabPageChart.Location = new System.Drawing.Point(4, 22);
			this.tabPageChart.Name = "tabPageChart";
			this.tabPageChart.Size = new System.Drawing.Size(911, 208);
			this.tabPageChart.TabIndex = 5;
			this.tabPageChart.Text = "Диаграмма";
			this.tabPageChart.UseVisualStyleBackColor = true;
			this.tabPageSmile.Location = new System.Drawing.Point(4, 22);
			this.tabPageSmile.Name = "tabPageSmile";
			this.tabPageSmile.Size = new System.Drawing.Size(911, 208);
			this.tabPageSmile.TabIndex = 6;
			this.tabPageSmile.Text = "Улыбка";
			this.tabPageSmile.UseVisualStyleBackColor = true;
			this.tabPageCalculator.Location = new System.Drawing.Point(4, 22);
			this.tabPageCalculator.Name = "tabPageCalculator";
			this.tabPageCalculator.Padding = new System.Windows.Forms.Padding(3);
			this.tabPageCalculator.Size = new System.Drawing.Size(911, 208);
			this.tabPageCalculator.TabIndex = 1;
			this.tabPageCalculator.Text = "Калькулятор";
			this.tabPageCalculator.UseVisualStyleBackColor = true;
			this.tabPageLog.Location = new System.Drawing.Point(4, 22);
			this.tabPageLog.Name = "tabPageLog";
			this.tabPageLog.Size = new System.Drawing.Size(911, 208);
			this.tabPageLog.TabIndex = 2;
			this.tabPageLog.Text = "Лог";
			this.tabPageLog.UseVisualStyleBackColor = true;
			this.tabPageData.Location = new System.Drawing.Point(4, 22);
			this.tabPageData.Name = "tabPageData";
			this.tabPageData.Size = new System.Drawing.Size(911, 208);
			this.tabPageData.TabIndex = 3;
			this.tabPageData.Text = "Данные";
			this.tabPageData.UseVisualStyleBackColor = true;
			this.tabPageData.Enter += new System.EventHandler(tabPageData_Enter);
			this.tabPageTransaction.Location = new System.Drawing.Point(4, 22);
			this.tabPageTransaction.Name = "tabPageTransaction";
			this.tabPageTransaction.Size = new System.Drawing.Size(911, 208);
			this.tabPageTransaction.TabIndex = 4;
			this.tabPageTransaction.Text = "Сделки";
			this.tabPageTransaction.UseVisualStyleBackColor = true;
			this.tabPageTransaction.Enter += new System.EventHandler(tabPageTransaction_Enter);
			this.statusStripMain.Items.AddRange(new System.Windows.Forms.ToolStripItem[2] { this.toolStripStatusLabelTimeCalculation, this.toolStripStatusLabelInfo });
			this.statusStripMain.Location = new System.Drawing.Point(0, 434);
			this.statusStripMain.Name = "statusStripMain";
			this.statusStripMain.Size = new System.Drawing.Size(921, 22);
			this.statusStripMain.TabIndex = 5;
			this.statusStripMain.Text = "statusStrip1";
			this.toolStripStatusLabelTimeCalculation.Name = "toolStripStatusLabelTimeCalculation";
			this.toolStripStatusLabelTimeCalculation.Size = new System.Drawing.Size(10, 17);
			this.toolStripStatusLabelTimeCalculation.Text = " ";
			this.toolStripStatusLabelInfo.Name = "toolStripStatusLabelInfo";
			this.toolStripStatusLabelInfo.Size = new System.Drawing.Size(118, 17);
			this.toolStripStatusLabelInfo.Text = "toolStripStatusLabel1";
			this.timerMain.Tick += new System.EventHandler(timerMain_Tick);
			this.openFileDialogImportTransaction.FileName = "openFileDialog1";
			base.AutoScaleDimensions = new System.Drawing.SizeF(6f, 13f);
			base.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
			base.ClientSize = new System.Drawing.Size(921, 456);
			base.Controls.Add(this.statusStripMain);
			base.Controls.Add(this.splitContainerMain);
			base.Controls.Add(this.menuStripMain);
			base.Icon = (System.Drawing.Icon)resources.GetObject("$this.Icon");
			base.IsMdiContainer = true;
			base.MainMenuStrip = this.menuStripMain;
			base.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
			this.Text = "OptionFVV";
			base.WindowState = System.Windows.Forms.FormWindowState.Maximized;
			base.FormClosing += new System.Windows.Forms.FormClosingEventHandler(FormMain_FormClosing);
			base.Load += new System.EventHandler(FormMain_Load);
			base.Shown += new System.EventHandler(FormMain_Shown);
			this.menuStripMain.ResumeLayout(false);
			this.menuStripMain.PerformLayout();
			this.splitContainerMain.Panel1.ResumeLayout(false);
			this.splitContainerMain.EndInit();
			this.splitContainerMain.ResumeLayout(false);
			this.tabControlMain.ResumeLayout(false);
			this.statusStripMain.ResumeLayout(false);
			this.statusStripMain.PerformLayout();
			base.ResumeLayout(false);
			base.PerformLayout();
		}
	}
}
