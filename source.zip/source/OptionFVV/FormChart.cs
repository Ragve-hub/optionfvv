using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Windows.Forms;
using System.Windows.Forms.DataVisualization.Charting;

namespace OptionFVV
{
	public class FormChart : Form
	{
		public struct Strategy
		{
			public string name_strategy;

			public double profit;

			public double GO;
		}

		public struct Quotes
		{
			public string paper_code;

			public DateTime expiration_date;

			public string base_asset;

			public double demand;

			public double sentence;

			public double last_price;

			public double strike;

			public string option_type;

			public double volatility;

			public double teoretical_price;

			public double step_price;

			public int decimal_points;

			public bool F;
		}

		public struct Chart
		{
			public string name;

			public double X;

			public double Y;

			public double YAddD1;

			public double YAddD2;

			public double YExpiration;

			public int decimal_points;
		}

		public struct Portfolio
		{
			public string paper_code;

			public string base_asset;

			public string option_type;

			public double strike;

			public DateTime expiration_date;

			public DateTime current_date;

			public double volume;

			public double open_price;

			public double open_volatility;

			public double teoretical_price;

			public double futures_price;

			public double profit;

			public double accumulated_profit;

			public double volatility;

			public double delta;

			public double gamma;

			public double vega;

			public double theta;

			public double vomma;

			public double step_price;

			public int decimal_points;

			public bool check;
		}

		private FormPortfolio fPortfolio = new FormPortfolio();

		private ClassCalculationOptions cCalculationOptions = new ClassCalculationOptions();

		private ClassDataDDE cDataDDE = new ClassDataDDE(false);

		private ClassCalculationPortfolio cCalculationPortfolio = new ClassCalculationPortfolio();

		public static List<Strategy> StrategyTable = new List<Strategy>();

		private Strategy StrategyPaper = default(Strategy);

		private Quotes FuturePaper1 = default(Quotes);

		private Quotes FuturePaper2 = default(Quotes);

		private List<Chart> ChartTable = new List<Chart>();

		private Chart ChartPaper = default(Chart);

		private List<Chart> ChartTableComparison = new List<Chart>();

		private Chart ChartPaperComparison = default(Chart);

		private List<Portfolio> PortfolioTable = new List<Portfolio>();

		private Portfolio PortfolioPaper = default(Portfolio);

		private List<Portfolio> PortfolioTableAddD1 = new List<Portfolio>();

		private Portfolio PortfolioPaperAddD1 = default(Portfolio);

		private List<Portfolio> PortfolioTableAddD2 = new List<Portfolio>();

		private Portfolio PortfolioPaperAddD2 = default(Portfolio);

		private List<Portfolio> PortfolioTableExpiration = new List<Portfolio>();

		private Portfolio PortfolioPaperExpiration = default(Portfolio);

		private IContainer components = null;

		private SplitContainer splitContainerChart;

		private System.Windows.Forms.DataVisualization.Charting.Chart chart1;

		private GroupBox groupBox1;

		private RadioButton radioButtonVomma;

		private RadioButton radioButtonTheta;

		private RadioButton radioButtonVega;

		private RadioButton radioButtonGamma;

		private RadioButton radioButtonDelta;

		private RadioButton radioButtonProfit;

		private Label label2;

		private TextBox textBoxStepGridX;

		private TextBox textBoxStepGridY;

		private Label label1;

		private GroupBox groupBox2;

		private Label label4;

		private Label label3;

		private TextBox textBoxIndentDn;

		private TextBox textBoxIndentUp;

		private Label label5;

		private TextBox textBoxAddD1;

		private CheckBox checkBoxChartAddD1;

		private CheckBox checkBoxChartCurrent;

		private Label label6;

		private TextBox textBoxAddD2;

		private CheckBox checkBoxChartAddD2;

		private CheckBox checkBoxChartExpiration;

		private CheckBox checkBoxStepGridYAuto;

		private Label labelStepGridY;

		private Button buttonIndentDnLess;

		private Button buttonIndentDnMore;

		private Button buttonIndentUpLess;

		private Button buttonIndentUpMore;

		private TextBox textBoxColorChartAddD2;

		private TextBox textBoxColorChartCurrent;

		private TextBox textBoxColorChartExpiration;

		private TextBox textBoxColorChartAddD1;

		private Label label7;

		private TextBox textBoxQuantityDaysStandartDeviation;

		private Label label8;

		private TextBox textBoxQuantityStandartDeviation;

		private TextBox textBoxChartExpirationColorComparison;

		private TextBox textBoxChartAddD1ColorComparison;

		private TextBox textBoxChartAddD2ColorComparison;

		private TextBox textBoxChartCurrentColorComparison;

		private ComboBox comboBoxStrategyComparison;

		private CheckBox checkBoxStrategyComparison;

		public FormChart()
		{
			InitializeComponent();
			StrategyTable.Clear();
			ChartTable.Clear();
			ChartTableComparison.Clear();
			PortfolioTable.Clear();
			PortfolioTableAddD1.Clear();
			PortfolioTableAddD2.Clear();
			PortfolioTableExpiration.Clear();
		}

		private void FormChart_Load(object sender, EventArgs e)
		{
			cCalculationPortfolio.ClearPortfolio();
			CallBackMy.callbackEventHandlerColorThemeFormChart = PaintColorTheme;
			CallBackMy.callbackEventHandlerTickChart = Tick;
			string name = "";
			base.FormBorderStyle = FormBorderStyle.None;
			Dock = DockStyle.Fill;
			textBoxStepGridX.Text = ClassSettings.gChartStepGridX;
			textBoxStepGridY.Text = ClassSettings.gChartStepGridY;
			textBoxIndentDn.Text = ClassSettings.gChartIndentDn;
			textBoxIndentUp.Text = ClassSettings.gChartIndentUp;
			textBoxQuantityStandartDeviation.Text = ClassSettings.gChartQuantityStandartDeviation;
			textBoxQuantityDaysStandartDeviation.Text = ClassSettings.gChartQuantityDaysStandartDeviation;
			checkBoxChartCurrent.Checked = ClassSettings.gChartCheckBoxChartCurrent == "True";
			checkBoxChartAddD1.Checked = ClassSettings.gChartCheckBoxChartAddD1 == "True";
			checkBoxChartAddD2.Checked = ClassSettings.gChartCheckBoxChartAddD2 == "True";
			checkBoxChartExpiration.Checked = ClassSettings.gChartCheckBoxChartExpiration == "True";
			checkBoxStepGridYAuto.Checked = ClassSettings.gChartCheckBoxStepGridYAuto == "True";
			textBoxAddD1.Text = ClassSettings.gChartTextBoxAddD1;
			textBoxAddD2.Text = ClassSettings.gChartTextBoxAddD2;
			if (checkBoxStepGridYAuto.Checked)
			{
				textBoxStepGridY.Enabled = false;
				labelStepGridY.Text = "";
			}
			else
			{
				textBoxStepGridY.Enabled = true;
				labelStepGridY.Text = "";
			}
			if (radioButtonProfit.Checked)
			{
				name = "Прибыль";
			}
			else if (radioButtonDelta.Checked)
			{
				name = "Дельта";
			}
			else if (radioButtonGamma.Checked)
			{
				name = "Гамма";
			}
			else if (radioButtonVega.Checked)
			{
				name = "Вега";
			}
			else if (radioButtonTheta.Checked)
			{
				name = "Тета";
			}
			else if (radioButtonVomma.Checked)
			{
				name = "Вомма";
			}
			chart1.BackColor = ClassColorTheme.BackColor;
			chart1.BackSecondaryColor = ClassColorTheme.BackColor;
			chart1.ForeColor = ClassColorTheme.BackColorFore;
			chart1.ChartAreas[0].AxisX.LabelStyle.ForeColor = ClassColorTheme.BackColorFore;
			chart1.ChartAreas[0].AxisY.LabelStyle.ForeColor = ClassColorTheme.BackColorFore;
			chart1.ChartAreas[0].AxisX.TitleForeColor = ClassColorTheme.BackColorFore;
			chart1.ChartAreas[0].AxisY.TitleForeColor = ClassColorTheme.BackColorFore;
			chart1.ChartAreas[0].AxisX.MajorGrid.LineColor = ClassColorTheme.ChartGridColor;
			chart1.ChartAreas[0].AxisY.MajorGrid.LineColor = ClassColorTheme.ChartGridColor;
			chart1.ChartAreas[0].AxisX.LineColor = ClassColorTheme.ChartGridColor;
			chart1.ChartAreas[0].AxisX.LineWidth = 2;
			chart1.ChartAreas[0].AxisY.LineColor = ClassColorTheme.ChartGridColor;
			chart1.ChartAreas[0].AxisY.LineWidth = 2;
			chart1.ChartAreas[0].Name = "ChartAreas1";
			chart1.ChartAreas[0].BackColor = ClassColorTheme.BackColor;
			chart1.Titles.Add(name);
			chart1.Titles[0].Font = new Font("Arial", 10f);
			chart1.Titles[0].ForeColor = ClassColorTheme.BackColorFore;
			chart1.Legends[0].Enabled = false;
			SeriesCollection series1 = chart1.Series;
			Series series2 = new Series("SeriesChart");
			series2.ChartType = SeriesChartType.Spline;
			series2.BorderWidth = 1;
			series2.ShadowOffset = 0;
			series2.Color = ClassColorTheme.ChartCurrentColor;
			series1.Add(series2);
			if (checkBoxChartCurrent.Checked)
			{
				chart1.Series["SeriesChart"].Enabled = true;
			}
			else
			{
				chart1.Series["SeriesChart"].Enabled = false;
			}
			SeriesCollection series3 = chart1.Series;
			Series series4 = new Series("SeriesChartAddD1");
			series4.ChartType = SeriesChartType.Spline;
			series4.BorderWidth = 1;
			series4.ShadowOffset = 0;
			series4.Color = ClassColorTheme.ChartAddD1Color;
			series3.Add(series4);
			if (checkBoxChartAddD1.Checked)
			{
				chart1.Series["SeriesChartAddD1"].Enabled = true;
			}
			else
			{
				chart1.Series["SeriesChartAddD1"].Enabled = false;
			}
			SeriesCollection series5 = chart1.Series;
			Series series6 = new Series("SeriesChartAddD2");
			series6.ChartType = SeriesChartType.Spline;
			series6.BorderWidth = 1;
			series6.ShadowOffset = 0;
			series6.Color = ClassColorTheme.ChartAddD2Color;
			series5.Add(series6);
			if (checkBoxChartAddD2.Checked)
			{
				chart1.Series["SeriesChartAddD2"].Enabled = true;
			}
			else
			{
				chart1.Series["SeriesChartAddD2"].Enabled = false;
			}
			SeriesCollection series7 = chart1.Series;
			Series series8 = new Series("SeriesChartExpiration");
			series8.ChartType = SeriesChartType.Spline;
			series8.BorderWidth = 2;
			series8.ShadowOffset = 0;
			series8.Color = ClassColorTheme.ChartExpirationColor;
			series7.Add(series8);
			if (checkBoxChartExpiration.Checked)
			{
				chart1.Series["SeriesChartExpiration"].Enabled = true;
			}
			else
			{
				chart1.Series["SeriesChartExpiration"].Enabled = false;
			}
			SeriesCollection series9 = chart1.Series;
			Series series10 = new Series("SeriesCurrentPrice");
			series10.ChartType = SeriesChartType.Line;
			series10.BorderWidth = 1;
			series10.ShadowOffset = 0;
			series10.Color = Color.SlateGray;
			series10.Enabled = true;
			series9.Add(series10);
			SeriesCollection series11 = chart1.Series;
			Series series12 = new Series("SeriesChartMarker");
			series12.ChartType = SeriesChartType.Point;
			series12.MarkerSize = 6;
			series12.ShadowOffset = 0;
			series12.Color = ClassColorTheme.ChartCurrentColor;
			series12.MarkerStyle = MarkerStyle.Circle;
			series12.Enabled = true;
			series11.Add(series12);
			SeriesCollection series13 = chart1.Series;
			Series series14 = new Series("SeriesChartAddD1Marker");
			series14.ChartType = SeriesChartType.Point;
			series14.MarkerSize = 4;
			series14.ShadowOffset = 0;
			series14.Color = ClassColorTheme.ChartAddD1Color;
			series14.MarkerStyle = MarkerStyle.Circle;
			series14.Enabled = true;
			series13.Add(series14);
			SeriesCollection series15 = chart1.Series;
			Series series16 = new Series("SeriesChartAddD2Marker");
			series16.ChartType = SeriesChartType.Point;
			series16.MarkerSize = 4;
			series16.ShadowOffset = 0;
			series16.Color = ClassColorTheme.ChartAddD2Color;
			series16.MarkerStyle = MarkerStyle.Circle;
			series16.Enabled = true;
			series15.Add(series16);
			SeriesCollection series17 = chart1.Series;
			Series series18 = new Series("SeriesChartExpirationMarker");
			series18.ChartType = SeriesChartType.Point;
			series18.MarkerSize = 6;
			series18.ShadowOffset = 0;
			series18.Color = ClassColorTheme.ChartExpirationColor;
			series18.MarkerStyle = MarkerStyle.Circle;
			series18.Enabled = true;
			series17.Add(series18);
			SeriesCollection series19 = chart1.Series;
			Series series20 = new Series("SeriesUpperLimit");
			series20.ChartType = SeriesChartType.Line;
			series20.BorderWidth = 1;
			series20.ShadowOffset = 0;
			series20.Color = Color.LightPink;
			series20.Enabled = true;
			series19.Add(series20);
			SeriesCollection series21 = chart1.Series;
			Series series22 = new Series("SeriesLowerLimit");
			series22.ChartType = SeriesChartType.Line;
			series22.BorderWidth = 1;
			series22.ShadowOffset = 0;
			series22.Color = Color.LightPink;
			series22.Enabled = true;
			series21.Add(series22);
			SeriesCollection series23 = chart1.Series;
			Series series24 = new Series("SeriesChartComparison");
			series24.ChartType = SeriesChartType.Spline;
			series24.BorderWidth = 1;
			series24.ShadowOffset = 0;
			series24.Color = ClassColorTheme.ChartCurrentColorComparison;
			series23.Add(series24);
			if (checkBoxChartCurrent.Checked && checkBoxStrategyComparison.Checked)
			{
				chart1.Series["SeriesChartComparison"].Enabled = true;
			}
			else
			{
				chart1.Series["SeriesChartComparison"].Enabled = false;
			}
			SeriesCollection series25 = chart1.Series;
			Series series26 = new Series("SeriesChartComparisonAdd1");
			series26.ChartType = SeriesChartType.Spline;
			series26.BorderWidth = 1;
			series26.ShadowOffset = 0;
			series26.Color = ClassColorTheme.ChartAddD1ColorComparison;
			series25.Add(series26);
			if (checkBoxChartAddD1.Checked && checkBoxStrategyComparison.Checked)
			{
				chart1.Series["SeriesChartComparisonAdd1"].Enabled = true;
			}
			else
			{
				chart1.Series["SeriesChartComparisonAdd1"].Enabled = false;
			}
			SeriesCollection series27 = chart1.Series;
			Series series28 = new Series("SeriesChartComparisonAdd2");
			series28.ChartType = SeriesChartType.Spline;
			series28.BorderWidth = 1;
			series28.ShadowOffset = 0;
			series28.Color = ClassColorTheme.ChartAddD2ColorComparison;
			series27.Add(series28);
			if (checkBoxChartAddD2.Checked && checkBoxStrategyComparison.Checked)
			{
				chart1.Series["SeriesChartComparisonAdd2"].Enabled = true;
			}
			else
			{
				chart1.Series["SeriesChartComparisonAdd2"].Enabled = false;
			}
			SeriesCollection series29 = chart1.Series;
			Series series30 = new Series("SeriesChartComparisonExpiration");
			series30.ChartType = SeriesChartType.Spline;
			series30.BorderWidth = 2;
			series30.ShadowOffset = 0;
			series30.Color = ClassColorTheme.ChartExpirationColorComparison;
			series29.Add(series30);
			if (checkBoxChartExpiration.Checked && checkBoxStrategyComparison.Checked)
			{
				chart1.Series["SeriesChartComparisonExpiration"].Enabled = true;
			}
			else
			{
				chart1.Series["SeriesChartComparisonExpiration"].Enabled = false;
			}
			SeriesCollection series31 = chart1.Series;
			Series series32 = new Series("SeriesChartComparisonMarker");
			series32.ChartType = SeriesChartType.Point;
			series32.MarkerSize = 6;
			series32.ShadowOffset = 0;
			series32.Color = ClassColorTheme.ChartCurrentColorComparison;
			series32.MarkerStyle = MarkerStyle.Circle;
			series32.Enabled = true;
			series31.Add(series32);
			SeriesCollection series33 = chart1.Series;
			Series series34 = new Series("SeriesChartAddD1ComparisonMarker");
			series34.ChartType = SeriesChartType.Point;
			series34.MarkerSize = 4;
			series34.ShadowOffset = 0;
			series34.Color = ClassColorTheme.ChartAddD1ColorComparison;
			series34.MarkerStyle = MarkerStyle.Circle;
			series34.Enabled = true;
			series33.Add(series34);
			SeriesCollection series35 = chart1.Series;
			Series series36 = new Series("SeriesChartAddD2ComparisonMarker");
			series36.ChartType = SeriesChartType.Point;
			series36.MarkerSize = 4;
			series36.ShadowOffset = 0;
			series36.Color = ClassColorTheme.ChartAddD2ColorComparison;
			series36.MarkerStyle = MarkerStyle.Circle;
			series36.Enabled = true;
			series35.Add(series36);
			SeriesCollection series37 = chart1.Series;
			Series series38 = new Series("SeriesChartExpirationComparisonMarker");
			series38.ChartType = SeriesChartType.Point;
			series38.MarkerSize = 6;
			series38.ShadowOffset = 0;
			series38.Color = ClassColorTheme.ChartExpirationColorComparison;
			series38.MarkerStyle = MarkerStyle.Circle;
			series38.Enabled = true;
			series37.Add(series38);
			checkBoxChartCurrent.Select();
			PaintColorTheme();
		}

		public void CreateChartTable()
		{
			FuturePaper1.base_asset = "";
			FuturePaper1.last_price = 0.0;
			FuturePaper1.step_price = 0.0;
			FuturePaper1.F = false;
			FuturePaper2.base_asset = "";
			FuturePaper2.last_price = 0.0;
			FuturePaper2.step_price = 0.0;
			FuturePaper2.F = false;
			ChartTable.Clear();
			ChartTableComparison.Clear();
			int result1 = 0;
			int result2 = 0;
			DateTime dateTime = Convert.ToDateTime("01.01.1900");
			double result3;
			if (!double.TryParse(textBoxIndentUp.Text, out result3))
			{
				result3 = 30.0;
			}
			double result4;
			if (!double.TryParse(textBoxIndentDn.Text, out result4))
			{
				result4 = 30.0;
			}
			if (!int.TryParse(textBoxAddD1.Text, out result1))
			{
				result1 = 0;
			}
			if (!int.TryParse(textBoxAddD2.Text, out result2))
			{
				result2 = 0;
			}
			cCalculationPortfolio.AddD1 = result1;
			cCalculationPortfolio.AddD2 = result2;
			cCalculationPortfolio.gD = FormPortfolio.shiftD;
			cCalculationPortfolio.gV1 = FormPortfolio.shiftV1;
			cCalculationPortfolio.gV2 = FormPortfolio.shiftV2;
			double num1 = 200.0;
			int num2 = 0;
			for (int index = 0; index < FormPortfolio.PortfolioTable.Count; index++)
			{
				if (FormPortfolio.PortfolioTable[index].volume == 0.0 || !FormPortfolio.PortfolioTable[index].check_calculation)
				{
					continue;
				}
				if (num2 == 0 && FormPortfolio.PortfolioTable[index].futures_price != 0.0)
				{
					double futuresPrice = FormPortfolio.PortfolioTable[index].futures_price;
					dateTime = FormPortfolio.PortfolioTable[index].expiration_date;
					double stepPrice = FormPortfolio.PortfolioTable[index].step_price;
					FuturePaper1.paper_code = FormPortfolio.PortfolioTable[index].paper_code;
					FuturePaper1.base_asset = FormPortfolio.PortfolioTable[index].base_asset;
					FuturePaper1.last_price = futuresPrice;
					FuturePaper1.expiration_date = dateTime;
					FuturePaper1.step_price = stepPrice;
					FuturePaper1.decimal_points = FormPortfolio.PortfolioTable[index].decimal_points;
					FuturePaper1.F = true;
					num2++;
				}
				else
				{
					if (FormPortfolio.PortfolioTable[index].futures_price == 0.0)
					{
						continue;
					}
					if (FormPortfolio.PortfolioTable[index].expiration_date < dateTime)
					{
						if (Helpers.IsOption(FuturePaper1.paper_code))
						{
							FuturePaper2.paper_code = FuturePaper1.paper_code;
							FuturePaper2.base_asset = FuturePaper1.base_asset;
							FuturePaper2.last_price = FuturePaper1.last_price;
							FuturePaper2.expiration_date = FuturePaper1.expiration_date;
							FuturePaper2.step_price = FuturePaper1.step_price;
							FuturePaper2.decimal_points = FuturePaper1.decimal_points;
							FuturePaper2.F = FuturePaper1.F;
						}
						double futuresPrice2 = FormPortfolio.PortfolioTable[index].futures_price;
						dateTime = FormPortfolio.PortfolioTable[index].expiration_date;
						double stepPrice2 = FormPortfolio.PortfolioTable[index].step_price;
						FuturePaper1.paper_code = FormPortfolio.PortfolioTable[index].paper_code;
						FuturePaper1.base_asset = FormPortfolio.PortfolioTable[index].base_asset;
						FuturePaper1.last_price = futuresPrice2;
						FuturePaper1.expiration_date = dateTime;
						FuturePaper1.step_price = stepPrice2;
						FuturePaper1.decimal_points = FormPortfolio.PortfolioTable[index].decimal_points;
						FuturePaper1.F = true;
					}
					else if (FormPortfolio.PortfolioTable[index].expiration_date > dateTime && Helpers.IsOption(FormPortfolio.PortfolioTable[index].paper_code))
					{
						FuturePaper2.paper_code = FormPortfolio.PortfolioTable[index].paper_code;
						FuturePaper2.base_asset = FormPortfolio.PortfolioTable[index].base_asset;
						FuturePaper2.last_price = FormPortfolio.PortfolioTable[index].futures_price;
						FuturePaper2.expiration_date = FormPortfolio.PortfolioTable[index].expiration_date;
						FuturePaper2.step_price = FormPortfolio.PortfolioTable[index].step_price;
						FuturePaper2.decimal_points = FormPortfolio.PortfolioTable[index].decimal_points;
						FuturePaper2.F = true;
					}
				}
			}
			double num3 = ((!FuturePaper1.F || !FuturePaper2.F) ? 0.0 : (FuturePaper2.last_price - FuturePaper1.last_price));
			double lastPrice = FuturePaper1.last_price;
			DateTime expirationDate = FuturePaper1.expiration_date;
			double stepPrice3 = FuturePaper1.step_price;
			if (!FuturePaper1.F)
			{
				return;
			}
			double num4 = cCalculationOptions.RoundStepPrice(lastPrice * result3 / 100.0, stepPrice3);
			double num5 = cCalculationOptions.RoundStepPrice(lastPrice * result4 / 100.0, stepPrice3);
			double futurePrice = cCalculationOptions.RoundStepPrice(lastPrice - num5, stepPrice3);
			if (futurePrice <= 0.0)
			{
				return;
			}
			for (double num6 = cCalculationOptions.RoundStepPrice((lastPrice + num4 - (lastPrice - num5)) / num1, stepPrice3); futurePrice <= lastPrice + num4; futurePrice += num6)
			{
				PortfolioTable.Clear();
				PortfolioTableAddD1.Clear();
				PortfolioTableAddD2.Clear();
				PortfolioTableExpiration.Clear();
				for (int i = 0; i < FormPortfolio.PortfolioTable.Count; i++)
				{
					if (FormPortfolio.PortfolioTable[i].volume != 0.0 && FormPortfolio.PortfolioTable[i].check_calculation)
					{
						PortfolioPaper.paper_code = FormPortfolio.PortfolioTable[i].paper_code;
						PortfolioPaperAddD1.paper_code = PortfolioPaper.paper_code;
						PortfolioPaperAddD2.paper_code = PortfolioPaper.paper_code;
						PortfolioPaperExpiration.paper_code = PortfolioPaper.paper_code;
						PortfolioPaper.base_asset = FormPortfolio.PortfolioTable[i].base_asset;
						PortfolioPaperAddD1.base_asset = PortfolioPaper.base_asset;
						PortfolioPaperAddD2.base_asset = PortfolioPaper.base_asset;
						PortfolioPaperExpiration.base_asset = PortfolioPaper.base_asset;
						PortfolioPaper.volume = FormPortfolio.PortfolioTable[i].volume;
						PortfolioPaperAddD1.volume = PortfolioPaper.volume;
						PortfolioPaperAddD2.volume = PortfolioPaper.volume;
						PortfolioPaperExpiration.volume = PortfolioPaper.volume;
						PortfolioPaper.open_price = FormPortfolio.PortfolioTable[i].open_price;
						PortfolioPaperAddD1.open_price = PortfolioPaper.open_price;
						PortfolioPaperAddD2.open_price = PortfolioPaper.open_price;
						PortfolioPaperExpiration.open_price = PortfolioPaper.open_price;
						PortfolioPaper.option_type = FormPortfolio.PortfolioTable[i].option_type;
						PortfolioPaperAddD1.option_type = PortfolioPaper.option_type;
						PortfolioPaperAddD2.option_type = PortfolioPaper.option_type;
						PortfolioPaperExpiration.option_type = PortfolioPaper.option_type;
						PortfolioPaper.strike = FormPortfolio.PortfolioTable[i].strike;
						PortfolioPaperAddD1.strike = PortfolioPaper.strike;
						PortfolioPaperAddD2.strike = PortfolioPaper.strike;
						PortfolioPaperExpiration.strike = PortfolioPaper.strike;
						PortfolioPaper.expiration_date = FormPortfolio.PortfolioTable[i].expiration_date;
						PortfolioPaperAddD1.expiration_date = PortfolioPaper.expiration_date;
						PortfolioPaperAddD2.expiration_date = PortfolioPaper.expiration_date;
						PortfolioPaperExpiration.expiration_date = PortfolioPaper.expiration_date;
						PortfolioPaper.current_date = ((!(FormPortfolio.PortfolioTable[i].current_date <= FuturePaper1.expiration_date)) ? FuturePaper1.expiration_date : FormPortfolio.PortfolioTable[i].current_date);
						PortfolioPaperAddD1.current_date = ((!(PortfolioPaper.current_date.AddDays(result1) <= FuturePaper1.expiration_date)) ? FuturePaper1.expiration_date : PortfolioPaper.current_date.AddDays(result1));
						PortfolioPaperAddD2.current_date = ((!(PortfolioPaper.current_date.AddDays(result2) <= FuturePaper1.expiration_date)) ? FuturePaper1.expiration_date : PortfolioPaper.current_date.AddDays(result2));
						PortfolioPaperExpiration.current_date = FuturePaper1.expiration_date;
						PortfolioPaper.accumulated_profit = FormPortfolio.PortfolioTable[i].accumulated_profit;
						PortfolioPaperAddD1.accumulated_profit = PortfolioPaper.accumulated_profit;
						PortfolioPaperAddD2.accumulated_profit = PortfolioPaper.accumulated_profit;
						PortfolioPaperExpiration.accumulated_profit = PortfolioPaper.accumulated_profit;
						PortfolioPaper.volatility = FormPortfolio.PortfolioTable[i].volatility;
						PortfolioPaperAddD1.volatility = PortfolioPaper.volatility;
						PortfolioPaperAddD2.volatility = PortfolioPaper.volatility;
						PortfolioPaperExpiration.volatility = PortfolioPaper.volatility;
						PortfolioPaper.step_price = FormPortfolio.PortfolioTable[i].step_price;
						PortfolioPaper.decimal_points = FormPortfolio.PortfolioTable[i].decimal_points;
						PortfolioPaperAddD1.step_price = PortfolioPaper.step_price;
						PortfolioPaperAddD1.decimal_points = PortfolioPaper.decimal_points;
						PortfolioPaperAddD2.step_price = PortfolioPaper.step_price;
						PortfolioPaperAddD2.decimal_points = PortfolioPaper.decimal_points;
						PortfolioPaperExpiration.step_price = PortfolioPaper.step_price;
						PortfolioPaperExpiration.decimal_points = PortfolioPaper.decimal_points;
						if (PortfolioPaper.base_asset == FuturePaper1.base_asset)
						{
							PortfolioPaper.futures_price = futurePrice;
							PortfolioPaperAddD1.futures_price = futurePrice;
							PortfolioPaperAddD2.futures_price = futurePrice;
							PortfolioPaperExpiration.futures_price = futurePrice;
						}
						else if (PortfolioPaper.base_asset == FuturePaper2.base_asset)
						{
							PortfolioPaper.futures_price = futurePrice + num3;
							PortfolioPaperAddD1.futures_price = futurePrice + num3;
							PortfolioPaperAddD2.futures_price = futurePrice + num3;
							PortfolioPaperExpiration.futures_price = futurePrice + num3;
						}
						cCalculationOptions.TypeO = PortfolioPaper.option_type;
						cCalculationOptions.Strike = PortfolioPaper.strike;
						cCalculationOptions.DateExp = PortfolioPaper.expiration_date;
						cCalculationOptions.DateCurrent = PortfolioPaper.current_date;
						cCalculationOptions.Q = Convert.ToInt32(PortfolioPaper.volume);
						cCalculationOptions.VolaO = PortfolioPaper.volatility;
						cCalculationOptions.LastF = PortfolioPaper.futures_price;
						if (cCalculationOptions.CalculationOpt())
						{
							PortfolioPaper.teoretical_price = (Helpers.IsOption(PortfolioPaper.paper_code) ? Math.Round(cCalculationOptions.calcTheoPrice, PortfolioPaper.decimal_points) : PortfolioPaper.futures_price);
							PortfolioPaper.delta = Math.Round(cCalculationOptions.calcDelta, 2);
							PortfolioPaper.gamma = Math.Round(cCalculationOptions.calcGamma, 6);
							PortfolioPaper.vega = Math.Round(cCalculationOptions.calcVega, 2);
							PortfolioPaper.theta = Math.Round(cCalculationOptions.calcTheta, 2);
							PortfolioPaper.vomma = Math.Round(cCalculationOptions.calcVomma, 2);
							PortfolioPaper.profit = (PortfolioPaper.teoretical_price - PortfolioPaper.open_price) * PortfolioPaper.volume;
							PortfolioPaper.check = true;
						}
						else
						{
							PortfolioPaper.delta = 0.0;
							PortfolioPaper.gamma = 0.0;
							PortfolioPaper.vega = 0.0;
							PortfolioPaper.theta = 0.0;
							PortfolioPaper.vomma = 0.0;
							PortfolioPaper.profit = 0.0;
							PortfolioPaper.check = false;
						}
						PortfolioTable.Add(PortfolioPaper);
						cCalculationOptions.DateCurrent = PortfolioPaperAddD1.current_date;
						if (cCalculationOptions.CalculationOpt())
						{
							PortfolioPaperAddD1.teoretical_price = (Helpers.IsOption(PortfolioPaperAddD1.paper_code) ? Math.Round(cCalculationOptions.calcTheoPrice, PortfolioPaperAddD1.decimal_points) : PortfolioPaperAddD1.futures_price);
							PortfolioPaperAddD1.delta = Math.Round(cCalculationOptions.calcDelta, 2);
							PortfolioPaperAddD1.gamma = Math.Round(cCalculationOptions.calcGamma, 6);
							PortfolioPaperAddD1.vega = Math.Round(cCalculationOptions.calcVega, 2);
							PortfolioPaperAddD1.theta = Math.Round(cCalculationOptions.calcTheta, 2);
							PortfolioPaperAddD1.vomma = Math.Round(cCalculationOptions.calcVomma, 2);
							PortfolioPaperAddD1.profit = (PortfolioPaperAddD1.teoretical_price - PortfolioPaperAddD1.open_price) * PortfolioPaperAddD1.volume;
							PortfolioPaperAddD1.check = true;
						}
						else
						{
							PortfolioPaperAddD1.delta = 0.0;
							PortfolioPaperAddD1.gamma = 0.0;
							PortfolioPaperAddD1.vega = 0.0;
							PortfolioPaperAddD1.theta = 0.0;
							PortfolioPaperAddD1.vomma = 0.0;
							PortfolioPaperAddD1.profit = 0.0;
							PortfolioPaperAddD1.check = false;
						}
						PortfolioTableAddD1.Add(PortfolioPaperAddD1);
						cCalculationOptions.DateCurrent = PortfolioPaperAddD2.current_date;
						if (cCalculationOptions.CalculationOpt())
						{
							PortfolioPaperAddD2.teoretical_price = (Helpers.IsOption(PortfolioPaperAddD2.paper_code) ? Math.Round(cCalculationOptions.calcTheoPrice, PortfolioPaperAddD2.decimal_points) : PortfolioPaperAddD2.futures_price);
							PortfolioPaperAddD2.delta = Math.Round(cCalculationOptions.calcDelta, 2);
							PortfolioPaperAddD2.gamma = Math.Round(cCalculationOptions.calcGamma, 6);
							PortfolioPaperAddD2.vega = Math.Round(cCalculationOptions.calcVega, 2);
							PortfolioPaperAddD2.theta = Math.Round(cCalculationOptions.calcTheta, 2);
							PortfolioPaperAddD2.vomma = Math.Round(cCalculationOptions.calcVomma, 2);
							PortfolioPaperAddD2.profit = (PortfolioPaperAddD2.teoretical_price - PortfolioPaperAddD2.open_price) * PortfolioPaperAddD2.volume;
							PortfolioPaperAddD2.check = true;
						}
						else
						{
							PortfolioPaperAddD2.delta = 0.0;
							PortfolioPaperAddD2.gamma = 0.0;
							PortfolioPaperAddD2.vega = 0.0;
							PortfolioPaperAddD2.theta = 0.0;
							PortfolioPaperAddD2.vomma = 0.0;
							PortfolioPaperAddD2.profit = 0.0;
							PortfolioPaperAddD2.check = false;
						}
						PortfolioTableAddD2.Add(PortfolioPaperAddD2);
						cCalculationOptions.DateCurrent = PortfolioPaperExpiration.current_date;
						if (cCalculationOptions.CalculationOpt())
						{
							PortfolioPaperExpiration.teoretical_price = (Helpers.IsOption(PortfolioPaperExpiration.paper_code) ? Math.Round(cCalculationOptions.calcTheoPrice, PortfolioPaperExpiration.decimal_points) : PortfolioPaperAddD2.futures_price);
							PortfolioPaperExpiration.delta = Math.Round(cCalculationOptions.calcDelta, 2);
							PortfolioPaperExpiration.gamma = Math.Round(cCalculationOptions.calcGamma, 6);
							PortfolioPaperExpiration.vega = Math.Round(cCalculationOptions.calcVega, 2);
							PortfolioPaperExpiration.theta = Math.Round(cCalculationOptions.calcTheta, 2);
							PortfolioPaperExpiration.vomma = Math.Round(cCalculationOptions.calcVomma, 2);
							PortfolioPaperExpiration.profit = (PortfolioPaperExpiration.teoretical_price - PortfolioPaperExpiration.open_price) * PortfolioPaperExpiration.volume;
							PortfolioPaperExpiration.check = true;
						}
						else
						{
							PortfolioPaperExpiration.delta = 0.0;
							PortfolioPaperExpiration.gamma = 0.0;
							PortfolioPaperExpiration.vega = 0.0;
							PortfolioPaperExpiration.theta = 0.0;
							PortfolioPaperExpiration.vomma = 0.0;
							PortfolioPaperExpiration.profit = 0.0;
							PortfolioPaperAddD2.check = false;
						}
						PortfolioTableExpiration.Add(PortfolioPaperExpiration);
					}
				}
				ChartPaper.name = "Chart";
				ChartPaper.X = futurePrice;
				ChartPaper.Y = 0.0;
				ChartPaper.YAddD1 = 0.0;
				ChartPaper.YAddD2 = 0.0;
				ChartPaper.YExpiration = 0.0;
				ChartPaper.decimal_points = 2;
				for (int j = 0; j < PortfolioTable.Count; j++)
				{
					if (PortfolioTable[j].decimal_points > ChartPaper.decimal_points && radioButtonProfit.Checked)
					{
						ChartPaper.decimal_points = PortfolioTable[j].decimal_points;
					}
					if (radioButtonProfit.Checked)
					{
						ChartPaper.Y += PortfolioTable[j].profit;
					}
					else if (radioButtonDelta.Checked)
					{
						ChartPaper.Y += PortfolioTable[j].delta;
					}
					else if (radioButtonGamma.Checked)
					{
						ChartPaper.Y += PortfolioTable[j].gamma;
					}
					else if (radioButtonVega.Checked)
					{
						ChartPaper.Y += PortfolioTable[j].vega;
					}
					else if (radioButtonTheta.Checked)
					{
						ChartPaper.Y += PortfolioTable[j].theta;
					}
					else if (radioButtonVomma.Checked)
					{
						ChartPaper.Y += PortfolioTable[j].vomma;
					}
				}
				for (int k = 0; k < PortfolioTableAddD1.Count; k++)
				{
					if (radioButtonProfit.Checked)
					{
						ChartPaper.YAddD1 += PortfolioTableAddD1[k].profit;
					}
					else if (radioButtonDelta.Checked)
					{
						ChartPaper.YAddD1 += PortfolioTableAddD1[k].delta;
					}
					else if (radioButtonGamma.Checked)
					{
						ChartPaper.YAddD1 += PortfolioTableAddD1[k].gamma;
					}
					else if (radioButtonVega.Checked)
					{
						ChartPaper.YAddD1 += PortfolioTableAddD1[k].vega;
					}
					else if (radioButtonTheta.Checked)
					{
						ChartPaper.YAddD1 += PortfolioTableAddD1[k].theta;
					}
					else if (radioButtonVomma.Checked)
					{
						ChartPaper.YAddD1 += PortfolioTableAddD1[k].vomma;
					}
				}
				for (int l = 0; l < PortfolioTableAddD2.Count; l++)
				{
					if (radioButtonProfit.Checked)
					{
						ChartPaper.YAddD2 += PortfolioTableAddD2[l].profit;
					}
					else if (radioButtonDelta.Checked)
					{
						ChartPaper.YAddD2 += PortfolioTableAddD2[l].delta;
					}
					else if (radioButtonGamma.Checked)
					{
						ChartPaper.YAddD2 += PortfolioTableAddD2[l].gamma;
					}
					else if (radioButtonVega.Checked)
					{
						ChartPaper.YAddD2 += PortfolioTableAddD2[l].vega;
					}
					else if (radioButtonTheta.Checked)
					{
						ChartPaper.YAddD2 += PortfolioTableAddD2[l].theta;
					}
					else if (radioButtonVomma.Checked)
					{
						ChartPaper.YAddD2 += PortfolioTableAddD2[l].vomma;
					}
				}
				for (int m = 0; m < PortfolioTableExpiration.Count; m++)
				{
					if (radioButtonProfit.Checked)
					{
						ChartPaper.YExpiration += PortfolioTableExpiration[m].profit;
					}
				}
				if (FormPortfolio.CheckFixedProfit)
				{
					cCalculationPortfolio.CheckFixedProfit = true;
					if (radioButtonProfit.Checked)
					{
						ChartPaper.Y += FormPortfolio.FixedProfit;
						ChartPaper.YAddD1 += FormPortfolio.FixedProfit;
						ChartPaper.YAddD2 += FormPortfolio.FixedProfit;
						ChartPaper.YExpiration += FormPortfolio.FixedProfit;
					}
				}
				else
				{
					cCalculationPortfolio.CheckFixedProfit = false;
				}
				ChartTable.Add(ChartPaper);
				if (checkBoxStrategyComparison.Checked && comboBoxStrategyComparison.Text != "")
				{
					ChartPaperComparison.name = "ChartComparison";
					ChartPaperComparison.X = futurePrice;
					cCalculationPortfolio.ReplaceFuturePrice(FuturePaper1.base_asset, futurePrice);
					if (checkBoxChartCurrent.Checked)
					{
						cCalculationPortfolio.UpdatePortfolioTableFromPortfolio();
						cCalculationPortfolio.UpdatePortfolioTotal();
						if (radioButtonProfit.Checked)
						{
							ChartPaperComparison.Y = cCalculationPortfolio.PortfolioTotalCurrent.profit;
						}
						else if (radioButtonDelta.Checked)
						{
							ChartPaperComparison.Y = cCalculationPortfolio.PortfolioTotalCurrent.delta;
						}
						else if (radioButtonGamma.Checked)
						{
							ChartPaperComparison.Y = cCalculationPortfolio.PortfolioTotalCurrent.gamma;
						}
						else if (radioButtonVega.Checked)
						{
							ChartPaperComparison.Y = cCalculationPortfolio.PortfolioTotalCurrent.vega;
						}
						else if (radioButtonTheta.Checked)
						{
							ChartPaperComparison.Y = cCalculationPortfolio.PortfolioTotalCurrent.theta;
						}
						else if (radioButtonVomma.Checked)
						{
							ChartPaperComparison.Y = cCalculationPortfolio.PortfolioTotalCurrent.vomma;
						}
					}
					if (checkBoxChartAddD1.Checked)
					{
						cCalculationPortfolio.UpdatePortfolioTableAdd1FromPortfolio();
						cCalculationPortfolio.UpdatePortfolioTotalAdd1();
						if (radioButtonProfit.Checked)
						{
							ChartPaperComparison.YAddD1 = cCalculationPortfolio.PortfolioTotalAdd1.profit;
						}
						else if (radioButtonDelta.Checked)
						{
							ChartPaperComparison.YAddD1 = cCalculationPortfolio.PortfolioTotalAdd1.delta;
						}
						else if (radioButtonGamma.Checked)
						{
							ChartPaperComparison.YAddD1 = cCalculationPortfolio.PortfolioTotalAdd1.gamma;
						}
						else if (radioButtonVega.Checked)
						{
							ChartPaperComparison.YAddD1 = cCalculationPortfolio.PortfolioTotalAdd1.vega;
						}
						else if (radioButtonTheta.Checked)
						{
							ChartPaperComparison.YAddD1 = cCalculationPortfolio.PortfolioTotalAdd1.theta;
						}
						else if (radioButtonVomma.Checked)
						{
							ChartPaperComparison.YAddD1 = cCalculationPortfolio.PortfolioTotalAdd1.vomma;
						}
					}
					if (checkBoxChartAddD2.Checked)
					{
						cCalculationPortfolio.UpdatePortfolioTableAdd2FromPortfolio();
						cCalculationPortfolio.UpdatePortfolioTotalAdd2();
						if (radioButtonProfit.Checked)
						{
							ChartPaperComparison.YAddD2 = cCalculationPortfolio.PortfolioTotalAdd2.profit;
						}
						else if (radioButtonDelta.Checked)
						{
							ChartPaperComparison.YAddD2 = cCalculationPortfolio.PortfolioTotalAdd2.delta;
						}
						else if (radioButtonGamma.Checked)
						{
							ChartPaperComparison.YAddD2 = cCalculationPortfolio.PortfolioTotalAdd2.gamma;
						}
						else if (radioButtonVega.Checked)
						{
							ChartPaperComparison.YAddD2 = cCalculationPortfolio.PortfolioTotalAdd2.vega;
						}
						else if (radioButtonTheta.Checked)
						{
							ChartPaperComparison.YAddD2 = cCalculationPortfolio.PortfolioTotalAdd2.theta;
						}
						else if (radioButtonVomma.Checked)
						{
							ChartPaperComparison.YAddD2 = cCalculationPortfolio.PortfolioTotalAdd2.vomma;
						}
					}
					if (checkBoxChartExpiration.Checked)
					{
						cCalculationPortfolio.UpdatePortfolioTableExpirationFromPortfolio();
						cCalculationPortfolio.UpdatePortfolioTotalExpiration();
						if (radioButtonProfit.Checked)
						{
							ChartPaperComparison.YExpiration = cCalculationPortfolio.PortfolioTotalExpiration.profit;
						}
						else if (radioButtonDelta.Checked)
						{
							ChartPaperComparison.YExpiration = cCalculationPortfolio.PortfolioTotalExpiration.delta;
						}
						else if (radioButtonGamma.Checked)
						{
							ChartPaperComparison.YExpiration = cCalculationPortfolio.PortfolioTotalExpiration.gamma;
						}
						else if (radioButtonVega.Checked)
						{
							ChartPaperComparison.YExpiration = cCalculationPortfolio.PortfolioTotalExpiration.vega;
						}
						else if (radioButtonTheta.Checked)
						{
							ChartPaperComparison.YExpiration = cCalculationPortfolio.PortfolioTotalExpiration.theta;
						}
						else if (radioButtonVomma.Checked)
						{
							ChartPaperComparison.YExpiration = cCalculationPortfolio.PortfolioTotalExpiration.vomma;
						}
					}
				}
				ChartTableComparison.Add(ChartPaperComparison);
			}
		}

		public void DrawChart()
		{
			double result1 = 0.0;
			double stepprice = 0.0;
			double num1 = 0.0;
			double num2 = 0.0;
			double val1_1 = 0.0;
			double val1_2 = 0.0;
			double num3 = 0.0;
			double num4 = 0.0;
			double num5 = 0.0;
			double num6 = 0.0;
			double result2 = 0.0;
			double result3 = 0.0;
			if (!double.TryParse(textBoxIndentDn.Text, out result2))
			{
				result2 = 30.0;
			}
			if (!double.TryParse(textBoxIndentUp.Text, out result3))
			{
				result3 = 30.0;
			}
			if (FuturePaper1.F)
			{
				num6 = cCalculationOptions.RoundStepPrice(FuturePaper1.last_price * result3 / 100.0, FuturePaper1.step_price);
				num5 = cCalculationOptions.RoundStepPrice(FuturePaper1.last_price * result2 / 100.0, FuturePaper1.step_price);
				if (!cDataDDE.StepStrike(Convert.ToString(FuturePaper1.base_asset)))
				{
					return;
				}
				stepprice = ClassDataDDE.iStepStrike;
				textBoxStepGridX.Text = Convert.ToString(stepprice);
			}
			chart1.Series["SeriesChart"].Points.Clear();
			chart1.Series["SeriesChartAddD1"].Points.Clear();
			chart1.Series["SeriesChartAddD2"].Points.Clear();
			chart1.Series["SeriesChartExpiration"].Points.Clear();
			chart1.Series["SeriesCurrentPrice"].Points.Clear();
			chart1.Series["SeriesUpperLimit"].Points.Clear();
			chart1.Series["SeriesLowerLimit"].Points.Clear();
			chart1.Series["SeriesChartComparison"].Points.Clear();
			chart1.Series["SeriesChartComparisonAdd1"].Points.Clear();
			chart1.Series["SeriesChartComparisonAdd2"].Points.Clear();
			chart1.Series["SeriesChartComparisonExpiration"].Points.Clear();
			if (!FuturePaper1.F)
			{
				return;
			}
			if (FuturePaper1.F)
			{
				if (FuturePaper1.last_price - num5 > 0.0)
				{
					num3 = cCalculationOptions.RoundStepPriceFloor(FuturePaper1.last_price - num5, stepprice);
					if (num3 > FuturePaper1.last_price)
					{
						num3 = FuturePaper1.last_price;
					}
				}
				else
				{
					num3 = 0.0;
				}
				num4 = cCalculationOptions.RoundStepPriceCeiling(FuturePaper1.last_price + num6, stepprice);
				if (num4 < FuturePaper1.last_price)
				{
					num4 = FuturePaper1.last_price;
				}
			}
			bool flag = false;
			for (int index = 0; index < ChartTable.Count; index++)
			{
				if (!(ChartTable[index].X >= num3) || !(ChartTable[index].X <= num4))
				{
					continue;
				}
				if (!flag)
				{
					if (checkBoxChartCurrent.Checked)
					{
						num1 = ChartTable[index].Y;
						num2 = ChartTable[index].Y;
						if (checkBoxChartAddD1.Checked)
						{
							val1_1 = Math.Min(val1_1, ChartTable[index].YAddD1);
							val1_2 = Math.Max(val1_2, ChartTable[index].YAddD1);
						}
						if (checkBoxChartAddD2.Checked)
						{
							val1_1 = Math.Min(val1_1, ChartTable[index].YAddD2);
							val1_2 = Math.Max(val1_2, ChartTable[index].YAddD2);
						}
						if (checkBoxChartExpiration.Checked)
						{
							val1_1 = Math.Min(val1_1, ChartTable[index].YExpiration);
							val1_2 = Math.Max(val1_2, ChartTable[index].YExpiration);
						}
					}
					else if (checkBoxChartAddD1.Checked)
					{
						val1_1 = ChartTable[index].YAddD1;
						val1_2 = ChartTable[index].YAddD1;
						if (checkBoxChartCurrent.Checked)
						{
							val1_1 = Math.Min(val1_1, ChartTable[index].Y);
							val1_2 = Math.Max(val1_2, ChartTable[index].Y);
						}
						if (checkBoxChartAddD2.Checked)
						{
							val1_1 = Math.Min(val1_1, ChartTable[index].YAddD2);
							val1_2 = Math.Max(val1_2, ChartTable[index].YAddD2);
						}
						if (checkBoxChartExpiration.Checked)
						{
							val1_1 = Math.Min(val1_1, ChartTable[index].YExpiration);
							val1_2 = Math.Max(val1_2, ChartTable[index].YExpiration);
						}
					}
					else if (checkBoxChartAddD2.Checked)
					{
						val1_1 = ChartTable[index].YAddD2;
						val1_2 = ChartTable[index].YAddD2;
						if (checkBoxChartCurrent.Checked)
						{
							val1_1 = Math.Min(val1_1, ChartTable[index].Y);
							val1_2 = Math.Max(val1_2, ChartTable[index].Y);
						}
						if (checkBoxChartAddD1.Checked)
						{
							val1_1 = Math.Min(val1_1, ChartTable[index].YAddD1);
							val1_2 = Math.Max(val1_2, ChartTable[index].YAddD1);
						}
						if (checkBoxChartExpiration.Checked)
						{
							val1_1 = Math.Min(val1_1, ChartTable[index].YExpiration);
							val1_2 = Math.Max(val1_2, ChartTable[index].YExpiration);
						}
					}
					else if (checkBoxChartExpiration.Checked)
					{
						val1_1 = ChartTable[index].YExpiration;
						val1_2 = ChartTable[index].YExpiration;
						if (checkBoxChartAddD1.Checked)
						{
							val1_1 = Math.Min(val1_1, ChartTable[index].YAddD1);
							val1_2 = Math.Max(val1_2, ChartTable[index].YAddD1);
						}
						if (checkBoxChartAddD2.Checked)
						{
							val1_1 = Math.Min(val1_1, ChartTable[index].YAddD2);
							val1_2 = Math.Max(val1_2, ChartTable[index].YAddD2);
						}
						if (checkBoxChartCurrent.Checked)
						{
							val1_1 = Math.Min(val1_1, ChartTable[index].Y);
							val1_2 = Math.Max(val1_2, ChartTable[index].Y);
						}
					}
					flag = true;
				}
				else
				{
					if (checkBoxChartCurrent.Checked)
					{
						val1_1 = Math.Min(val1_1, ChartTable[index].Y);
						val1_2 = Math.Max(val1_2, ChartTable[index].Y);
					}
					if (checkBoxChartAddD1.Checked)
					{
						val1_1 = Math.Min(val1_1, ChartTable[index].YAddD1);
						val1_2 = Math.Max(val1_2, ChartTable[index].YAddD1);
					}
					if (checkBoxChartAddD2.Checked)
					{
						val1_1 = Math.Min(val1_1, ChartTable[index].YAddD2);
						val1_2 = Math.Max(val1_2, ChartTable[index].YAddD2);
					}
					if (checkBoxChartExpiration.Checked)
					{
						val1_1 = Math.Min(val1_1, ChartTable[index].YExpiration);
						val1_2 = Math.Max(val1_2, ChartTable[index].YExpiration);
					}
				}
			}
			for (int i = 0; i < ChartTableComparison.Count; i++)
			{
				if (checkBoxStrategyComparison.Checked && comboBoxStrategyComparison.Text != "" && ChartTableComparison[i].X >= num3 && ChartTableComparison[i].X <= num4)
				{
					if (checkBoxChartCurrent.Checked)
					{
						val1_1 = Math.Min(val1_1, ChartTableComparison[i].Y);
						val1_2 = Math.Max(val1_2, ChartTableComparison[i].Y);
					}
					if (checkBoxChartAddD1.Checked)
					{
						val1_1 = Math.Min(val1_1, ChartTableComparison[i].YAddD1);
						val1_2 = Math.Max(val1_2, ChartTableComparison[i].YAddD1);
					}
					if (checkBoxChartAddD2.Checked)
					{
						val1_1 = Math.Min(val1_1, ChartTableComparison[i].YAddD2);
						val1_2 = Math.Max(val1_2, ChartTableComparison[i].YAddD2);
					}
					if (checkBoxChartExpiration.Checked)
					{
						val1_1 = Math.Min(val1_1, ChartTableComparison[i].YExpiration);
						val1_2 = Math.Max(val1_2, ChartTableComparison[i].YExpiration);
					}
				}
			}
			if (!checkBoxStepGridYAuto.Checked)
			{
				if (!double.TryParse(textBoxStepGridY.Text, out result1))
				{
					result1 = 10000.0;
				}
			}
			else
			{
				result1 = cCalculationOptions.RoundNearestNumber(Convert.ToDouble((val1_2 - val1_1) / 10.0));
				if (result1 == 0.0)
				{
					result1 = 1.0;
				}
				labelStepGridY.Text = Convert.ToString(result1);
			}
			double yValue1 = cCalculationOptions.RoundStepPriceFloor(val1_1 - Math.Abs(val1_2 - val1_1) * 0.05, result1);
			double yValue2 = cCalculationOptions.RoundStepPriceCeiling(val1_2 + Math.Abs(val1_2 - yValue1) * 0.05, result1);
			chart1.ChartAreas[0].AxisX.Interval = stepprice;
			chart1.ChartAreas[0].AxisX.MajorGrid.Interval = stepprice;
			chart1.ChartAreas[0].AxisX.Minimum = num3;
			chart1.ChartAreas[0].AxisX.Maximum = num4;
			chart1.ChartAreas[0].AxisX.MajorGrid.LineWidth = 1;
			chart1.ChartAreas[0].AxisX.MajorGrid.LineDashStyle = ChartDashStyle.Dash;
			chart1.ChartAreas[0].AxisY.Interval = result1;
			chart1.ChartAreas[0].AxisY.Minimum = yValue1;
			chart1.ChartAreas[0].AxisY.Maximum = yValue2;
			chart1.ChartAreas[0].AxisY.MajorGrid.Interval = result1;
			chart1.ChartAreas[0].AxisY.MajorGrid.LineWidth = 1;
			chart1.ChartAreas[0].AxisY.MajorGrid.LineDashStyle = ChartDashStyle.Dash;
			chart1.Series["SeriesCurrentPrice"].Color = Color.SlateGray;
			chart1.Series["SeriesCurrentPrice"].BorderWidth = 1;
			chart1.ChartAreas[0].AxisX.ArrowStyle = AxisArrowStyle.None;
			chart1.ChartAreas[0].AxisY.Crossing = 0.0;
			if (FuturePaper1.F)
			{
				for (int j = 0; j < ChartTable.Count && !(ChartTable[j].name == ""); j++)
				{
					if (checkBoxChartCurrent.Checked)
					{
						chart1.Series["SeriesChart"].Enabled = true;
						chart1.Series["SeriesChart"].Points.AddXY(ChartTable[j].X, ChartTable[j].Y);
					}
					else
					{
						chart1.Series["SeriesChart"].Enabled = false;
					}
					if (checkBoxChartAddD1.Checked)
					{
						chart1.Series["SeriesChartAddD1"].Enabled = true;
						chart1.Series["SeriesChartAddD1"].Points.AddXY(ChartTable[j].X, ChartTable[j].YAddD1);
					}
					else
					{
						chart1.Series["SeriesChartAddD1"].Enabled = false;
					}
					if (checkBoxChartAddD2.Checked)
					{
						chart1.Series["SeriesChartAddD2"].Enabled = true;
						chart1.Series["SeriesChartAddD2"].Points.AddXY(ChartTable[j].X, ChartTable[j].YAddD2);
					}
					else
					{
						chart1.Series["SeriesChartAddD2"].Enabled = false;
					}
					if (checkBoxChartExpiration.Checked)
					{
						chart1.Series["SeriesChartExpiration"].Enabled = true;
						chart1.Series["SeriesChartExpiration"].Points.AddXY(ChartTable[j].X, ChartTable[j].YExpiration);
					}
					else
					{
						chart1.Series["SeriesChartExpiration"].Enabled = false;
					}
				}
			}
			else
			{
				chart1.Series["SeriesChart"].Enabled = false;
				chart1.Series["SeriesChartAddD1"].Enabled = false;
				chart1.Series["SeriesChartAddD2"].Enabled = false;
				chart1.Series["SeriesChartExpiration"].Enabled = false;
			}
			if (FuturePaper1.F && checkBoxStrategyComparison.Checked)
			{
				for (int k = 0; k < ChartTableComparison.Count && !(ChartTableComparison[k].name == ""); k++)
				{
					if (checkBoxChartCurrent.Checked && checkBoxStrategyComparison.Checked)
					{
						chart1.Series["SeriesChartComparison"].Enabled = true;
						chart1.Series["SeriesChartComparison"].Points.AddXY(ChartTableComparison[k].X, ChartTableComparison[k].Y);
					}
					else
					{
						chart1.Series["SeriesChartComparison"].Enabled = false;
					}
					if (checkBoxChartAddD1.Checked && checkBoxStrategyComparison.Checked)
					{
						chart1.Series["SeriesChartComparisonAdd1"].Enabled = true;
						chart1.Series["SeriesChartComparisonAdd1"].Points.AddXY(ChartTableComparison[k].X, ChartTableComparison[k].YAddD1);
					}
					else
					{
						chart1.Series["SeriesChartComparisonAdd1"].Enabled = false;
					}
					if (checkBoxChartAddD2.Checked && checkBoxStrategyComparison.Checked)
					{
						chart1.Series["SeriesChartComparisonAdd2"].Enabled = true;
						chart1.Series["SeriesChartComparisonAdd2"].Points.AddXY(ChartTableComparison[k].X, ChartTableComparison[k].YAddD2);
					}
					else
					{
						chart1.Series["SeriesChartComparisonAdd2"].Enabled = false;
					}
					if (checkBoxChartExpiration.Checked && checkBoxStrategyComparison.Checked)
					{
						chart1.Series["SeriesChartComparisonExpiration"].Enabled = true;
						chart1.Series["SeriesChartComparisonExpiration"].Points.AddXY(ChartTableComparison[k].X, ChartTableComparison[k].YExpiration);
					}
					else
					{
						chart1.Series["SeriesChartComparisonExpiration"].Enabled = false;
					}
				}
			}
			else
			{
				chart1.Series["SeriesChartComparison"].Enabled = false;
				chart1.Series["SeriesChartComparisonAdd1"].Enabled = false;
				chart1.Series["SeriesChartComparisonAdd2"].Enabled = false;
				chart1.Series["SeriesChartComparisonExpiration"].Enabled = false;
			}
			if (FuturePaper1.F)
			{
				chart1.Series["SeriesCurrentPrice"].Enabled = true;
				chart1.Series["SeriesCurrentPrice"].Points.AddXY(FuturePaper1.last_price, yValue1);
				chart1.Series["SeriesCurrentPrice"].Points.AddXY(FuturePaper1.last_price, yValue2);
			}
			else
			{
				chart1.Series["SeriesCurrentPrice"].Enabled = false;
			}
			double result4 = 0.0;
			double num7 = CalculationStandardDeviation();
			if (num7 > 0.0)
			{
				if (!double.TryParse(textBoxQuantityStandartDeviation.Text, out result4))
				{
					chart1.Series["SeriesUpperLimit"].Enabled = false;
					chart1.Series["SeriesLowerLimit"].Enabled = false;
					return;
				}
				if (FuturePaper1.last_price + result4 * num7 < num4)
				{
					chart1.Series["SeriesUpperLimit"].Enabled = true;
					chart1.Series["SeriesUpperLimit"].Points.AddXY(FuturePaper1.last_price + result4 * num7, yValue1);
					chart1.Series["SeriesUpperLimit"].Points.AddXY(FuturePaper1.last_price + result4 * num7, yValue2);
				}
				else
				{
					chart1.Series["SeriesUpperLimit"].Enabled = false;
				}
				if (FuturePaper1.last_price - result4 * num7 > num3)
				{
					chart1.Series["SeriesLowerLimit"].Enabled = true;
					chart1.Series["SeriesLowerLimit"].Points.AddXY(FuturePaper1.last_price - result4 * num7, yValue1);
					chart1.Series["SeriesLowerLimit"].Points.AddXY(FuturePaper1.last_price - result4 * num7, yValue2);
				}
				else
				{
					chart1.Series["SeriesLowerLimit"].Enabled = false;
				}
			}
			else
			{
				chart1.Series["SeriesUpperLimit"].Enabled = false;
				chart1.Series["SeriesLowerLimit"].Enabled = false;
			}
		}

		public void Tick()
		{
			CreateChartTable();
			DrawChart();
		}

		public void FillSettingsChartStepGridX()
		{
			ClassSettings.gChartStepGridX = textBoxStepGridX.Text;
		}

		public void FillSettingsChartStepGridY()
		{
			ClassSettings.gChartStepGridY = textBoxStepGridY.Text;
		}

		public void FillSettingsChartIndentUp()
		{
			ClassSettings.gChartIndentUp = textBoxIndentUp.Text;
		}

		public void FillSettingsChartIndentDn()
		{
			ClassSettings.gChartIndentDn = textBoxIndentDn.Text;
		}

		public void FillSettings()
		{
			ClassSettings.gChartStepGridX = textBoxStepGridX.Text;
			ClassSettings.gChartStepGridY = textBoxStepGridY.Text;
			ClassSettings.gChartIndentUp = textBoxIndentUp.Text;
			ClassSettings.gChartIndentDn = textBoxIndentDn.Text;
			ClassSettings.gChartQuantityStandartDeviation = Convert.ToString(textBoxQuantityStandartDeviation.Text);
			ClassSettings.gChartQuantityDaysStandartDeviation = Convert.ToString(textBoxQuantityDaysStandartDeviation.Text);
			ClassSettings.gChartCheckBoxChartCurrent = Convert.ToString(checkBoxChartCurrent.Checked);
			ClassSettings.gChartCheckBoxChartAddD1 = Convert.ToString(checkBoxChartAddD1.Checked);
			ClassSettings.gChartCheckBoxChartAddD2 = Convert.ToString(checkBoxChartAddD2.Checked);
			ClassSettings.gChartCheckBoxChartExpiration = Convert.ToString(checkBoxChartExpiration.Checked);
			ClassSettings.gChartTextBoxAddD1 = Convert.ToString(textBoxAddD1.Text);
			ClassSettings.gChartTextBoxAddD2 = Convert.ToString(textBoxAddD2.Text);
			ClassSettings.gChartCheckBoxStepGridYAuto = Convert.ToString(checkBoxStepGridYAuto.Checked);
		}

		private void PaintColorTheme()
		{
			BackColor = ClassColorTheme.BackColor;
			ForeColor = ClassColorTheme.HeadersColorFore;
			groupBox1.BackColor = ClassColorTheme.BackColor;
			groupBox1.ForeColor = ClassColorTheme.BackColorFore;
			groupBox2.BackColor = ClassColorTheme.BackColor;
			groupBox2.ForeColor = ClassColorTheme.BackColorFore;
			buttonIndentUpMore.FlatStyle = FlatStyle.System;
			buttonIndentUpLess.FlatStyle = FlatStyle.System;
			buttonIndentDnMore.FlatStyle = FlatStyle.System;
			buttonIndentDnLess.FlatStyle = FlatStyle.System;
			splitContainerChart.BackColor = ClassColorTheme.BackColor;
			splitContainerChart.Panel1.BackColor = ClassColorTheme.BackColor;
			splitContainerChart.Panel2.BackColor = ClassColorTheme.BackColor;
			splitContainerChart.BorderStyle = BorderStyle.None;
			label1.BackColor = ClassColorTheme.BackColor;
			label1.ForeColor = ClassColorTheme.BackColorFore;
			label2.BackColor = ClassColorTheme.BackColor;
			label2.ForeColor = ClassColorTheme.BackColorFore;
			label3.BackColor = ClassColorTheme.BackColor;
			label3.ForeColor = ClassColorTheme.BackColorFore;
			label4.BackColor = ClassColorTheme.BackColor;
			label4.ForeColor = ClassColorTheme.BackColorFore;
			label5.BackColor = ClassColorTheme.BackColor;
			label5.ForeColor = ClassColorTheme.BackColorFore;
			label6.BackColor = ClassColorTheme.BackColor;
			label6.ForeColor = ClassColorTheme.BackColorFore;
			label7.BackColor = ClassColorTheme.BackColor;
			label7.ForeColor = ClassColorTheme.BackColorFore;
			label8.BackColor = ClassColorTheme.BackColor;
			label8.ForeColor = ClassColorTheme.BackColorFore;
			labelStepGridY.BackColor = ClassColorTheme.BackColor;
			labelStepGridY.ForeColor = ClassColorTheme.BackColorFore;
			checkBoxChartCurrent.ForeColor = ClassColorTheme.BackColorFore;
			checkBoxChartAddD1.ForeColor = ClassColorTheme.BackColorFore;
			checkBoxChartAddD2.ForeColor = ClassColorTheme.BackColorFore;
			checkBoxChartExpiration.ForeColor = ClassColorTheme.BackColorFore;
			checkBoxStepGridYAuto.ForeColor = ClassColorTheme.BackColorFore;
			textBoxColorChartCurrent.BackColor = ClassColorTheme.ChartCurrentColor;
			textBoxColorChartAddD1.BackColor = ClassColorTheme.ChartAddD1Color;
			textBoxColorChartAddD2.BackColor = ClassColorTheme.ChartAddD2Color;
			textBoxColorChartExpiration.BackColor = ClassColorTheme.ChartExpirationColor;
			textBoxChartCurrentColorComparison.BackColor = ClassColorTheme.ChartCurrentColorComparison;
			textBoxChartAddD1ColorComparison.BackColor = ClassColorTheme.ChartAddD1ColorComparison;
			textBoxChartAddD2ColorComparison.BackColor = ClassColorTheme.ChartAddD2ColorComparison;
			textBoxChartExpirationColorComparison.BackColor = ClassColorTheme.ChartExpirationColorComparison;
			radioButtonProfit.ForeColor = ClassColorTheme.BackColorFore;
			radioButtonDelta.ForeColor = ClassColorTheme.BackColorFore;
			radioButtonGamma.ForeColor = ClassColorTheme.BackColorFore;
			radioButtonVega.ForeColor = ClassColorTheme.BackColorFore;
			radioButtonTheta.ForeColor = ClassColorTheme.BackColorFore;
			radioButtonVomma.ForeColor = ClassColorTheme.BackColorFore;
			chart1.BackColor = ClassColorTheme.BackColor;
			chart1.BackSecondaryColor = ClassColorTheme.BackColor;
			chart1.ForeColor = ClassColorTheme.BackColorFore;
			chart1.ChartAreas[0].AxisX.LabelStyle.ForeColor = ClassColorTheme.BackColorFore;
			chart1.ChartAreas[0].AxisY.LabelStyle.ForeColor = ClassColorTheme.BackColorFore;
			chart1.ChartAreas[0].AxisX.TitleForeColor = ClassColorTheme.BackColorFore;
			chart1.ChartAreas[0].AxisY.TitleForeColor = ClassColorTheme.BackColorFore;
			chart1.ChartAreas[0].AxisX.MajorGrid.LineColor = ClassColorTheme.ChartGridColor;
			chart1.ChartAreas[0].AxisY.MajorGrid.LineColor = ClassColorTheme.ChartGridColor;
			chart1.ChartAreas[0].AxisX.LineColor = ClassColorTheme.ChartGridColor;
			chart1.ChartAreas[0].AxisY.LineColor = ClassColorTheme.ChartGridColor;
			chart1.Series["SeriesChart"].Color = ClassColorTheme.ChartCurrentColor;
			chart1.Series["SeriesChartAddD1"].Color = ClassColorTheme.ChartAddD1Color;
			chart1.Series["SeriesChartAddD2"].Color = ClassColorTheme.ChartAddD2Color;
			chart1.Series["SeriesChartExpiration"].Color = ClassColorTheme.ChartExpirationColor;
			chart1.Series["SeriesChartMarker"].Color = ClassColorTheme.ChartCurrentColor;
			chart1.Series["SeriesChartAddD1Marker"].Color = ClassColorTheme.ChartAddD1Color;
			chart1.Series["SeriesChartAddD2Marker"].Color = ClassColorTheme.ChartAddD2Color;
			chart1.Series["SeriesChartExpirationMarker"].Color = ClassColorTheme.ChartExpirationColor;
			chart1.Series["SeriesChartComparison"].Color = ClassColorTheme.ChartCurrentColorComparison;
			chart1.Series["SeriesChartComparisonAdd1"].Color = ClassColorTheme.ChartAddD1ColorComparison;
			chart1.Series["SeriesChartComparisonAdd2"].Color = ClassColorTheme.ChartAddD2ColorComparison;
			chart1.Series["SeriesChartComparisonExpiration"].Color = ClassColorTheme.ChartExpirationColorComparison;
			chart1.ChartAreas[0].BackColor = ClassColorTheme.BackColor;
			chart1.Titles[0].ForeColor = ClassColorTheme.BackColorFore;
		}

		private void checkBoxStepGridYAuto_CheckedChanged(object sender, EventArgs e)
		{
			if (checkBoxStepGridYAuto.Checked)
			{
				textBoxStepGridY.Enabled = false;
				return;
			}
			textBoxStepGridY.Enabled = true;
			labelStepGridY.Text = "";
		}

		private void buttonIndentUpMore_Click(object sender, EventArgs e)
		{
			double result = 0.0;
			if (double.TryParse(textBoxIndentUp.Text, out result) && !(result <= 0.0))
			{
				textBoxIndentUp.Text = Convert.ToString(result + 1.0);
			}
		}

		private void buttonIndentUpLess_Click(object sender, EventArgs e)
		{
			double result = 0.0;
			if (double.TryParse(textBoxIndentUp.Text, out result) && !(result - 1.0 <= 0.0))
			{
				textBoxIndentUp.Text = Convert.ToString(result - 1.0);
			}
		}

		private void buttonIndentDnMore_Click(object sender, EventArgs e)
		{
			double result = 0.0;
			if (double.TryParse(textBoxIndentDn.Text, out result) && !(result <= 0.0) && !(result + 1.0 >= 100.0))
			{
				textBoxIndentDn.Text = Convert.ToString(result + 1.0);
			}
		}

		private void buttonIndentDnLess_Click(object sender, EventArgs e)
		{
			double result = 0.0;
			if (double.TryParse(textBoxIndentDn.Text, out result) && !(result - 1.0 <= 0.0))
			{
				textBoxIndentDn.Text = Convert.ToString(result - 1.0);
			}
		}

		private void chart1_MouseMove(object sender, MouseEventArgs e)
		{
			double result;
			if (!double.TryParse(Convert.ToString(e.X), out result) || result <= 0.0)
			{
				return;
			}
			double X;
			try
			{
				X = Convert.ToDouble(chart1.ChartAreas[0].AxisX.PixelPositionToValue(result));
			}
			catch
			{
				return;
			}
			chart1.Series["SeriesChartMarker"].Points.Clear();
			chart1.Series["SeriesChartAddD1Marker"].Points.Clear();
			chart1.Series["SeriesChartAddD2Marker"].Points.Clear();
			chart1.Series["SeriesChartExpirationMarker"].Points.Clear();
			ChartPaper = SearchCoordinatesY(X, ChartPaper.decimal_points);
			string str1;
			if (chart1.Series["SeriesChart"].Enabled)
			{
				str1 = " (Текущий " + Convert.ToString(ChartPaper.Y) + ") ";
				if (ChartPaper.X > 0.0)
				{
					chart1.Series["SeriesChartMarker"].Enabled = true;
					chart1.Series["SeriesChartMarker"].Points.AddXY(ChartPaper.X, ChartPaper.Y);
				}
				else
				{
					chart1.Series["SeriesChartMarker"].Enabled = false;
				}
			}
			else
			{
				str1 = "";
				chart1.Series["SeriesChartMarker"].Enabled = false;
			}
			string str2;
			if (chart1.Series["SeriesChartAddD1"].Enabled)
			{
				str2 = " (+" + textBoxAddD1.Text + " дн. " + Convert.ToString(ChartPaper.YAddD1) + ") ";
				if (ChartPaper.X > 0.0)
				{
					chart1.Series["SeriesChartAddD1Marker"].Enabled = true;
					chart1.Series["SeriesChartAddD1Marker"].Points.AddXY(ChartPaper.X, ChartPaper.YAddD1);
				}
				else
				{
					chart1.Series["SeriesChartAddD1Marker"].Enabled = false;
				}
			}
			else
			{
				str2 = "";
				chart1.Series["SeriesChartAddD1Marker"].Enabled = false;
			}
			string str3;
			if (chart1.Series["SeriesChartAddD2"].Enabled)
			{
				str3 = " (+" + textBoxAddD2.Text + " дн. " + Convert.ToString(ChartPaper.YAddD2) + ") ";
				if (ChartPaper.X > 0.0)
				{
					chart1.Series["SeriesChartAddD2Marker"].Enabled = true;
					chart1.Series["SeriesChartAddD2Marker"].Points.AddXY(ChartPaper.X, ChartPaper.YAddD2);
				}
				else
				{
					chart1.Series["SeriesChartAddD2Marker"].Enabled = false;
				}
			}
			else
			{
				str3 = "";
				chart1.Series["SeriesChartAddD2Marker"].Enabled = false;
			}
			string str4;
			if (chart1.Series["SeriesChartExpiration"].Enabled)
			{
				str4 = " (На экспирацию " + Convert.ToString(ChartPaper.YExpiration) + ") ";
				if (ChartPaper.X > 0.0)
				{
					chart1.Series["SeriesChartExpirationMarker"].Enabled = true;
					chart1.Series["SeriesChartExpirationMarker"].Points.AddXY(ChartPaper.X, ChartPaper.YExpiration);
				}
				else
				{
					chart1.Series["SeriesChartExpirationMarker"].Enabled = false;
				}
			}
			else
			{
				str4 = "";
				chart1.Series["SeriesChartExpirationMarker"].Enabled = false;
			}
			chart1.Series["SeriesChartComparisonMarker"].Points.Clear();
			chart1.Series["SeriesChartAddD1ComparisonMarker"].Points.Clear();
			chart1.Series["SeriesChartAddD2ComparisonMarker"].Points.Clear();
			chart1.Series["SeriesChartExpirationComparisonMarker"].Points.Clear();
			string str5 = "";
			string str6 = "";
			string str7 = "";
			string str8 = "";
			if (checkBoxStrategyComparison.Checked && comboBoxStrategyComparison.Text.Length > 0)
			{
				ChartPaper = SearchCoordinatesComparisonY(X);
				if (chart1.Series["SeriesChartComparison"].Enabled)
				{
					str5 = " (Текущий " + Convert.ToString(ChartPaper.Y) + ") ";
					if (ChartPaper.X > 0.0)
					{
						chart1.Series["SeriesChartComparisonMarker"].Enabled = true;
						chart1.Series["SeriesChartComparisonMarker"].Points.AddXY(ChartPaper.X, ChartPaper.Y);
					}
					else
					{
						chart1.Series["SeriesChartComparisonMarker"].Enabled = false;
					}
				}
				else
				{
					str5 = "";
					chart1.Series["SeriesChartComparisonMarker"].Enabled = false;
				}
				if (chart1.Series["SeriesChartComparisonAdd1"].Enabled)
				{
					str6 = " (+" + textBoxAddD1.Text + " дн. " + Convert.ToString(ChartPaper.YAddD1) + ") ";
					if (ChartPaper.X > 0.0)
					{
						chart1.Series["SeriesChartAddD1ComparisonMarker"].Enabled = true;
						chart1.Series["SeriesChartAddD1ComparisonMarker"].Points.AddXY(ChartPaper.X, ChartPaper.YAddD1);
					}
					else
					{
						chart1.Series["SeriesChartAddD1ComparisonMarker"].Enabled = false;
					}
				}
				else
				{
					str6 = "";
					chart1.Series["SeriesChartAddD1ComparisonMarker"].Enabled = false;
				}
				if (chart1.Series["SeriesChartComparisonAdd2"].Enabled)
				{
					str7 = " (+" + textBoxAddD2.Text + " дн. " + Convert.ToString(ChartPaper.YAddD2) + ") ";
					if (ChartPaper.X > 0.0)
					{
						chart1.Series["SeriesChartAddD2ComparisonMarker"].Enabled = true;
						chart1.Series["SeriesChartAddD2ComparisonMarker"].Points.AddXY(ChartPaper.X, ChartPaper.YAddD2);
					}
					else
					{
						chart1.Series["SeriesChartAddD2ComparisonMarker"].Enabled = false;
					}
				}
				else
				{
					str7 = "";
					chart1.Series["SeriesChartAddD2ComparisonMarker"].Enabled = false;
				}
				if (chart1.Series["SeriesChartComparisonExpiration"].Enabled)
				{
					str8 = " (На экспирацию " + Convert.ToString(ChartPaper.YExpiration) + ") ";
					if (ChartPaper.X > 0.0)
					{
						chart1.Series["SeriesChartExpirationComparisonMarker"].Enabled = true;
						chart1.Series["SeriesChartExpirationComparisonMarker"].Points.AddXY(ChartPaper.X, ChartPaper.YExpiration);
					}
					else
					{
						chart1.Series["SeriesChartExpirationComparisonMarker"].Enabled = false;
					}
				}
				else
				{
					str8 = "";
					chart1.Series["SeriesChartExpirationComparisonMarker"].Enabled = false;
				}
			}
			if (checkBoxStrategyComparison.Checked && comboBoxStrategyComparison.Text.Length > 0)
			{
				chart1.Titles[0].Text = "Портфель: Ось Х: " + Convert.ToString(ChartPaper.X) + " Ось Y: " + str1 + str2 + str3 + str4 + "\nСтратегия " + comboBoxStrategyComparison.Text + ":  Ось Y: " + str5 + str6 + str7 + str8;
			}
			else
			{
				chart1.Titles[0].Text = "Портфель: Ось Х: " + Convert.ToString(ChartPaper.X) + " Ось Y: " + str1 + str2 + str3 + str4;
			}
		}

		private Chart SearchCoordinatesY(double X, int numDecimals)
		{
			Chart chart = default(Chart);
			chart.decimal_points = numDecimals;
			double num = 0.0;
			for (int index = 0; index < ChartTable.Count; index++)
			{
				if (index == 0)
				{
					chart.X = ChartTable[index].X;
					chart.Y = ChartTable[index].Y;
					chart.YAddD1 = ChartTable[index].YAddD1;
					chart.YAddD2 = ChartTable[index].YAddD2;
					chart.YExpiration = ChartTable[index].YExpiration;
					num = Math.Abs(ChartTable[index].X - X);
				}
				if (Math.Abs(ChartTable[index].X - X) < num)
				{
					chart.X = ChartTable[index].X;
					chart.Y = ChartTable[index].Y;
					chart.YAddD1 = ChartTable[index].YAddD1;
					chart.YAddD2 = ChartTable[index].YAddD2;
					chart.YExpiration = ChartTable[index].YExpiration;
					num = Math.Abs(ChartTable[index].X - X);
				}
			}
			if (radioButtonProfit.Checked)
			{
				chart.Y = Math.Round(chart.Y, chart.decimal_points);
				chart.YAddD1 = Math.Round(chart.YAddD1, chart.decimal_points);
				chart.YAddD2 = Math.Round(chart.YAddD2, chart.decimal_points);
				chart.YExpiration = Math.Round(chart.YExpiration, chart.decimal_points);
			}
			else if (radioButtonDelta.Checked || radioButtonVega.Checked || radioButtonTheta.Checked)
			{
				chart.Y = Math.Round(chart.Y, 2);
				chart.YAddD1 = Math.Round(chart.YAddD1, 2);
				chart.YAddD2 = Math.Round(chart.YAddD2, 2);
				chart.YExpiration = Math.Round(chart.YExpiration, 2);
			}
			else if (radioButtonGamma.Checked)
			{
				chart.Y = Math.Round(chart.Y, 6);
				chart.YAddD1 = Math.Round(chart.YAddD1, 6);
				chart.YAddD2 = Math.Round(chart.YAddD2, 6);
				chart.YExpiration = Math.Round(chart.YExpiration, 6);
			}
			else if (radioButtonVomma.Checked)
			{
				chart.Y = Math.Round(chart.Y, 4);
				chart.YAddD1 = Math.Round(chart.YAddD1, 4);
				chart.YAddD2 = Math.Round(chart.YAddD2, 4);
				chart.YExpiration = Math.Round(chart.YExpiration, 4);
			}
			return chart;
		}

		private Chart SearchCoordinatesComparisonY(double X)
		{
			Chart chart = default(Chart);
			double num = 0.0;
			for (int index = 0; index < ChartTableComparison.Count; index++)
			{
				if (index == 0)
				{
					chart.X = ChartTableComparison[index].X;
					chart.Y = ChartTableComparison[index].Y;
					chart.YAddD1 = ChartTableComparison[index].YAddD1;
					chart.YAddD2 = ChartTableComparison[index].YAddD2;
					chart.YExpiration = ChartTableComparison[index].YExpiration;
					num = Math.Abs(ChartTableComparison[index].X - X);
				}
				if (Math.Abs(ChartTableComparison[index].X - X) < num)
				{
					chart.X = ChartTableComparison[index].X;
					chart.Y = ChartTableComparison[index].Y;
					chart.YAddD1 = ChartTableComparison[index].YAddD1;
					chart.YAddD2 = ChartTableComparison[index].YAddD2;
					chart.YExpiration = ChartTableComparison[index].YExpiration;
					num = Math.Abs(ChartTableComparison[index].X - X);
				}
			}
			if (radioButtonProfit.Checked || radioButtonDelta.Checked || radioButtonVega.Checked || radioButtonTheta.Checked)
			{
				chart.Y = Math.Round(chart.Y, chart.decimal_points);
				chart.YAddD1 = Math.Round(chart.YAddD1, chart.decimal_points);
				chart.YAddD2 = Math.Round(chart.YAddD2, chart.decimal_points);
				chart.YExpiration = Math.Round(chart.YExpiration, chart.decimal_points);
			}
			else if (radioButtonGamma.Checked)
			{
				chart.Y = Math.Round(chart.Y, 6);
				chart.YAddD1 = Math.Round(chart.YAddD1, 6);
				chart.YAddD2 = Math.Round(chart.YAddD2, 6);
				chart.YExpiration = Math.Round(chart.YExpiration, 6);
			}
			else if (radioButtonVomma.Checked)
			{
				chart.Y = Math.Round(chart.Y, 4);
				chart.YAddD1 = Math.Round(chart.YAddD1, 4);
				chart.YAddD2 = Math.Round(chart.YAddD2, 4);
				chart.YExpiration = Math.Round(chart.YExpiration, 4);
			}
			return chart;
		}

		private double CalculationStandardDeviation()
		{
			double num1 = 0.0;
			double result = 0.0;
			bool flag = double.TryParse(textBoxQuantityDaysStandartDeviation.Text, out result);
			if (flag)
			{
				if (result <= 0.0)
				{
					return 0.0;
				}
			}
			else if (!flag)
			{
				return 0.0;
			}
			int num2 = 0;
			double num3 = 0.0;
			double num4 = 0.0;
			if (FuturePaper1.F && Helpers.IsOption(FuturePaper1.paper_code))
			{
				lock (ClassDataDDE.QuotesTable)
				{
					for (int index = 0; index < ClassDataDDE.QuotesTable.Count; index++)
					{
						if (num2 == 0 && FuturePaper1.base_asset == ClassDataDDE.QuotesTable[index].base_asset && FuturePaper1.expiration_date.Date == ClassDataDDE.QuotesTable[index].expiration_date.Date)
						{
							double strike = ClassDataDDE.QuotesTable[index].strike;
							num4 = ClassDataDDE.QuotesTable[index].volatility;
							num3 = Math.Abs(strike - FuturePaper1.last_price);
							num2++;
						}
						if (Math.Abs(Math.Abs(ClassDataDDE.QuotesTable[index].strike - FuturePaper1.last_price)) < num3)
						{
							double strike2 = ClassDataDDE.QuotesTable[index].strike;
							num4 = ClassDataDDE.QuotesTable[index].volatility;
							num3 = Math.Abs(strike2 - FuturePaper1.last_price);
						}
					}
				}
				if (num4 > 0.0 && result > 0.0)
				{
					num1 = FuturePaper1.last_price * num4 / 100.0 / Math.Sqrt(252.0 / result);
				}
			}
			return num1;
		}

		private void FormChart_Shown(object sender, EventArgs e)
		{
			checkBoxChartCurrent.Focus();
		}

		private void comboBoxStrategyComparison_Click(object sender, EventArgs e)
		{
			string text = comboBoxStrategyComparison.Text;
			CreateStrategyTable();
			FillComboBoxStrategyComparison(text);
		}

		public void CreateStrategyTable()
		{
			StrategyTable.Clear();
			for (int index1 = 0; index1 < FormTransaction.TransactionTable.Count; index1++)
			{
				bool flag = false;
				string strategy = FormTransaction.TransactionTable[index1].strategy;
				if (strategy != "" && StrategyTable.Count == 0)
				{
					StrategyPaper.name_strategy = FormTransaction.TransactionTable[index1].strategy;
					StrategyPaper.profit = 0.0;
					StrategyPaper.GO = 0.0;
					StrategyTable.Add(StrategyPaper);
				}
				else
				{
					if (!(strategy != ""))
					{
						continue;
					}
					for (int i = 0; i < StrategyTable.Count; i++)
					{
						if (strategy == StrategyTable[i].name_strategy)
						{
							flag = true;
							break;
						}
					}
					if (!flag)
					{
						StrategyPaper.name_strategy = FormTransaction.TransactionTable[index1].strategy;
						StrategyPaper.profit = 0.0;
						StrategyPaper.GO = 0.0;
						StrategyTable.Add(StrategyPaper);
					}
				}
			}
		}

		public void FillComboBoxStrategyComparison(string StrategyComparison)
		{
			comboBoxStrategyComparison.Items.Clear();
			int num = 0;
			for (int index = 0; index < StrategyTable.Count; index++)
			{
				comboBoxStrategyComparison.Items.Add(StrategyTable[index].name_strategy);
				if (StrategyTable[index].name_strategy == StrategyComparison)
				{
					num = index;
				}
			}
			if (StrategyTable.Count > 0)
			{
				comboBoxStrategyComparison.SelectedIndex = num;
			}
		}

		private void checkBoxStrategyComparison_CheckedChanged(object sender, EventArgs e)
		{
			if (checkBoxStrategyComparison.Checked)
			{
				cCalculationPortfolio.ClearPortfolio();
				cCalculationPortfolio.CurrentStrategy = comboBoxStrategyComparison.Text;
				cCalculationPortfolio.CreatePortfolioTableFromTransaction();
				cCalculationPortfolio.UpdateFixedProfit();
			}
			Tick();
		}

		private void comboBoxStrategyComparison_SelectedIndexChanged(object sender, EventArgs e)
		{
			if (checkBoxStrategyComparison.Checked)
			{
				cCalculationPortfolio.ClearPortfolio();
				cCalculationPortfolio.CurrentStrategy = comboBoxStrategyComparison.Text;
				cCalculationPortfolio.CreatePortfolioTableFromTransaction();
				cCalculationPortfolio.UpdateFixedProfit();
				Tick();
			}
		}

		protected override void Dispose(bool disposing)
		{
			if (disposing && components != null)
			{
				components.Dispose();
			}
			base.Dispose(disposing);
		}

		private void InitializeComponent()
		{
			System.Windows.Forms.DataVisualization.Charting.ChartArea chartArea = new System.Windows.Forms.DataVisualization.Charting.ChartArea();
			System.Windows.Forms.DataVisualization.Charting.Legend legend = new System.Windows.Forms.DataVisualization.Charting.Legend();
			this.splitContainerChart = new System.Windows.Forms.SplitContainer();
			this.comboBoxStrategyComparison = new System.Windows.Forms.ComboBox();
			this.checkBoxStrategyComparison = new System.Windows.Forms.CheckBox();
			this.textBoxQuantityStandartDeviation = new System.Windows.Forms.TextBox();
			this.textBoxQuantityDaysStandartDeviation = new System.Windows.Forms.TextBox();
			this.label8 = new System.Windows.Forms.Label();
			this.label7 = new System.Windows.Forms.Label();
			this.textBoxChartExpirationColorComparison = new System.Windows.Forms.TextBox();
			this.textBoxColorChartExpiration = new System.Windows.Forms.TextBox();
			this.textBoxChartAddD1ColorComparison = new System.Windows.Forms.TextBox();
			this.textBoxColorChartAddD1 = new System.Windows.Forms.TextBox();
			this.textBoxChartAddD2ColorComparison = new System.Windows.Forms.TextBox();
			this.textBoxColorChartAddD2 = new System.Windows.Forms.TextBox();
			this.textBoxChartCurrentColorComparison = new System.Windows.Forms.TextBox();
			this.textBoxColorChartCurrent = new System.Windows.Forms.TextBox();
			this.labelStepGridY = new System.Windows.Forms.Label();
			this.checkBoxStepGridYAuto = new System.Windows.Forms.CheckBox();
			this.checkBoxChartExpiration = new System.Windows.Forms.CheckBox();
			this.groupBox2 = new System.Windows.Forms.GroupBox();
			this.buttonIndentDnLess = new System.Windows.Forms.Button();
			this.buttonIndentDnMore = new System.Windows.Forms.Button();
			this.buttonIndentUpLess = new System.Windows.Forms.Button();
			this.buttonIndentUpMore = new System.Windows.Forms.Button();
			this.label4 = new System.Windows.Forms.Label();
			this.label3 = new System.Windows.Forms.Label();
			this.textBoxIndentDn = new System.Windows.Forms.TextBox();
			this.textBoxIndentUp = new System.Windows.Forms.TextBox();
			this.label6 = new System.Windows.Forms.Label();
			this.label5 = new System.Windows.Forms.Label();
			this.textBoxAddD2 = new System.Windows.Forms.TextBox();
			this.checkBoxChartAddD2 = new System.Windows.Forms.CheckBox();
			this.textBoxAddD1 = new System.Windows.Forms.TextBox();
			this.checkBoxChartAddD1 = new System.Windows.Forms.CheckBox();
			this.checkBoxChartCurrent = new System.Windows.Forms.CheckBox();
			this.label2 = new System.Windows.Forms.Label();
			this.textBoxStepGridX = new System.Windows.Forms.TextBox();
			this.textBoxStepGridY = new System.Windows.Forms.TextBox();
			this.label1 = new System.Windows.Forms.Label();
			this.groupBox1 = new System.Windows.Forms.GroupBox();
			this.radioButtonVomma = new System.Windows.Forms.RadioButton();
			this.radioButtonTheta = new System.Windows.Forms.RadioButton();
			this.radioButtonVega = new System.Windows.Forms.RadioButton();
			this.radioButtonGamma = new System.Windows.Forms.RadioButton();
			this.radioButtonDelta = new System.Windows.Forms.RadioButton();
			this.radioButtonProfit = new System.Windows.Forms.RadioButton();
			this.chart1 = new System.Windows.Forms.DataVisualization.Charting.Chart();
			this.splitContainerChart.BeginInit();
			this.splitContainerChart.Panel1.SuspendLayout();
			this.splitContainerChart.Panel2.SuspendLayout();
			this.splitContainerChart.SuspendLayout();
			this.groupBox2.SuspendLayout();
			this.groupBox1.SuspendLayout();
			this.chart1.BeginInit();
			base.SuspendLayout();
			this.splitContainerChart.Dock = System.Windows.Forms.DockStyle.Fill;
			this.splitContainerChart.FixedPanel = System.Windows.Forms.FixedPanel.Panel1;
			this.splitContainerChart.IsSplitterFixed = true;
			this.splitContainerChart.Location = new System.Drawing.Point(0, 0);
			this.splitContainerChart.Name = "splitContainerChart";
			this.splitContainerChart.Panel1.AutoScroll = true;
			this.splitContainerChart.Panel1.Controls.Add(this.comboBoxStrategyComparison);
			this.splitContainerChart.Panel1.Controls.Add(this.checkBoxStrategyComparison);
			this.splitContainerChart.Panel1.Controls.Add(this.textBoxQuantityStandartDeviation);
			this.splitContainerChart.Panel1.Controls.Add(this.textBoxQuantityDaysStandartDeviation);
			this.splitContainerChart.Panel1.Controls.Add(this.label8);
			this.splitContainerChart.Panel1.Controls.Add(this.label7);
			this.splitContainerChart.Panel1.Controls.Add(this.textBoxChartExpirationColorComparison);
			this.splitContainerChart.Panel1.Controls.Add(this.textBoxColorChartExpiration);
			this.splitContainerChart.Panel1.Controls.Add(this.textBoxChartAddD1ColorComparison);
			this.splitContainerChart.Panel1.Controls.Add(this.textBoxColorChartAddD1);
			this.splitContainerChart.Panel1.Controls.Add(this.textBoxChartAddD2ColorComparison);
			this.splitContainerChart.Panel1.Controls.Add(this.textBoxColorChartAddD2);
			this.splitContainerChart.Panel1.Controls.Add(this.textBoxChartCurrentColorComparison);
			this.splitContainerChart.Panel1.Controls.Add(this.textBoxColorChartCurrent);
			this.splitContainerChart.Panel1.Controls.Add(this.labelStepGridY);
			this.splitContainerChart.Panel1.Controls.Add(this.checkBoxStepGridYAuto);
			this.splitContainerChart.Panel1.Controls.Add(this.checkBoxChartExpiration);
			this.splitContainerChart.Panel1.Controls.Add(this.groupBox2);
			this.splitContainerChart.Panel1.Controls.Add(this.label6);
			this.splitContainerChart.Panel1.Controls.Add(this.label5);
			this.splitContainerChart.Panel1.Controls.Add(this.textBoxAddD2);
			this.splitContainerChart.Panel1.Controls.Add(this.checkBoxChartAddD2);
			this.splitContainerChart.Panel1.Controls.Add(this.textBoxAddD1);
			this.splitContainerChart.Panel1.Controls.Add(this.checkBoxChartAddD1);
			this.splitContainerChart.Panel1.Controls.Add(this.checkBoxChartCurrent);
			this.splitContainerChart.Panel1.Controls.Add(this.label2);
			this.splitContainerChart.Panel1.Controls.Add(this.textBoxStepGridX);
			this.splitContainerChart.Panel1.Controls.Add(this.textBoxStepGridY);
			this.splitContainerChart.Panel1.Controls.Add(this.label1);
			this.splitContainerChart.Panel1.Controls.Add(this.groupBox1);
			this.splitContainerChart.Panel2.Controls.Add(this.chart1);
			this.splitContainerChart.Size = new System.Drawing.Size(1261, 552);
			this.splitContainerChart.SplitterDistance = 190;
			this.splitContainerChart.TabIndex = 0;
			this.comboBoxStrategyComparison.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
			this.comboBoxStrategyComparison.FormattingEnabled = true;
			this.comboBoxStrategyComparison.Location = new System.Drawing.Point(7, 122);
			this.comboBoxStrategyComparison.Name = "comboBoxStrategyComparison";
			this.comboBoxStrategyComparison.Size = new System.Drawing.Size(157, 21);
			this.comboBoxStrategyComparison.TabIndex = 18;
			this.comboBoxStrategyComparison.SelectedIndexChanged += new System.EventHandler(comboBoxStrategyComparison_SelectedIndexChanged);
			this.comboBoxStrategyComparison.Click += new System.EventHandler(comboBoxStrategyComparison_Click);
			this.checkBoxStrategyComparison.AutoSize = true;
			this.checkBoxStrategyComparison.Location = new System.Drawing.Point(7, 99);
			this.checkBoxStrategyComparison.Name = "checkBoxStrategyComparison";
			this.checkBoxStrategyComparison.Size = new System.Drawing.Size(149, 17);
			this.checkBoxStrategyComparison.TabIndex = 17;
			this.checkBoxStrategyComparison.Text = "Сравнить со стратегией";
			this.checkBoxStrategyComparison.UseVisualStyleBackColor = true;
			this.checkBoxStrategyComparison.CheckedChanged += new System.EventHandler(checkBoxStrategyComparison_CheckedChanged);
			this.textBoxQuantityStandartDeviation.Location = new System.Drawing.Point(119, 480);
			this.textBoxQuantityStandartDeviation.Name = "textBoxQuantityStandartDeviation";
			this.textBoxQuantityStandartDeviation.Size = new System.Drawing.Size(49, 20);
			this.textBoxQuantityStandartDeviation.TabIndex = 1;
			this.textBoxQuantityDaysStandartDeviation.Location = new System.Drawing.Point(119, 506);
			this.textBoxQuantityDaysStandartDeviation.Name = "textBoxQuantityDaysStandartDeviation";
			this.textBoxQuantityDaysStandartDeviation.Size = new System.Drawing.Size(49, 20);
			this.textBoxQuantityDaysStandartDeviation.TabIndex = 1;
			this.label8.AutoSize = true;
			this.label8.Location = new System.Drawing.Point(8, 509);
			this.label8.Name = "label8";
			this.label8.Size = new System.Drawing.Size(68, 13);
			this.label8.TabIndex = 1;
			this.label8.Text = "Кол-во дней";
			this.label7.AutoSize = true;
			this.label7.Location = new System.Drawing.Point(8, 483);
			this.label7.Name = "label7";
			this.label7.Size = new System.Drawing.Size(66, 13);
			this.label7.TabIndex = 1;
			this.label7.Text = "Кол-во СКО";
			this.textBoxChartExpirationColorComparison.BorderStyle = System.Windows.Forms.BorderStyle.None;
			this.textBoxChartExpirationColorComparison.Enabled = false;
			this.textBoxChartExpirationColorComparison.Location = new System.Drawing.Point(146, 77);
			this.textBoxChartExpirationColorComparison.Name = "textBoxChartExpirationColorComparison";
			this.textBoxChartExpirationColorComparison.Size = new System.Drawing.Size(18, 13);
			this.textBoxChartExpirationColorComparison.TabIndex = 15;
			this.textBoxColorChartExpiration.BorderStyle = System.Windows.Forms.BorderStyle.None;
			this.textBoxColorChartExpiration.Enabled = false;
			this.textBoxColorChartExpiration.Location = new System.Drawing.Point(122, 77);
			this.textBoxColorChartExpiration.Name = "textBoxColorChartExpiration";
			this.textBoxColorChartExpiration.Size = new System.Drawing.Size(18, 13);
			this.textBoxColorChartExpiration.TabIndex = 15;
			this.textBoxChartAddD1ColorComparison.BorderStyle = System.Windows.Forms.BorderStyle.None;
			this.textBoxChartAddD1ColorComparison.Enabled = false;
			this.textBoxChartAddD1ColorComparison.Location = new System.Drawing.Point(146, 27);
			this.textBoxChartAddD1ColorComparison.Name = "textBoxChartAddD1ColorComparison";
			this.textBoxChartAddD1ColorComparison.Size = new System.Drawing.Size(18, 13);
			this.textBoxChartAddD1ColorComparison.TabIndex = 15;
			this.textBoxColorChartAddD1.BorderStyle = System.Windows.Forms.BorderStyle.None;
			this.textBoxColorChartAddD1.Enabled = false;
			this.textBoxColorChartAddD1.Location = new System.Drawing.Point(122, 27);
			this.textBoxColorChartAddD1.Name = "textBoxColorChartAddD1";
			this.textBoxColorChartAddD1.Size = new System.Drawing.Size(18, 13);
			this.textBoxColorChartAddD1.TabIndex = 15;
			this.textBoxChartAddD2ColorComparison.BorderStyle = System.Windows.Forms.BorderStyle.None;
			this.textBoxChartAddD2ColorComparison.Enabled = false;
			this.textBoxChartAddD2ColorComparison.Location = new System.Drawing.Point(146, 53);
			this.textBoxChartAddD2ColorComparison.Name = "textBoxChartAddD2ColorComparison";
			this.textBoxChartAddD2ColorComparison.Size = new System.Drawing.Size(18, 13);
			this.textBoxChartAddD2ColorComparison.TabIndex = 15;
			this.textBoxColorChartAddD2.BorderStyle = System.Windows.Forms.BorderStyle.None;
			this.textBoxColorChartAddD2.Enabled = false;
			this.textBoxColorChartAddD2.Location = new System.Drawing.Point(122, 53);
			this.textBoxColorChartAddD2.Name = "textBoxColorChartAddD2";
			this.textBoxColorChartAddD2.Size = new System.Drawing.Size(18, 13);
			this.textBoxColorChartAddD2.TabIndex = 15;
			this.textBoxChartCurrentColorComparison.BorderStyle = System.Windows.Forms.BorderStyle.None;
			this.textBoxChartCurrentColorComparison.Enabled = false;
			this.textBoxChartCurrentColorComparison.Location = new System.Drawing.Point(146, 4);
			this.textBoxChartCurrentColorComparison.Name = "textBoxChartCurrentColorComparison";
			this.textBoxChartCurrentColorComparison.Size = new System.Drawing.Size(18, 13);
			this.textBoxChartCurrentColorComparison.TabIndex = 14;
			this.textBoxColorChartCurrent.BorderStyle = System.Windows.Forms.BorderStyle.None;
			this.textBoxColorChartCurrent.Enabled = false;
			this.textBoxColorChartCurrent.Location = new System.Drawing.Point(122, 4);
			this.textBoxColorChartCurrent.Name = "textBoxColorChartCurrent";
			this.textBoxColorChartCurrent.Size = new System.Drawing.Size(18, 13);
			this.textBoxColorChartCurrent.TabIndex = 14;
			this.labelStepGridY.AutoSize = true;
			this.labelStepGridY.Location = new System.Drawing.Point(86, 438);
			this.labelStepGridY.Name = "labelStepGridY";
			this.labelStepGridY.Size = new System.Drawing.Size(35, 13);
			this.labelStepGridY.TabIndex = 13;
			this.labelStepGridY.Text = "label7";
			this.checkBoxStepGridYAuto.AutoSize = true;
			this.checkBoxStepGridYAuto.Location = new System.Drawing.Point(11, 437);
			this.checkBoxStepGridYAuto.Name = "checkBoxStepGridYAuto";
			this.checkBoxStepGridYAuto.Size = new System.Drawing.Size(50, 17);
			this.checkBoxStepGridYAuto.TabIndex = 12;
			this.checkBoxStepGridYAuto.Text = "Авто";
			this.checkBoxStepGridYAuto.UseVisualStyleBackColor = true;
			this.checkBoxStepGridYAuto.CheckedChanged += new System.EventHandler(checkBoxStepGridYAuto_CheckedChanged);
			this.checkBoxChartExpiration.AutoSize = true;
			this.checkBoxChartExpiration.Location = new System.Drawing.Point(7, 76);
			this.checkBoxChartExpiration.Name = "checkBoxChartExpiration";
			this.checkBoxChartExpiration.Size = new System.Drawing.Size(105, 17);
			this.checkBoxChartExpiration.TabIndex = 11;
			this.checkBoxChartExpiration.Text = "На экспирацию";
			this.checkBoxChartExpiration.UseVisualStyleBackColor = true;
			this.groupBox2.Controls.Add(this.buttonIndentDnLess);
			this.groupBox2.Controls.Add(this.buttonIndentDnMore);
			this.groupBox2.Controls.Add(this.buttonIndentUpLess);
			this.groupBox2.Controls.Add(this.buttonIndentUpMore);
			this.groupBox2.Controls.Add(this.label4);
			this.groupBox2.Controls.Add(this.label3);
			this.groupBox2.Controls.Add(this.textBoxIndentDn);
			this.groupBox2.Controls.Add(this.textBoxIndentUp);
			this.groupBox2.Location = new System.Drawing.Point(7, 314);
			this.groupBox2.Name = "groupBox2";
			this.groupBox2.Size = new System.Drawing.Size(161, 75);
			this.groupBox2.TabIndex = 6;
			this.groupBox2.TabStop = false;
			this.groupBox2.Text = "Отрисовка графика %";
			this.buttonIndentDnLess.Location = new System.Drawing.Point(42, 43);
			this.buttonIndentDnLess.Name = "buttonIndentDnLess";
			this.buttonIndentDnLess.Size = new System.Drawing.Size(27, 23);
			this.buttonIndentDnLess.TabIndex = 7;
			this.buttonIndentDnLess.Text = "<";
			this.buttonIndentDnLess.UseVisualStyleBackColor = true;
			this.buttonIndentDnLess.Click += new System.EventHandler(buttonIndentDnLess_Click);
			this.buttonIndentDnMore.Location = new System.Drawing.Point(127, 43);
			this.buttonIndentDnMore.Name = "buttonIndentDnMore";
			this.buttonIndentDnMore.Size = new System.Drawing.Size(28, 23);
			this.buttonIndentDnMore.TabIndex = 6;
			this.buttonIndentDnMore.Text = ">";
			this.buttonIndentDnMore.UseVisualStyleBackColor = true;
			this.buttonIndentDnMore.Click += new System.EventHandler(buttonIndentDnMore_Click);
			this.buttonIndentUpLess.Location = new System.Drawing.Point(42, 17);
			this.buttonIndentUpLess.Name = "buttonIndentUpLess";
			this.buttonIndentUpLess.Size = new System.Drawing.Size(28, 23);
			this.buttonIndentUpLess.TabIndex = 5;
			this.buttonIndentUpLess.Text = "<";
			this.buttonIndentUpLess.UseVisualStyleBackColor = true;
			this.buttonIndentUpLess.Click += new System.EventHandler(buttonIndentUpLess_Click);
			this.buttonIndentUpMore.Location = new System.Drawing.Point(127, 17);
			this.buttonIndentUpMore.Name = "buttonIndentUpMore";
			this.buttonIndentUpMore.Size = new System.Drawing.Size(28, 23);
			this.buttonIndentUpMore.TabIndex = 4;
			this.buttonIndentUpMore.Text = ">";
			this.buttonIndentUpMore.UseVisualStyleBackColor = true;
			this.buttonIndentUpMore.Click += new System.EventHandler(buttonIndentUpMore_Click);
			this.label4.AutoSize = true;
			this.label4.Location = new System.Drawing.Point(7, 48);
			this.label4.Name = "label4";
			this.label4.Size = new System.Drawing.Size(35, 13);
			this.label4.TabIndex = 3;
			this.label4.Text = "Ниже";
			this.label3.AutoSize = true;
			this.label3.Location = new System.Drawing.Point(7, 22);
			this.label3.Name = "label3";
			this.label3.Size = new System.Drawing.Size(36, 13);
			this.label3.TabIndex = 2;
			this.label3.Text = "Выше";
			this.textBoxIndentDn.Location = new System.Drawing.Point(76, 45);
			this.textBoxIndentDn.Name = "textBoxIndentDn";
			this.textBoxIndentDn.ReadOnly = false;
			this.textBoxIndentDn.Size = new System.Drawing.Size(45, 20);
			this.textBoxIndentDn.TabIndex = 1;
			this.textBoxIndentDn.Text = "20000";
			this.textBoxIndentDn.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
			this.textBoxIndentUp.Location = new System.Drawing.Point(76, 19);
			this.textBoxIndentUp.Name = "textBoxIndentUp";
			this.textBoxIndentUp.ReadOnly = false;
			this.textBoxIndentUp.Size = new System.Drawing.Size(45, 20);
			this.textBoxIndentUp.TabIndex = 0;
			this.textBoxIndentUp.Text = "20000";
			this.textBoxIndentUp.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
			this.label6.AutoSize = true;
			this.label6.Location = new System.Drawing.Point(82, 53);
			this.label6.Name = "label6";
			this.label6.Size = new System.Drawing.Size(34, 13);
			this.label6.TabIndex = 10;
			this.label6.Text = "Дней";
			this.label5.AutoSize = true;
			this.label5.Location = new System.Drawing.Point(82, 27);
			this.label5.Name = "label5";
			this.label5.Size = new System.Drawing.Size(34, 13);
			this.label5.TabIndex = 10;
			this.label5.Text = "Дней";
			this.textBoxAddD2.Location = new System.Drawing.Point(45, 50);
			this.textBoxAddD2.Name = "textBoxAddD2";
			this.textBoxAddD2.Size = new System.Drawing.Size(27, 20);
			this.textBoxAddD2.TabIndex = 9;
			this.checkBoxChartAddD2.AutoSize = true;
			this.checkBoxChartAddD2.Location = new System.Drawing.Point(7, 52);
			this.checkBoxChartAddD2.Name = "checkBoxChartAddD2";
			this.checkBoxChartAddD2.Size = new System.Drawing.Size(32, 17);
			this.checkBoxChartAddD2.TabIndex = 8;
			this.checkBoxChartAddD2.Text = "+";
			this.checkBoxChartAddD2.UseVisualStyleBackColor = true;
			this.textBoxAddD1.Location = new System.Drawing.Point(45, 24);
			this.textBoxAddD1.Name = "textBoxAddD1";
			this.textBoxAddD1.Size = new System.Drawing.Size(27, 20);
			this.textBoxAddD1.TabIndex = 9;
			this.checkBoxChartAddD1.AutoSize = true;
			this.checkBoxChartAddD1.Location = new System.Drawing.Point(7, 26);
			this.checkBoxChartAddD1.Name = "checkBoxChartAddD1";
			this.checkBoxChartAddD1.Size = new System.Drawing.Size(32, 17);
			this.checkBoxChartAddD1.TabIndex = 8;
			this.checkBoxChartAddD1.Text = "+";
			this.checkBoxChartAddD1.UseVisualStyleBackColor = true;
			this.checkBoxChartCurrent.AutoSize = true;
			this.checkBoxChartCurrent.Location = new System.Drawing.Point(7, 3);
			this.checkBoxChartCurrent.Name = "checkBoxChartCurrent";
			this.checkBoxChartCurrent.Size = new System.Drawing.Size(71, 17);
			this.checkBoxChartCurrent.TabIndex = 7;
			this.checkBoxChartCurrent.Text = "Текущий";
			this.checkBoxChartCurrent.UseVisualStyleBackColor = true;
			this.label2.AutoSize = true;
			this.label2.Location = new System.Drawing.Point(8, 457);
			this.label2.Name = "label2";
			this.label2.Size = new System.Drawing.Size(69, 13);
			this.label2.TabIndex = 5;
			this.label2.Text = "Шаг сетки X";
			this.textBoxStepGridX.Location = new System.Drawing.Point(119, 454);
			this.textBoxStepGridX.Name = "textBoxStepGridX";
			this.textBoxStepGridX.ReadOnly = false;
			this.textBoxStepGridX.Size = new System.Drawing.Size(49, 20);
			this.textBoxStepGridX.TabIndex = 4;
			this.textBoxStepGridX.Text = "2500";
			this.textBoxStepGridY.Location = new System.Drawing.Point(119, 418);
			this.textBoxStepGridY.Name = "textBoxStepGridY";
			this.textBoxStepGridY.Size = new System.Drawing.Size(49, 20);
			this.textBoxStepGridY.TabIndex = 3;
			this.textBoxStepGridY.Text = "1000";
			this.label1.AutoSize = true;
			this.label1.Location = new System.Drawing.Point(8, 421);
			this.label1.Name = "label1";
			this.label1.Size = new System.Drawing.Size(69, 13);
			this.label1.TabIndex = 2;
			this.label1.Text = "Шаг сетки Y";
			this.groupBox1.Controls.Add(this.radioButtonVomma);
			this.groupBox1.Controls.Add(this.radioButtonTheta);
			this.groupBox1.Controls.Add(this.radioButtonVega);
			this.groupBox1.Controls.Add(this.radioButtonGamma);
			this.groupBox1.Controls.Add(this.radioButtonDelta);
			this.groupBox1.Controls.Add(this.radioButtonProfit);
			this.groupBox1.Location = new System.Drawing.Point(7, 149);
			this.groupBox1.Name = "groupBox1";
			this.groupBox1.Size = new System.Drawing.Size(161, 159);
			this.groupBox1.TabIndex = 1;
			this.groupBox1.TabStop = false;
			this.groupBox1.Text = "Чего рисуем";
			this.radioButtonVomma.AutoSize = true;
			this.radioButtonVomma.Location = new System.Drawing.Point(10, 134);
			this.radioButtonVomma.Name = "radioButtonVomma";
			this.radioButtonVomma.Size = new System.Drawing.Size(60, 17);
			this.radioButtonVomma.TabIndex = 0;
			this.radioButtonVomma.Text = "Вомма";
			this.radioButtonVomma.UseVisualStyleBackColor = true;
			this.radioButtonTheta.AutoSize = true;
			this.radioButtonTheta.Location = new System.Drawing.Point(10, 111);
			this.radioButtonTheta.Name = "radioButtonTheta";
			this.radioButtonTheta.Size = new System.Drawing.Size(49, 17);
			this.radioButtonTheta.TabIndex = 0;
			this.radioButtonTheta.Text = "Тета";
			this.radioButtonTheta.UseVisualStyleBackColor = true;
			this.radioButtonVega.AutoSize = true;
			this.radioButtonVega.Location = new System.Drawing.Point(10, 88);
			this.radioButtonVega.Name = "radioButtonVega";
			this.radioButtonVega.Size = new System.Drawing.Size(49, 17);
			this.radioButtonVega.TabIndex = 0;
			this.radioButtonVega.Text = "Вега";
			this.radioButtonVega.UseVisualStyleBackColor = true;
			this.radioButtonGamma.AutoSize = true;
			this.radioButtonGamma.Location = new System.Drawing.Point(10, 65);
			this.radioButtonGamma.Name = "radioButtonGamma";
			this.radioButtonGamma.Size = new System.Drawing.Size(59, 17);
			this.radioButtonGamma.TabIndex = 0;
			this.radioButtonGamma.Text = "Гамма";
			this.radioButtonGamma.UseVisualStyleBackColor = true;
			this.radioButtonDelta.AutoSize = true;
			this.radioButtonDelta.Location = new System.Drawing.Point(10, 42);
			this.radioButtonDelta.Name = "radioButtonDelta";
			this.radioButtonDelta.Size = new System.Drawing.Size(63, 17);
			this.radioButtonDelta.TabIndex = 0;
			this.radioButtonDelta.Text = "Дельта";
			this.radioButtonDelta.UseVisualStyleBackColor = true;
			this.radioButtonProfit.AutoSize = true;
			this.radioButtonProfit.Checked = true;
			this.radioButtonProfit.Location = new System.Drawing.Point(10, 19);
			this.radioButtonProfit.Name = "radioButtonProfit";
			this.radioButtonProfit.Size = new System.Drawing.Size(71, 17);
			this.radioButtonProfit.TabIndex = 0;
			this.radioButtonProfit.TabStop = true;
			this.radioButtonProfit.Text = "Прибыль";
			this.radioButtonProfit.UseVisualStyleBackColor = true;
			chartArea.AlignmentOrientation = System.Windows.Forms.DataVisualization.Charting.AreaAlignmentOrientations.All;
			chartArea.Name = "ChartArea1";
			this.chart1.ChartAreas.Add(chartArea);
			this.chart1.Dock = System.Windows.Forms.DockStyle.Fill;
			legend.Name = "Legend1";
			this.chart1.Legends.Add(legend);
			this.chart1.Location = new System.Drawing.Point(0, 0);
			this.chart1.Name = "chart1";
			this.chart1.Size = new System.Drawing.Size(1067, 552);
			this.chart1.TabIndex = 0;
			this.chart1.Text = "Диаграмма";
			this.chart1.MouseMove += new System.Windows.Forms.MouseEventHandler(chart1_MouseMove);
			base.AutoScaleDimensions = new System.Drawing.SizeF(6f, 13f);
			base.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
			base.ClientSize = new System.Drawing.Size(1261, 552);
			base.Controls.Add(this.splitContainerChart);
			base.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
			base.Load += new System.EventHandler(FormChart_Load);
			base.Shown += new System.EventHandler(FormChart_Shown);
			this.splitContainerChart.Panel1.ResumeLayout(false);
			this.splitContainerChart.Panel1.PerformLayout();
			this.splitContainerChart.Panel2.ResumeLayout(false);
			this.splitContainerChart.EndInit();
			this.splitContainerChart.ResumeLayout(false);
			this.groupBox2.ResumeLayout(false);
			this.groupBox2.PerformLayout();
			this.groupBox1.ResumeLayout(false);
			this.groupBox1.PerformLayout();
			this.chart1.EndInit();
			base.ResumeLayout(false);
		}
	}
}
