using System.Drawing;

namespace OptionFVV
{
	internal class ClassColorTheme
	{
		public static string ColorTheme = "";

		public static Color BackColor;

		public static Color HeadersColor;

		public static Color BackColorFore;

		public static Color BackColorPaleFore;

		public static Color HeadersColorFore;

		public static Color GridColor;

		public static Color ChartGridColor;

		public static Color TableRedColor;

		public static Color TableGreenColor;

		public static Color ChartCurrentColor;

		public static Color ChartAddD1Color;

		public static Color ChartAddD2Color;

		public static Color ChartExpirationColor;

		public static Color ChartCurrentColorComparison;

		public static Color ChartAddD1ColorComparison;

		public static Color ChartAddD2ColorComparison;

		public static Color ChartExpirationColorComparison;

		public static Color GlassDemandColor;

		public static Color GlassSentenceColor;

		public static Color SmileModelColor;

		public static void FillColorVariables(string iColorTheme)
		{
			switch (iColorTheme)
			{
			case "Ocean Dark":
				ColorTheme = iColorTheme;
				BackColor = Color.FromArgb(34, 50, 57);
				HeadersColor = Color.FromArgb(34, 50, 57);
				BackColorFore = Color.FromArgb(166, 184, 191);
				BackColorPaleFore = Color.FromArgb(47, 67, 76);
				HeadersColorFore = Color.FromArgb(0, 149, 159);
				GridColor = Color.FromArgb(57, 88, 103);
				ChartGridColor = Color.FromArgb(57, 88, 103);
				TableRedColor = Color.FromArgb(125, 97, 89);
				TableGreenColor = Color.FromArgb(92, 116, 65);
				ChartCurrentColor = Color.FromArgb(250, 250, 255);
				ChartAddD1Color = Color.FromArgb(110, 210, 255);
				ChartAddD2Color = Color.FromArgb(60, 120, 255);
				ChartExpirationColor = Color.FromArgb(250, 250, 255);
				ChartCurrentColorComparison = Color.FromArgb(10, 100, 10);
				ChartAddD1ColorComparison = Color.FromArgb(20, 200, 20);
				ChartAddD2ColorComparison = Color.FromArgb(40, 250, 40);
				ChartExpirationColorComparison = Color.FromArgb(92, 116, 65);
				GlassDemandColor = Color.FromArgb(92, 116, 65);
				GlassSentenceColor = Color.FromArgb(125, 97, 89);
				SmileModelColor = Color.FromArgb(251, 183, 53);
				break;
			default:
				ColorTheme = iColorTheme;
				BackColor = Color.Snow;
				HeadersColor = Color.LightGray;
				BackColorFore = Color.Black;
				HeadersColorFore = Color.Black;
				GridColor = Color.Black;
				ChartGridColor = Color.LightGray;
				TableRedColor = Color.LightPink;
				TableGreenColor = Color.LightGreen;
				ChartCurrentColor = Color.Blue;
				ChartAddD1Color = Color.LightBlue;
				ChartAddD2Color = Color.LightSkyBlue;
				ChartExpirationColor = Color.Red;
				ChartCurrentColorComparison = Color.FromArgb(10, 100, 10);
				ChartAddD1ColorComparison = Color.FromArgb(20, 200, 20);
				ChartAddD2ColorComparison = Color.FromArgb(40, 250, 40);
				ChartExpirationColorComparison = Color.Green;
				GlassDemandColor = Color.DarkGreen;
				GlassSentenceColor = Color.DarkRed;
				SmileModelColor = Color.FromArgb(250, 150, 20);
				break;
			case "Кофе с молоком":
				ColorTheme = iColorTheme;
				BackColor = Color.Beige;
				HeadersColor = Color.Peru;
				BackColorFore = Color.Black;
				BackColorPaleFore = Color.FromArgb(255, 180, 100);
				HeadersColorFore = Color.Black;
				GridColor = Color.Black;
				ChartGridColor = Color.LightGray;
				TableRedColor = Color.LightPink;
				TableGreenColor = Color.LightGreen;
				ChartCurrentColor = Color.FromArgb(90, 45, 20);
				ChartAddD1Color = Color.FromArgb(180, 95, 40);
				ChartAddD2Color = Color.FromArgb(255, 180, 100);
				ChartExpirationColor = Color.FromArgb(50, 25, 5);
				ChartCurrentColorComparison = Color.FromArgb(10, 100, 10);
				ChartAddD1ColorComparison = Color.FromArgb(20, 200, 20);
				ChartAddD2ColorComparison = Color.FromArgb(40, 250, 40);
				ChartExpirationColorComparison = Color.Green;
				GlassDemandColor = Color.DarkGreen;
				GlassSentenceColor = Color.DarkRed;
				SmileModelColor = Color.FromArgb(250, 150, 20);
				break;
			case "Небо с облаками":
				ColorTheme = iColorTheme;
				BackColor = Color.AliceBlue;
				HeadersColor = Color.SkyBlue;
				BackColorFore = Color.Black;
				BackColorPaleFore = Color.FromArgb(170, 220, 255);
				HeadersColorFore = Color.Black;
				GridColor = Color.Black;
				ChartGridColor = Color.LightGray;
				TableRedColor = Color.LightPink;
				TableGreenColor = Color.LightGreen;
				ChartCurrentColor = Color.FromArgb(20, 50, 255);
				ChartAddD1Color = Color.FromArgb(120, 170, 255);
				ChartAddD2Color = Color.FromArgb(170, 220, 255);
				ChartExpirationColor = Color.FromArgb(0, 0, 255);
				ChartCurrentColorComparison = Color.FromArgb(80, 80, 80);
				ChartAddD1ColorComparison = Color.FromArgb(170, 170, 170);
				ChartAddD2ColorComparison = Color.FromArgb(200, 200, 200);
				ChartExpirationColorComparison = Color.FromArgb(30, 30, 30);
				GlassDemandColor = Color.DarkGreen;
				GlassSentenceColor = Color.DarkRed;
				SmileModelColor = Color.FromArgb(250, 150, 20);
				break;
			case "Витек":
				ColorTheme = iColorTheme;
				BackColor = Color.WhiteSmoke;
				HeadersColor = Color.LightGray;
				BackColorFore = Color.Black;
				BackColorPaleFore = Color.FromArgb(200, 200, 200);
				HeadersColorFore = Color.Black;
				GridColor = Color.Black;
				ChartGridColor = Color.LightGray;
				TableRedColor = Color.LightPink;
				TableGreenColor = Color.LightGreen;
				ChartCurrentColor = Color.FromArgb(80, 80, 80);
				ChartAddD1Color = Color.FromArgb(170, 170, 170);
				ChartAddD2Color = Color.FromArgb(200, 200, 200);
				ChartExpirationColor = Color.FromArgb(30, 30, 30);
				ChartCurrentColorComparison = Color.FromArgb(40, 80, 255);
				ChartAddD1ColorComparison = Color.FromArgb(120, 170, 255);
				ChartAddD2ColorComparison = Color.FromArgb(170, 220, 255);
				ChartExpirationColorComparison = Color.FromArgb(0, 0, 200);
				GlassDemandColor = Color.DarkGreen;
				GlassSentenceColor = Color.DarkRed;
				SmileModelColor = Color.FromArgb(250, 150, 20);
				break;
			case "Угли с золой":
				ColorTheme = iColorTheme;
				BackColor = Color.FromArgb(10, 10, 10);
				HeadersColor = Color.FromArgb(50, 50, 50);
				BackColorFore = Color.WhiteSmoke;
				BackColorPaleFore = Color.FromArgb(80, 80, 80);
				HeadersColorFore = Color.OrangeRed;
				GridColor = Color.WhiteSmoke;
				ChartGridColor = Color.FromArgb(30, 30, 30);
				TableRedColor = Color.DarkRed;
				TableGreenColor = Color.DarkGreen;
				ChartCurrentColor = Color.FromArgb(240, 240, 240);
				ChartAddD1Color = Color.FromArgb(170, 170, 170);
				ChartAddD2Color = Color.FromArgb(80, 80, 80);
				ChartExpirationColor = Color.FromArgb(255, 255, 255);
				ChartCurrentColorComparison = Color.FromArgb(250, 0, 0);
				ChartAddD1ColorComparison = Color.FromArgb(150, 70, 70);
				ChartAddD2ColorComparison = Color.FromArgb(70, 30, 30);
				ChartExpirationColorComparison = Color.FromArgb(250, 70, 70);
				GlassDemandColor = Color.LightGreen;
				GlassSentenceColor = Color.LightPink;
				SmileModelColor = Color.FromArgb(250, 150, 20);
				break;
			case "Темный шоколад":
				ColorTheme = iColorTheme;
				BackColor = Color.FromArgb(30, 15, 5);
				HeadersColor = Color.FromArgb(80, 40, 12);
				BackColorFore = Color.Beige;
				BackColorPaleFore = Color.FromArgb(85, 42, 18);
				HeadersColorFore = Color.Beige;
				GridColor = Color.Beige;
				ChartGridColor = Color.FromArgb(50, 25, 8);
				TableRedColor = Color.DarkRed;
				TableGreenColor = Color.DarkGreen;
				ChartCurrentColor = Color.FromArgb(250, 150, 80);
				ChartAddD1Color = Color.FromArgb(170, 85, 35);
				ChartAddD2Color = Color.FromArgb(85, 42, 18);
				ChartExpirationColor = Color.FromArgb(250, 200, 150);
				ChartCurrentColorComparison = Color.FromArgb(10, 100, 10);
				ChartAddD1ColorComparison = Color.FromArgb(20, 200, 20);
				ChartAddD2ColorComparison = Color.FromArgb(40, 250, 40);
				ChartExpirationColorComparison = Color.Green;
				GlassDemandColor = Color.LightGreen;
				GlassSentenceColor = Color.LightPink;
				SmileModelColor = Color.FromArgb(250, 150, 20);
				break;
			}
		}
	}
}
