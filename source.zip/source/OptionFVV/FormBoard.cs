using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Windows.Forms;

namespace OptionFVV
{
	public class FormBoard : Form
	{
		public struct Board
		{
			public string paper_code;

			public DateTime expiration_date;

			public string base_asset;

			public double demand;

			public double sentence;

			public double last_price;

			public double strike;

			public string option_type;

			public double volatility;

			public double teoretical_price;

			public double step_price;

			public int decimal_points;
		}

		public struct BoardTotal
		{
			public string paper_code_call;

			public string option_type_call;

			public double theta_call;

			public double vega_call;

			public double gamma_call;

			public double delta_call;

			public double demand_call;

			public double sentence_call;

			public double last_price_call;

			public double teoretical_price_call;

			public double strike;

			public double volatility;

			public DateTime expiration_date;

			public string base_asset;

			public double step_price;

			public int decimal_points;

			public double teoretical_price_put;

			public double last_price_put;

			public double sentence_put;

			public double demand_put;

			public double delta_put;

			public double gamma_put;

			public double vega_put;

			public double theta_put;

			public string option_type_put;

			public string paper_code_put;
		}

		private string ThemeBoard;

		private ClassCalculationOptions result = new ClassCalculationOptions();

		private ClassDataDDE cDataDDE = new ClassDataDDE(false);

		private List<Board> BoardTableCall = new List<Board>();

		private Board BoardPaperCall = default(Board);

		private List<Board> BoardTablePut = new List<Board>();

		private Board BoardPaperPut = default(Board);

		private SortedList<double, BoardTotal> BoardTable = new SortedList<double, BoardTotal>();

		private BoardTotal BoardPaper = default(BoardTotal);

		private Board FuturePaper = default(Board);

		private IContainer components = null;

		private DataGridView dataGridViewBoard;

		private SplitContainer splitContainer1;

		private GroupBox groupBoxBoard;

		private ComboBox comboBoxQuantity;

		private Label label1;

		private ComboBox comboBox1;

		private GroupBox groupBoxInformation;

		private RichTextBox richTextBoxInformation;

		private SplitContainer splitContainer2;

		private Label label2;

		private ComboBox comboBoxThemeBoard;

		private ComboBox comboBoxExpirationDate;

		private Label label4;

		private ComboBox comboBoxBaseAsset;

		private Label label3;

		private GroupBox groupBoxFutures;

		private DataGridView dataGridViewFutures;

		private ContextMenuStrip contextMenuStripBoard;

		private ToolStripMenuItem добавитьВПортфельToolStripMenuItem;

		private ContextMenuStrip contextMenuStripFuture;

		private ToolStripMenuItem добавитьВПортфельToolStripMenuItem1;

		private ToolStripMenuItem ToolStripMenuItemGlass;

		private ToolStripMenuItem ToolStripMenuItemGlass1;

		public FormBoard()
		{
			InitializeComponent();
			BoardTableCall.Clear();
			BoardTablePut.Clear();
			BoardTable.Clear();
		}

		public void setBoardTheme(string str)
		{
			ThemeBoard = str;
		}

		private void Board_Load(object sender, EventArgs e)
		{
			ThemeBoard = ClassSettings.gBoardTheme;
			CallBackMy.callbackEventHandlerColorThemeFormBoard = PaintColorTheme;
			base.FormBorderStyle = FormBorderStyle.None;
			Dock = DockStyle.Fill;
			Create(ThemeBoard);
			comboBoxThemeBoard.Text = ClassSettings.gBoardTheme;
			dataGridViewBoard.EnableHeadersVisualStyles = false;
			dataGridViewFutures.EnableHeadersVisualStyles = false;
			FillcomboBoxQuantity(ClassSettings.gBoardQuantity);
			FillcomboBoxThemeBoard(ClassSettings.gBoardTheme);
			FillcomboBoxBaseAsset(ClassSettings.gBoardBaseAsset);
			FillcomboBoxExpirationDate(ClassSettings.gBoardBaseAsset, ClassSettings.gBoardExpirationDate);
			PaintColorTheme();
		}

		public void Tick()
		{
			richTextBoxInformation.Text = Trans2Quik.PATH_2_QUIK;
			if (ThemeBoard != comboBoxThemeBoard.Text)
			{
				ThemeBoard = comboBoxThemeBoard.Text;
				ClassSettings.gBoardTheme = ThemeBoard;
				Create(ThemeBoard);
			}
			double num1 = 0.0;
			double num2 = 0.0;
			double num3 = 0.0;
			double num4 = 0.0;
			double num5 = 0.0;
			double num6 = 0.0;
			double num7 = 0.0;
			double num8 = 0.0;
			double num9 = 0.0;
			bool flag1 = false;
			BoardTableCall.Clear();
			BoardTablePut.Clear();
			BoardTable.Clear();
			lock (ClassDataDDE.FuturesQuotesTable)
			{
				for (int index = 0; index < ClassDataDDE.FuturesQuotesTable.Count; index++)
				{
					if (Convert.ToString(comboBoxBaseAsset.Text) == ClassDataDDE.FuturesQuotesTable[index].paper_code)
					{
						num7 = ClassDataDDE.FuturesQuotesTable[index].last_price;
						FuturePaper.paper_code = ClassDataDDE.FuturesQuotesTable[index].paper_code;
						FuturePaper.expiration_date = ClassDataDDE.FuturesQuotesTable[index].expiration_date;
						FuturePaper.base_asset = ClassDataDDE.FuturesQuotesTable[index].base_asset;
						FuturePaper.demand = ClassDataDDE.FuturesQuotesTable[index].demand;
						FuturePaper.sentence = ClassDataDDE.FuturesQuotesTable[index].sentence;
						FuturePaper.last_price = ClassDataDDE.FuturesQuotesTable[index].last_price;
						FuturePaper.strike = ClassDataDDE.FuturesQuotesTable[index].strike;
						FuturePaper.option_type = ClassDataDDE.FuturesQuotesTable[index].option_type;
						FuturePaper.volatility = ClassDataDDE.FuturesQuotesTable[index].volatility;
						FuturePaper.teoretical_price = ClassDataDDE.FuturesQuotesTable[index].teoretical_price;
						FuturePaper.step_price = ClassDataDDE.FuturesQuotesTable[index].step_price;
						FuturePaper.decimal_points = ClassDataDDE.FuturesQuotesTable[index].decimal_points;
						flag1 = true;
						break;
					}
				}
			}
			if (flag1)
			{
				lock (ClassDataDDE.QuotesTable)
				{
					for (int i = 0; i < ClassDataDDE.QuotesTable.Count; i++)
					{
						DateTime result;
						if (!DateTime.TryParse(Convert.ToString(comboBoxExpirationDate.Text), out result))
						{
							richTextBoxInformation.Text = "Ошибка, в дате экспирации введена не дата";
							return;
						}
						if (!(Convert.ToString(comboBoxBaseAsset.Text) == ClassDataDDE.QuotesTable[i].base_asset) || !(result.Date == ClassDataDDE.QuotesTable[i].expiration_date.Date))
						{
							continue;
						}
						if (ClassDataDDE.QuotesTable[i].option_type == "Call")
						{
							if (BoardTableCall.Count > 0)
							{
								bool flag2 = false;
								for (int j = 0; j < BoardTableCall.Count; j++)
								{
									if (BoardTableCall[j].strike == ClassDataDDE.QuotesTable[i].strike)
									{
										BoardPaperCall.paper_code = ClassDataDDE.QuotesTable[i].paper_code;
										BoardPaperCall.expiration_date = ClassDataDDE.QuotesTable[i].expiration_date;
										BoardPaperCall.base_asset = ClassDataDDE.QuotesTable[i].base_asset;
										BoardPaperCall.demand = ClassDataDDE.QuotesTable[i].demand;
										BoardPaperCall.sentence = ClassDataDDE.QuotesTable[i].sentence;
										BoardPaperCall.last_price = ClassDataDDE.QuotesTable[i].last_price;
										BoardPaperCall.strike = ClassDataDDE.QuotesTable[i].strike;
										BoardPaperCall.option_type = ClassDataDDE.QuotesTable[i].option_type;
										BoardPaperCall.volatility = ClassDataDDE.QuotesTable[i].volatility;
										BoardPaperCall.teoretical_price = ClassDataDDE.QuotesTable[i].teoretical_price;
										BoardPaperCall.step_price = ClassDataDDE.QuotesTable[i].step_price;
										BoardPaperCall.decimal_points = ClassDataDDE.QuotesTable[i].decimal_points;
										BoardTableCall[j] = BoardPaperCall;
										flag2 = true;
										break;
									}
								}
								if (!flag2)
								{
									BoardPaperCall.paper_code = ClassDataDDE.QuotesTable[i].paper_code;
									BoardPaperCall.expiration_date = ClassDataDDE.QuotesTable[i].expiration_date;
									BoardPaperCall.base_asset = ClassDataDDE.QuotesTable[i].base_asset;
									BoardPaperCall.demand = ClassDataDDE.QuotesTable[i].demand;
									BoardPaperCall.sentence = ClassDataDDE.QuotesTable[i].sentence;
									BoardPaperCall.last_price = ClassDataDDE.QuotesTable[i].last_price;
									BoardPaperCall.strike = ClassDataDDE.QuotesTable[i].strike;
									BoardPaperCall.option_type = ClassDataDDE.QuotesTable[i].option_type;
									BoardPaperCall.volatility = ClassDataDDE.QuotesTable[i].volatility;
									BoardPaperCall.teoretical_price = ClassDataDDE.QuotesTable[i].teoretical_price;
									BoardPaperCall.step_price = ClassDataDDE.QuotesTable[i].step_price;
									BoardPaperCall.decimal_points = ClassDataDDE.QuotesTable[i].decimal_points;
									BoardTableCall.Add(BoardPaperCall);
									BoardPaperPut.paper_code = "";
									BoardPaperPut.expiration_date = ClassDataDDE.QuotesTable[i].expiration_date;
									BoardPaperPut.base_asset = ClassDataDDE.QuotesTable[i].base_asset;
									BoardPaperPut.demand = 0.0;
									BoardPaperPut.sentence = 0.0;
									BoardPaperPut.last_price = 0.0;
									BoardPaperPut.strike = ClassDataDDE.QuotesTable[i].strike;
									BoardPaperPut.option_type = "Put";
									BoardPaperPut.volatility = ClassDataDDE.QuotesTable[i].volatility;
									BoardPaperPut.teoretical_price = 0.0;
									BoardPaperPut.step_price = ClassDataDDE.QuotesTable[i].step_price;
									BoardPaperPut.decimal_points = ClassDataDDE.QuotesTable[i].decimal_points;
									BoardTablePut.Add(BoardPaperPut);
								}
							}
							else
							{
								BoardPaperCall.paper_code = ClassDataDDE.QuotesTable[i].paper_code;
								BoardPaperCall.expiration_date = ClassDataDDE.QuotesTable[i].expiration_date;
								BoardPaperCall.base_asset = ClassDataDDE.QuotesTable[i].base_asset;
								BoardPaperCall.demand = ClassDataDDE.QuotesTable[i].demand;
								BoardPaperCall.sentence = ClassDataDDE.QuotesTable[i].sentence;
								BoardPaperCall.last_price = ClassDataDDE.QuotesTable[i].last_price;
								BoardPaperCall.strike = ClassDataDDE.QuotesTable[i].strike;
								BoardPaperCall.option_type = ClassDataDDE.QuotesTable[i].option_type;
								BoardPaperCall.volatility = ClassDataDDE.QuotesTable[i].volatility;
								BoardPaperCall.teoretical_price = ClassDataDDE.QuotesTable[i].teoretical_price;
								BoardPaperCall.step_price = ClassDataDDE.QuotesTable[i].step_price;
								BoardPaperCall.decimal_points = ClassDataDDE.QuotesTable[i].decimal_points;
								BoardTableCall.Add(BoardPaperCall);
								BoardPaperPut.paper_code = "";
								BoardPaperPut.expiration_date = ClassDataDDE.QuotesTable[i].expiration_date;
								BoardPaperPut.base_asset = ClassDataDDE.QuotesTable[i].base_asset;
								BoardPaperPut.demand = 0.0;
								BoardPaperPut.sentence = 0.0;
								BoardPaperPut.last_price = 0.0;
								BoardPaperPut.strike = ClassDataDDE.QuotesTable[i].strike;
								BoardPaperPut.option_type = "Put";
								BoardPaperPut.volatility = ClassDataDDE.QuotesTable[i].volatility;
								BoardPaperPut.teoretical_price = 0.0;
								BoardPaperPut.step_price = ClassDataDDE.QuotesTable[i].step_price;
								BoardPaperPut.decimal_points = ClassDataDDE.QuotesTable[i].decimal_points;
								BoardTablePut.Add(BoardPaperPut);
							}
						}
						else
						{
							if (!(ClassDataDDE.QuotesTable[i].option_type == "Put"))
							{
								continue;
							}
							if (BoardTablePut.Count > 0)
							{
								bool flag3 = false;
								for (int k = 0; k < BoardTablePut.Count; k++)
								{
									if (BoardTablePut[k].strike == ClassDataDDE.QuotesTable[i].strike)
									{
										BoardPaperPut.paper_code = ClassDataDDE.QuotesTable[i].paper_code;
										BoardPaperPut.expiration_date = ClassDataDDE.QuotesTable[i].expiration_date;
										BoardPaperPut.base_asset = ClassDataDDE.QuotesTable[i].base_asset;
										BoardPaperPut.demand = ClassDataDDE.QuotesTable[i].demand;
										BoardPaperPut.sentence = ClassDataDDE.QuotesTable[i].sentence;
										BoardPaperPut.last_price = ClassDataDDE.QuotesTable[i].last_price;
										BoardPaperPut.strike = ClassDataDDE.QuotesTable[i].strike;
										BoardPaperPut.option_type = ClassDataDDE.QuotesTable[i].option_type;
										BoardPaperPut.volatility = ClassDataDDE.QuotesTable[i].volatility;
										BoardPaperPut.teoretical_price = ClassDataDDE.QuotesTable[i].teoretical_price;
										BoardPaperPut.step_price = ClassDataDDE.QuotesTable[i].step_price;
										BoardPaperPut.decimal_points = ClassDataDDE.QuotesTable[i].decimal_points;
										BoardTablePut[k] = BoardPaperPut;
										flag3 = true;
										break;
									}
								}
								if (!flag3)
								{
									BoardPaperCall.paper_code = "";
									BoardPaperCall.expiration_date = ClassDataDDE.QuotesTable[i].expiration_date;
									BoardPaperCall.base_asset = ClassDataDDE.QuotesTable[i].base_asset;
									BoardPaperCall.demand = 0.0;
									BoardPaperCall.sentence = 0.0;
									BoardPaperCall.last_price = 0.0;
									BoardPaperCall.strike = ClassDataDDE.QuotesTable[i].strike;
									BoardPaperCall.option_type = "Call";
									BoardPaperCall.volatility = ClassDataDDE.QuotesTable[i].volatility;
									BoardPaperCall.teoretical_price = 0.0;
									BoardPaperCall.step_price = ClassDataDDE.QuotesTable[i].step_price;
									BoardPaperCall.decimal_points = ClassDataDDE.QuotesTable[i].decimal_points;
									BoardTableCall.Add(BoardPaperCall);
									BoardPaperPut.paper_code = ClassDataDDE.QuotesTable[i].paper_code;
									BoardPaperPut.expiration_date = ClassDataDDE.QuotesTable[i].expiration_date;
									BoardPaperPut.base_asset = ClassDataDDE.QuotesTable[i].base_asset;
									BoardPaperPut.demand = ClassDataDDE.QuotesTable[i].demand;
									BoardPaperPut.sentence = ClassDataDDE.QuotesTable[i].sentence;
									BoardPaperPut.last_price = ClassDataDDE.QuotesTable[i].last_price;
									BoardPaperPut.strike = ClassDataDDE.QuotesTable[i].strike;
									BoardPaperPut.option_type = ClassDataDDE.QuotesTable[i].option_type;
									BoardPaperPut.volatility = ClassDataDDE.QuotesTable[i].volatility;
									BoardPaperPut.teoretical_price = ClassDataDDE.QuotesTable[i].teoretical_price;
									BoardPaperPut.step_price = ClassDataDDE.QuotesTable[i].step_price;
									BoardPaperPut.decimal_points = ClassDataDDE.QuotesTable[i].decimal_points;
									BoardTablePut.Add(BoardPaperPut);
								}
							}
							else
							{
								BoardPaperCall.paper_code = "";
								BoardPaperCall.expiration_date = ClassDataDDE.QuotesTable[i].expiration_date;
								BoardPaperCall.base_asset = ClassDataDDE.QuotesTable[i].base_asset;
								BoardPaperCall.demand = 0.0;
								BoardPaperCall.sentence = 0.0;
								BoardPaperCall.last_price = 0.0;
								BoardPaperCall.strike = ClassDataDDE.QuotesTable[i].strike;
								BoardPaperCall.option_type = "Call";
								BoardPaperCall.volatility = ClassDataDDE.QuotesTable[i].volatility;
								BoardPaperCall.teoretical_price = 0.0;
								BoardPaperCall.step_price = ClassDataDDE.QuotesTable[i].step_price;
								BoardPaperCall.decimal_points = ClassDataDDE.QuotesTable[i].decimal_points;
								BoardTableCall.Add(BoardPaperCall);
								BoardPaperPut.paper_code = ClassDataDDE.QuotesTable[i].paper_code;
								BoardPaperPut.expiration_date = ClassDataDDE.QuotesTable[i].expiration_date;
								BoardPaperPut.base_asset = ClassDataDDE.QuotesTable[i].base_asset;
								BoardPaperPut.demand = ClassDataDDE.QuotesTable[i].demand;
								BoardPaperPut.sentence = ClassDataDDE.QuotesTable[i].sentence;
								BoardPaperPut.last_price = ClassDataDDE.QuotesTable[i].last_price;
								BoardPaperPut.strike = ClassDataDDE.QuotesTable[i].strike;
								BoardPaperPut.option_type = ClassDataDDE.QuotesTable[i].option_type;
								BoardPaperPut.volatility = ClassDataDDE.QuotesTable[i].volatility;
								BoardPaperPut.teoretical_price = ClassDataDDE.QuotesTable[i].teoretical_price;
								BoardPaperPut.step_price = ClassDataDDE.QuotesTable[i].step_price;
								BoardPaperPut.decimal_points = ClassDataDDE.QuotesTable[i].decimal_points;
								BoardTablePut.Add(BoardPaperPut);
							}
						}
					}
				}
				if (BoardTableCall.Count > 0)
				{
					for (int l = 0; l < BoardTableCall.Count; l++)
					{
						BoardPaper.paper_code_call = BoardTableCall[l].paper_code;
						BoardPaper.option_type_call = BoardTableCall[l].option_type;
						int num10 = 1;
						this.result.TypeO = "CALL";
						this.result.Strike = BoardTableCall[l].strike;
						this.result.DateExp = BoardTableCall[l].expiration_date;
						this.result.DateCurrent = DateTime.Now;
						this.result.LastF = num7;
						this.result.Q = num10;
						this.result.VolaO = BoardTableCall[l].volatility;
						if (this.result.CalculationOpt())
						{
							num1 = Math.Round(this.result.calcTheoPrice, BoardTableCall[l].decimal_points);
							num2 = Math.Round(this.result.calcDelta, 2);
							num3 = Math.Round(this.result.calcGamma, 6);
							num4 = Math.Round(this.result.calcVega, 2);
							num5 = Math.Round(this.result.calcTheta, 2);
							num6 = Math.Round(this.result.calcVomma, 4);
						}
						else
						{
							richTextBoxInformation.Text = "Ошибка рассчета греков " + this.result.calcMessageError;
						}
						BoardPaper.theta_call = num5;
						BoardPaper.vega_call = num4;
						BoardPaper.gamma_call = num3;
						BoardPaper.delta_call = num2;
						BoardPaper.demand_call = BoardTableCall[l].demand;
						BoardPaper.sentence_call = BoardTableCall[l].sentence;
						BoardPaper.last_price_call = BoardTableCall[l].last_price;
						BoardPaper.teoretical_price_call = BoardTableCall[l].teoretical_price;
						BoardPaper.strike = BoardTableCall[l].strike;
						BoardPaper.volatility = BoardTableCall[l].volatility;
						BoardPaper.expiration_date = BoardTableCall[l].expiration_date;
						BoardPaper.base_asset = BoardTableCall[l].base_asset;
						BoardPaper.step_price = BoardTableCall[l].step_price;
						BoardPaper.decimal_points = BoardTableCall[l].decimal_points;
						BoardPaper.teoretical_price_put = BoardTablePut[l].teoretical_price;
						BoardPaper.last_price_put = BoardTablePut[l].last_price;
						BoardPaper.sentence_put = BoardTablePut[l].sentence;
						BoardPaper.demand_put = BoardTablePut[l].demand;
						int num11 = 1;
						this.result.TypeO = "PUT";
						this.result.Strike = BoardTableCall[l].strike;
						this.result.DateExp = BoardTableCall[l].expiration_date;
						this.result.DateCurrent = DateTime.Now;
						this.result.LastF = num7;
						this.result.Q = num11;
						this.result.VolaO = BoardTableCall[l].volatility;
						if (this.result.CalculationOpt())
						{
							num1 = Math.Round(this.result.calcTheoPrice, BoardTableCall[l].decimal_points);
							num2 = Math.Round(this.result.calcDelta, 2);
							num3 = Math.Round(this.result.calcGamma, 6);
							num4 = Math.Round(this.result.calcVega, 2);
							num5 = Math.Round(this.result.calcTheta, 2);
							num6 = Math.Round(this.result.calcVomma, 4);
						}
						else
						{
							richTextBoxInformation.Text = "Ошибка рассчета греков " + this.result.calcMessageError;
						}
						BoardPaper.delta_put = num2;
						BoardPaper.gamma_put = num3;
						BoardPaper.vega_put = num4;
						BoardPaper.theta_put = num5;
						BoardPaper.option_type_put = BoardTablePut[l].option_type;
						BoardPaper.paper_code_put = BoardTablePut[l].paper_code;
						try
						{
							BoardTable.Add(BoardPaper.strike, BoardPaper);
						}
						catch (Exception)
						{
						}
					}
				}
				else
				{
					richTextBoxInformation.Text = "Таблицу нет возможности заполнить, проверте дату экспирации.";
				}
				double iCentralStrike = 0.0;
				int num12 = -1;
				double num13 = -1.0;
				num8 = 0.0;
				num9 = 0.0;
				for (int m = 0; m < BoardTable.Count; m++)
				{
					BoardPaper = BoardTable.Values[m];
					if (num13 == -1.0)
					{
						iCentralStrike = BoardPaper.strike;
						num13 = Math.Abs(num7 - iCentralStrike);
						num12 = m;
					}
					else if (num13 > Math.Abs(num7 - BoardPaper.strike))
					{
						iCentralStrike = BoardPaper.strike;
						num13 = Math.Abs(num7 - iCentralStrike);
						num12 = m;
					}
				}
				if (BoardTable.Count > 0)
				{
					double strike1;
					if (num12 >= Convert.ToInt32(comboBoxQuantity.Text))
					{
						BoardPaper = BoardTable.Values[num12 - Convert.ToInt32(comboBoxQuantity.Text)];
						strike1 = BoardPaper.strike;
					}
					else
					{
						BoardPaper = BoardTable.Values[0];
						strike1 = BoardPaper.strike;
					}
					double strike2;
					if (num12 + Convert.ToInt32(comboBoxQuantity.Text) < BoardTable.Count)
					{
						BoardPaper = BoardTable.Values[num12 + Convert.ToInt32(comboBoxQuantity.Text)];
						strike2 = BoardPaper.strike;
					}
					else
					{
						BoardPaper = BoardTable.Values[BoardTable.Count - 1];
						strike2 = BoardPaper.strike;
					}
					for (int n = 0; n < BoardTable.Count; n++)
					{
						BoardPaper = BoardTable.Values[n];
						if (BoardPaper.strike < strike1 || BoardPaper.strike > strike2)
						{
							BoardTable.RemoveAt(n);
							n--;
						}
					}
				}
				if (comboBoxThemeBoard.Text == "Classic")
				{
					FillBoard("Classic", iCentralStrike);
				}
				else if (comboBoxThemeBoard.Text == "Viktor")
				{
					FillBoard("Viktor", iCentralStrike);
				}
				else
				{
					FillBoard("Classic", iCentralStrike);
				}
			}
			else
			{
				richTextBoxInformation.Text = "В ДДЕ сервере нет фьючерса " + Convert.ToString(comboBoxBaseAsset.Text);
			}
		}

		public void Create(string iThemeBoard)
		{
			dataGridViewBoard.Columns.Clear();
			if (!(iThemeBoard == "Classic"))
			{
				if (iThemeBoard == "Viktor")
				{
					DataGridViewTextBoxColumn viewTextBoxColumn1 = new DataGridViewTextBoxColumn();
					viewTextBoxColumn1.HeaderText = "Код";
					viewTextBoxColumn1.Name = "PaperCodePut";
					viewTextBoxColumn1.AutoSizeMode = DataGridViewAutoSizeColumnMode.DisplayedCells;
					viewTextBoxColumn1.DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;
					viewTextBoxColumn1.DefaultCellStyle.BackColor = ClassColorTheme.TableRedColor;
					DataGridViewTextBoxColumn viewTextBoxColumn2 = new DataGridViewTextBoxColumn();
					viewTextBoxColumn2.HeaderText = "Тета";
					viewTextBoxColumn2.Name = "ThetaPut";
					viewTextBoxColumn2.AutoSizeMode = DataGridViewAutoSizeColumnMode.DisplayedCells;
					viewTextBoxColumn2.DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;
					viewTextBoxColumn2.DefaultCellStyle.BackColor = ClassColorTheme.TableRedColor;
					DataGridViewTextBoxColumn viewTextBoxColumn3 = new DataGridViewTextBoxColumn();
					viewTextBoxColumn3.HeaderText = "Вега";
					viewTextBoxColumn3.Name = "VegaPut";
					viewTextBoxColumn3.AutoSizeMode = DataGridViewAutoSizeColumnMode.DisplayedCells;
					viewTextBoxColumn3.DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;
					viewTextBoxColumn3.DefaultCellStyle.BackColor = ClassColorTheme.TableRedColor;
					DataGridViewTextBoxColumn viewTextBoxColumn4 = new DataGridViewTextBoxColumn();
					viewTextBoxColumn4.HeaderText = "Гамма";
					viewTextBoxColumn4.Name = "GammaPut";
					viewTextBoxColumn4.AutoSizeMode = DataGridViewAutoSizeColumnMode.DisplayedCells;
					viewTextBoxColumn4.DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;
					viewTextBoxColumn4.DefaultCellStyle.BackColor = ClassColorTheme.TableRedColor;
					DataGridViewTextBoxColumn viewTextBoxColumn5 = new DataGridViewTextBoxColumn();
					viewTextBoxColumn5.HeaderText = "Дельта";
					viewTextBoxColumn5.Name = "DeltaPut";
					viewTextBoxColumn5.AutoSizeMode = DataGridViewAutoSizeColumnMode.DisplayedCells;
					viewTextBoxColumn5.DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;
					viewTextBoxColumn5.DefaultCellStyle.BackColor = ClassColorTheme.TableRedColor;
					DataGridViewTextBoxColumn viewTextBoxColumn6 = new DataGridViewTextBoxColumn();
					viewTextBoxColumn6.HeaderText = "Теор. цена";
					viewTextBoxColumn6.Name = "TheoPut";
					viewTextBoxColumn6.AutoSizeMode = DataGridViewAutoSizeColumnMode.DisplayedCells;
					viewTextBoxColumn6.DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;
					viewTextBoxColumn6.DefaultCellStyle.BackColor = ClassColorTheme.TableRedColor;
					DataGridViewTextBoxColumn viewTextBoxColumn7 = new DataGridViewTextBoxColumn();
					viewTextBoxColumn7.HeaderText = "Страйк";
					viewTextBoxColumn7.Name = "Strike";
					viewTextBoxColumn7.AutoSizeMode = DataGridViewAutoSizeColumnMode.DisplayedCells;
					viewTextBoxColumn7.DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;
					viewTextBoxColumn7.DefaultCellStyle.BackColor = ClassColorTheme.BackColor;
					DataGridViewTextBoxColumn viewTextBoxColumn8 = new DataGridViewTextBoxColumn();
					viewTextBoxColumn8.HeaderText = "Вола.";
					viewTextBoxColumn8.Name = "Vola";
					viewTextBoxColumn8.AutoSizeMode = DataGridViewAutoSizeColumnMode.DisplayedCells;
					viewTextBoxColumn8.DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;
					viewTextBoxColumn8.DefaultCellStyle.BackColor = ClassColorTheme.BackColor;
					DataGridViewTextBoxColumn viewTextBoxColumn9 = new DataGridViewTextBoxColumn();
					viewTextBoxColumn9.HeaderText = "Теор. цена";
					viewTextBoxColumn9.Name = "TheoCall";
					viewTextBoxColumn9.AutoSizeMode = DataGridViewAutoSizeColumnMode.DisplayedCells;
					viewTextBoxColumn9.DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;
					viewTextBoxColumn9.DefaultCellStyle.BackColor = ClassColorTheme.TableGreenColor;
					DataGridViewTextBoxColumn viewTextBoxColumn10 = new DataGridViewTextBoxColumn();
					viewTextBoxColumn10.HeaderText = "Дельта";
					viewTextBoxColumn10.Name = "DeltaCall";
					viewTextBoxColumn10.AutoSizeMode = DataGridViewAutoSizeColumnMode.DisplayedCells;
					viewTextBoxColumn10.DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;
					viewTextBoxColumn10.DefaultCellStyle.BackColor = ClassColorTheme.TableGreenColor;
					DataGridViewTextBoxColumn viewTextBoxColumn11 = new DataGridViewTextBoxColumn();
					viewTextBoxColumn11.HeaderText = "Гамма";
					viewTextBoxColumn11.Name = "GammaCall";
					viewTextBoxColumn11.AutoSizeMode = DataGridViewAutoSizeColumnMode.DisplayedCells;
					viewTextBoxColumn11.DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;
					viewTextBoxColumn11.DefaultCellStyle.BackColor = ClassColorTheme.TableGreenColor;
					DataGridViewTextBoxColumn viewTextBoxColumn12 = new DataGridViewTextBoxColumn();
					viewTextBoxColumn12.HeaderText = "Вега";
					viewTextBoxColumn12.Name = "VegaCall";
					viewTextBoxColumn12.AutoSizeMode = DataGridViewAutoSizeColumnMode.DisplayedCells;
					viewTextBoxColumn12.DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;
					viewTextBoxColumn12.DefaultCellStyle.BackColor = ClassColorTheme.TableGreenColor;
					DataGridViewTextBoxColumn viewTextBoxColumn13 = new DataGridViewTextBoxColumn();
					viewTextBoxColumn13.HeaderText = "Тета";
					viewTextBoxColumn13.Name = "ThetaCall";
					viewTextBoxColumn13.AutoSizeMode = DataGridViewAutoSizeColumnMode.DisplayedCells;
					viewTextBoxColumn13.DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;
					viewTextBoxColumn13.DefaultCellStyle.BackColor = ClassColorTheme.TableGreenColor;
					DataGridViewTextBoxColumn viewTextBoxColumn14 = new DataGridViewTextBoxColumn();
					viewTextBoxColumn14.HeaderText = "Код";
					viewTextBoxColumn14.Name = "PaperCodeCall";
					viewTextBoxColumn14.AutoSizeMode = DataGridViewAutoSizeColumnMode.DisplayedCells;
					viewTextBoxColumn14.DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;
					viewTextBoxColumn14.DefaultCellStyle.BackColor = ClassColorTheme.TableGreenColor;
					dataGridViewBoard.Columns.Add(viewTextBoxColumn1);
					dataGridViewBoard.Columns.Add(viewTextBoxColumn2);
					dataGridViewBoard.Columns.Add(viewTextBoxColumn3);
					dataGridViewBoard.Columns.Add(viewTextBoxColumn4);
					dataGridViewBoard.Columns.Add(viewTextBoxColumn5);
					dataGridViewBoard.Columns.Add(viewTextBoxColumn6);
					dataGridViewBoard.Columns.Add(viewTextBoxColumn7);
					dataGridViewBoard.Columns.Add(viewTextBoxColumn8);
					dataGridViewBoard.Columns.Add(viewTextBoxColumn9);
					dataGridViewBoard.Columns.Add(viewTextBoxColumn10);
					dataGridViewBoard.Columns.Add(viewTextBoxColumn11);
					dataGridViewBoard.Columns.Add(viewTextBoxColumn12);
					dataGridViewBoard.Columns.Add(viewTextBoxColumn13);
					dataGridViewBoard.Columns.Add(viewTextBoxColumn14);
					viewTextBoxColumn1.SortMode = DataGridViewColumnSortMode.NotSortable;
					viewTextBoxColumn2.SortMode = DataGridViewColumnSortMode.NotSortable;
					viewTextBoxColumn3.SortMode = DataGridViewColumnSortMode.NotSortable;
					viewTextBoxColumn4.SortMode = DataGridViewColumnSortMode.NotSortable;
					viewTextBoxColumn5.SortMode = DataGridViewColumnSortMode.NotSortable;
					viewTextBoxColumn6.SortMode = DataGridViewColumnSortMode.NotSortable;
					viewTextBoxColumn7.SortMode = DataGridViewColumnSortMode.NotSortable;
					viewTextBoxColumn8.SortMode = DataGridViewColumnSortMode.NotSortable;
					viewTextBoxColumn9.SortMode = DataGridViewColumnSortMode.NotSortable;
					viewTextBoxColumn10.SortMode = DataGridViewColumnSortMode.NotSortable;
					viewTextBoxColumn11.SortMode = DataGridViewColumnSortMode.NotSortable;
					viewTextBoxColumn12.SortMode = DataGridViewColumnSortMode.NotSortable;
					viewTextBoxColumn13.SortMode = DataGridViewColumnSortMode.NotSortable;
					viewTextBoxColumn14.SortMode = DataGridViewColumnSortMode.NotSortable;
					dataGridViewBoard.RowHeadersVisible = false;
					dataGridViewBoard.ColumnHeadersDefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;
					viewTextBoxColumn7.AutoSizeMode = DataGridViewAutoSizeColumnMode.Fill;
					viewTextBoxColumn7.MinimumWidth = 50;
				}
				else
				{
					DataGridViewTextBoxColumn viewTextBoxColumn15 = new DataGridViewTextBoxColumn();
					viewTextBoxColumn15.HeaderText = "Тета";
					viewTextBoxColumn15.Name = "ThetaCall";
					viewTextBoxColumn15.AutoSizeMode = DataGridViewAutoSizeColumnMode.DisplayedCells;
					viewTextBoxColumn15.DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;
					viewTextBoxColumn15.DefaultCellStyle.BackColor = ClassColorTheme.TableGreenColor;
					DataGridViewTextBoxColumn viewTextBoxColumn16 = new DataGridViewTextBoxColumn();
					viewTextBoxColumn16.HeaderText = "Вега";
					viewTextBoxColumn16.Name = "VegaCall";
					viewTextBoxColumn16.AutoSizeMode = DataGridViewAutoSizeColumnMode.DisplayedCells;
					viewTextBoxColumn16.DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;
					viewTextBoxColumn16.DefaultCellStyle.BackColor = ClassColorTheme.TableGreenColor;
					DataGridViewTextBoxColumn viewTextBoxColumn17 = new DataGridViewTextBoxColumn();
					viewTextBoxColumn17.HeaderText = "Гамма";
					viewTextBoxColumn17.Name = "GammaCall";
					viewTextBoxColumn17.AutoSizeMode = DataGridViewAutoSizeColumnMode.DisplayedCells;
					viewTextBoxColumn17.DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;
					viewTextBoxColumn17.DefaultCellStyle.BackColor = ClassColorTheme.TableGreenColor;
					DataGridViewTextBoxColumn viewTextBoxColumn18 = new DataGridViewTextBoxColumn();
					viewTextBoxColumn18.HeaderText = "Дельта";
					viewTextBoxColumn18.Name = "DeltaCall";
					viewTextBoxColumn18.AutoSizeMode = DataGridViewAutoSizeColumnMode.DisplayedCells;
					viewTextBoxColumn18.DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;
					viewTextBoxColumn18.DefaultCellStyle.BackColor = ClassColorTheme.TableGreenColor;
					DataGridViewTextBoxColumn viewTextBoxColumn19 = new DataGridViewTextBoxColumn();
					viewTextBoxColumn19.HeaderText = "Теор. цена";
					viewTextBoxColumn19.Name = "TheoCall";
					viewTextBoxColumn19.AutoSizeMode = DataGridViewAutoSizeColumnMode.DisplayedCells;
					viewTextBoxColumn19.DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;
					viewTextBoxColumn19.DefaultCellStyle.BackColor = ClassColorTheme.TableGreenColor;
					DataGridViewTextBoxColumn viewTextBoxColumn20 = new DataGridViewTextBoxColumn();
					viewTextBoxColumn20.HeaderText = "Страйк";
					viewTextBoxColumn20.Name = "Strike";
					viewTextBoxColumn20.AutoSizeMode = DataGridViewAutoSizeColumnMode.DisplayedCells;
					viewTextBoxColumn20.DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;
					viewTextBoxColumn20.DefaultCellStyle.BackColor = ClassColorTheme.BackColor;
					DataGridViewTextBoxColumn viewTextBoxColumn21 = new DataGridViewTextBoxColumn();
					viewTextBoxColumn21.HeaderText = "Вола.";
					viewTextBoxColumn21.Name = "Vola";
					viewTextBoxColumn21.AutoSizeMode = DataGridViewAutoSizeColumnMode.DisplayedCells;
					viewTextBoxColumn21.DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;
					viewTextBoxColumn21.DefaultCellStyle.BackColor = ClassColorTheme.BackColor;
					DataGridViewTextBoxColumn viewTextBoxColumn22 = new DataGridViewTextBoxColumn();
					viewTextBoxColumn22.HeaderText = "Теор. цена";
					viewTextBoxColumn22.Name = "TheoPut";
					viewTextBoxColumn22.AutoSizeMode = DataGridViewAutoSizeColumnMode.DisplayedCells;
					viewTextBoxColumn22.DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;
					viewTextBoxColumn22.DefaultCellStyle.BackColor = ClassColorTheme.TableRedColor;
					DataGridViewTextBoxColumn viewTextBoxColumn23 = new DataGridViewTextBoxColumn();
					viewTextBoxColumn23.HeaderText = "Дельта";
					viewTextBoxColumn23.Name = "DeltaPut";
					viewTextBoxColumn23.AutoSizeMode = DataGridViewAutoSizeColumnMode.DisplayedCells;
					viewTextBoxColumn23.DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;
					viewTextBoxColumn23.DefaultCellStyle.BackColor = ClassColorTheme.TableRedColor;
					DataGridViewTextBoxColumn viewTextBoxColumn24 = new DataGridViewTextBoxColumn();
					viewTextBoxColumn24.HeaderText = "Гамма";
					viewTextBoxColumn24.Name = "GammaPut";
					viewTextBoxColumn24.AutoSizeMode = DataGridViewAutoSizeColumnMode.DisplayedCells;
					viewTextBoxColumn24.DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;
					viewTextBoxColumn24.DefaultCellStyle.BackColor = ClassColorTheme.TableRedColor;
					DataGridViewTextBoxColumn viewTextBoxColumn25 = new DataGridViewTextBoxColumn();
					viewTextBoxColumn25.HeaderText = "Вега";
					viewTextBoxColumn25.Name = "VegaPut";
					viewTextBoxColumn25.AutoSizeMode = DataGridViewAutoSizeColumnMode.DisplayedCells;
					viewTextBoxColumn25.DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;
					viewTextBoxColumn25.DefaultCellStyle.BackColor = ClassColorTheme.TableRedColor;
					DataGridViewTextBoxColumn viewTextBoxColumn26 = new DataGridViewTextBoxColumn();
					viewTextBoxColumn26.HeaderText = "Тета";
					viewTextBoxColumn26.Name = "ThetaPut";
					viewTextBoxColumn26.AutoSizeMode = DataGridViewAutoSizeColumnMode.DisplayedCells;
					viewTextBoxColumn26.DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;
					viewTextBoxColumn26.DefaultCellStyle.BackColor = ClassColorTheme.TableRedColor;
					dataGridViewBoard.Columns.Add(viewTextBoxColumn15);
					dataGridViewBoard.Columns.Add(viewTextBoxColumn16);
					dataGridViewBoard.Columns.Add(viewTextBoxColumn17);
					dataGridViewBoard.Columns.Add(viewTextBoxColumn18);
					dataGridViewBoard.Columns.Add(viewTextBoxColumn19);
					dataGridViewBoard.Columns.Add(viewTextBoxColumn20);
					dataGridViewBoard.Columns.Add(viewTextBoxColumn21);
					dataGridViewBoard.Columns.Add(viewTextBoxColumn22);
					dataGridViewBoard.Columns.Add(viewTextBoxColumn23);
					dataGridViewBoard.Columns.Add(viewTextBoxColumn24);
					dataGridViewBoard.Columns.Add(viewTextBoxColumn25);
					dataGridViewBoard.Columns.Add(viewTextBoxColumn26);
					dataGridViewBoard.RowHeadersVisible = false;
					dataGridViewBoard.ColumnHeadersDefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;
					viewTextBoxColumn20.AutoSizeMode = DataGridViewAutoSizeColumnMode.Fill;
					viewTextBoxColumn20.MinimumWidth = 50;
				}
			}
			else
			{
				DataGridViewTextBoxColumn viewTextBoxColumn27 = new DataGridViewTextBoxColumn();
				viewTextBoxColumn27.HeaderText = "Тета";
				viewTextBoxColumn27.Name = "ThetaCall";
				viewTextBoxColumn27.AutoSizeMode = DataGridViewAutoSizeColumnMode.DisplayedCells;
				viewTextBoxColumn27.DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;
				viewTextBoxColumn27.DefaultCellStyle.BackColor = ClassColorTheme.TableGreenColor;
				DataGridViewTextBoxColumn viewTextBoxColumn28 = new DataGridViewTextBoxColumn();
				viewTextBoxColumn28.HeaderText = "Вега";
				viewTextBoxColumn28.Name = "VegaCall";
				viewTextBoxColumn28.AutoSizeMode = DataGridViewAutoSizeColumnMode.DisplayedCells;
				viewTextBoxColumn28.DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;
				viewTextBoxColumn28.DefaultCellStyle.BackColor = ClassColorTheme.TableGreenColor;
				DataGridViewTextBoxColumn viewTextBoxColumn29 = new DataGridViewTextBoxColumn();
				viewTextBoxColumn29.HeaderText = "Гамма";
				viewTextBoxColumn29.Name = "GammaCall";
				viewTextBoxColumn29.AutoSizeMode = DataGridViewAutoSizeColumnMode.DisplayedCells;
				viewTextBoxColumn29.DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;
				viewTextBoxColumn29.DefaultCellStyle.BackColor = ClassColorTheme.TableGreenColor;
				DataGridViewTextBoxColumn viewTextBoxColumn30 = new DataGridViewTextBoxColumn();
				viewTextBoxColumn30.HeaderText = "Дельта";
				viewTextBoxColumn30.Name = "DeltaCall";
				viewTextBoxColumn30.AutoSizeMode = DataGridViewAutoSizeColumnMode.DisplayedCells;
				viewTextBoxColumn30.DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;
				viewTextBoxColumn30.DefaultCellStyle.BackColor = ClassColorTheme.TableGreenColor;
				DataGridViewTextBoxColumn viewTextBoxColumn5_1 = new DataGridViewTextBoxColumn();
				viewTextBoxColumn5_1.HeaderText = "Посл. цена";
				viewTextBoxColumn5_1.Name = "LastPriceCall";
				viewTextBoxColumn5_1.AutoSizeMode = DataGridViewAutoSizeColumnMode.DisplayedCells;
				viewTextBoxColumn5_1.DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;
				viewTextBoxColumn5_1.DefaultCellStyle.BackColor = ClassColorTheme.TableGreenColor;
				DataGridViewTextBoxColumn viewTextBoxColumn5_2 = new DataGridViewTextBoxColumn();
				viewTextBoxColumn5_2.HeaderText = "Спрос";
				viewTextBoxColumn5_2.Name = "BidCall";
				viewTextBoxColumn5_2.AutoSizeMode = DataGridViewAutoSizeColumnMode.DisplayedCells;
				viewTextBoxColumn5_2.DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;
				viewTextBoxColumn5_2.DefaultCellStyle.BackColor = ClassColorTheme.TableGreenColor;
				DataGridViewTextBoxColumn viewTextBoxColumn5_3 = new DataGridViewTextBoxColumn();
				viewTextBoxColumn5_3.HeaderText = "Предл";
				viewTextBoxColumn5_3.Name = "AskCall";
				viewTextBoxColumn5_3.AutoSizeMode = DataGridViewAutoSizeColumnMode.DisplayedCells;
				viewTextBoxColumn5_3.DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;
				viewTextBoxColumn5_3.DefaultCellStyle.BackColor = ClassColorTheme.TableGreenColor;
				DataGridViewTextBoxColumn viewTextBoxColumn31 = new DataGridViewTextBoxColumn();
				viewTextBoxColumn31.HeaderText = "Теор. цена";
				viewTextBoxColumn31.Name = "TheoCall";
				viewTextBoxColumn31.AutoSizeMode = DataGridViewAutoSizeColumnMode.DisplayedCells;
				viewTextBoxColumn31.DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;
				viewTextBoxColumn31.DefaultCellStyle.BackColor = ClassColorTheme.TableGreenColor;
				DataGridViewTextBoxColumn viewTextBoxColumn32 = new DataGridViewTextBoxColumn();
				viewTextBoxColumn32.HeaderText = "Страйк";
				viewTextBoxColumn32.Name = "Strike";
				viewTextBoxColumn32.AutoSizeMode = DataGridViewAutoSizeColumnMode.DisplayedCells;
				viewTextBoxColumn32.DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;
				viewTextBoxColumn32.DefaultCellStyle.BackColor = ClassColorTheme.BackColor;
				DataGridViewTextBoxColumn viewTextBoxColumn33 = new DataGridViewTextBoxColumn();
				viewTextBoxColumn33.HeaderText = "Вола.";
				viewTextBoxColumn33.Name = "Vola";
				viewTextBoxColumn33.AutoSizeMode = DataGridViewAutoSizeColumnMode.DisplayedCells;
				viewTextBoxColumn33.DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;
				viewTextBoxColumn33.DefaultCellStyle.BackColor = ClassColorTheme.BackColor;
				DataGridViewTextBoxColumn viewTextBoxColumn34 = new DataGridViewTextBoxColumn();
				viewTextBoxColumn34.HeaderText = "Теор. цена";
				viewTextBoxColumn34.Name = "TheoPut";
				viewTextBoxColumn34.AutoSizeMode = DataGridViewAutoSizeColumnMode.DisplayedCells;
				viewTextBoxColumn34.DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;
				viewTextBoxColumn34.DefaultCellStyle.BackColor = ClassColorTheme.TableRedColor;
				DataGridViewTextBoxColumn viewTextBoxColumn8_1 = new DataGridViewTextBoxColumn();
				viewTextBoxColumn8_1.HeaderText = "Спрос";
				viewTextBoxColumn8_1.Name = "BidPut";
				viewTextBoxColumn8_1.AutoSizeMode = DataGridViewAutoSizeColumnMode.DisplayedCells;
				viewTextBoxColumn8_1.DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;
				viewTextBoxColumn8_1.DefaultCellStyle.BackColor = ClassColorTheme.TableRedColor;
				DataGridViewTextBoxColumn viewTextBoxColumn8_2 = new DataGridViewTextBoxColumn();
				viewTextBoxColumn8_2.HeaderText = "Предл";
				viewTextBoxColumn8_2.Name = "AskPut";
				viewTextBoxColumn8_2.AutoSizeMode = DataGridViewAutoSizeColumnMode.DisplayedCells;
				viewTextBoxColumn8_2.DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;
				viewTextBoxColumn8_2.DefaultCellStyle.BackColor = ClassColorTheme.TableRedColor;
				DataGridViewTextBoxColumn viewTextBoxColumn8_3 = new DataGridViewTextBoxColumn();
				viewTextBoxColumn8_3.HeaderText = "Посл. цена";
				viewTextBoxColumn8_3.Name = "LastPricePut";
				viewTextBoxColumn8_3.AutoSizeMode = DataGridViewAutoSizeColumnMode.DisplayedCells;
				viewTextBoxColumn8_3.DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;
				viewTextBoxColumn8_3.DefaultCellStyle.BackColor = ClassColorTheme.TableRedColor;
				DataGridViewTextBoxColumn viewTextBoxColumn35 = new DataGridViewTextBoxColumn();
				viewTextBoxColumn35.HeaderText = "Дельта";
				viewTextBoxColumn35.Name = "DeltaPut";
				viewTextBoxColumn35.AutoSizeMode = DataGridViewAutoSizeColumnMode.DisplayedCells;
				viewTextBoxColumn35.DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;
				viewTextBoxColumn35.DefaultCellStyle.BackColor = ClassColorTheme.TableRedColor;
				DataGridViewTextBoxColumn viewTextBoxColumn36 = new DataGridViewTextBoxColumn();
				viewTextBoxColumn36.HeaderText = "Гамма";
				viewTextBoxColumn36.Name = "GammaPut";
				viewTextBoxColumn36.AutoSizeMode = DataGridViewAutoSizeColumnMode.DisplayedCells;
				viewTextBoxColumn36.DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;
				viewTextBoxColumn36.DefaultCellStyle.BackColor = ClassColorTheme.TableRedColor;
				DataGridViewTextBoxColumn viewTextBoxColumn37 = new DataGridViewTextBoxColumn();
				viewTextBoxColumn37.HeaderText = "Вега";
				viewTextBoxColumn37.Name = "VegaPut";
				viewTextBoxColumn37.AutoSizeMode = DataGridViewAutoSizeColumnMode.DisplayedCells;
				viewTextBoxColumn37.DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;
				viewTextBoxColumn37.DefaultCellStyle.BackColor = ClassColorTheme.TableRedColor;
				DataGridViewTextBoxColumn viewTextBoxColumn38 = new DataGridViewTextBoxColumn();
				viewTextBoxColumn38.HeaderText = "Тета";
				viewTextBoxColumn38.Name = "ThetaPut";
				viewTextBoxColumn38.AutoSizeMode = DataGridViewAutoSizeColumnMode.DisplayedCells;
				viewTextBoxColumn38.DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;
				viewTextBoxColumn38.DefaultCellStyle.BackColor = ClassColorTheme.TableRedColor;
				dataGridViewBoard.Columns.Add(viewTextBoxColumn27);
				dataGridViewBoard.Columns.Add(viewTextBoxColumn28);
				dataGridViewBoard.Columns.Add(viewTextBoxColumn29);
				dataGridViewBoard.Columns.Add(viewTextBoxColumn30);
				dataGridViewBoard.Columns.Add(viewTextBoxColumn5_1);
				dataGridViewBoard.Columns.Add(viewTextBoxColumn5_2);
				dataGridViewBoard.Columns.Add(viewTextBoxColumn5_3);
				dataGridViewBoard.Columns.Add(viewTextBoxColumn31);
				dataGridViewBoard.Columns.Add(viewTextBoxColumn32);
				dataGridViewBoard.Columns.Add(viewTextBoxColumn33);
				dataGridViewBoard.Columns.Add(viewTextBoxColumn34);
				dataGridViewBoard.Columns.Add(viewTextBoxColumn8_1);
				dataGridViewBoard.Columns.Add(viewTextBoxColumn8_2);
				dataGridViewBoard.Columns.Add(viewTextBoxColumn8_3);
				dataGridViewBoard.Columns.Add(viewTextBoxColumn35);
				dataGridViewBoard.Columns.Add(viewTextBoxColumn36);
				dataGridViewBoard.Columns.Add(viewTextBoxColumn37);
				dataGridViewBoard.Columns.Add(viewTextBoxColumn38);
				viewTextBoxColumn27.SortMode = DataGridViewColumnSortMode.NotSortable;
				viewTextBoxColumn28.SortMode = DataGridViewColumnSortMode.NotSortable;
				viewTextBoxColumn29.SortMode = DataGridViewColumnSortMode.NotSortable;
				viewTextBoxColumn30.SortMode = DataGridViewColumnSortMode.NotSortable;
				viewTextBoxColumn31.SortMode = DataGridViewColumnSortMode.NotSortable;
				viewTextBoxColumn5_1.SortMode = DataGridViewColumnSortMode.NotSortable;
				viewTextBoxColumn5_2.SortMode = DataGridViewColumnSortMode.NotSortable;
				viewTextBoxColumn5_3.SortMode = DataGridViewColumnSortMode.NotSortable;
				viewTextBoxColumn32.SortMode = DataGridViewColumnSortMode.NotSortable;
				viewTextBoxColumn33.SortMode = DataGridViewColumnSortMode.NotSortable;
				viewTextBoxColumn34.SortMode = DataGridViewColumnSortMode.NotSortable;
				viewTextBoxColumn8_1.SortMode = DataGridViewColumnSortMode.NotSortable;
				viewTextBoxColumn8_2.SortMode = DataGridViewColumnSortMode.NotSortable;
				viewTextBoxColumn8_3.SortMode = DataGridViewColumnSortMode.NotSortable;
				viewTextBoxColumn35.SortMode = DataGridViewColumnSortMode.NotSortable;
				viewTextBoxColumn36.SortMode = DataGridViewColumnSortMode.NotSortable;
				viewTextBoxColumn37.SortMode = DataGridViewColumnSortMode.NotSortable;
				viewTextBoxColumn38.SortMode = DataGridViewColumnSortMode.NotSortable;
				dataGridViewBoard.RowHeadersVisible = false;
				dataGridViewBoard.ColumnHeadersDefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;
				viewTextBoxColumn32.AutoSizeMode = DataGridViewAutoSizeColumnMode.Fill;
				viewTextBoxColumn32.MinimumWidth = 50;
			}
			dataGridViewBoard.ContextMenuStrip = contextMenuStripBoard;
			dataGridViewFutures.Columns.Clear();
			DataGridViewTextBoxColumn viewTextBoxColumn39 = new DataGridViewTextBoxColumn();
			viewTextBoxColumn39.HeaderText = "Параметр";
			viewTextBoxColumn39.Name = "Parameter";
			viewTextBoxColumn39.AutoSizeMode = DataGridViewAutoSizeColumnMode.DisplayedCells;
			viewTextBoxColumn39.DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;
			viewTextBoxColumn39.DefaultCellStyle.BackColor = ClassColorTheme.HeadersColor;
			DataGridViewTextBoxColumn viewTextBoxColumn40 = new DataGridViewTextBoxColumn();
			viewTextBoxColumn40.HeaderText = "Значение";
			viewTextBoxColumn40.Name = "Value";
			viewTextBoxColumn40.DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;
			viewTextBoxColumn40.DefaultCellStyle.BackColor = ClassColorTheme.BackColor;
			dataGridViewFutures.Columns.Add(viewTextBoxColumn39);
			dataGridViewFutures.Columns.Add(viewTextBoxColumn40);
			dataGridViewFutures.RowHeadersVisible = false;
			dataGridViewFutures.ColumnHeadersDefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;
			viewTextBoxColumn40.AutoSizeMode = DataGridViewAutoSizeColumnMode.Fill;
			viewTextBoxColumn40.MinimumWidth = 50;
			dataGridViewFutures.Rows.Add("Код фьючерса", "");
			dataGridViewFutures.Rows.Add("Дата экспирации", "");
			dataGridViewFutures.Rows.Add("Последняя цена", "");
			dataGridViewFutures.Rows.Add("Предложение", "");
			dataGridViewFutures.Rows.Add("Спрос", "");
			dataGridViewFutures.Rows.Add("Шаг цены", "");
			dataGridViewFutures.ContextMenuStrip = contextMenuStripFuture;
		}

		private void FillBoard(string iThemeBoard, double iCentralStrike)
		{
			try
			{
				BoardTable.Add(BoardPaper.strike, BoardPaper);
			}
			catch (Exception)
			{
			}
			if (!(iThemeBoard == "Classic"))
			{
				if (iThemeBoard == "Viktor")
				{
					int index1 = 0;
					for (int index2 = BoardTable.Count - 1; index2 >= 0; index2--)
					{
						if (index1 < dataGridViewBoard.RowCount)
						{
							BoardPaper = BoardTable.Values[index2];
							dataGridViewBoard.Rows[index1].Cells[0].Value = BoardPaper.paper_code_put;
							dataGridViewBoard.Rows[index1].Cells[1].Value = BoardPaper.theta_put;
							dataGridViewBoard.Rows[index1].Cells[2].Value = BoardPaper.vega_put;
							dataGridViewBoard.Rows[index1].Cells[3].Value = BoardPaper.gamma_put;
							dataGridViewBoard.Rows[index1].Cells[4].Value = BoardPaper.delta_put;
							dataGridViewBoard.Rows[index1].Cells[5].Value = BoardPaper.teoretical_price_put;
							dataGridViewBoard.Rows[index1].Cells[6].Value = BoardPaper.strike;
							dataGridViewBoard.Rows[index1].Cells[7].Value = BoardPaper.volatility;
							dataGridViewBoard.Rows[index1].Cells[8].Value = BoardPaper.teoretical_price_call;
							dataGridViewBoard.Rows[index1].Cells[9].Value = BoardPaper.delta_call;
							dataGridViewBoard.Rows[index1].Cells[10].Value = BoardPaper.gamma_call;
							dataGridViewBoard.Rows[index1].Cells[11].Value = BoardPaper.vega_call;
							dataGridViewBoard.Rows[index1].Cells[12].Value = BoardPaper.theta_call;
							dataGridViewBoard.Rows[index1].Cells[13].Value = BoardPaper.paper_code_call;
							if (BoardPaper.strike == iCentralStrike)
							{
								dataGridViewBoard.Rows[index1].DefaultCellStyle.Font = new Font(dataGridViewBoard.DefaultCellStyle.Font, FontStyle.Bold);
							}
							else
							{
								dataGridViewBoard.Rows[index1].DefaultCellStyle.Font = new Font(dataGridViewBoard.DefaultCellStyle.Font, FontStyle.Regular);
							}
							if (index2 == 0)
							{
								int num = dataGridViewBoard.RowCount - BoardTable.Count;
								for (int i = 1; i <= num; i++)
								{
									dataGridViewBoard.Rows.RemoveAt(index1);
								}
							}
							index1++;
						}
						else if (dataGridViewBoard.ColumnCount > 0)
						{
							BoardPaper = BoardTable.Values[index2];
							dataGridViewBoard.Rows.Add(BoardPaper.paper_code_put, BoardPaper.theta_put, BoardPaper.vega_put, BoardPaper.gamma_put, BoardPaper.delta_put, BoardPaper.teoretical_price_put, BoardPaper.strike, BoardPaper.volatility, BoardPaper.teoretical_price_call, BoardPaper.delta_call, BoardPaper.gamma_call, BoardPaper.vega_call, BoardPaper.theta_call, BoardPaper.paper_code_call);
							if (BoardPaper.strike == iCentralStrike)
							{
								dataGridViewBoard.Rows[index1].DefaultCellStyle.Font = new Font(dataGridViewBoard.DefaultCellStyle.Font, FontStyle.Bold);
							}
							else
							{
								dataGridViewBoard.Rows[index1].DefaultCellStyle.Font = new Font(dataGridViewBoard.DefaultCellStyle.Font, FontStyle.Regular);
							}
							index1++;
						}
					}
				}
				else
				{
					for (int j = 0; j < BoardTable.Count; j++)
					{
						if (j < dataGridViewBoard.RowCount)
						{
							BoardPaper = BoardTable.Values[j];
							dataGridViewBoard.Rows[j].Cells[0].Value = BoardPaper.theta_call;
							dataGridViewBoard.Rows[j].Cells[1].Value = BoardPaper.vega_call;
							dataGridViewBoard.Rows[j].Cells[2].Value = BoardPaper.gamma_call;
							dataGridViewBoard.Rows[j].Cells[3].Value = BoardPaper.delta_call;
							dataGridViewBoard.Rows[j].Cells[4].Value = BoardPaper.last_price_call;
							dataGridViewBoard.Rows[j].Cells[5].Value = BoardPaper.demand_call;
							dataGridViewBoard.Rows[j].Cells[6].Value = BoardPaper.sentence_call;
							dataGridViewBoard.Rows[j].Cells[7].Value = BoardPaper.teoretical_price_call;
							dataGridViewBoard.Rows[j].Cells[8].Value = BoardPaper.strike;
							dataGridViewBoard.Rows[j].Cells[9].Value = BoardPaper.volatility;
							dataGridViewBoard.Rows[j].Cells[10].Value = BoardPaper.teoretical_price_put;
							dataGridViewBoard.Rows[j].Cells[11].Value = BoardPaper.demand_put;
							dataGridViewBoard.Rows[j].Cells[12].Value = BoardPaper.sentence_put;
							dataGridViewBoard.Rows[j].Cells[13].Value = BoardPaper.last_price_put;
							dataGridViewBoard.Rows[j].Cells[14].Value = BoardPaper.delta_put;
							dataGridViewBoard.Rows[j].Cells[15].Value = BoardPaper.gamma_put;
							dataGridViewBoard.Rows[j].Cells[16].Value = BoardPaper.vega_put;
							dataGridViewBoard.Rows[j].Cells[17].Value = BoardPaper.theta_put;
							if (BoardPaper.strike == iCentralStrike)
							{
								dataGridViewBoard.Rows[j].DefaultCellStyle.Font = new Font(dataGridViewBoard.DefaultCellStyle.Font, FontStyle.Bold);
							}
							else
							{
								dataGridViewBoard.Rows[j].DefaultCellStyle.Font = new Font(dataGridViewBoard.DefaultCellStyle.Font, FontStyle.Regular);
							}
							if (j == BoardTable.Count - 1)
							{
								int num2 = dataGridViewBoard.RowCount - BoardTable.Count;
								for (int k = 1; k <= num2; k++)
								{
									dataGridViewBoard.Rows.RemoveAt(j);
								}
							}
						}
						else if (dataGridViewBoard.ColumnCount > 0)
						{
							BoardPaper = BoardTable.Values[j];
							dataGridViewBoard.Rows.Add(BoardPaper.theta_call, BoardPaper.vega_call, BoardPaper.gamma_call, BoardPaper.delta_call, BoardPaper.teoretical_price_call, BoardPaper.strike, BoardPaper.volatility, BoardPaper.teoretical_price_put, BoardPaper.delta_put, BoardPaper.gamma_put, BoardPaper.vega_put, BoardPaper.theta_put);
							if (BoardPaper.strike == iCentralStrike)
							{
								dataGridViewBoard.Rows[j].DefaultCellStyle.Font = new Font(dataGridViewBoard.DefaultCellStyle.Font, FontStyle.Bold);
							}
							else
							{
								dataGridViewBoard.Rows[j].DefaultCellStyle.Font = new Font(dataGridViewBoard.DefaultCellStyle.Font, FontStyle.Regular);
							}
						}
					}
				}
			}
			else
			{
				for (int l = 0; l < BoardTable.Count; l++)
				{
					if (l < dataGridViewBoard.RowCount)
					{
						BoardPaper = BoardTable.Values[l];
						dataGridViewBoard.Rows[l].Cells[0].Value = BoardPaper.theta_call;
						dataGridViewBoard.Rows[l].Cells[1].Value = BoardPaper.vega_call;
						dataGridViewBoard.Rows[l].Cells[2].Value = BoardPaper.gamma_call;
						dataGridViewBoard.Rows[l].Cells[3].Value = BoardPaper.delta_call;
						dataGridViewBoard.Rows[l].Cells[4].Value = BoardPaper.last_price_call;
						dataGridViewBoard.Rows[l].Cells[5].Value = BoardPaper.demand_call;
						dataGridViewBoard.Rows[l].Cells[6].Value = BoardPaper.sentence_call;
						dataGridViewBoard.Rows[l].Cells[7].Value = BoardPaper.teoretical_price_call;
						dataGridViewBoard.Rows[l].Cells[8].Value = BoardPaper.strike;
						dataGridViewBoard.Rows[l].Cells[9].Value = BoardPaper.volatility;
						dataGridViewBoard.Rows[l].Cells[10].Value = BoardPaper.teoretical_price_put;
						dataGridViewBoard.Rows[l].Cells[11].Value = BoardPaper.demand_put;
						dataGridViewBoard.Rows[l].Cells[12].Value = BoardPaper.sentence_put;
						dataGridViewBoard.Rows[l].Cells[13].Value = BoardPaper.last_price_put;
						dataGridViewBoard.Rows[l].Cells[14].Value = BoardPaper.delta_put;
						dataGridViewBoard.Rows[l].Cells[15].Value = BoardPaper.gamma_put;
						dataGridViewBoard.Rows[l].Cells[16].Value = BoardPaper.vega_put;
						dataGridViewBoard.Rows[l].Cells[17].Value = BoardPaper.theta_put;
						if (BoardPaper.strike == iCentralStrike)
						{
							dataGridViewBoard.Rows[l].DefaultCellStyle.Font = new Font(dataGridViewBoard.DefaultCellStyle.Font, FontStyle.Bold);
						}
						else
						{
							dataGridViewBoard.Rows[l].DefaultCellStyle.Font = new Font(dataGridViewBoard.DefaultCellStyle.Font, FontStyle.Regular);
						}
						if (l == BoardTable.Count - 1)
						{
							int num3 = dataGridViewBoard.RowCount - BoardTable.Count;
							for (int m = 1; m <= num3; m++)
							{
								dataGridViewBoard.Rows.RemoveAt(l);
							}
						}
					}
					else if (dataGridViewBoard.ColumnCount > 0)
					{
						BoardPaper = BoardTable.Values[l];
						dataGridViewBoard.Rows.Add(BoardPaper.theta_call, BoardPaper.vega_call, BoardPaper.gamma_call, BoardPaper.delta_call, BoardPaper.teoretical_price_call, BoardPaper.strike, BoardPaper.volatility, BoardPaper.teoretical_price_put, BoardPaper.delta_put, BoardPaper.gamma_put, BoardPaper.vega_put, BoardPaper.theta_put);
						if (BoardPaper.strike == iCentralStrike)
						{
							dataGridViewBoard.Rows[l].DefaultCellStyle.Font = new Font(dataGridViewBoard.DefaultCellStyle.Font, FontStyle.Bold);
						}
						else
						{
							dataGridViewBoard.Rows[l].DefaultCellStyle.Font = new Font(dataGridViewBoard.DefaultCellStyle.Font, FontStyle.Regular);
						}
					}
				}
			}
			dataGridViewFutures.Rows[0].Cells[1].Value = FuturePaper.paper_code;
			dataGridViewFutures.Rows[1].Cells[1].Value = FuturePaper.expiration_date.ToShortDateString();
			dataGridViewFutures.Rows[2].Cells[1].Value = FuturePaper.last_price;
			dataGridViewFutures.Rows[3].Cells[1].Value = FuturePaper.sentence;
			dataGridViewFutures.Rows[4].Cells[1].Value = FuturePaper.demand;
			dataGridViewFutures.Rows[5].Cells[1].Value = FuturePaper.step_price;
		}

		private void PaintColorTheme()
		{
			BackColor = ClassColorTheme.BackColor;
			ForeColor = ClassColorTheme.HeadersColorFore;
			groupBoxBoard.BackColor = ClassColorTheme.BackColor;
			groupBoxBoard.ForeColor = ClassColorTheme.BackColorFore;
			groupBoxFutures.BackColor = ClassColorTheme.BackColor;
			groupBoxFutures.ForeColor = ClassColorTheme.BackColorFore;
			groupBoxInformation.BackColor = ClassColorTheme.BackColor;
			groupBoxInformation.ForeColor = ClassColorTheme.BackColorFore;
			splitContainer1.BackColor = ClassColorTheme.HeadersColor;
			splitContainer1.Panel1.BackColor = ClassColorTheme.BackColor;
			splitContainer1.Panel2.BackColor = ClassColorTheme.BackColor;
			splitContainer1.BorderStyle = BorderStyle.None;
			splitContainer2.BackColor = ClassColorTheme.HeadersColor;
			splitContainer2.Panel1.BackColor = ClassColorTheme.BackColor;
			splitContainer2.Panel2.BackColor = ClassColorTheme.BackColor;
			splitContainer2.BorderStyle = BorderStyle.None;
			comboBoxQuantity.FlatStyle = FlatStyle.System;
			comboBoxThemeBoard.FlatStyle = FlatStyle.System;
			comboBoxBaseAsset.FlatStyle = FlatStyle.System;
			comboBoxExpirationDate.FlatStyle = FlatStyle.System;
			label1.BackColor = ClassColorTheme.BackColor;
			label1.ForeColor = ClassColorTheme.BackColorFore;
			label2.BackColor = ClassColorTheme.BackColor;
			label2.ForeColor = ClassColorTheme.BackColorFore;
			label3.BackColor = ClassColorTheme.BackColor;
			label3.ForeColor = ClassColorTheme.BackColorFore;
			label4.BackColor = ClassColorTheme.BackColor;
			label4.ForeColor = ClassColorTheme.BackColorFore;
			dataGridViewBoard.ColumnHeadersDefaultCellStyle.BackColor = ClassColorTheme.HeadersColor;
			dataGridViewBoard.BackgroundColor = ClassColorTheme.BackColor;
			dataGridViewBoard.ForeColor = ClassColorTheme.BackColorFore;
			dataGridViewBoard.DefaultCellStyle.BackColor = ClassColorTheme.BackColor;
			dataGridViewBoard.ColumnHeadersDefaultCellStyle.ForeColor = ClassColorTheme.HeadersColorFore;
			dataGridViewBoard.GridColor = ClassColorTheme.GridColor;
			richTextBoxInformation.BackColor = ClassColorTheme.BackColor;
			richTextBoxInformation.ForeColor = ClassColorTheme.BackColorFore;
			string text = comboBoxThemeBoard.Text;
			if (!(text == "Classic"))
			{
				if (text == "Viktor")
				{
					dataGridViewBoard.Columns["ThetaPut"].DefaultCellStyle.BackColor = ClassColorTheme.TableRedColor;
					dataGridViewBoard.Columns["VegaPut"].DefaultCellStyle.BackColor = ClassColorTheme.TableRedColor;
					dataGridViewBoard.Columns["GammaPut"].DefaultCellStyle.BackColor = ClassColorTheme.TableRedColor;
					dataGridViewBoard.Columns["DeltaPut"].DefaultCellStyle.BackColor = ClassColorTheme.TableRedColor;
					dataGridViewBoard.Columns["TheoPut"].DefaultCellStyle.BackColor = ClassColorTheme.TableRedColor;
					dataGridViewBoard.Columns["Strike"].DefaultCellStyle.BackColor = ClassColorTheme.BackColor;
					dataGridViewBoard.Columns["Vola"].DefaultCellStyle.BackColor = ClassColorTheme.BackColor;
					dataGridViewBoard.Columns["TheoCall"].DefaultCellStyle.BackColor = ClassColorTheme.TableGreenColor;
					dataGridViewBoard.Columns["DeltaCall"].DefaultCellStyle.BackColor = ClassColorTheme.TableGreenColor;
					dataGridViewBoard.Columns["GammaCall"].DefaultCellStyle.BackColor = ClassColorTheme.TableGreenColor;
					dataGridViewBoard.Columns["VegaCall"].DefaultCellStyle.BackColor = ClassColorTheme.TableGreenColor;
					dataGridViewBoard.Columns["ThetaCall"].DefaultCellStyle.BackColor = ClassColorTheme.TableGreenColor;
				}
				else
				{
					dataGridViewBoard.Columns["ThetaPut"].DefaultCellStyle.BackColor = ClassColorTheme.TableRedColor;
					dataGridViewBoard.Columns["VegaPut"].DefaultCellStyle.BackColor = ClassColorTheme.TableRedColor;
					dataGridViewBoard.Columns["GammaPut"].DefaultCellStyle.BackColor = ClassColorTheme.TableRedColor;
					dataGridViewBoard.Columns["DeltaPut"].DefaultCellStyle.BackColor = ClassColorTheme.TableRedColor;
					dataGridViewBoard.Columns["TheoPut"].DefaultCellStyle.BackColor = ClassColorTheme.TableRedColor;
					dataGridViewBoard.Columns["Strike"].DefaultCellStyle.BackColor = ClassColorTheme.BackColor;
					dataGridViewBoard.Columns["Vola"].DefaultCellStyle.BackColor = ClassColorTheme.BackColor;
					dataGridViewBoard.Columns["TheoCall"].DefaultCellStyle.BackColor = ClassColorTheme.TableGreenColor;
					dataGridViewBoard.Columns["DeltaCall"].DefaultCellStyle.BackColor = ClassColorTheme.TableGreenColor;
					dataGridViewBoard.Columns["GammaCall"].DefaultCellStyle.BackColor = ClassColorTheme.TableGreenColor;
					dataGridViewBoard.Columns["VegaCall"].DefaultCellStyle.BackColor = ClassColorTheme.TableGreenColor;
					dataGridViewBoard.Columns["ThetaCall"].DefaultCellStyle.BackColor = ClassColorTheme.TableGreenColor;
				}
			}
			else
			{
				dataGridViewBoard.Columns["ThetaPut"].DefaultCellStyle.BackColor = ClassColorTheme.TableRedColor;
				dataGridViewBoard.Columns["VegaPut"].DefaultCellStyle.BackColor = ClassColorTheme.TableRedColor;
				dataGridViewBoard.Columns["GammaPut"].DefaultCellStyle.BackColor = ClassColorTheme.TableRedColor;
				dataGridViewBoard.Columns["DeltaPut"].DefaultCellStyle.BackColor = ClassColorTheme.TableRedColor;
				dataGridViewBoard.Columns["TheoPut"].DefaultCellStyle.BackColor = ClassColorTheme.TableRedColor;
				dataGridViewBoard.Columns["Strike"].DefaultCellStyle.BackColor = ClassColorTheme.BackColor;
				dataGridViewBoard.Columns["Vola"].DefaultCellStyle.BackColor = ClassColorTheme.BackColor;
				dataGridViewBoard.Columns["TheoCall"].DefaultCellStyle.BackColor = ClassColorTheme.TableGreenColor;
				dataGridViewBoard.Columns["DeltaCall"].DefaultCellStyle.BackColor = ClassColorTheme.TableGreenColor;
				dataGridViewBoard.Columns["GammaCall"].DefaultCellStyle.BackColor = ClassColorTheme.TableGreenColor;
				dataGridViewBoard.Columns["VegaCall"].DefaultCellStyle.BackColor = ClassColorTheme.TableGreenColor;
				dataGridViewBoard.Columns["ThetaCall"].DefaultCellStyle.BackColor = ClassColorTheme.TableGreenColor;
			}
			dataGridViewFutures.ColumnHeadersDefaultCellStyle.BackColor = ClassColorTheme.HeadersColor;
			dataGridViewFutures.BackgroundColor = ClassColorTheme.BackColor;
			dataGridViewFutures.ForeColor = ClassColorTheme.BackColorFore;
			dataGridViewFutures.DefaultCellStyle.BackColor = ClassColorTheme.BackColor;
			dataGridViewFutures.ColumnHeadersDefaultCellStyle.ForeColor = ClassColorTheme.HeadersColorFore;
			dataGridViewFutures.GridColor = ClassColorTheme.GridColor;
			dataGridViewFutures.RowsDefaultCellStyle.BackColor = ClassColorTheme.BackColor;
			dataGridViewFutures.AlternatingRowsDefaultCellStyle.BackColor = ClassColorTheme.HeadersColor;
		}

		public void FillcomboBoxQuantity(string defaultQuantity)
		{
			comboBoxQuantity.Items.Clear();
			int num = 0;
			for (int index = 1; index <= 20; index++)
			{
				string str = Convert.ToString(index * 5);
				comboBoxQuantity.Items.Add(str);
				if (str == defaultQuantity)
				{
					num = index - 1;
				}
			}
			comboBoxQuantity.SelectedIndex = num;
		}

		public void FillcomboBoxThemeBoard(string defaultThemeBoard)
		{
			comboBoxThemeBoard.Items.Clear();
			comboBoxThemeBoard.Items.Add("Classic");
			comboBoxThemeBoard.Items.Add("Viktor");
			if (defaultThemeBoard == "Classic")
			{
				comboBoxThemeBoard.SelectedIndex = 0;
			}
			else
			{
				comboBoxThemeBoard.SelectedIndex = 1;
			}
		}

		public void FillcomboBoxBaseAsset(string defaultBaseAsset)
		{
			int num = 0;
			List<string> stringList = new List<string>();
			stringList.Clear();
			if (defaultBaseAsset.Length > 0)
			{
				stringList.Add(defaultBaseAsset);
			}
			comboBoxBaseAsset.Items.Clear();
			if (!ClassDataDDE.F_ErrorOpenFile)
			{
				lock (ClassDataDDE.QuotesTable)
				{
					for (int index1 = 0; index1 < ClassDataDDE.QuotesTable.Count; index1++)
					{
						bool flag = false;
						string baseAsset = ClassDataDDE.QuotesTable[index1].base_asset;
						if (baseAsset != "" && stringList.Count == 0 && Helpers.IsOption(ClassDataDDE.QuotesTable[index1].paper_code))
						{
							stringList.Add(baseAsset);
						}
						else
						{
							if (!(baseAsset != "") || !Helpers.IsOption(ClassDataDDE.QuotesTable[index1].paper_code))
							{
								continue;
							}
							for (int i = 0; i < stringList.Count; i++)
							{
								if (baseAsset == stringList[i])
								{
									flag = true;
									break;
								}
							}
							if (!flag)
							{
								stringList.Add(baseAsset);
							}
						}
					}
				}
			}
			else
			{
				stringList.Add(defaultBaseAsset);
			}
			for (int j = 0; j < stringList.Count; j++)
			{
				if (stringList[j] == defaultBaseAsset)
				{
					num = j;
				}
				comboBoxBaseAsset.Items.Add(stringList[j]);
			}
			if (stringList.Count > 0)
			{
				comboBoxBaseAsset.SelectedIndex = num;
			}
		}

		public void FillcomboBoxExpirationDate(string baseAsset, string defaultExpirationDate)
		{
			int num = 0;
			List<DateTime> dateTimeList = new List<DateTime>();
			dateTimeList.Clear();
			DateTime result;
			if (DateTime.TryParse(defaultExpirationDate, out result))
			{
				dateTimeList.Add(result);
			}
			comboBoxExpirationDate.Items.Clear();
			if (!ClassDataDDE.F_ErrorOpenFile)
			{
				lock (ClassDataDDE.QuotesTable)
				{
					for (int index1 = 0; index1 < ClassDataDDE.QuotesTable.Count; index1++)
					{
						bool flag = false;
						DateTime expirationDate = ClassDataDDE.QuotesTable[index1].expiration_date;
						if (ClassDataDDE.QuotesTable[index1].base_asset == baseAsset && dateTimeList.Count == 0 && Helpers.IsOption(ClassDataDDE.QuotesTable[index1].paper_code))
						{
							dateTimeList.Add(expirationDate);
						}
						else
						{
							if (!(ClassDataDDE.QuotesTable[index1].base_asset == baseAsset) || !Helpers.IsOption(ClassDataDDE.QuotesTable[index1].paper_code))
							{
								continue;
							}
							for (int i = 0; i < dateTimeList.Count; i++)
							{
								if (expirationDate == dateTimeList[i])
								{
									flag = true;
									break;
								}
							}
							if (!flag)
							{
								dateTimeList.Add(expirationDate);
							}
						}
					}
				}
				for (int j = 0; j < dateTimeList.Count; j++)
				{
					if (dateTimeList[j].ToShortDateString() == defaultExpirationDate)
					{
						num = j;
					}
					ComboBox.ObjectCollection items = comboBoxExpirationDate.Items;
					string shortDateString = dateTimeList[j].ToShortDateString();
					items.Add(shortDateString);
				}
				if (dateTimeList.Count > 0)
				{
					comboBoxExpirationDate.SelectedIndex = num;
				}
			}
			else
			{
				comboBoxExpirationDate.Items.Add(defaultExpirationDate);
				comboBoxExpirationDate.SelectedIndex = 0;
			}
		}

		public void FillSettingsBoardQuantity()
		{
			ClassSettings.gBoardQuantity = comboBoxQuantity.Text;
		}

		public void FillSettingsBoardTheme()
		{
			ClassSettings.gBoardTheme = comboBoxThemeBoard.Text;
		}

		public void FillSettingsBoardBaseAsset()
		{
			ClassSettings.gBoardBaseAsset = comboBoxBaseAsset.Text;
		}

		public void FillSettingsBoardExpirationDate()
		{
			ClassSettings.gBoardExpirationDate = comboBoxExpirationDate.Text;
		}

		private void comboBoxBaseAsset_Click(object sender, EventArgs e)
		{
			FillcomboBoxBaseAsset(comboBoxBaseAsset.Text);
		}

		private void comboBoxExpirationDate_Click(object sender, EventArgs e)
		{
			FillcomboBoxExpirationDate(comboBoxBaseAsset.Text, comboBoxExpirationDate.Text);
		}

		private void добавитьВПортфельToolStripMenuItem_Click(object sender, EventArgs e)
		{
			bool flag = true;
			string paper_code = "";
			double result1 = 0.0;
			if (dataGridViewBoard.SelectedCells[0].RowIndex >= 0)
			{
				if (comboBoxThemeBoard.Text == "Viktor")
				{
					if (dataGridViewBoard.SelectedCells[0].ColumnIndex < 6)
					{
						paper_code = Convert.ToString(dataGridViewBoard.Rows[dataGridViewBoard.SelectedCells[0].RowIndex].Cells[0].Value);
						if (double.TryParse(Convert.ToString(dataGridViewBoard.Rows[dataGridViewBoard.SelectedCells[0].RowIndex].Cells[5].Value), out result1))
						{
							if (result1 <= 0.0)
							{
								int num = (int)MessageBox.Show("Не корректна теоретическая цена. Она должна быть больше нуля");
								flag = false;
							}
						}
						else
						{
							int num2 = (int)MessageBox.Show("Не корректна теоретическая цена. Она должна быть числом");
							flag = false;
						}
					}
					else if (dataGridViewBoard.SelectedCells[0].ColumnIndex >= 8)
					{
						paper_code = Convert.ToString(dataGridViewBoard.Rows[dataGridViewBoard.SelectedCells[0].RowIndex].Cells[13].Value);
						if (double.TryParse(Convert.ToString(dataGridViewBoard.Rows[dataGridViewBoard.SelectedCells[0].RowIndex].Cells[8].Value), out result1))
						{
							if (result1 <= 0.0)
							{
								int num3 = (int)MessageBox.Show("Не корректна теоретическая цена. Она должна быть больше нуля");
								flag = false;
							}
						}
						else
						{
							int num4 = (int)MessageBox.Show("Не корректна теоретическая цена. Она должна быть числом");
							flag = false;
						}
					}
					else
					{
						int num5 = (int)MessageBox.Show("Необходимо выделять ячейки путов или колов");
						flag = false;
					}
					if (flag)
					{
						CallBackMy.callbackEventHandlerAddTransactionFromBoard(paper_code, Convert.ToDouble(1), result1);
					}
				}
				else if (comboBoxThemeBoard.Text == "Classic")
				{
					if (dataGridViewBoard.SelectedCells[0].ColumnIndex < 8)
					{
						DateTime result2;
						if (!DateTime.TryParse(comboBoxExpirationDate.Text, out result2))
						{
							int num6 = (int)MessageBox.Show("Не корректна дата экспирации");
							flag = false;
						}
						string base_asset = Convert.ToString(comboBoxBaseAsset.Text);
						double result3;
						if (double.TryParse(Convert.ToString(dataGridViewBoard.Rows[dataGridViewBoard.SelectedCells[0].RowIndex].Cells[8].Value), out result3))
						{
							if (result3 <= 0.0)
							{
								int num7 = (int)MessageBox.Show("Не корректен страйк. Он должен быть числом больше нуля");
								flag = false;
							}
						}
						else
						{
							int num8 = (int)MessageBox.Show("Не корректен страйк. Он должен быть числом.");
							flag = false;
						}
						string option_type = "Call";
						if (!cDataDDE.SearchPaper(result2, base_asset, result3, option_type))
						{
							int num9 = (int)MessageBox.Show("Не удалось найти этот инструмент в DDE");
							flag = false;
						}
						paper_code = Convert.ToString(ClassDataDDE.QuotesPaper.paper_code);
						if (double.TryParse(Convert.ToString(dataGridViewBoard.Rows[dataGridViewBoard.SelectedCells[0].RowIndex].Cells[7].Value), out result1))
						{
							if (result1 <= 0.0)
							{
								int num10 = (int)MessageBox.Show("Не корректна теоретическая цена. Она должна быть больше нуля");
								flag = false;
							}
						}
						else
						{
							int num11 = (int)MessageBox.Show("Не корректна теоретическая цена. Она должна быть числом");
							flag = false;
						}
					}
					else if (dataGridViewBoard.SelectedCells[0].ColumnIndex >= 10)
					{
						DateTime result4;
						if (!DateTime.TryParse(comboBoxExpirationDate.Text, out result4))
						{
							int num12 = (int)MessageBox.Show("Не корректна дата экспирации");
							flag = false;
						}
						string base_asset2 = Convert.ToString(comboBoxBaseAsset.Text);
						double result5;
						if (double.TryParse(Convert.ToString(dataGridViewBoard.Rows[dataGridViewBoard.SelectedCells[0].RowIndex].Cells[8].Value), out result5))
						{
							if (result5 <= 0.0)
							{
								int num13 = (int)MessageBox.Show("Не корректен страйк. Он должен быть числом больше нуля");
								flag = false;
							}
						}
						else
						{
							int num14 = (int)MessageBox.Show("Не корректен страйк. Он должен быть числом.");
							flag = false;
						}
						string option_type2 = "Put";
						if (!cDataDDE.SearchPaper(result4, base_asset2, result5, option_type2))
						{
							int num15 = (int)MessageBox.Show("Не удалось найти этот инструмент в DDE");
							flag = false;
						}
						paper_code = Convert.ToString(ClassDataDDE.QuotesPaper.paper_code);
						if (double.TryParse(Convert.ToString(dataGridViewBoard.Rows[dataGridViewBoard.SelectedCells[0].RowIndex].Cells[10].Value), out result1))
						{
							if (result1 <= 0.0)
							{
								int num16 = (int)MessageBox.Show("Не корректна теоретическая цена. Она должна быть больше нуля");
								flag = false;
							}
						}
						else
						{
							int num17 = (int)MessageBox.Show("Не корректна теоретическая цена. Она должна быть числом");
							flag = false;
						}
					}
					else
					{
						int num18 = (int)MessageBox.Show("Необходимо выделять ячейки путов или колов");
						flag = false;
					}
					if (flag)
					{
						CallBackMy.callbackEventHandlerAddTransactionFromBoard(paper_code, Convert.ToDouble(1), result1);
					}
				}
				else
				{
					int num19 = (int)MessageBox.Show("Должна быть выбрана тема доски только Viktor или Classic");
				}
			}
			else
			{
				int num20 = (int)MessageBox.Show("Не выбрана ячейка");
			}
		}

		private void добавитьВПортфельToolStripMenuItem1_Click(object sender, EventArgs e)
		{
			bool flag = true;
			double result = 0.0;
			if (dataGridViewFutures.SelectedCells[0].RowIndex >= 0)
			{
				string paper_code = Convert.ToString(dataGridViewFutures.Rows[0].Cells[1].Value);
				if (double.TryParse(Convert.ToString(dataGridViewFutures.Rows[2].Cells[1].Value), out result))
				{
					if (result <= 0.0)
					{
						int num = (int)MessageBox.Show("Не корректна цена. Она должна быть больше нуля");
						flag = false;
					}
				}
				else
				{
					int num2 = (int)MessageBox.Show("Не корректна цена. Она должна быть числом");
					flag = false;
				}
				if (flag)
				{
					CallBackMy.callbackEventHandlerAddTransactionFromBoard(paper_code, Convert.ToDouble(1), result);
				}
			}
			else
			{
				int num3 = (int)MessageBox.Show("Не выбрана ячейка");
			}
		}

		private void ToolStripMenuItemGlass_Click(object sender, EventArgs e)
		{
			bool flag = true;
			string iText = "";
			if (dataGridViewBoard.SelectedCells[0].RowIndex >= 0)
			{
				if (comboBoxThemeBoard.Text == "Viktor")
				{
					if (dataGridViewBoard.SelectedCells[0].ColumnIndex < 6)
					{
						iText = Convert.ToString(dataGridViewBoard.Rows[dataGridViewBoard.SelectedCells[0].RowIndex].Cells[0].Value);
					}
					else if (dataGridViewBoard.SelectedCells[0].ColumnIndex >= 8)
					{
						iText = Convert.ToString(dataGridViewBoard.Rows[dataGridViewBoard.SelectedCells[0].RowIndex].Cells[13].Value);
					}
					else
					{
						int num = (int)MessageBox.Show("Необходимо выделять ячейки путов или колов");
						flag = false;
					}
					if (flag)
					{
						CallBackMy.callbackEventHandlerOpenGlass(iText);
					}
				}
				else if (comboBoxThemeBoard.Text == "Classic")
				{
					if (dataGridViewBoard.SelectedCells[0].ColumnIndex < 8)
					{
						DateTime result1;
						if (!DateTime.TryParse(comboBoxExpirationDate.Text, out result1))
						{
							int num2 = (int)MessageBox.Show("Не корректна дата экспирации. Она должна быть числом");
							flag = false;
						}
						string base_asset = Convert.ToString(comboBoxBaseAsset.Text);
						double result2;
						if (double.TryParse(Convert.ToString(dataGridViewBoard.Rows[dataGridViewBoard.SelectedCells[0].RowIndex].Cells[8].Value), out result2))
						{
							if (result2 <= 0.0)
							{
								int num3 = (int)MessageBox.Show("Не корректен страйк. Он должен быть числом больше нуля");
								flag = false;
							}
						}
						else
						{
							int num4 = (int)MessageBox.Show("Не корректен страйк. Он должен быть числом.");
							flag = false;
						}
						string option_type = "Call";
						if (!cDataDDE.SearchPaper(result1, base_asset, result2, option_type))
						{
							int num5 = (int)MessageBox.Show("Не удалось найти этот инструмент в DDE");
							flag = false;
						}
						iText = Convert.ToString(ClassDataDDE.QuotesPaper.paper_code);
					}
					else if (dataGridViewBoard.SelectedCells[0].ColumnIndex >= 10)
					{
						DateTime result3;
						if (!DateTime.TryParse(comboBoxExpirationDate.Text, out result3))
						{
							int num6 = (int)MessageBox.Show("Не корректна дата экспирации. Она должна быть числом");
							flag = false;
						}
						string base_asset2 = Convert.ToString(comboBoxBaseAsset.Text);
						double result4;
						if (double.TryParse(Convert.ToString(dataGridViewBoard.Rows[dataGridViewBoard.SelectedCells[0].RowIndex].Cells[8].Value), out result4))
						{
							if (result4 <= 0.0)
							{
								int num7 = (int)MessageBox.Show("Не корректен страйк. Он должен быть числом больше нуля");
								flag = false;
							}
						}
						else
						{
							int num8 = (int)MessageBox.Show("Не корректен страйк. Он должен быть числом.");
							flag = false;
						}
						string option_type2 = "Put";
						if (!cDataDDE.SearchPaper(result3, base_asset2, result4, option_type2))
						{
							int num9 = (int)MessageBox.Show("Не удалось найти этот инструмент в DDE");
							flag = false;
						}
						iText = Convert.ToString(ClassDataDDE.QuotesPaper.paper_code);
					}
					else
					{
						int num10 = (int)MessageBox.Show("Необходимо выделять ячейки путов или колов");
						flag = false;
					}
					if (flag)
					{
						CallBackMy.callbackEventHandlerOpenGlass(iText);
					}
				}
				else
				{
					int num11 = (int)MessageBox.Show("Должна быть выбрана тема доски только Viktor или Classic");
				}
			}
			else
			{
				int num12 = (int)MessageBox.Show("Не выбрана ячейка");
			}
		}

		private void ToolStripMenuItemGlass1_Click(object sender, EventArgs e)
		{
			bool flag = true;
			double result = 0.0;
			if (dataGridViewFutures.SelectedCells[0].RowIndex >= 0)
			{
				string iText = Convert.ToString(dataGridViewFutures.Rows[0].Cells[1].Value);
				if (double.TryParse(Convert.ToString(dataGridViewFutures.Rows[2].Cells[1].Value), out result))
				{
					if (result <= 0.0)
					{
						int num = (int)MessageBox.Show("Не корректна цена. Она должна быть больше нуля");
						flag = false;
					}
				}
				else
				{
					int num2 = (int)MessageBox.Show("Не корректна цена. Она должна быть числом");
					flag = false;
				}
				if (flag)
				{
					CallBackMy.callbackEventHandlerOpenGlass(iText);
				}
			}
			else
			{
				int num3 = (int)MessageBox.Show("Не выбрана ячейка");
			}
		}

		protected override void Dispose(bool disposing)
		{
			if (disposing && components != null)
			{
				components.Dispose();
			}
			base.Dispose(disposing);
		}

		private void InitializeComponent()
		{
			this.components = new System.ComponentModel.Container();
			System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(OptionFVV.FormBoard));
			this.dataGridViewBoard = new System.Windows.Forms.DataGridView();
			this.splitContainer1 = new System.Windows.Forms.SplitContainer();
			this.comboBoxExpirationDate = new System.Windows.Forms.ComboBox();
			this.label4 = new System.Windows.Forms.Label();
			this.comboBoxBaseAsset = new System.Windows.Forms.ComboBox();
			this.label3 = new System.Windows.Forms.Label();
			this.label2 = new System.Windows.Forms.Label();
			this.comboBoxThemeBoard = new System.Windows.Forms.ComboBox();
			this.groupBoxInformation = new System.Windows.Forms.GroupBox();
			this.richTextBoxInformation = new System.Windows.Forms.RichTextBox();
			this.comboBoxQuantity = new System.Windows.Forms.ComboBox();
			this.label1 = new System.Windows.Forms.Label();
			this.splitContainer2 = new System.Windows.Forms.SplitContainer();
			this.groupBoxBoard = new System.Windows.Forms.GroupBox();
			this.comboBox1 = new System.Windows.Forms.ComboBox();
			this.groupBoxFutures = new System.Windows.Forms.GroupBox();
			this.dataGridViewFutures = new System.Windows.Forms.DataGridView();
			this.contextMenuStripBoard = new System.Windows.Forms.ContextMenuStrip(this.components);
			this.добавитьВПортфельToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
			this.ToolStripMenuItemGlass = new System.Windows.Forms.ToolStripMenuItem();
			this.contextMenuStripFuture = new System.Windows.Forms.ContextMenuStrip(this.components);
			this.добавитьВПортфельToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
			this.ToolStripMenuItemGlass1 = new System.Windows.Forms.ToolStripMenuItem();
			((System.ComponentModel.ISupportInitialize)this.dataGridViewBoard).BeginInit();
			((System.ComponentModel.ISupportInitialize)this.splitContainer1).BeginInit();
			this.splitContainer1.Panel1.SuspendLayout();
			this.splitContainer1.Panel2.SuspendLayout();
			this.splitContainer1.SuspendLayout();
			this.groupBoxInformation.SuspendLayout();
			((System.ComponentModel.ISupportInitialize)this.splitContainer2).BeginInit();
			this.splitContainer2.Panel1.SuspendLayout();
			this.splitContainer2.Panel2.SuspendLayout();
			this.splitContainer2.SuspendLayout();
			this.groupBoxBoard.SuspendLayout();
			this.groupBoxFutures.SuspendLayout();
			((System.ComponentModel.ISupportInitialize)this.dataGridViewFutures).BeginInit();
			this.contextMenuStripBoard.SuspendLayout();
			this.contextMenuStripFuture.SuspendLayout();
			base.SuspendLayout();
			this.dataGridViewBoard.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
			this.dataGridViewBoard.Dock = System.Windows.Forms.DockStyle.Fill;
			this.dataGridViewBoard.Location = new System.Drawing.Point(3, 16);
			this.dataGridViewBoard.Name = "dataGridViewBoard";
			this.dataGridViewBoard.Size = new System.Drawing.Size(862, 519);
			this.dataGridViewBoard.TabIndex = 0;
			this.splitContainer1.Dock = System.Windows.Forms.DockStyle.Fill;
			this.splitContainer1.FixedPanel = System.Windows.Forms.FixedPanel.Panel1;
			this.splitContainer1.Location = new System.Drawing.Point(0, 0);
			this.splitContainer1.Name = "splitContainer1";
			this.splitContainer1.Panel1.Controls.Add(this.comboBoxExpirationDate);
			this.splitContainer1.Panel1.Controls.Add(this.label4);
			this.splitContainer1.Panel1.Controls.Add(this.comboBoxBaseAsset);
			this.splitContainer1.Panel1.Controls.Add(this.label3);
			this.splitContainer1.Panel1.Controls.Add(this.label2);
			this.splitContainer1.Panel1.Controls.Add(this.comboBoxThemeBoard);
			this.splitContainer1.Panel1.Controls.Add(this.groupBoxInformation);
			this.splitContainer1.Panel1.Controls.Add(this.comboBoxQuantity);
			this.splitContainer1.Panel1.Controls.Add(this.label1);
			this.splitContainer1.Panel2.Controls.Add(this.splitContainer2);
			this.splitContainer1.Size = new System.Drawing.Size(1266, 538);
			this.splitContainer1.SplitterDistance = 215;
			this.splitContainer1.TabIndex = 1;
			this.comboBoxExpirationDate.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
			this.comboBoxExpirationDate.FormattingEnabled = true;
			this.comboBoxExpirationDate.Location = new System.Drawing.Point(114, 87);
			this.comboBoxExpirationDate.Name = "comboBoxExpirationDate";
			this.comboBoxExpirationDate.Size = new System.Drawing.Size(92, 21);
			this.comboBoxExpirationDate.TabIndex = 2;
			this.comboBoxExpirationDate.Click += new System.EventHandler(comboBoxExpirationDate_Click);
			this.label4.AutoSize = true;
			this.label4.Location = new System.Drawing.Point(12, 90);
			this.label4.Name = "label4";
			this.label4.Size = new System.Drawing.Size(96, 13);
			this.label4.TabIndex = 2;
			this.label4.Text = "Дата экспирации";
			this.comboBoxBaseAsset.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
			this.comboBoxBaseAsset.FormattingEnabled = true;
			this.comboBoxBaseAsset.Location = new System.Drawing.Point(116, 60);
			this.comboBoxBaseAsset.Name = "comboBoxBaseAsset";
			this.comboBoxBaseAsset.Size = new System.Drawing.Size(90, 21);
			this.comboBoxBaseAsset.TabIndex = 2;
			this.comboBoxBaseAsset.Click += new System.EventHandler(comboBoxBaseAsset_Click);
			this.label3.AutoSize = true;
			this.label3.Location = new System.Drawing.Point(12, 63);
			this.label3.Name = "label3";
			this.label3.Size = new System.Drawing.Size(84, 13);
			this.label3.TabIndex = 2;
			this.label3.Text = "Базовый актив";
			this.label2.AutoSize = true;
			this.label2.Location = new System.Drawing.Point(12, 36);
			this.label2.Name = "label2";
			this.label2.Size = new System.Drawing.Size(59, 13);
			this.label2.TabIndex = 2;
			this.label2.Text = "Вид доски";
			this.comboBoxThemeBoard.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
			this.comboBoxThemeBoard.FormattingEnabled = true;
			this.comboBoxThemeBoard.Items.AddRange(new object[2] { "Classic", "Viktor" });
			this.comboBoxThemeBoard.Location = new System.Drawing.Point(116, 33);
			this.comboBoxThemeBoard.Name = "comboBoxThemeBoard";
			this.comboBoxThemeBoard.Size = new System.Drawing.Size(90, 21);
			this.comboBoxThemeBoard.TabIndex = 0;
			this.groupBoxInformation.Controls.Add(this.richTextBoxInformation);
			this.groupBoxInformation.Location = new System.Drawing.Point(3, 114);
			this.groupBoxInformation.Name = "groupBoxInformation";
			this.groupBoxInformation.Size = new System.Drawing.Size(203, 412);
			this.groupBoxInformation.TabIndex = 2;
			this.groupBoxInformation.TabStop = false;
			this.groupBoxInformation.Text = "Информация";
			this.richTextBoxInformation.BackColor = System.Drawing.SystemColors.Window;
			this.richTextBoxInformation.Dock = System.Windows.Forms.DockStyle.Fill;
			this.richTextBoxInformation.Location = new System.Drawing.Point(3, 16);
			this.richTextBoxInformation.Name = "richTextBoxInformation";
			this.richTextBoxInformation.Size = new System.Drawing.Size(197, 393);
			this.richTextBoxInformation.TabIndex = 2;
			this.richTextBoxInformation.Text = "";
			this.comboBoxQuantity.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
			this.comboBoxQuantity.FormattingEnabled = true;
			this.comboBoxQuantity.Items.AddRange(new object[7] { "5", "10", "15", "20", "25", "30", "50" });
			this.comboBoxQuantity.Location = new System.Drawing.Point(135, 6);
			this.comboBoxQuantity.Name = "comboBoxQuantity";
			this.comboBoxQuantity.Size = new System.Drawing.Size(71, 21);
			this.comboBoxQuantity.TabIndex = 2;
			this.label1.AutoSize = true;
			this.label1.Location = new System.Drawing.Point(12, 9);
			this.label1.Name = "label1";
			this.label1.Size = new System.Drawing.Size(98, 13);
			this.label1.TabIndex = 1;
			this.label1.Text = "Количество строк";
			this.splitContainer2.Dock = System.Windows.Forms.DockStyle.Fill;
			this.splitContainer2.Location = new System.Drawing.Point(0, 0);
			this.splitContainer2.Name = "splitContainer2";
			this.splitContainer2.Panel1.Controls.Add(this.groupBoxBoard);
			this.splitContainer2.Panel2.Controls.Add(this.groupBoxFutures);
			this.splitContainer2.Size = new System.Drawing.Size(1047, 538);
			this.splitContainer2.SplitterDistance = 868;
			this.splitContainer2.TabIndex = 1;
			this.groupBoxBoard.Controls.Add(this.comboBox1);
			this.groupBoxBoard.Controls.Add(this.dataGridViewBoard);
			this.groupBoxBoard.Dock = System.Windows.Forms.DockStyle.Fill;
			this.groupBoxBoard.Location = new System.Drawing.Point(0, 0);
			this.groupBoxBoard.Name = "groupBoxBoard";
			this.groupBoxBoard.Size = new System.Drawing.Size(868, 538);
			this.groupBoxBoard.TabIndex = 0;
			this.groupBoxBoard.TabStop = false;
			this.groupBoxBoard.Text = "Доска опционов";
			this.comboBox1.FormattingEnabled = true;
			this.comboBox1.Location = new System.Drawing.Point(-41, 6);
			this.comboBox1.Name = "comboBox1";
			this.comboBox1.Size = new System.Drawing.Size(34, 21);
			this.comboBox1.TabIndex = 1;
			this.groupBoxFutures.Controls.Add(this.dataGridViewFutures);
			this.groupBoxFutures.Dock = System.Windows.Forms.DockStyle.Fill;
			this.groupBoxFutures.Location = new System.Drawing.Point(0, 0);
			this.groupBoxFutures.Name = "groupBoxFutures";
			this.groupBoxFutures.Size = new System.Drawing.Size(175, 538);
			this.groupBoxFutures.TabIndex = 0;
			this.groupBoxFutures.TabStop = false;
			this.groupBoxFutures.Text = "Информация по фьючерсу";
			this.dataGridViewFutures.AllowUserToAddRows = false;
			this.dataGridViewFutures.AllowUserToDeleteRows = false;
			this.dataGridViewFutures.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
			this.dataGridViewFutures.Dock = System.Windows.Forms.DockStyle.Fill;
			this.dataGridViewFutures.Location = new System.Drawing.Point(3, 16);
			this.dataGridViewFutures.Name = "dataGridViewFutures";
			this.dataGridViewFutures.ReadOnly = true;
			this.dataGridViewFutures.Size = new System.Drawing.Size(169, 519);
			this.dataGridViewFutures.TabIndex = 0;
			this.contextMenuStripBoard.Items.AddRange(new System.Windows.Forms.ToolStripItem[2] { this.добавитьВПортфельToolStripMenuItem, this.ToolStripMenuItemGlass });
			this.contextMenuStripBoard.Name = "contextMenuStripBoard";
			this.contextMenuStripBoard.Size = new System.Drawing.Size(193, 48);
			this.добавитьВПортфельToolStripMenuItem.Image = (System.Drawing.Image)resources.GetObject("добавитьВПортфельToolStripMenuItem.Image");
			this.добавитьВПортфельToolStripMenuItem.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
			this.добавитьВПортфельToolStripMenuItem.Name = "добавитьВПортфельToolStripMenuItem";
			this.добавитьВПортфельToolStripMenuItem.Size = new System.Drawing.Size(192, 22);
			this.добавитьВПортфельToolStripMenuItem.Text = "Добавить в портфель";
			this.добавитьВПортфельToolStripMenuItem.Click += new System.EventHandler(добавитьВПортфельToolStripMenuItem_Click);
			this.ToolStripMenuItemGlass.Name = "ToolStripMenuItemGlass";
			this.ToolStripMenuItemGlass.Size = new System.Drawing.Size(192, 22);
			this.ToolStripMenuItemGlass.Text = "Стакан";
			this.ToolStripMenuItemGlass.Click += new System.EventHandler(ToolStripMenuItemGlass_Click);
			this.contextMenuStripFuture.Items.AddRange(new System.Windows.Forms.ToolStripItem[2] { this.добавитьВПортфельToolStripMenuItem1, this.ToolStripMenuItemGlass1 });
			this.contextMenuStripFuture.Name = "contextMenuStripFuture";
			this.contextMenuStripFuture.Size = new System.Drawing.Size(193, 48);
			this.добавитьВПортфельToolStripMenuItem1.Image = (System.Drawing.Image)resources.GetObject("добавитьВПортфельToolStripMenuItem1.Image");
			this.добавитьВПортфельToolStripMenuItem1.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
			this.добавитьВПортфельToolStripMenuItem1.Name = "добавитьВПортфельToolStripMenuItem1";
			this.добавитьВПортфельToolStripMenuItem1.Size = new System.Drawing.Size(192, 22);
			this.добавитьВПортфельToolStripMenuItem1.Text = "Добавить в портфель";
			this.добавитьВПортфельToolStripMenuItem1.Click += new System.EventHandler(добавитьВПортфельToolStripMenuItem1_Click);
			this.ToolStripMenuItemGlass1.Name = "ToolStripMenuItemGlass1";
			this.ToolStripMenuItemGlass1.Size = new System.Drawing.Size(192, 22);
			this.ToolStripMenuItemGlass1.Text = "Стакан";
			this.ToolStripMenuItemGlass1.Click += new System.EventHandler(ToolStripMenuItemGlass1_Click);
			base.AutoScaleDimensions = new System.Drawing.SizeF(6f, 13f);
			base.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
			base.ClientSize = new System.Drawing.Size(1266, 538);
			base.Controls.Add(this.splitContainer1);
			base.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
			base.Name = "FormBoard";
			this.Text = "Board";
			base.Load += new System.EventHandler(Board_Load);
			((System.ComponentModel.ISupportInitialize)this.dataGridViewBoard).EndInit();
			this.splitContainer1.Panel1.ResumeLayout(false);
			this.splitContainer1.Panel1.PerformLayout();
			this.splitContainer1.Panel2.ResumeLayout(false);
			((System.ComponentModel.ISupportInitialize)this.splitContainer1).EndInit();
			this.splitContainer1.ResumeLayout(false);
			this.groupBoxInformation.ResumeLayout(false);
			this.splitContainer2.Panel1.ResumeLayout(false);
			this.splitContainer2.Panel2.ResumeLayout(false);
			((System.ComponentModel.ISupportInitialize)this.splitContainer2).EndInit();
			this.splitContainer2.ResumeLayout(false);
			this.groupBoxBoard.ResumeLayout(false);
			this.groupBoxFutures.ResumeLayout(false);
			((System.ComponentModel.ISupportInitialize)this.dataGridViewFutures).EndInit();
			this.contextMenuStripBoard.ResumeLayout(false);
			this.contextMenuStripFuture.ResumeLayout(false);
			base.ResumeLayout(false);
		}
	}
}
