using System;
using System.ComponentModel;
using System.Drawing;
using System.Windows.Forms;

namespace OptionFVV
{
	public class FormCalculator : Form
	{
		private IContainer components = null;

		private Panel panelOptionCalculator1;

		private GroupBox groupBoxResult;

		private TextBox textBoxResultVola;

		private Label label6;

		private Label label12;

		private TextBox textBoxResultVomma;

		private TextBox textBoxResultTheo;

		private TextBox textBoxResultTheta;

		private Label label11;

		private Label label7;

		private TextBox textBoxResultVega;

		private TextBox textBoxResultDelta;

		private Label label10;

		private TextBox textBoxResultGamma;

		private Label label8;

		private Label label9;

		private GroupBox groupBoxSet;

		private Label label1;

		private ComboBox comboBoxTypeO;

		private TextBox textBoxDate;

		private Label label2;

		private TextBox textBoxDateExp;

		private Label label3;

		private TextBox textBoxStrike;

		private Label label4;

		private TextBox textBoxLastF;

		private Label label5;

		private TextBox textBoxVolaO;

		private RadioButton radioButtonVola;

		private TextBox textBoxTheo;

		private RadioButton radioButtonTheo;

		private Button buttonСalculate;

		public FormCalculator()
		{
			CallBackMy.callbackEventHandlerColorThemeFormCalculator = PaintColorTheme;
			InitializeComponent();
		}

		private void FormCalculator_Load(object sender, EventArgs e)
		{
			base.FormBorderStyle = FormBorderStyle.None;
			Dock = DockStyle.Fill;
			textBoxDateExp.Text = NearestThursday().ToString("dd.MM.yyyy HH:mm");
			PaintColorTheme();
		}

		private void buttonСalculate_Click(object sender, EventArgs e)
		{
			ClassCalculationOptions calculationOptions = new ClassCalculationOptions();
			bool flag = true;
			double result1 = 0.0;
			double result2 = 0.0;
			double num1 = 0.0;
			double num2 = 0.0;
			double num3 = 0.0;
			double num4 = 0.0;
			double num5 = 0.0;
			double result3 = 0.0;
			double result4 = 0.0;
			string text = comboBoxTypeO.Text;
			if (double.TryParse(textBoxStrike.Text, out result1))
			{
				if (result1 <= 0.0)
				{
					int num6 = (int)MessageBox.Show("Не корректно введен страйк. Страйк должен быть больше нуля");
					flag = false;
				}
			}
			else
			{
				int num7 = (int)MessageBox.Show("Не корректно введен страйк. Страйк должен быть числом");
				flag = false;
			}
			DateTime result5;
			if (!DateTime.TryParse(textBoxDateExp.Text, out result5))
			{
				int num8 = (int)MessageBox.Show("Не корректно введена дата экспирации. Формат должен быть таким 19:00 01.01.2001");
				flag = false;
			}
			DateTime result6;
			if (DateTime.TryParse(textBoxDate.Text, out result6))
			{
				if (result6 >= result5)
				{
					int num9 = (int)MessageBox.Show("Не корректно введена дата рассчета. Дата рассчета должна быть меныше даты экспирации");
					flag = false;
				}
			}
			else
			{
				int num10 = (int)MessageBox.Show("Не корректно введена дата рассчета. Формат должен быть таким 19:00 01.01.2001");
				flag = false;
			}
			if (double.TryParse(textBoxLastF.Text, out result4))
			{
				if (result4 <= 0.0)
				{
					int num11 = (int)MessageBox.Show("Не корректно введена цена фьючерса. Цена фьючерса должна быть больше нуля");
					flag = false;
				}
			}
			else
			{
				int num12 = (int)MessageBox.Show("Не корректно введена цена фьючерса. Должно быть число больше 0");
				flag = false;
			}
			int num13 = 1;
			calculationOptions.TypeO = text;
			calculationOptions.Strike = result1;
			calculationOptions.DateExp = result5;
			calculationOptions.DateCurrent = result6;
			calculationOptions.LastF = result4;
			calculationOptions.Q = num13;
			if (radioButtonVola.Checked)
			{
				if (double.TryParse(textBoxVolaO.Text, out result3))
				{
					if (result3 <= 0.0)
					{
						int num14 = (int)MessageBox.Show("Не корректно введена волатильность. Волатильность должна быть больше 0");
						flag = false;
					}
				}
				else
				{
					int num15 = (int)MessageBox.Show("Не корректно введена волатильность. Должно быть число больше 0");
					flag = false;
				}
				calculationOptions.VolaO = result3;
				if (flag)
				{
					if (calculationOptions.CalculationOpt())
					{
						result2 = Math.Round(calculationOptions.calcTheoPrice, 3);
						num1 = Math.Round(calculationOptions.calcDelta, 2);
						num2 = Math.Round(calculationOptions.calcGamma, 6);
						num3 = Math.Round(calculationOptions.calcVega, 2);
						num4 = Math.Round(calculationOptions.calcTheta, 2);
						num5 = Math.Round(calculationOptions.calcVomma, 4);
					}
					else
					{
						int num16 = (int)MessageBox.Show(calculationOptions.calcMessageError);
						flag = false;
					}
				}
			}
			else
			{
				if (double.TryParse(textBoxTheo.Text, out result2))
				{
					if (result2 <= 0.0)
					{
						int num17 = (int)MessageBox.Show("Не корректно введена теоретическая цена. Она должна быть больше 0");
						flag = false;
					}
				}
				else
				{
					int num18 = (int)MessageBox.Show("Не корректно введена теоретическая цена. Должно быть число больше 0");
					flag = false;
				}
				calculationOptions.Theo = result2;
				if (flag)
				{
					if (calculationOptions.CalculationVola())
					{
						result3 = Math.Round(calculationOptions.calcVola, 2);
						num1 = Math.Round(calculationOptions.calcDelta, 2);
						num2 = Math.Round(calculationOptions.calcGamma, 6);
						num3 = Math.Round(calculationOptions.calcVega, 2);
						num4 = Math.Round(calculationOptions.calcTheta, 2);
						num5 = Math.Round(calculationOptions.calcVomma, 4);
					}
					else
					{
						int num19 = (int)MessageBox.Show(calculationOptions.calcMessageError);
						flag = false;
					}
				}
			}
			if (flag)
			{
				textBoxResultVola.Text = string.Format("{0:0.##}", result3);
				textBoxResultTheo.Text = string.Format("{0:0.##}", result2);
				textBoxResultDelta.Text = string.Format("{0:0.##}", num1);
				textBoxResultGamma.Text = string.Format("{0:0.######}", num2);
				textBoxResultVega.Text = string.Format("{0:0.##}", num3);
				textBoxResultTheta.Text = string.Format("{0:0.##}", num4);
				textBoxResultVomma.Text = string.Format("{0:0.####}", num5);
			}
			else
			{
				textBoxResultVola.Text = "";
				textBoxResultTheo.Text = "";
				textBoxResultDelta.Text = "";
				textBoxResultGamma.Text = "";
				textBoxResultVega.Text = "";
				textBoxResultTheta.Text = "";
				textBoxResultVomma.Text = "";
			}
		}

		private void PaintColorTheme()
		{
			BackColor = ClassColorTheme.BackColor;
			ForeColor = ClassColorTheme.HeadersColorFore;
			groupBoxSet.BackColor = ClassColorTheme.BackColor;
			groupBoxSet.ForeColor = ClassColorTheme.BackColorFore;
			panelOptionCalculator1.BackColor = ClassColorTheme.BackColor;
			panelOptionCalculator1.ForeColor = ClassColorTheme.BackColorFore;
			groupBoxResult.BackColor = ClassColorTheme.BackColor;
			groupBoxResult.ForeColor = ClassColorTheme.BackColorFore;
			comboBoxTypeO.FlatStyle = FlatStyle.System;
			buttonСalculate.FlatStyle = FlatStyle.System;
		}

		protected override void Dispose(bool disposing)
		{
			if (disposing && components != null)
			{
				components.Dispose();
			}
			base.Dispose(disposing);
		}

		protected DateTime NearestThursday()
		{
			int daysToAdd = (int)(4 - DateTime.Now.DayOfWeek + 7) % 7;
			DateTime thursday = DateTime.Now.AddDays(daysToAdd);
			return new DateTime(thursday.Year, thursday.Month, thursday.Day, 18, 50, 0);
		}

		private void InitializeComponent()
		{
			this.panelOptionCalculator1 = new System.Windows.Forms.Panel();
			this.groupBoxResult = new System.Windows.Forms.GroupBox();
			this.textBoxResultVola = new System.Windows.Forms.TextBox();
			this.label6 = new System.Windows.Forms.Label();
			this.label12 = new System.Windows.Forms.Label();
			this.textBoxResultVomma = new System.Windows.Forms.TextBox();
			this.textBoxResultTheo = new System.Windows.Forms.TextBox();
			this.textBoxResultTheta = new System.Windows.Forms.TextBox();
			this.label11 = new System.Windows.Forms.Label();
			this.label7 = new System.Windows.Forms.Label();
			this.textBoxResultVega = new System.Windows.Forms.TextBox();
			this.textBoxResultDelta = new System.Windows.Forms.TextBox();
			this.label10 = new System.Windows.Forms.Label();
			this.textBoxResultGamma = new System.Windows.Forms.TextBox();
			this.label8 = new System.Windows.Forms.Label();
			this.label9 = new System.Windows.Forms.Label();
			this.groupBoxSet = new System.Windows.Forms.GroupBox();
			this.label1 = new System.Windows.Forms.Label();
			this.comboBoxTypeO = new System.Windows.Forms.ComboBox();
			this.textBoxDate = new System.Windows.Forms.TextBox();
			this.label2 = new System.Windows.Forms.Label();
			this.textBoxDateExp = new System.Windows.Forms.TextBox();
			this.label3 = new System.Windows.Forms.Label();
			this.textBoxStrike = new System.Windows.Forms.TextBox();
			this.label4 = new System.Windows.Forms.Label();
			this.textBoxLastF = new System.Windows.Forms.TextBox();
			this.label5 = new System.Windows.Forms.Label();
			this.textBoxVolaO = new System.Windows.Forms.TextBox();
			this.radioButtonVola = new System.Windows.Forms.RadioButton();
			this.textBoxTheo = new System.Windows.Forms.TextBox();
			this.radioButtonTheo = new System.Windows.Forms.RadioButton();
			this.buttonСalculate = new System.Windows.Forms.Button();
			this.panelOptionCalculator1.SuspendLayout();
			this.groupBoxResult.SuspendLayout();
			this.groupBoxSet.SuspendLayout();
			base.SuspendLayout();
			this.panelOptionCalculator1.BackColor = System.Drawing.SystemColors.Control;
			this.panelOptionCalculator1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
			this.panelOptionCalculator1.Controls.Add(this.groupBoxResult);
			this.panelOptionCalculator1.Controls.Add(this.groupBoxSet);
			this.panelOptionCalculator1.Controls.Add(this.buttonСalculate);
			this.panelOptionCalculator1.Location = new System.Drawing.Point(12, 12);
			this.panelOptionCalculator1.Name = "panelOptionCalculator1";
			this.panelOptionCalculator1.Size = new System.Drawing.Size(703, 226);
			this.panelOptionCalculator1.TabIndex = 1;
			this.groupBoxResult.Controls.Add(this.textBoxResultVola);
			this.groupBoxResult.Controls.Add(this.label6);
			this.groupBoxResult.Controls.Add(this.label12);
			this.groupBoxResult.Controls.Add(this.textBoxResultVomma);
			this.groupBoxResult.Controls.Add(this.textBoxResultTheo);
			this.groupBoxResult.Controls.Add(this.textBoxResultTheta);
			this.groupBoxResult.Controls.Add(this.label11);
			this.groupBoxResult.Controls.Add(this.label7);
			this.groupBoxResult.Controls.Add(this.textBoxResultVega);
			this.groupBoxResult.Controls.Add(this.textBoxResultDelta);
			this.groupBoxResult.Controls.Add(this.label10);
			this.groupBoxResult.Controls.Add(this.textBoxResultGamma);
			this.groupBoxResult.Controls.Add(this.label8);
			this.groupBoxResult.Controls.Add(this.label9);
			this.groupBoxResult.Location = new System.Drawing.Point(413, 2);
			this.groupBoxResult.Name = "groupBoxResult";
			this.groupBoxResult.Size = new System.Drawing.Size(285, 219);
			this.groupBoxResult.TabIndex = 31;
			this.groupBoxResult.TabStop = false;
			this.groupBoxResult.Text = "Результат";
			this.textBoxResultVola.Location = new System.Drawing.Point(179, 19);
			this.textBoxResultVola.Name = "textBoxResultVola";
			this.textBoxResultVola.Size = new System.Drawing.Size(100, 20);
			this.textBoxResultVola.TabIndex = 23;
			this.label6.AutoSize = true;
			this.label6.Location = new System.Drawing.Point(6, 22);
			this.label6.Name = "label6";
			this.label6.Size = new System.Drawing.Size(84, 13);
			this.label6.TabIndex = 16;
			this.label6.Text = "Волатильность";
			this.label12.AutoSize = true;
			this.label12.Location = new System.Drawing.Point(6, 178);
			this.label12.Name = "label12";
			this.label12.Size = new System.Drawing.Size(42, 13);
			this.label12.TabIndex = 22;
			this.label12.Text = "Вомма";
			this.textBoxResultVomma.Location = new System.Drawing.Point(179, 175);
			this.textBoxResultVomma.Name = "textBoxResultVomma";
			this.textBoxResultVomma.Size = new System.Drawing.Size(100, 20);
			this.textBoxResultVomma.TabIndex = 29;
			this.textBoxResultTheo.Location = new System.Drawing.Point(179, 45);
			this.textBoxResultTheo.Name = "textBoxResultTheo";
			this.textBoxResultTheo.Size = new System.Drawing.Size(100, 20);
			this.textBoxResultTheo.TabIndex = 24;
			this.textBoxResultTheta.Location = new System.Drawing.Point(179, 149);
			this.textBoxResultTheta.Name = "textBoxResultTheta";
			this.textBoxResultTheta.Size = new System.Drawing.Size(100, 20);
			this.textBoxResultTheta.TabIndex = 28;
			this.label11.AutoSize = true;
			this.label11.Location = new System.Drawing.Point(6, 152);
			this.label11.Name = "label11";
			this.label11.Size = new System.Drawing.Size(36, 13);
			this.label11.TabIndex = 21;
			this.label11.Text = "Тетта";
			this.label7.AutoSize = true;
			this.label7.Location = new System.Drawing.Point(6, 48);
			this.label7.Name = "label7";
			this.label7.Size = new System.Drawing.Size(111, 13);
			this.label7.TabIndex = 17;
			this.label7.Text = "Теоретическая цена";
			this.textBoxResultVega.Location = new System.Drawing.Point(179, 123);
			this.textBoxResultVega.Name = "textBoxResultVega";
			this.textBoxResultVega.Size = new System.Drawing.Size(100, 20);
			this.textBoxResultVega.TabIndex = 27;
			this.textBoxResultDelta.Location = new System.Drawing.Point(179, 71);
			this.textBoxResultDelta.Name = "textBoxResultDelta";
			this.textBoxResultDelta.Size = new System.Drawing.Size(100, 20);
			this.textBoxResultDelta.TabIndex = 25;
			this.label10.AutoSize = true;
			this.label10.Location = new System.Drawing.Point(6, 126);
			this.label10.Name = "label10";
			this.label10.Size = new System.Drawing.Size(31, 13);
			this.label10.TabIndex = 20;
			this.label10.Text = "Вега";
			this.textBoxResultGamma.Location = new System.Drawing.Point(179, 97);
			this.textBoxResultGamma.Name = "textBoxResultGamma";
			this.textBoxResultGamma.Size = new System.Drawing.Size(100, 20);
			this.textBoxResultGamma.TabIndex = 26;
			this.label8.AutoSize = true;
			this.label8.Location = new System.Drawing.Point(6, 74);
			this.label8.Name = "label8";
			this.label8.Size = new System.Drawing.Size(45, 13);
			this.label8.TabIndex = 18;
			this.label8.Text = "Дельта";
			this.label9.AutoSize = true;
			this.label9.Location = new System.Drawing.Point(6, 100);
			this.label9.Name = "label9";
			this.label9.Size = new System.Drawing.Size(41, 13);
			this.label9.TabIndex = 19;
			this.label9.Text = "Гамма";
			this.groupBoxSet.Controls.Add(this.label1);
			this.groupBoxSet.Controls.Add(this.comboBoxTypeO);
			this.groupBoxSet.Controls.Add(this.textBoxDate);
			this.groupBoxSet.Controls.Add(this.label2);
			this.groupBoxSet.Controls.Add(this.textBoxDateExp);
			this.groupBoxSet.Controls.Add(this.label3);
			this.groupBoxSet.Controls.Add(this.textBoxStrike);
			this.groupBoxSet.Controls.Add(this.label4);
			this.groupBoxSet.Controls.Add(this.textBoxLastF);
			this.groupBoxSet.Controls.Add(this.label5);
			this.groupBoxSet.Controls.Add(this.textBoxVolaO);
			this.groupBoxSet.Controls.Add(this.radioButtonVola);
			this.groupBoxSet.Controls.Add(this.textBoxTheo);
			this.groupBoxSet.Controls.Add(this.radioButtonTheo);
			this.groupBoxSet.Location = new System.Drawing.Point(3, 3);
			this.groupBoxSet.Name = "groupBoxSet";
			this.groupBoxSet.Size = new System.Drawing.Size(292, 219);
			this.groupBoxSet.TabIndex = 30;
			this.groupBoxSet.TabStop = false;
			this.groupBoxSet.Text = "Ввод параметров";
			this.label1.AutoSize = true;
			this.label1.Location = new System.Drawing.Point(6, 22);
			this.label1.Name = "label1";
			this.label1.Size = new System.Drawing.Size(71, 13);
			this.label1.TabIndex = 2;
			this.label1.Text = "Тип опциона";
			this.comboBoxTypeO.FormattingEnabled = true;
			this.comboBoxTypeO.Items.AddRange(new object[2] { "CALL", "PUT" });
			this.comboBoxTypeO.Location = new System.Drawing.Point(141, 19);
			this.comboBoxTypeO.Name = "comboBoxTypeO";
			this.comboBoxTypeO.Size = new System.Drawing.Size(145, 21);
			this.comboBoxTypeO.TabIndex = 0;
			this.comboBoxTypeO.Text = "CALL";
			this.textBoxDate.Location = new System.Drawing.Point(141, 46);
			this.textBoxDate.Name = "textBoxDate";
			this.textBoxDate.Size = new System.Drawing.Size(145, 20);
			this.textBoxDate.TabIndex = 3;
			this.textBoxDate.Text = System.DateTime.Now.ToString("dd.MM.yyyy HH:mm");
			this.label2.AutoSize = true;
			this.label2.Location = new System.Drawing.Point(6, 49);
			this.label2.Name = "label2";
			this.label2.Size = new System.Drawing.Size(82, 13);
			this.label2.TabIndex = 4;
			this.label2.Text = "Дата рассчета";
			this.textBoxDateExp.Location = new System.Drawing.Point(141, 72);
			this.textBoxDateExp.Name = "textBoxDateExp";
			this.textBoxDateExp.Size = new System.Drawing.Size(145, 20);
			this.textBoxDateExp.TabIndex = 5;
			this.textBoxDateExp.Text = System.DateTime.Now.ToString("dd.MM.yyyy HH:mm");
			this.label3.AutoSize = true;
			this.label3.Location = new System.Drawing.Point(6, 75);
			this.label3.Name = "label3";
			this.label3.Size = new System.Drawing.Size(96, 13);
			this.label3.TabIndex = 6;
			this.label3.Text = "Дата экспирации";
			this.textBoxStrike.Location = new System.Drawing.Point(141, 98);
			this.textBoxStrike.Name = "textBoxStrike";
			this.textBoxStrike.Size = new System.Drawing.Size(145, 20);
			this.textBoxStrike.TabIndex = 7;
			this.textBoxStrike.Text = "90000";
			this.label4.AutoSize = true;
			this.label4.Location = new System.Drawing.Point(6, 101);
			this.label4.Name = "label4";
			this.label4.Size = new System.Drawing.Size(43, 13);
			this.label4.TabIndex = 8;
			this.label4.Text = "Страйк";
			this.textBoxLastF.Location = new System.Drawing.Point(141, 124);
			this.textBoxLastF.Name = "textBoxLastF";
			this.textBoxLastF.Size = new System.Drawing.Size(145, 20);
			this.textBoxLastF.TabIndex = 9;
			this.textBoxLastF.Text = "90000";
			this.label5.AutoSize = true;
			this.label5.Location = new System.Drawing.Point(6, 127);
			this.label5.Name = "label5";
			this.label5.Size = new System.Drawing.Size(87, 13);
			this.label5.TabIndex = 10;
			this.label5.Text = "Цена фьючерса";
			this.textBoxVolaO.Location = new System.Drawing.Point(141, 150);
			this.textBoxVolaO.Name = "textBoxVolaO";
			this.textBoxVolaO.Size = new System.Drawing.Size(145, 20);
			this.textBoxVolaO.TabIndex = 13;
			this.textBoxVolaO.Text = "30";
			this.radioButtonVola.AutoSize = true;
			this.radioButtonVola.Checked = true;
			this.radioButtonVola.Location = new System.Drawing.Point(9, 150);
			this.radioButtonVola.Name = "radioButtonVola";
			this.radioButtonVola.Size = new System.Drawing.Size(102, 17);
			this.radioButtonVola.TabIndex = 11;
			this.radioButtonVola.TabStop = true;
			this.radioButtonVola.Text = "Волатильность";
			this.radioButtonVola.UseVisualStyleBackColor = true;
			this.textBoxTheo.Location = new System.Drawing.Point(141, 176);
			this.textBoxTheo.Name = "textBoxTheo";
			this.textBoxTheo.Size = new System.Drawing.Size(145, 20);
			this.textBoxTheo.TabIndex = 14;
			this.textBoxTheo.Text = "2500";
			this.radioButtonTheo.AutoSize = true;
			this.radioButtonTheo.Location = new System.Drawing.Point(9, 179);
			this.radioButtonTheo.Name = "radioButtonTheo";
			this.radioButtonTheo.Size = new System.Drawing.Size(129, 17);
			this.radioButtonTheo.TabIndex = 12;
			this.radioButtonTheo.TabStop = true;
			this.radioButtonTheo.Text = "Теоретическая цена";
			this.radioButtonTheo.UseVisualStyleBackColor = true;
			this.buttonСalculate.Location = new System.Drawing.Point(318, 101);
			this.buttonСalculate.Name = "buttonСalculate";
			this.buttonСalculate.Size = new System.Drawing.Size(75, 23);
			this.buttonСalculate.TabIndex = 15;
			this.buttonСalculate.Text = "Рассчитать";
			this.buttonСalculate.UseVisualStyleBackColor = true;
			this.buttonСalculate.Click += new System.EventHandler(buttonСalculate_Click);
			base.AutoScaleDimensions = new System.Drawing.SizeF(6f, 13f);
			base.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
			base.ClientSize = new System.Drawing.Size(727, 455);
			base.Controls.Add(this.panelOptionCalculator1);
			this.Cursor = System.Windows.Forms.Cursors.Default;
			base.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
			base.Load += new System.EventHandler(FormCalculator_Load);
			this.panelOptionCalculator1.ResumeLayout(false);
			this.groupBoxResult.ResumeLayout(false);
			this.groupBoxResult.PerformLayout();
			this.groupBoxSet.ResumeLayout(false);
			this.groupBoxSet.PerformLayout();
			base.ResumeLayout(false);
		}
	}
}
