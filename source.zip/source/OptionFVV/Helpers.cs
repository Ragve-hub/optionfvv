using System.Collections.Generic;

namespace OptionFVV
{
	public class Helpers
	{
		public static bool IsFutures(string paper_code)
		{
			return paper_code.Length == 4 || paper_code.Contains("_CLT");
		}

		public static bool IsOption(string paper_code)
		{
			return paper_code.Length > 4 && !paper_code.Contains("_CLT");
		}

		public static bool IsSpotOption(string paper_code)
		{
			string letter = paper_code.Substring(paper_code.Length - 4, 1);
			return letter == "C";
		}

		public static string MapCodeClt(string fut_base_code)
		{
			Dictionary<string, string> codes = new Dictionary<string, string>
			{
				{ "SBRF", "SBER" },
				{ "GAZR", "GAZP" },
				{ "SBPR", "SBERP" },
				{ "TCSI", "TCSG" },
				{ "SNGR", "SNGS" },
				{ "SNGP", "SNGSP" },
				{ "TRNF", "TRNFP" },
				{ "YNDF", "YNDX" }
			};
			string newCode;
			if (!codes.TryGetValue(fut_base_code, out newCode))
			{
				return fut_base_code;
			}
			return newCode;
		}

		public static bool CheckHasClt(string fut_base_code)
		{
			List<string> hasCollaterals = new List<string>
			{
				"AFKS", "AFLT", "ALRS", "CHMF", "DSKY", "FEES", "FIVE", "GAZR", "GMKN", "HYDR",
				"IRAO", "LKOH", "MAGN", "MAIL", "MGNT", "MOEX", "MTLR", "MTSI", "NLMK", "NOTK",
				"OZON", "PHOR", "PIKK", "PLZL", "POLY", "POSI", "ROSN", "RSTI", "RTKM", "RUAL",
				"SBPR", "SBRF", "SIBN", "SMLT", "SNGP", "SNGR", "SPBE", "TATN", "TCSI", "TRNF",
				"VTBR", "YNDF"
			};
			return hasCollaterals.Contains(fut_base_code);
		}
	}
}
