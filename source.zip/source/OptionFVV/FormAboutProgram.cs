using System;
using System.ComponentModel;
using System.Drawing;
using System.Windows.Forms;

namespace OptionFVV
{
	public class FormAboutProgram : Form
	{
		private IContainer components = null;

		private PictureBox pictureBox1;

		private RichTextBox richTextBoxInformation;

		private Button button1;

		public FormAboutProgram()
		{
			InitializeComponent();
		}

		private void FormAboutProgram_Load(object sender, EventArgs e)
		{
			PaintColorTheme();
		}

		private void PaintColorTheme()
		{
			BackColor = ClassColorTheme.BackColor;
			ForeColor = ClassColorTheme.HeadersColorFore;
			richTextBoxInformation.BackColor = ClassColorTheme.BackColor;
			richTextBoxInformation.ForeColor = ClassColorTheme.BackColorFore;
		}

		private void richTextBoxInformation_TextChanged(object sender, EventArgs e)
		{
		}

		protected override void Dispose(bool disposing)
		{
			if (disposing && components != null)
			{
				components.Dispose();
			}
			base.Dispose(disposing);
		}

		private void InitializeComponent()
		{
			System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(OptionFVV.FormAboutProgram));
			this.pictureBox1 = new System.Windows.Forms.PictureBox();
			this.richTextBoxInformation = new System.Windows.Forms.RichTextBox();
			this.button1 = new System.Windows.Forms.Button();
			((System.ComponentModel.ISupportInitialize)this.pictureBox1).BeginInit();
			base.SuspendLayout();
			this.pictureBox1.Dock = System.Windows.Forms.DockStyle.Right;
			this.pictureBox1.Image = (System.Drawing.Image)resources.GetObject("pictureBox1.Image");
			this.pictureBox1.Location = new System.Drawing.Point(279, 0);
			this.pictureBox1.Name = "pictureBox1";
			this.pictureBox1.Size = new System.Drawing.Size(387, 510);
			this.pictureBox1.TabIndex = 1;
			this.pictureBox1.TabStop = false;
			this.richTextBoxInformation.BorderStyle = System.Windows.Forms.BorderStyle.None;
			this.richTextBoxInformation.Location = new System.Drawing.Point(12, 14);
			this.richTextBoxInformation.Name = "richTextBoxInformation";
			this.richTextBoxInformation.ReadOnly = true;
			this.richTextBoxInformation.Size = new System.Drawing.Size(249, 374);
			this.richTextBoxInformation.TabIndex = 2;
			this.richTextBoxInformation.Text = resources.GetString("richTextBoxInformation.Text");
			this.richTextBoxInformation.TextChanged += new System.EventHandler(richTextBoxInformation_TextChanged);
			this.button1.DialogResult = System.Windows.Forms.DialogResult.OK;
			this.button1.Location = new System.Drawing.Point(108, 445);
			this.button1.Name = "button1";
			this.button1.Size = new System.Drawing.Size(75, 23);
			this.button1.TabIndex = 3;
			this.button1.Text = "OK";
			this.button1.UseVisualStyleBackColor = true;
			base.AcceptButton = this.button1;
			base.AutoScaleDimensions = new System.Drawing.SizeF(6f, 13f);
			base.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
			base.CancelButton = this.button1;
			base.ClientSize = new System.Drawing.Size(666, 510);
			base.Controls.Add(this.button1);
			base.Controls.Add(this.richTextBoxInformation);
			base.Controls.Add(this.pictureBox1);
			base.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog;
			base.Icon = (System.Drawing.Icon)resources.GetObject("$this.Icon");
			base.MaximizeBox = false;
			base.MinimizeBox = false;
			base.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent;
			this.Text = "О программе";
			base.Load += new System.EventHandler(FormAboutProgram_Load);
			((System.ComponentModel.ISupportInitialize)this.pictureBox1).EndInit();
			base.ResumeLayout(false);
		}
	}
}
