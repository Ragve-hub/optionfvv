using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Windows.Forms;
using System.Windows.Forms.DataVisualization.Charting;
using QuikDDE.Data;

namespace OptionFVV
{
	public class FormGlass : Form
	{
		private delegate void SetTextCallback(string text);

		private delegate void SetDrawLineOrder(Order f_ApplicationPaper);

		public struct Chart
		{
			public string name;

			public double X;

			public double Y_demand;

			public double Y_sentence;

			public double Y_IV;

			public double Y_HV;

			public double Y_Application;

			public double Y_TransactionBuy;

			public double Y_TransactionSell;
		}

		public struct Settings
		{
			public string paper_code;

			public string base_asset;

			public DateTime expiration_date;

			public double strike;

			public string option_type;

			public string strategy;

			public double step_price;

			public double show_indent;

			public bool check;
		}

		public static string ClientCode;

		private Trans2Quik trans_2_quik = new Trans2Quik();

		public static string gAccount;

		private string gType;

		public string gTransID;

		private string gClassCode;

		private string gSecCode;

		private string gAction;

		private string gOperation;

		private string gPrice;

		private string gQuantity;

		public string gStrategy;

		private bool F_Start;

		private bool F_SubscribeOrders;

		private bool F_SubscribeTrades;

		private int iTimerGlass;

		private double quantityPoints;

		private int Lots;

		private double PriceApplication;

		private double SelectPriceApplication;

		private double SelectNumberApplication;

		private double showProc = 10.0;

		private ClassDataDDE cDataDDE = new ClassDataDDE(false);

		private ClassCalculationOptions cCalculationOptions = new ClassCalculationOptions();

		private List<Order> ApplicationTable = new List<Order>();

		private Order ApplicationPaper = default(Order);

		private List<Chart> ChartTable = new List<Chart>();

		private Chart ChartPaper = default(Chart);

		private Settings SettingsGlass = default(Settings);

		private IContainer components = null;

		private RichTextBox richTextBoxInformationTransaction;

		private Label labelCodePaper;

		private Label label3;

		private Label label4;

		private ComboBox comboBoxBaseAsset;

		private ComboBox comboBoxExpirationDate;

		private Label label5;

		private ComboBox comboBoxStrike;

		private ComboBox comboBoxOptionType;

		private Label label6;

		private ComboBox comboBoxStrategy;

		private TabControl tabControlGlass;

		private TabPage tabPageGlass;

		private TabPage tabPageSettings;

		private StatusStrip statusStrip1;

		private ToolStripStatusLabel toolStripStatusLabelInformation;

		private ToolStripStatusLabel toolStripStatusLabelStatusDLL;

		private ToolStripStatusLabel toolStripStatusLabelEmpty;

		private System.Windows.Forms.DataVisualization.Charting.Chart chart1;

		private NumericUpDown numericUpDownQuantity;

		private Label label8;

		private Button buttonApply;

		private RadioButton radioButtonSell;

		private RadioButton radioButtonBuy;

		private ContextMenuStrip contextMenuStripChart;

		private ToolStripMenuItem ToolStripMenuItemApplication;

		private ToolStripMenuItem ToolStripMenuItemDelete;

		private Button buttonShowIndentLess;

		private Button buttonShowIndentMore;

		private TextBox textBoxShowIndent;

		public string Account
		{
			get
			{
				return gAccount;
			}
			set
			{
				gAccount = value;
			}
		}

		public string Type
		{
			get
			{
				return gType;
			}
			set
			{
				gType = value;
			}
		}

		public string TransID
		{
			get
			{
				return gTransID;
			}
			set
			{
				gTransID = value;
			}
		}

		public string ClassCode
		{
			get
			{
				return gClassCode;
			}
			set
			{
				gClassCode = value;
			}
		}

		public string SecCode
		{
			get
			{
				return gSecCode;
			}
			set
			{
				gSecCode = value;
			}
		}

		public string Action
		{
			get
			{
				return gAction;
			}
			set
			{
				gAction = value;
			}
		}

		public string Operation
		{
			get
			{
				return gOperation;
			}
			set
			{
				gOperation = value;
			}
		}

		public string Price
		{
			get
			{
				return gPrice;
			}
			set
			{
				gPrice = value;
			}
		}

		public string Quantity
		{
			get
			{
				return gQuantity;
			}
			set
			{
				gQuantity = value;
			}
		}

		public string Strategy
		{
			get
			{
				return gStrategy;
			}
			set
			{
				gStrategy = value;
			}
		}

		public FormGlass(string paper_code, int fTransID)
		{
			gAccount = ClassSettings.gAccount;
			gType = "L";
			gTransID = Convert.ToString(fTransID);
			if (Helpers.IsFutures(paper_code))
			{
				gClassCode = "SPBFUT";
			}
			else if (Helpers.IsOption(paper_code))
			{
				gClassCode = "SPBOPT";
			}
			gSecCode = "";
			gAction = "NEW_ORDER";
			gOperation = "";
			gPrice = "";
			gQuantity = "";
			gStrategy = "";
			F_Start = false;
			Lots = 0;
			InitializeComponent();
			EraseSettingsGlass();
			ChartTable.Clear();
			quantityPoints = 30.0;
			if (paper_code.Length > 0)
			{
				FillSettings(paper_code);
				if (SettingsGlass.check)
				{
					F_Start = true;
				}
			}
		}

		private void FormGlass_Load(object sender, EventArgs e)
		{
			iTimerGlass = 0;
			EraseChartPaper();
			ChartTable.Clear();
			ApplicationTable.Clear();
			F_SubscribeOrders = false;
			F_SubscribeTrades = false;
			radioButtonBuy.Checked = false;
			radioButtonSell.Checked = false;
			numericUpDownQuantity.Value = 1m;
			toolStripStatusLabelStatusDLL.BackColor = Color.Yellow;
			toolStripStatusLabelStatusDLL.Text = "dll";
			textBoxShowIndent.Text = Convert.ToString(showProc);
			chart1.BackColor = ClassColorTheme.BackColor;
			chart1.BackSecondaryColor = ClassColorTheme.BackColor;
			chart1.ForeColor = ClassColorTheme.BackColorFore;
			chart1.ChartAreas[0].AxisX.LabelStyle.ForeColor = ClassColorTheme.BackColorFore;
			chart1.ChartAreas[0].AxisY.LabelStyle.ForeColor = ClassColorTheme.BackColorFore;
			chart1.ChartAreas[0].AxisX.TitleForeColor = ClassColorTheme.BackColorFore;
			chart1.ChartAreas[0].AxisY.TitleForeColor = ClassColorTheme.BackColorFore;
			chart1.ChartAreas[0].AxisX.MajorGrid.LineColor = ClassColorTheme.ChartGridColor;
			chart1.ChartAreas[0].AxisY.MajorGrid.LineColor = ClassColorTheme.ChartGridColor;
			chart1.ChartAreas[0].AxisX.LineColor = ClassColorTheme.ChartGridColor;
			chart1.ChartAreas[0].AxisX.LineWidth = 2;
			chart1.ChartAreas[0].AxisY.LineColor = ClassColorTheme.ChartGridColor;
			chart1.ChartAreas[0].AxisY.LineWidth = 2;
			chart1.ChartAreas[0].Name = "ChartAreas1";
			chart1.ChartAreas[0].BackColor = ClassColorTheme.BackColor;
			chart1.Titles.Add("Ведущий стакан");
			chart1.Titles[0].Font = new Font("Arial", 10f);
			chart1.Titles[0].ForeColor = ClassColorTheme.BackColorFore;
			chart1.Legends[0].Enabled = false;
			SeriesCollection series1 = chart1.Series;
			Series series2 = new Series("SeriesChart_Demand");
			series2.ChartType = SeriesChartType.Line;
			series2.BorderWidth = 1;
			series2.ShadowOffset = 0;
			series2.Color = ClassColorTheme.ChartCurrentColor;
			series2.Enabled = true;
			series1.Add(series2);
			SeriesCollection series3 = chart1.Series;
			Series series4 = new Series("SeriesChart_Sentence");
			series4.ChartType = SeriesChartType.Line;
			series4.BorderWidth = 1;
			series4.ShadowOffset = 0;
			series4.Color = ClassColorTheme.ChartCurrentColor;
			series4.Enabled = true;
			series3.Add(series4);
			SeriesCollection series5 = chart1.Series;
			Series series6 = new Series("SeriesChart_IV");
			series6.ChartType = SeriesChartType.Line;
			series6.BorderWidth = 2;
			series6.ShadowOffset = 0;
			series6.Color = ClassColorTheme.ChartCurrentColorComparison;
			series6.Enabled = true;
			series5.Add(series6);
			chart1.ContextMenuStrip = contextMenuStripChart;
		}

		private void CreateChartTable()
		{
			if (!F_Start)
			{
				return;
			}
			if ((double)ChartTable.Count >= quantityPoints)
			{
				for (int index = 0; index < ChartTable.Count - 1; index++)
				{
					ChartPaper = ChartTable[index + 1];
					ChartPaper.X = index + 1;
					ChartTable[index] = ChartPaper;
				}
			}
			if (!cDataDDE.SearchPaper(SettingsGlass.paper_code))
			{
				return;
			}
			ChartPaper.name = "Glass";
			ChartPaper.X = ChartTable.Count;
			ChartPaper.Y_demand = ClassDataDDE.QuotesPaper.demand;
			ChartPaper.Y_sentence = ClassDataDDE.QuotesPaper.sentence;
			if (Helpers.IsOption(SettingsGlass.paper_code))
			{
				cCalculationOptions.TypeO = SettingsGlass.option_type;
				cCalculationOptions.Strike = SettingsGlass.strike;
				cCalculationOptions.DateExp = SettingsGlass.expiration_date;
				cCalculationOptions.DateCurrent = DateTime.Now;
				cCalculationOptions.Q = Lots;
				cCalculationOptions.VolaO = ClassDataDDE.QuotesPaper.volatility;
				if (cDataDDE.SearchPaper(SettingsGlass.base_asset))
				{
					cCalculationOptions.LastF = ClassDataDDE.QuotesPaper.last_price;
					if (cCalculationOptions.CalculationOpt())
					{
						ChartPaper.Y_IV = Math.Round(cCalculationOptions.calcTheoPrice, 2);
					}
				}
			}
			else
			{
				if (SettingsGlass.paper_code.Length != 4)
				{
					return;
				}
				ChartPaper.Y_IV = ClassDataDDE.QuotesPaper.last_price;
			}
			ChartPaper.Y_HV = 0.0;
			ChartPaper.Y_Application = 0.0;
			ChartPaper.Y_TransactionBuy = 0.0;
			ChartPaper.Y_TransactionSell = 0.0;
			if ((double)ChartTable.Count < quantityPoints)
			{
				ChartPaper.X = ChartTable.Count + 1;
				ChartTable.Add(ChartPaper);
			}
			else
			{
				ChartTable[ChartTable.Count - 1] = ChartPaper;
			}
		}

		private void DrawLineOrder(Order f_ApplicationPaper)
		{
			SetDrawLineOrder setDrawLineOrder = DrawLineOrder;
			bool flag = false;
			if (chart1.InvokeRequired)
			{
				Invoke(setDrawLineOrder, f_ApplicationPaper);
				return;
			}
			if (f_ApplicationPaper.status == 1 && f_ApplicationPaper.volume > 0)
			{
				for (int index = chart1.Series.Count - 1; index >= 0; index--)
				{
					if (chart1.Series[index].Name == Convert.ToString(f_ApplicationPaper.number))
					{
						flag = true;
						chart1.Series[index].Points.Clear();
						chart1.Series[index].Points.AddXY(0.0, f_ApplicationPaper.price);
						chart1.Series[index].Points.AddXY(quantityPoints - 1.0, f_ApplicationPaper.price);
						break;
					}
				}
				if (!flag)
				{
					Color color = ((f_ApplicationPaper.operation != 0) ? ClassColorTheme.GlassSentenceColor : ClassColorTheme.GlassDemandColor);
					SeriesCollection series1 = chart1.Series;
					Series series2 = new Series(Convert.ToString(f_ApplicationPaper.number));
					series2.ChartType = SeriesChartType.Line;
					series2.BorderWidth = 1;
					series2.ShadowOffset = 0;
					series2.Color = color;
					series2.Enabled = true;
					series1.Add(series2);
					chart1.Series[Convert.ToString(f_ApplicationPaper.number)].Points.AddXY(0.0, f_ApplicationPaper.price);
					chart1.Series[Convert.ToString(f_ApplicationPaper.number)].Points.AddXY(quantityPoints - 1.0, f_ApplicationPaper.price);
				}
				return;
			}
			for (int i = 0; i < chart1.Series.Count; i++)
			{
				if (chart1.Series[i].Name == Convert.ToString(f_ApplicationPaper.number))
				{
					chart1.Series[i].Points.Clear();
					chart1.Series.RemoveAt(i);
					break;
				}
			}
		}

		private void DrawChart()
		{
			double val1_1 = 0.0;
			double val1_2 = 0.0;
			double num1 = 1.0;
			for (int index = 0; index < chart1.Series.Count; index++)
			{
				if (chart1.Series[index].Name == "SeriesChart_Demand" || chart1.Series[index].Name == "SeriesChart_Sentence" || chart1.Series[index].Name == "SeriesChart_IV")
				{
					chart1.Series[index].Points.Clear();
				}
			}
			double num2 = 1.0;
			double quantityPoints = this.quantityPoints;
			bool flag = false;
			for (int i = 0; i < ChartTable.Count; i++)
			{
				if (!(ChartTable[i].X >= num2) || !(ChartTable[i].X <= quantityPoints))
				{
					continue;
				}
				if (!flag)
				{
					if (ChartTable[i].Y_IV > 0.0)
					{
						val1_1 = ChartTable[i].Y_IV;
						val1_2 = ChartTable[i].Y_IV;
					}
					flag = true;
				}
				else if (ChartTable[i].Y_IV > 0.0)
				{
					val1_1 = Math.Min(val1_1, ChartTable[i].Y_IV);
					val1_2 = Math.Max(val1_2, ChartTable[i].Y_IV);
				}
			}
			double stepprice = SettingsGlass.step_price;
			for (int index2 = ApplicationTable.Count - 1; index2 >= 0; index2--)
			{
				if (ApplicationTable[index2].price < val1_1 && ApplicationTable[index2].status == 1)
				{
					val1_1 = ApplicationTable[index2].price;
				}
				if (ApplicationTable[index2].price > val1_2 && ApplicationTable[index2].status == 1)
				{
					val1_2 = ApplicationTable[index2].price;
				}
			}
			double num3 = cCalculationOptions.RoundStepPriceFloor(val1_1 - val1_2 * (showProc / 100.0), stepprice);
			double num4 = cCalculationOptions.RoundStepPriceCeiling(val1_2 + val1_2 * (showProc / 100.0), stepprice);
			double num5 = num3 - stepprice * 3.0;
			if (num5 < 0.0)
			{
				num5 = 0.0;
			}
			double num6 = num4 + stepprice * 3.0;
			if ((num6 - num5) / SettingsGlass.step_price > 20.0)
			{
				stepprice = cCalculationOptions.RoundStepPrice(Convert.ToDouble((num6 - num5) / 15.0), SettingsGlass.step_price);
			}
			chart1.ChartAreas[0].AxisX.Interval = num1;
			chart1.ChartAreas[0].AxisX.MajorGrid.Interval = num1;
			chart1.ChartAreas[0].AxisX.Minimum = num2;
			chart1.ChartAreas[0].AxisX.Maximum = quantityPoints;
			chart1.ChartAreas[0].AxisX.MajorGrid.LineWidth = 1;
			chart1.ChartAreas[0].AxisX.MajorGrid.LineDashStyle = ChartDashStyle.Dash;
			chart1.ChartAreas[0].AxisY.Interval = stepprice;
			chart1.ChartAreas[0].AxisY.Minimum = num5;
			chart1.ChartAreas[0].AxisY.Maximum = num6;
			chart1.ChartAreas[0].AxisY.MajorGrid.Interval = stepprice;
			chart1.ChartAreas[0].AxisY.MajorGrid.LineWidth = 1;
			chart1.ChartAreas[0].AxisY.MajorGrid.LineDashStyle = ChartDashStyle.Dash;
			chart1.ChartAreas[0].AxisX.ArrowStyle = AxisArrowStyle.None;
			chart1.ChartAreas[0].AxisY.Crossing = 0.0;
			if (ChartTable.Count > 0)
			{
				for (int j = 0; j < chart1.Series.Count; j++)
				{
					chart1.Series[j].Enabled = true;
				}
				for (int k = 0; k < ChartTable.Count && !(ChartTable[k].name == ""); k++)
				{
					chart1.Series["SeriesChart_Demand"].Points.AddXY(ChartTable[k].X, ChartTable[k].Y_demand);
					chart1.Series["SeriesChart_Sentence"].Points.AddXY(ChartTable[k].X, ChartTable[k].Y_sentence);
					chart1.Series["SeriesChart_IV"].Points.AddXY(ChartTable[k].X, ChartTable[k].Y_IV);
				}
			}
			else
			{
				for (int l = 0; l < chart1.Series.Count; l++)
				{
					chart1.Series[l].Enabled = false;
				}
			}
		}

		private void comboBoxBaseAsset_Click(object sender, EventArgs e)
		{
			FillcomboBoxBaseAsset(comboBoxBaseAsset.Text);
		}

		private void FillcomboBoxBaseAsset(string defaultBaseAsset)
		{
			int num = 0;
			List<string> stringList = new List<string>();
			stringList.Clear();
			comboBoxBaseAsset.Items.Clear();
			if (!ClassDataDDE.F_ErrorOpenFile)
			{
				lock (ClassDataDDE.QuotesTable)
				{
					for (int index1 = 0; index1 < ClassDataDDE.QuotesTable.Count; index1++)
					{
						bool flag = false;
						string baseAsset = ClassDataDDE.QuotesTable[index1].base_asset;
						if (baseAsset != "" && stringList.Count == 0 && Helpers.IsOption(ClassDataDDE.QuotesTable[index1].paper_code))
						{
							stringList.Add(baseAsset);
						}
						else
						{
							if (!(baseAsset != "") || !Helpers.IsOption(ClassDataDDE.QuotesTable[index1].paper_code))
							{
								continue;
							}
							for (int i = 0; i < stringList.Count; i++)
							{
								if (baseAsset == stringList[i])
								{
									flag = true;
									break;
								}
							}
							if (!flag)
							{
								stringList.Add(baseAsset);
							}
						}
					}
				}
			}
			else
			{
				stringList.Add(defaultBaseAsset);
			}
			for (int j = 0; j < stringList.Count; j++)
			{
				if (stringList[j] == defaultBaseAsset)
				{
					num = j;
				}
				comboBoxBaseAsset.Items.Add(stringList[j]);
			}
			if (stringList.Count > 0)
			{
				comboBoxBaseAsset.SelectedIndex = num;
			}
		}

		private void comboBoxExpirationDate_Click(object sender, EventArgs e)
		{
			FillcomboBoxExpirationDate(comboBoxBaseAsset.Text, comboBoxExpirationDate.Text);
		}

		private void FillcomboBoxExpirationDate(string baseAsset, string defaultExpirationDate)
		{
			int num = 0;
			List<DateTime> dateTimeList = new List<DateTime>();
			dateTimeList.Clear();
			comboBoxExpirationDate.Items.Clear();
			if (!ClassDataDDE.F_ErrorOpenFile)
			{
				lock (ClassDataDDE.QuotesTable)
				{
					for (int index1 = 0; index1 < ClassDataDDE.QuotesTable.Count; index1++)
					{
						bool flag = false;
						DateTime expirationDate = ClassDataDDE.QuotesTable[index1].expiration_date;
						if (ClassDataDDE.QuotesTable[index1].base_asset == baseAsset && dateTimeList.Count == 0 && Helpers.IsOption(ClassDataDDE.QuotesTable[index1].paper_code))
						{
							dateTimeList.Add(expirationDate);
						}
						else
						{
							if (!(ClassDataDDE.QuotesTable[index1].base_asset == baseAsset) || !Helpers.IsOption(ClassDataDDE.QuotesTable[index1].paper_code))
							{
								continue;
							}
							for (int i = 0; i < dateTimeList.Count; i++)
							{
								if (expirationDate == dateTimeList[i])
								{
									flag = true;
									break;
								}
							}
							if (!flag)
							{
								dateTimeList.Add(expirationDate);
							}
						}
					}
				}
				for (int j = 0; j < dateTimeList.Count; j++)
				{
					if (dateTimeList[j].ToShortDateString() == defaultExpirationDate)
					{
						num = j;
					}
					ComboBox.ObjectCollection items = comboBoxExpirationDate.Items;
					string shortDateString = dateTimeList[j].ToShortDateString();
					items.Add(shortDateString);
				}
				if (dateTimeList.Count > 0)
				{
					comboBoxExpirationDate.SelectedIndex = num;
				}
			}
			else
			{
				comboBoxExpirationDate.Items.Add(defaultExpirationDate);
				comboBoxExpirationDate.SelectedIndex = 0;
			}
		}

		private void comboBoxStrike_Click(object sender, EventArgs e)
		{
			string text1 = comboBoxExpirationDate.Text;
			string text2 = comboBoxBaseAsset.Text;
			string text3 = comboBoxStrike.Text;
			FillcomboBoxStrike(text2, text1, text3);
		}

		private void FillcomboBoxStrike(string baseAsset, string expirationDate, string defaultStrike)
		{
			int num = 0;
			List<double> doubleList = new List<double>();
			doubleList.Clear();
			comboBoxStrike.Items.Clear();
			if (!ClassDataDDE.F_ErrorOpenFile)
			{
				lock (ClassDataDDE.QuotesTable)
				{
					for (int index1 = 0; index1 < ClassDataDDE.QuotesTable.Count; index1++)
					{
						bool flag = false;
						double strike = ClassDataDDE.QuotesTable[index1].strike;
						if (ClassDataDDE.QuotesTable[index1].base_asset == baseAsset && doubleList.Count == 0 && Helpers.IsOption(ClassDataDDE.QuotesTable[index1].paper_code) && Convert.ToDateTime(expirationDate).Date == ClassDataDDE.QuotesTable[index1].expiration_date.Date)
						{
							doubleList.Add(strike);
						}
						else
						{
							if (!(ClassDataDDE.QuotesTable[index1].base_asset == baseAsset) || !Helpers.IsOption(ClassDataDDE.QuotesTable[index1].paper_code) || !(Convert.ToDateTime(expirationDate).Date == ClassDataDDE.QuotesTable[index1].expiration_date.Date))
							{
								continue;
							}
							for (int i = 0; i < doubleList.Count; i++)
							{
								if (strike == doubleList[i])
								{
									flag = true;
									break;
								}
							}
							if (!flag)
							{
								doubleList.Add(strike);
							}
						}
					}
				}
				for (int j = 0; j < doubleList.Count; j++)
				{
					if (Convert.ToString(doubleList[j]) == defaultStrike)
					{
						num = j;
					}
					comboBoxStrike.Items.Add(Convert.ToString(doubleList[j]));
				}
				if (doubleList.Count > 0)
				{
					comboBoxStrike.SelectedIndex = num;
				}
			}
			else
			{
				comboBoxStrike.Items.Add(defaultStrike);
				comboBoxStrike.SelectedIndex = 0;
			}
		}

		private void comboBoxOptionType_Click(object sender, EventArgs e)
		{
			FillcomboBoxOptionType(comboBoxOptionType.Text);
		}

		private void FillcomboBoxOptionType(string defaultoptionType)
		{
			comboBoxOptionType.Items.Clear();
			comboBoxOptionType.Items.Add("Put");
			comboBoxOptionType.Items.Add("Call");
			comboBoxOptionType.SelectedIndex = ((!(defaultoptionType == "Put") && defaultoptionType == "Call") ? 1 : 0);
		}

		private void comboBoxStrategy_Click(object sender, EventArgs e)
		{
			FillcomboBoxStrategy(comboBoxBaseAsset.Text, comboBoxStrategy.Text);
		}

		private void FillcomboBoxStrategy(string baseAsset, string defaultStrategy)
		{
			int num = 0;
			List<string> stringList = new List<string>();
			stringList.Clear();
			comboBoxStrategy.Items.Clear();
			if (FormTransaction.TransactionTable.Count > 0)
			{
				for (int index1 = 0; index1 < FormTransaction.TransactionTable.Count; index1++)
				{
					bool flag = false;
					string strategy = FormTransaction.TransactionTable[index1].strategy;
					if (FormTransaction.TransactionTable[index1].paper_code.Substring(0, 2) == baseAsset.Substring(0, 2) && stringList.Count == 0)
					{
						stringList.Add(strategy);
					}
					else
					{
						if (!(FormTransaction.TransactionTable[index1].paper_code.Substring(0, 2) == baseAsset.Substring(0, 2)))
						{
							continue;
						}
						for (int i = 0; i < stringList.Count; i++)
						{
							if (strategy == stringList[i])
							{
								flag = true;
								break;
							}
						}
						if (!flag)
						{
							stringList.Add(strategy);
						}
					}
				}
				for (int j = 0; j < stringList.Count; j++)
				{
					if (Convert.ToString(stringList[j]) == defaultStrategy)
					{
						num = j;
					}
					comboBoxStrategy.Items.Add(Convert.ToString(stringList[j]));
				}
				if (stringList.Count > 0)
				{
					comboBoxStrategy.SelectedIndex = num;
				}
			}
			else
			{
				comboBoxStrategy.Items.Add(defaultStrategy);
				comboBoxStrategy.SelectedIndex = 0;
			}
		}

		private bool FillSettings()
		{
			EraseSettingsGlass();
			richTextBoxInformationTransaction.Clear();
			if (comboBoxBaseAsset.Text != "")
			{
				SettingsGlass.base_asset = comboBoxBaseAsset.Text;
				if (!DateTime.TryParse(comboBoxExpirationDate.Text, out SettingsGlass.expiration_date))
				{
					richTextBoxInformationTransaction.Text = "Не корректно указана дата экспирации";
					return false;
				}
				if (double.TryParse(comboBoxStrike.Text, out SettingsGlass.strike))
				{
					if (SettingsGlass.strike <= 0.0)
					{
						richTextBoxInformationTransaction.Text = "Страйк должен быть больше нуля";
						SettingsGlass.strike = 0.0;
						return false;
					}
					if (comboBoxOptionType.Text != "")
					{
						SettingsGlass.option_type = comboBoxOptionType.Text;
						if (comboBoxStrategy.Text != "")
						{
							SettingsGlass.strategy = comboBoxStrategy.Text;
							gStrategy = SettingsGlass.strategy;
							if (textBoxShowIndent.Text != "")
							{
								if (double.TryParse(textBoxShowIndent.Text, out showProc))
								{
									if (showProc > 0.0)
									{
										SettingsGlass.show_indent = showProc;
									}
									else
									{
										textBoxShowIndent.Text = "5";
										showProc = 5.0;
										SettingsGlass.show_indent = showProc;
									}
								}
								else
								{
									textBoxShowIndent.Text = "10";
									showProc = 10.0;
									SettingsGlass.show_indent = showProc;
								}
							}
							else
							{
								textBoxShowIndent.Text = "10";
								showProc = 10.0;
								SettingsGlass.show_indent = showProc;
							}
							if (!cDataDDE.SearchPaper(SettingsGlass.expiration_date, SettingsGlass.base_asset, SettingsGlass.strike, SettingsGlass.option_type))
							{
								return false;
							}
							SettingsGlass.paper_code = ClassDataDDE.QuotesPaper.paper_code;
							SettingsGlass.step_price = ClassDataDDE.QuotesPaper.step_price;
							bool flag = true;
							SettingsGlass.check = flag;
							Text = SettingsGlass.paper_code + "(" + SettingsGlass.strategy + ")";
							return flag;
						}
						richTextBoxInformationTransaction.Text = "Не указана стратегия";
						return false;
					}
					richTextBoxInformationTransaction.Text = "Не указан тип опциона";
					return false;
				}
				richTextBoxInformationTransaction.Text = "Не корректно указан страйк";
				return false;
			}
			richTextBoxInformationTransaction.Text = "Не указан базовый актив";
			return false;
		}

		private bool FillSettings(string paper_code)
		{
			EraseSettingsGlass();
			richTextBoxInformationTransaction.Clear();
			if (!cDataDDE.SearchPaper(paper_code))
			{
				return false;
			}
			SettingsGlass.paper_code = paper_code;
			SettingsGlass.base_asset = ClassDataDDE.QuotesPaper.base_asset;
			SettingsGlass.expiration_date = ClassDataDDE.QuotesPaper.expiration_date;
			SettingsGlass.strike = ClassDataDDE.QuotesPaper.strike;
			SettingsGlass.option_type = ClassDataDDE.QuotesPaper.option_type;
			SettingsGlass.strategy = CallBackMy.callbackEventHandlerCurrentStrategy();
			gStrategy = SettingsGlass.strategy;
			SettingsGlass.step_price = ClassDataDDE.QuotesPaper.step_price;
			SettingsGlass.show_indent = showProc;
			comboBoxBaseAsset.Items.Clear();
			comboBoxBaseAsset.Items.Add(SettingsGlass.base_asset);
			comboBoxBaseAsset.SelectedIndex = 0;
			comboBoxExpirationDate.Items.Clear();
			comboBoxExpirationDate.Items.Add(SettingsGlass.expiration_date.ToShortDateString());
			comboBoxExpirationDate.SelectedIndex = 0;
			comboBoxStrike.Items.Clear();
			comboBoxStrike.Items.Add(Convert.ToString(SettingsGlass.strike));
			comboBoxStrike.SelectedIndex = 0;
			comboBoxOptionType.Items.Clear();
			comboBoxOptionType.Items.Add(SettingsGlass.option_type);
			comboBoxOptionType.SelectedIndex = 0;
			comboBoxStrategy.Items.Clear();
			comboBoxStrategy.Items.Add(SettingsGlass.strategy);
			comboBoxStrategy.SelectedIndex = 0;
			textBoxShowIndent.Text = Convert.ToString(showProc);
			bool flag = true;
			SettingsGlass.check = flag;
			Text = SettingsGlass.paper_code + "(" + SettingsGlass.strategy + ")";
			return flag;
		}

		private void EraseSettingsGlass()
		{
			SettingsGlass.paper_code = "";
			SettingsGlass.base_asset = "";
			SettingsGlass.expiration_date = Convert.ToDateTime("01.01.1900");
			SettingsGlass.strike = 0.0;
			SettingsGlass.option_type = "";
			SettingsGlass.strategy = "";
			gStrategy = "";
			SettingsGlass.step_price = 0.0;
			SettingsGlass.show_indent = 5.0;
			SettingsGlass.check = false;
		}

		private void EraseChartPaper()
		{
			ChartPaper.name = "";
			ChartPaper.X = 0.0;
			ChartPaper.Y_demand = 0.0;
			ChartPaper.Y_sentence = 0.0;
			ChartPaper.Y_IV = 0.0;
			ChartPaper.Y_HV = 0.0;
			ChartPaper.Y_Application = 0.0;
			ChartPaper.Y_TransactionBuy = 0.0;
			ChartPaper.Y_TransactionSell = 0.0;
		}

		public void Tick()
		{
			if (!FormMain.F_DllConnected)
			{
				toolStripStatusLabelStatusDLL.BackColor = Color.Yellow;
			}
			else
			{
				toolStripStatusLabelStatusDLL.BackColor = Color.Green;
			}
			if (int.TryParse(numericUpDownQuantity.Text, out Lots))
			{
				if (Lots <= 0)
				{
					richTextBoxInformationTransaction.Text = "Количество контрактов должно быть целым числом больше нуля";
					Lots = 0;
				}
			}
			else
			{
				richTextBoxInformationTransaction.Text = "Количество контрактов должно быть числом";
				Lots = 0;
			}
			iTimerGlass++;
			if (F_Start && tabControlGlass.SelectedTab.Name == "tabPageGlass" && iTimerGlass >= 1)
			{
				CreateChartTable();
				DrawChart();
				iTimerGlass = 0;
			}
		}

		private void buttonApply_Click(object sender, EventArgs e)
		{
			FillSettings();
			if (SettingsGlass.check)
			{
				F_Start = true;
			}
		}

		private void chart1_MouseMove(object sender, MouseEventArgs e)
		{
			bool flag = true;
			double result1;
			if (!double.TryParse(Convert.ToString(e.X), out result1) || result1 <= 0.0)
			{
				return;
			}
			double num1;
			try
			{
				num1 = Convert.ToDouble(chart1.ChartAreas[0].AxisX.PixelPositionToValue(result1));
			}
			catch
			{
				return;
			}
			flag = true;
			double result2;
			if (!double.TryParse(Convert.ToString(e.Y), out result2) || result2 <= 0.0)
			{
				return;
			}
			double num2;
			try
			{
				num2 = Convert.ToDouble(chart1.ChartAreas[0].AxisY.PixelPositionToValue(result2));
			}
			catch
			{
				return;
			}
			double num3 = cCalculationOptions.RoundStepPrice(num1, 0.1);
			double num4 = cCalculationOptions.RoundStepPrice(num2, SettingsGlass.step_price / 10.0);
			PriceApplication = cCalculationOptions.RoundStepPrice(num4, SettingsGlass.step_price);
			chart1.Titles[0].Text = "X=" + Convert.ToString(num3) + " Y=" + Convert.ToString(num4);
			if (SelectPriceApplication > 0.0)
			{
				if (PriceApplication == SelectPriceApplication)
				{
					return;
				}
				for (int index = chart1.Series.Count - 1; index >= 0; index--)
				{
					if (chart1.Series[index].Name == Convert.ToString(SelectNumberApplication))
					{
						chart1.Series[index].BorderWidth = 1;
						SelectPriceApplication = 0.0;
						SelectNumberApplication = 0.0;
						break;
					}
				}
				return;
			}
			for (int index2 = ApplicationTable.Count - 1; index2 >= 0; index2--)
			{
				if (ApplicationTable[index2].price == PriceApplication)
				{
					for (int index3 = chart1.Series.Count - 1; index3 >= 0; index3--)
					{
						if (chart1.Series[index3].Name == Convert.ToString(ApplicationTable[index2].number))
						{
							chart1.Series[index3].BorderWidth = 3;
							SelectPriceApplication = PriceApplication;
							SelectNumberApplication = ApplicationTable[index2].number;
							break;
						}
					}
					if (SelectPriceApplication > 0.0)
					{
						break;
					}
				}
			}
		}

		private void ToolStripMenuItemApplication_Click(object sender, EventArgs e)
		{
			if (FormMain.F_DllConnected)
			{
				if (FormMain.F_QuikConnected)
				{
					string transactionString = FillStrApplication();
					if (transactionString.Length > 0)
					{
						WriteInformation(Convert.ToString(trans_2_quik.send_async_transaction_test(transactionString)) + " " + transactionString);
					}
				}
				else
				{
					WriteInformation("Нет коннекта с сервером");
				}
			}
			else
			{
				WriteInformation("Нет коннекта с TRANS2QUIK.dll");
			}
		}

		private void ToolStripMenuItemDelete_Click(object sender, EventArgs e)
		{
			if (FormMain.F_DllConnected)
			{
				if (FormMain.F_QuikConnected)
				{
					if (!(SelectNumberApplication <= 0.0) && !(SelectPriceApplication <= 0.0))
					{
						string transactionString = FillStrApplicationDelete(SelectNumberApplication);
						if (transactionString.Length > 0)
						{
							int num = trans_2_quik.send_async_transaction_test(transactionString);
							SelectPriceApplication = 0.0;
							SelectNumberApplication = 0.0;
							WriteInformation(Convert.ToString(num) + " " + transactionString);
						}
					}
				}
				else
				{
					WriteInformation("Нет коннекта с сервером");
				}
			}
			else
			{
				WriteInformation("Нет коннекта с TRANS2QUIK.dll");
			}
		}

		private void contextMenuStripChart_Opening(object sender, CancelEventArgs e)
		{
			ToolStripMenuItemApplication.Text = (radioButtonBuy.Checked ? "Покупка" : ((!radioButtonSell.Checked) ? "" : "Продажа"));
			if (PriceApplication > 0.0)
			{
				gPrice = Convert.ToString(PriceApplication);
			}
			if (SelectPriceApplication > 0.0)
			{
				ToolStripMenuItemDelete.Enabled = true;
			}
			else
			{
				ToolStripMenuItemDelete.Enabled = false;
			}
		}

		private string FillStrApplication()
		{
			string str = "";
			if (SettingsGlass.paper_code.Length > 0)
			{
				gSecCode = SettingsGlass.paper_code;
				gAction = "NEW_ORDER";
				if (radioButtonBuy.Checked)
				{
					gOperation = "B";
				}
				else
				{
					if (!radioButtonSell.Checked)
					{
						richTextBoxInformationTransaction.Clear();
						richTextBoxInformationTransaction.Text = "Не выбран ни покупка ни продажа";
						return str;
					}
					gOperation = "S";
				}
				if (gPrice.Length <= 0)
				{
					richTextBoxInformationTransaction.Clear();
					richTextBoxInformationTransaction.Text = "Цена в заявке менее или равна нулю";
					return str;
				}
				if (int.TryParse(numericUpDownQuantity.Text, out Lots))
				{
					if (Lots <= 0)
					{
						richTextBoxInformationTransaction.Clear();
						richTextBoxInformationTransaction.Text = "Количество контрактов должно быть целым числом больше нуля";
						Lots = 0;
						return str;
					}
					gQuantity = Convert.ToString(Lots);
					return "ACCOUNT=" + gAccount + ";TYPE=" + gType + ";TRANS_ID=" + gTransID + ";CLASSCODE=" + gClassCode + ";SECCODE=" + gSecCode + ";ACTION=" + gAction + ";OPERATION=" + gOperation + ";PRICE=" + gPrice + ";QUANTITY=" + gQuantity + ";";
				}
				richTextBoxInformationTransaction.Clear();
				richTextBoxInformationTransaction.Text = "Количество контрактов должно быть числом";
				Lots = 0;
				return str;
			}
			richTextBoxInformationTransaction.Clear();
			richTextBoxInformationTransaction.Text = "Нет кода инструмента";
			return str;
		}

		private string FillStrApplicationDelete(double f_NumberApplication)
		{
			string str = "";
			if (f_NumberApplication > 0.0)
			{
				if (SettingsGlass.paper_code.Length <= 0)
				{
					WriteInformation("Нет кода инструмента");
					return str;
				}
				gSecCode = SettingsGlass.paper_code;
				gAction = "KILL_ORDER";
				str = "ACCOUNT=" + gAccount + ";TRANS_ID=" + gTransID + ";CLASSCODE=" + gClassCode + ";SECCODE=" + gSecCode + ";ACTION=" + gAction + ";ORDER_KEY=" + Convert.ToString(f_NumberApplication);
			}
			return str;
		}

		public void NewApplication(Order f_ApplicationPaper)
		{
			string str = "Ордер в КВИК, номер=" + f_ApplicationPaper.number + " Код бумаги=" + f_ApplicationPaper.paper_code + " Цена=" + Convert.ToString(f_ApplicationPaper.price) + " Количество=" + Convert.ToString(f_ApplicationPaper.volume) + " Операция=" + Convert.ToString(f_ApplicationPaper.operation) + " Статус заявки=" + Convert.ToString(f_ApplicationPaper.status) + " ID заявки=" + Convert.ToString(f_ApplicationPaper.ID);
			if (!(gTransID == Convert.ToString(f_ApplicationPaper.ID)))
			{
				return;
			}
			bool flag = false;
			for (int index = 0; index < ApplicationTable.Count; index++)
			{
				if (f_ApplicationPaper.number == ApplicationTable[index].number)
				{
					ApplicationTable[index] = f_ApplicationPaper;
					flag = true;
					break;
				}
			}
			if (!flag)
			{
				ApplicationTable.Add(f_ApplicationPaper);
				WriteInformation(str);
			}
			DrawLineOrder(f_ApplicationPaper);
		}

		private void WriteInformation(string str)
		{
			SetTextCallback setTextCallback = WriteInformation;
			if (richTextBoxInformationTransaction.InvokeRequired)
			{
				Invoke(setTextCallback, str);
			}
			else
			{
				richTextBoxInformationTransaction.Clear();
				richTextBoxInformationTransaction.AppendText(str + "\n");
				richTextBoxInformationTransaction.AppendText("\n");
			}
		}

		private void FormGlass_FormClosing(object sender, FormClosingEventArgs e)
		{
		}

		public void CreateTransactionTableFromTrans2Quik(string currentStrategy)
		{
		}

		private void buttonShowIndentMore_Click(object sender, EventArgs e)
		{
			showProc += 5.0;
			SettingsGlass.show_indent = showProc;
			textBoxShowIndent.Text = Convert.ToString(showProc);
			DrawChart();
		}

		private void buttonShowIndentLess_Click(object sender, EventArgs e)
		{
			showProc -= 5.0;
			if (showProc < 0.0)
			{
				showProc = 0.0;
			}
			SettingsGlass.show_indent = showProc;
			textBoxShowIndent.Text = Convert.ToString(showProc);
			DrawChart();
		}

		private void chart1_MouseLeave(object sender, EventArgs e)
		{
		}

		protected override void Dispose(bool disposing)
		{
			if (disposing && components != null)
			{
				components.Dispose();
			}
			base.Dispose(disposing);
		}

		private void InitializeComponent()
		{
			this.components = new System.ComponentModel.Container();
			System.Windows.Forms.DataVisualization.Charting.ChartArea chartArea = new System.Windows.Forms.DataVisualization.Charting.ChartArea();
			System.Windows.Forms.DataVisualization.Charting.Legend legend = new System.Windows.Forms.DataVisualization.Charting.Legend();
			System.Windows.Forms.DataVisualization.Charting.Series series = new System.Windows.Forms.DataVisualization.Charting.Series();
			this.richTextBoxInformationTransaction = new System.Windows.Forms.RichTextBox();
			this.labelCodePaper = new System.Windows.Forms.Label();
			this.label3 = new System.Windows.Forms.Label();
			this.label4 = new System.Windows.Forms.Label();
			this.comboBoxBaseAsset = new System.Windows.Forms.ComboBox();
			this.comboBoxExpirationDate = new System.Windows.Forms.ComboBox();
			this.label5 = new System.Windows.Forms.Label();
			this.comboBoxStrike = new System.Windows.Forms.ComboBox();
			this.comboBoxOptionType = new System.Windows.Forms.ComboBox();
			this.label6 = new System.Windows.Forms.Label();
			this.comboBoxStrategy = new System.Windows.Forms.ComboBox();
			this.tabControlGlass = new System.Windows.Forms.TabControl();
			this.tabPageGlass = new System.Windows.Forms.TabPage();
			this.buttonShowIndentLess = new System.Windows.Forms.Button();
			this.buttonShowIndentMore = new System.Windows.Forms.Button();
			this.textBoxShowIndent = new System.Windows.Forms.TextBox();
			this.radioButtonSell = new System.Windows.Forms.RadioButton();
			this.radioButtonBuy = new System.Windows.Forms.RadioButton();
			this.numericUpDownQuantity = new System.Windows.Forms.NumericUpDown();
			this.label8 = new System.Windows.Forms.Label();
			this.chart1 = new System.Windows.Forms.DataVisualization.Charting.Chart();
			this.tabPageSettings = new System.Windows.Forms.TabPage();
			this.buttonApply = new System.Windows.Forms.Button();
			this.statusStrip1 = new System.Windows.Forms.StatusStrip();
			this.toolStripStatusLabelInformation = new System.Windows.Forms.ToolStripStatusLabel();
			this.toolStripStatusLabelEmpty = new System.Windows.Forms.ToolStripStatusLabel();
			this.toolStripStatusLabelStatusDLL = new System.Windows.Forms.ToolStripStatusLabel();
			this.contextMenuStripChart = new System.Windows.Forms.ContextMenuStrip(this.components);
			this.ToolStripMenuItemApplication = new System.Windows.Forms.ToolStripMenuItem();
			this.ToolStripMenuItemDelete = new System.Windows.Forms.ToolStripMenuItem();
			this.tabControlGlass.SuspendLayout();
			this.tabPageGlass.SuspendLayout();
			this.numericUpDownQuantity.BeginInit();
			this.chart1.BeginInit();
			this.tabPageSettings.SuspendLayout();
			this.statusStrip1.SuspendLayout();
			this.contextMenuStripChart.SuspendLayout();
			base.SuspendLayout();
			this.richTextBoxInformationTransaction.Location = new System.Drawing.Point(12, 352);
			this.richTextBoxInformationTransaction.Name = "richTextBoxInformationTransaction";
			this.richTextBoxInformationTransaction.Size = new System.Drawing.Size(274, 72);
			this.richTextBoxInformationTransaction.TabIndex = 11;
			this.richTextBoxInformationTransaction.Text = "";
			this.labelCodePaper.AutoSize = true;
			this.labelCodePaper.Location = new System.Drawing.Point(6, 93);
			this.labelCodePaper.Name = "labelCodePaper";
			this.labelCodePaper.Size = new System.Drawing.Size(26, 13);
			this.labelCodePaper.TabIndex = 12;
			this.labelCodePaper.Text = "Тип";
			this.label3.AutoSize = true;
			this.label3.Location = new System.Drawing.Point(6, 39);
			this.label3.Name = "label3";
			this.label3.Size = new System.Drawing.Size(96, 13);
			this.label3.TabIndex = 14;
			this.label3.Text = "Дата экспирации";
			this.label4.AutoSize = true;
			this.label4.Location = new System.Drawing.Point(6, 12);
			this.label4.Name = "label4";
			this.label4.Size = new System.Drawing.Size(84, 13);
			this.label4.TabIndex = 15;
			this.label4.Text = "Базовый актив";
			this.comboBoxBaseAsset.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
			this.comboBoxBaseAsset.FormattingEnabled = true;
			this.comboBoxBaseAsset.Location = new System.Drawing.Point(114, 9);
			this.comboBoxBaseAsset.Name = "comboBoxBaseAsset";
			this.comboBoxBaseAsset.Size = new System.Drawing.Size(121, 21);
			this.comboBoxBaseAsset.TabIndex = 16;
			this.comboBoxBaseAsset.Click += new System.EventHandler(comboBoxBaseAsset_Click);
			this.comboBoxExpirationDate.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
			this.comboBoxExpirationDate.FormattingEnabled = true;
			this.comboBoxExpirationDate.Location = new System.Drawing.Point(114, 36);
			this.comboBoxExpirationDate.Name = "comboBoxExpirationDate";
			this.comboBoxExpirationDate.Size = new System.Drawing.Size(121, 21);
			this.comboBoxExpirationDate.TabIndex = 17;
			this.comboBoxExpirationDate.Click += new System.EventHandler(comboBoxExpirationDate_Click);
			this.label5.AutoSize = true;
			this.label5.Location = new System.Drawing.Point(6, 66);
			this.label5.Name = "label5";
			this.label5.Size = new System.Drawing.Size(43, 13);
			this.label5.TabIndex = 18;
			this.label5.Text = "Страйк";
			this.comboBoxStrike.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
			this.comboBoxStrike.FormattingEnabled = true;
			this.comboBoxStrike.Location = new System.Drawing.Point(114, 63);
			this.comboBoxStrike.Name = "comboBoxStrike";
			this.comboBoxStrike.Size = new System.Drawing.Size(121, 21);
			this.comboBoxStrike.TabIndex = 19;
			this.comboBoxStrike.Click += new System.EventHandler(comboBoxStrike_Click);
			this.comboBoxOptionType.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
			this.comboBoxOptionType.FormattingEnabled = true;
			this.comboBoxOptionType.Location = new System.Drawing.Point(114, 90);
			this.comboBoxOptionType.Name = "comboBoxOptionType";
			this.comboBoxOptionType.Size = new System.Drawing.Size(121, 21);
			this.comboBoxOptionType.TabIndex = 20;
			this.comboBoxOptionType.Click += new System.EventHandler(comboBoxOptionType_Click);
			this.label6.AutoSize = true;
			this.label6.Location = new System.Drawing.Point(6, 120);
			this.label6.Name = "label6";
			this.label6.Size = new System.Drawing.Size(59, 13);
			this.label6.TabIndex = 21;
			this.label6.Text = "Стратегия";
			this.comboBoxStrategy.FormattingEnabled = true;
			this.comboBoxStrategy.Location = new System.Drawing.Point(113, 117);
			this.comboBoxStrategy.Name = "comboBoxStrategy";
			this.comboBoxStrategy.Size = new System.Drawing.Size(121, 21);
			this.comboBoxStrategy.TabIndex = 22;
			this.comboBoxStrategy.Click += new System.EventHandler(comboBoxStrategy_Click);
			this.tabControlGlass.Controls.Add(this.tabPageGlass);
			this.tabControlGlass.Controls.Add(this.tabPageSettings);
			this.tabControlGlass.Location = new System.Drawing.Point(12, 12);
			this.tabControlGlass.Name = "tabControlGlass";
			this.tabControlGlass.SelectedIndex = 0;
			this.tabControlGlass.Size = new System.Drawing.Size(278, 334);
			this.tabControlGlass.TabIndex = 32;
			this.tabPageGlass.Controls.Add(this.buttonShowIndentLess);
			this.tabPageGlass.Controls.Add(this.buttonShowIndentMore);
			this.tabPageGlass.Controls.Add(this.textBoxShowIndent);
			this.tabPageGlass.Controls.Add(this.radioButtonSell);
			this.tabPageGlass.Controls.Add(this.radioButtonBuy);
			this.tabPageGlass.Controls.Add(this.numericUpDownQuantity);
			this.tabPageGlass.Controls.Add(this.label8);
			this.tabPageGlass.Controls.Add(this.chart1);
			this.tabPageGlass.Location = new System.Drawing.Point(4, 22);
			this.tabPageGlass.Name = "tabPageGlass";
			this.tabPageGlass.Padding = new System.Windows.Forms.Padding(3);
			this.tabPageGlass.Size = new System.Drawing.Size(270, 308);
			this.tabPageGlass.TabIndex = 0;
			this.tabPageGlass.Text = "Стакан";
			this.tabPageGlass.UseVisualStyleBackColor = true;
			this.buttonShowIndentLess.Location = new System.Drawing.Point(6, 161);
			this.buttonShowIndentLess.Name = "buttonShowIndentLess";
			this.buttonShowIndentLess.Size = new System.Drawing.Size(20, 20);
			this.buttonShowIndentLess.TabIndex = 39;
			this.buttonShowIndentLess.Text = "-";
			this.buttonShowIndentLess.UseVisualStyleBackColor = true;
			this.buttonShowIndentLess.Click += new System.EventHandler(buttonShowIndentLess_Click);
			this.buttonShowIndentMore.Location = new System.Drawing.Point(6, 109);
			this.buttonShowIndentMore.Name = "buttonShowIndentMore";
			this.buttonShowIndentMore.Size = new System.Drawing.Size(20, 20);
			this.buttonShowIndentMore.TabIndex = 38;
			this.buttonShowIndentMore.Text = "+";
			this.buttonShowIndentMore.UseVisualStyleBackColor = true;
			this.buttonShowIndentMore.Click += new System.EventHandler(buttonShowIndentMore_Click);
			this.textBoxShowIndent.Location = new System.Drawing.Point(6, 135);
			this.textBoxShowIndent.Name = "textBoxShowIndent";
			this.textBoxShowIndent.ReadOnly = true;
			this.textBoxShowIndent.Size = new System.Drawing.Size(20, 20);
			this.textBoxShowIndent.TabIndex = 37;
			this.textBoxShowIndent.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
			this.radioButtonSell.AutoSize = true;
			this.radioButtonSell.Enabled = false;
			this.radioButtonSell.Location = new System.Drawing.Point(80, 282);
			this.radioButtonSell.Name = "radioButtonSell";
			this.radioButtonSell.Size = new System.Drawing.Size(71, 17);
			this.radioButtonSell.TabIndex = 34;
			this.radioButtonSell.TabStop = true;
			this.radioButtonSell.Text = "Продажа";
			this.radioButtonSell.UseVisualStyleBackColor = true;
			this.radioButtonBuy.AutoSize = true;
			this.radioButtonBuy.Enabled = false;
			this.radioButtonBuy.Location = new System.Drawing.Point(6, 282);
			this.radioButtonBuy.Name = "radioButtonBuy";
			this.radioButtonBuy.Size = new System.Drawing.Size(68, 17);
			this.radioButtonBuy.TabIndex = 36;
			this.radioButtonBuy.TabStop = true;
			this.radioButtonBuy.Text = "Покупка";
			this.radioButtonBuy.UseVisualStyleBackColor = true;
			this.numericUpDownQuantity.Anchor = System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right;
			this.numericUpDownQuantity.Location = new System.Drawing.Point(222, 282);
			this.numericUpDownQuantity.Name = "numericUpDownQuantity";
			this.numericUpDownQuantity.Size = new System.Drawing.Size(42, 20);
			this.numericUpDownQuantity.TabIndex = 35;
			this.label8.AutoSize = true;
			this.label8.Location = new System.Drawing.Point(175, 284);
			this.label8.Name = "label8";
			this.label8.Size = new System.Drawing.Size(41, 13);
			this.label8.TabIndex = 35;
			this.label8.Text = "Кол-во";
			this.chart1.Anchor = System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left | System.Windows.Forms.AnchorStyles.Right;
			chartArea.Name = "ChartArea1";
			this.chart1.ChartAreas.Add(chartArea);
			legend.Name = "Legend1";
			this.chart1.Legends.Add(legend);
			this.chart1.Location = new System.Drawing.Point(32, 6);
			this.chart1.Name = "chart1";
			series.ChartArea = "ChartArea1";
			series.ChartType = System.Windows.Forms.DataVisualization.Charting.SeriesChartType.Line;
			series.Legend = "Legend1";
			series.Name = "Series1";
			this.chart1.Series.Add(series);
			this.chart1.Size = new System.Drawing.Size(232, 270);
			this.chart1.TabIndex = 14;
			this.chart1.Text = "chart1";
			this.chart1.MouseLeave += new System.EventHandler(chart1_MouseLeave);
			this.chart1.MouseMove += new System.Windows.Forms.MouseEventHandler(chart1_MouseMove);
			this.tabPageSettings.AutoScroll = true;
			this.tabPageSettings.Controls.Add(this.buttonApply);
			this.tabPageSettings.Controls.Add(this.label4);
			this.tabPageSettings.Controls.Add(this.labelCodePaper);
			this.tabPageSettings.Controls.Add(this.comboBoxStrategy);
			this.tabPageSettings.Controls.Add(this.label3);
			this.tabPageSettings.Controls.Add(this.label6);
			this.tabPageSettings.Controls.Add(this.comboBoxBaseAsset);
			this.tabPageSettings.Controls.Add(this.comboBoxOptionType);
			this.tabPageSettings.Controls.Add(this.comboBoxExpirationDate);
			this.tabPageSettings.Controls.Add(this.comboBoxStrike);
			this.tabPageSettings.Controls.Add(this.label5);
			this.tabPageSettings.Location = new System.Drawing.Point(4, 22);
			this.tabPageSettings.Name = "tabPageSettings";
			this.tabPageSettings.Padding = new System.Windows.Forms.Padding(3);
			this.tabPageSettings.Size = new System.Drawing.Size(270, 308);
			this.tabPageSettings.TabIndex = 1;
			this.tabPageSettings.Text = "Настройки";
			this.tabPageSettings.UseVisualStyleBackColor = true;
			this.buttonApply.Anchor = System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left | System.Windows.Forms.AnchorStyles.Right;
			this.buttonApply.Location = new System.Drawing.Point(101, 160);
			this.buttonApply.Name = "buttonApply";
			this.buttonApply.Size = new System.Drawing.Size(75, 23);
			this.buttonApply.TabIndex = 30;
			this.buttonApply.Text = "Применить";
			this.buttonApply.UseVisualStyleBackColor = true;
			this.buttonApply.Click += new System.EventHandler(buttonApply_Click);
			this.statusStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[3] { this.toolStripStatusLabelInformation, this.toolStripStatusLabelEmpty, this.toolStripStatusLabelStatusDLL });
			this.statusStrip1.Location = new System.Drawing.Point(0, 437);
			this.statusStrip1.Name = "statusStrip1";
			this.statusStrip1.Size = new System.Drawing.Size(299, 22);
			this.statusStrip1.TabIndex = 33;
			this.statusStrip1.Text = "statusStrip1";
			this.toolStripStatusLabelInformation.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
			this.toolStripStatusLabelInformation.Name = "toolStripStatusLabelInformation";
			this.toolStripStatusLabelInformation.Size = new System.Drawing.Size(0, 17);
			this.toolStripStatusLabelInformation.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
			this.toolStripStatusLabelEmpty.Name = "toolStripStatusLabelEmpty";
			this.toolStripStatusLabelEmpty.Size = new System.Drawing.Size(267, 17);
			this.toolStripStatusLabelEmpty.Spring = true;
			this.toolStripStatusLabelStatusDLL.AutoSize = false;
			this.toolStripStatusLabelStatusDLL.BorderSides = System.Windows.Forms.ToolStripStatusLabelBorderSides.All;
			this.toolStripStatusLabelStatusDLL.BorderStyle = System.Windows.Forms.Border3DStyle.Adjust;
			this.toolStripStatusLabelStatusDLL.ImageAlign = System.Drawing.ContentAlignment.MiddleRight;
			this.toolStripStatusLabelStatusDLL.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
			this.toolStripStatusLabelStatusDLL.Name = "toolStripStatusLabelStatusDLL";
			this.toolStripStatusLabelStatusDLL.Size = new System.Drawing.Size(17, 17);
			this.toolStripStatusLabelStatusDLL.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
			this.toolStripStatusLabelStatusDLL.ToolTipText = "Подключение к DLL";
			this.contextMenuStripChart.Items.AddRange(new System.Windows.Forms.ToolStripItem[2] { this.ToolStripMenuItemApplication, this.ToolStripMenuItemDelete });
			this.contextMenuStripChart.Name = "contextMenuStripChart";
			this.contextMenuStripChart.RenderMode = System.Windows.Forms.ToolStripRenderMode.System;
			this.contextMenuStripChart.Size = new System.Drawing.Size(119, 48);
			this.contextMenuStripChart.Opening += new System.ComponentModel.CancelEventHandler(contextMenuStripChart_Opening);
			this.ToolStripMenuItemApplication.Name = "ToolStripMenuItemApplication";
			this.ToolStripMenuItemApplication.Size = new System.Drawing.Size(118, 22);
			this.ToolStripMenuItemApplication.Text = "Купить";
			this.ToolStripMenuItemApplication.Click += new System.EventHandler(ToolStripMenuItemApplication_Click);
			this.ToolStripMenuItemDelete.Name = "ToolStripMenuItemDelete";
			this.ToolStripMenuItemDelete.Size = new System.Drawing.Size(118, 22);
			this.ToolStripMenuItemDelete.Text = "Удалить";
			this.ToolStripMenuItemDelete.Click += new System.EventHandler(ToolStripMenuItemDelete_Click);
			base.AutoScaleDimensions = new System.Drawing.SizeF(6f, 13f);
			base.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
			base.ClientSize = new System.Drawing.Size(299, 459);
			base.Controls.Add(this.statusStrip1);
			base.Controls.Add(this.tabControlGlass);
			base.Controls.Add(this.richTextBoxInformationTransaction);
			base.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog;
			base.MaximizeBox = false;
			this.Text = "Стакан";
			base.TopMost = true;
			base.FormClosing += new System.Windows.Forms.FormClosingEventHandler(FormGlass_FormClosing);
			base.Load += new System.EventHandler(FormGlass_Load);
			this.tabControlGlass.ResumeLayout(false);
			this.tabPageGlass.ResumeLayout(false);
			this.tabPageGlass.PerformLayout();
			this.numericUpDownQuantity.EndInit();
			this.chart1.EndInit();
			this.tabPageSettings.ResumeLayout(false);
			this.tabPageSettings.PerformLayout();
			this.statusStrip1.ResumeLayout(false);
			this.statusStrip1.PerformLayout();
			this.contextMenuStripChart.ResumeLayout(false);
			base.ResumeLayout(false);
			base.PerformLayout();
		}
	}
}
