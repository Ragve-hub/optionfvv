using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Diagnostics;
using System.Drawing;
using System.IO;
using System.Text;
using System.Windows.Forms;
using QuikDDE.Data;

namespace OptionFVV
{
	public class FormTransaction : Form
	{
		private delegate void SetAddTransaction();

		public struct Strategy
		{
			public string name_strategy;

			public double profit;

			public double GO;
		}

		private string nameFiltrStrategy;

		public static List<Strategy> StrategyTable = new List<Strategy>();

		private Strategy StrategyPaper = default(Strategy);

		public static List<Transaction> TransactionTable = new List<Transaction>();

		public static Transaction TransactionPaper = default(Transaction);

		private IContainer components = null;

		private SplitContainer splitContainerTransaction;

		private DataGridView dataGridViewTransaction;

		private ComboBox comboBoxTransaction;

		private Button buttonDeleteTransaction;

		private Button buttonAddTransaction;

		private Button buttonApply;

		private RichTextBox richTextBoxInformation;

		private GroupBox groupBoxInformation;

		private GroupBox groupBoxTransaction;

		private ComboBox comboBoxFilter;

		private CheckBox checkBoxFilter;

		public FormTransaction()
		{
			InitializeComponent();
			TransactionTable.Clear();
			nameFiltrStrategy = "";
		}

		private void FormTransaction_Load(object sender, EventArgs e)
		{
			nameFiltrStrategy = ClassSettings.gCurrentStrategy;
			CallBackMy.callbackEventHandlerColorThemeFormTransaction = PaintColorTheme;
			base.FormBorderStyle = FormBorderStyle.None;
			Dock = DockStyle.Fill;
			Create();
			dataGridViewTransaction.EnableHeadersVisualStyles = false;
			dataGridViewTransaction.AutoGenerateColumns = false;
			CreateStrategyTable();
			FillComboBoxCurrentStrategy(ClassSettings.gCurrentStrategy);
			FillComboBoxFilter(ClassSettings.gCurrentStrategy);
			ReadFile();
			PaintColorTheme();
		}

		public bool WriteFileTransaction()
		{
			bool flag = true;
			StreamWriter streamWriter1 = new StreamWriter(Application.StartupPath + "\\Transaction.txt", false, Encoding.Default);
			for (int index = 0; index < TransactionTable.Count; index++)
			{
				StreamWriter streamWriter2 = streamWriter1;
				string str = Convert.ToString(TransactionTable[index].number) + ";" + Convert.ToString(TransactionTable[index].date.ToShortDateString()) + ";" + Convert.ToString(TransactionTable[index].time.ToShortTimeString()) + ";" + Convert.ToString(TransactionTable[index].paper_code) + ";" + Convert.ToString(TransactionTable[index].operation) + ";" + Convert.ToString(TransactionTable[index].price) + ";" + Convert.ToString(TransactionTable[index].volume) + ";" + Convert.ToString(TransactionTable[index].strategy);
				streamWriter2.WriteLine(str);
			}
			streamWriter1.Close();
			return flag;
		}

		public void Create()
		{
			DataGridViewCheckBoxColumn viewCheckBoxColumn = new DataGridViewCheckBoxColumn();
			viewCheckBoxColumn.HeaderText = "";
			viewCheckBoxColumn.Name = "check";
			viewCheckBoxColumn.AutoSizeMode = DataGridViewAutoSizeColumnMode.DisplayedCells;
			viewCheckBoxColumn.DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;
			DataGridViewTextBoxColumn viewTextBoxColumn1 = new DataGridViewTextBoxColumn();
			viewTextBoxColumn1.HeaderText = "Номер";
			viewTextBoxColumn1.Name = "number";
			viewTextBoxColumn1.AutoSizeMode = DataGridViewAutoSizeColumnMode.DisplayedCells;
			viewTextBoxColumn1.DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;
			DataGridViewTextBoxColumn viewTextBoxColumn2 = new DataGridViewTextBoxColumn();
			viewTextBoxColumn2.HeaderText = "Дата";
			viewTextBoxColumn2.Name = "date";
			viewTextBoxColumn2.DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;
			DataGridViewTextBoxColumn viewTextBoxColumn3 = new DataGridViewTextBoxColumn();
			viewTextBoxColumn3.HeaderText = "Время";
			viewTextBoxColumn3.Name = "time";
			viewTextBoxColumn3.DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;
			DataGridViewTextBoxColumn viewTextBoxColumn4 = new DataGridViewTextBoxColumn();
			viewTextBoxColumn4.HeaderText = "Код бумаги";
			viewTextBoxColumn4.Name = "paper_code";
			viewTextBoxColumn4.DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;
			DataGridViewTextBoxColumn viewTextBoxColumn5 = new DataGridViewTextBoxColumn();
			viewTextBoxColumn5.HeaderText = "Операция";
			viewTextBoxColumn5.Name = "operation";
			viewTextBoxColumn5.DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;
			DataGridViewTextBoxColumn viewTextBoxColumn6 = new DataGridViewTextBoxColumn();
			viewTextBoxColumn6.HeaderText = "Цена";
			viewTextBoxColumn6.Name = "price";
			viewTextBoxColumn6.DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;
			DataGridViewTextBoxColumn viewTextBoxColumn7 = new DataGridViewTextBoxColumn();
			viewTextBoxColumn7.HeaderText = "Количество";
			viewTextBoxColumn7.Name = "volume";
			viewTextBoxColumn7.DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;
			DataGridViewTextBoxColumn viewTextBoxColumn8 = new DataGridViewTextBoxColumn();
			viewTextBoxColumn8.HeaderText = "Стратегия";
			viewTextBoxColumn8.Name = "strategy";
			viewTextBoxColumn8.DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;
			dataGridViewTransaction.Columns.Add(viewCheckBoxColumn);
			dataGridViewTransaction.Columns.Add(viewTextBoxColumn1);
			dataGridViewTransaction.Columns.Add(viewTextBoxColumn2);
			dataGridViewTransaction.Columns.Add(viewTextBoxColumn3);
			dataGridViewTransaction.Columns.Add(viewTextBoxColumn4);
			dataGridViewTransaction.Columns.Add(viewTextBoxColumn5);
			dataGridViewTransaction.Columns.Add(viewTextBoxColumn6);
			dataGridViewTransaction.Columns.Add(viewTextBoxColumn7);
			dataGridViewTransaction.Columns.Add(viewTextBoxColumn8);
			dataGridViewTransaction.RowHeadersVisible = false;
			dataGridViewTransaction.ColumnHeadersDefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;
			viewCheckBoxColumn.AutoSizeMode = DataGridViewAutoSizeColumnMode.AllCells;
			viewTextBoxColumn1.AutoSizeMode = DataGridViewAutoSizeColumnMode.AllCells;
			viewTextBoxColumn2.AutoSizeMode = DataGridViewAutoSizeColumnMode.AllCells;
			viewTextBoxColumn3.AutoSizeMode = DataGridViewAutoSizeColumnMode.AllCells;
			viewTextBoxColumn4.AutoSizeMode = DataGridViewAutoSizeColumnMode.AllCells;
			viewTextBoxColumn5.AutoSizeMode = DataGridViewAutoSizeColumnMode.AllCells;
			viewTextBoxColumn6.AutoSizeMode = DataGridViewAutoSizeColumnMode.AllCells;
			viewTextBoxColumn7.AutoSizeMode = DataGridViewAutoSizeColumnMode.AllCells;
			viewTextBoxColumn8.AutoSizeMode = DataGridViewAutoSizeColumnMode.Fill;
			viewTextBoxColumn8.MinimumWidth = 100;
			viewCheckBoxColumn.SortMode = DataGridViewColumnSortMode.NotSortable;
			viewTextBoxColumn1.SortMode = DataGridViewColumnSortMode.NotSortable;
			viewTextBoxColumn2.SortMode = DataGridViewColumnSortMode.NotSortable;
			viewTextBoxColumn3.SortMode = DataGridViewColumnSortMode.NotSortable;
			viewTextBoxColumn4.SortMode = DataGridViewColumnSortMode.NotSortable;
			viewTextBoxColumn5.SortMode = DataGridViewColumnSortMode.NotSortable;
			viewTextBoxColumn6.SortMode = DataGridViewColumnSortMode.NotSortable;
			viewTextBoxColumn7.SortMode = DataGridViewColumnSortMode.NotSortable;
			viewTextBoxColumn8.SortMode = DataGridViewColumnSortMode.NotSortable;
		}

		public void Tick()
		{
			FillBoard();
		}

		public void OpenFile()
		{
			string str = Application.StartupPath + "\\Transaction.txt";
			if (File.Exists(str))
			{
				try
				{
					Process.Start(str);
					return;
				}
				catch
				{
					return;
				}
			}
			int num = (int)MessageBox.Show("Пока файл не создан");
		}

		public void ReadFile()
		{
			TransactionTable.Clear();
			string path = Application.StartupPath + "\\Transaction.txt";
			if (!File.Exists(path))
			{
				return;
			}
			try
			{
				StreamReader streamReader = new StreamReader(path, Encoding.Default);
				while (streamReader.Peek() != -1)
				{
					string[] strArray = streamReader.ReadLine().Split(';');
					TransactionPaper.number = Convert.ToString(strArray[0]);
					TransactionPaper.date = Convert.ToDateTime(strArray[1]);
					TransactionPaper.time = Convert.ToDateTime(strArray[2]);
					TransactionPaper.paper_code = Convert.ToString(strArray[3]);
					TransactionPaper.operation = Convert.ToString(strArray[4]);
					if (double.TryParse(strArray[5], out TransactionPaper.price))
					{
						if (TransactionPaper.price < 0.0)
						{
							TransactionPaper.price = 0.0;
						}
					}
					else
					{
						TransactionPaper.price = 0.0;
					}
					if (double.TryParse(strArray[6], out TransactionPaper.volume))
					{
						if (TransactionPaper.volume < 0.0)
						{
							TransactionPaper.volume = 0.0;
						}
					}
					else
					{
						TransactionPaper.volume = 0.0;
					}
					TransactionPaper.strategy = Convert.ToString(strArray[7]);
					TransactionTable.Add(TransactionPaper);
				}
				streamReader.Close();
			}
			catch
			{
			}
		}

		public void ReadFile(string fileName)
		{
			TransactionTable.Clear();
			if (!File.Exists(fileName))
			{
				return;
			}
			try
			{
				StreamReader streamReader = new StreamReader(fileName, Encoding.Default);
				while (streamReader.Peek() != -1)
				{
					string[] strArray = streamReader.ReadLine().Split(';');
					TransactionPaper.number = Convert.ToString(strArray[0]);
					TransactionPaper.date = Convert.ToDateTime(strArray[1]);
					TransactionPaper.time = Convert.ToDateTime(strArray[2]);
					TransactionPaper.paper_code = Convert.ToString(strArray[3]);
					TransactionPaper.operation = Convert.ToString(strArray[4]);
					if (double.TryParse(strArray[5], out TransactionPaper.price))
					{
						if (TransactionPaper.price < 0.0)
						{
							TransactionPaper.price = 0.0;
						}
					}
					else
					{
						TransactionPaper.price = 0.0;
					}
					if (double.TryParse(strArray[6], out TransactionPaper.volume))
					{
						if (TransactionPaper.volume < 0.0)
						{
							TransactionPaper.volume = 0.0;
						}
					}
					else
					{
						TransactionPaper.volume = 0.0;
					}
					TransactionPaper.strategy = Convert.ToString(strArray[7]);
					TransactionTable.Add(TransactionPaper);
				}
				streamReader.Close();
			}
			catch
			{
			}
		}

		private void FillBoard()
		{
			int index1 = 0;
			if (checkBoxFilter.Checked && nameFiltrStrategy != comboBoxFilter.Text && comboBoxFilter.Text != "")
			{
				dataGridViewTransaction.Rows.Clear();
				nameFiltrStrategy = comboBoxFilter.Text;
			}
			lock (TransactionTable)
			{
				for (int i = 0; i < TransactionTable.Count; i++)
				{
					if (index1 < dataGridViewTransaction.RowCount)
					{
						if (checkBoxFilter.Checked)
						{
							if (comboBoxFilter.Text != "" && TransactionTable[i].strategy == comboBoxFilter.Text)
							{
								dataGridViewTransaction.Rows[index1].Cells[0].Value = dataGridViewTransaction.Rows[index1].Cells[0].Value;
								dataGridViewTransaction.Rows[index1].Cells[1].Value = TransactionTable[i].number;
								DataGridViewCell cell1 = dataGridViewTransaction.Rows[index1].Cells[2];
								string shortDateString = TransactionTable[i].date.ToShortDateString();
								cell1.Value = shortDateString;
								DataGridViewCell cell2 = dataGridViewTransaction.Rows[index1].Cells[3];
								string shortTimeString = TransactionTable[i].time.ToShortTimeString();
								cell2.Value = shortTimeString;
								dataGridViewTransaction.Rows[index1].Cells[4].Value = TransactionTable[i].paper_code;
								dataGridViewTransaction.Rows[index1].Cells[5].Value = TransactionTable[i].operation;
								dataGridViewTransaction.Rows[index1].Cells[6].Value = TransactionTable[i].price;
								dataGridViewTransaction.Rows[index1].Cells[7].Value = TransactionTable[i].volume;
								dataGridViewTransaction.Rows[index1].Cells[8].Value = TransactionTable[i].strategy;
								index1++;
							}
						}
						else
						{
							dataGridViewTransaction.Rows[index1].Cells[0].Value = dataGridViewTransaction.Rows[index1].Cells[0].Value;
							dataGridViewTransaction.Rows[index1].Cells[1].Value = TransactionTable[i].number;
							DataGridViewCell cell3 = dataGridViewTransaction.Rows[index1].Cells[2];
							string shortDateString2 = TransactionTable[i].date.ToShortDateString();
							cell3.Value = shortDateString2;
							DataGridViewCell cell4 = dataGridViewTransaction.Rows[index1].Cells[3];
							string shortTimeString2 = TransactionTable[i].time.ToShortTimeString();
							cell4.Value = shortTimeString2;
							dataGridViewTransaction.Rows[index1].Cells[4].Value = TransactionTable[i].paper_code;
							dataGridViewTransaction.Rows[index1].Cells[5].Value = TransactionTable[i].operation;
							dataGridViewTransaction.Rows[index1].Cells[6].Value = TransactionTable[i].price;
							dataGridViewTransaction.Rows[index1].Cells[7].Value = TransactionTable[i].volume;
							dataGridViewTransaction.Rows[index1].Cells[8].Value = TransactionTable[i].strategy;
							index1++;
						}
					}
					else
					{
						if (dataGridViewTransaction.ColumnCount != 9)
						{
							continue;
						}
						if (checkBoxFilter.Checked)
						{
							if (TransactionTable[i].strategy == comboBoxFilter.Text)
							{
								DataGridViewRowCollection rows = dataGridViewTransaction.Rows;
								rows.Add(false, TransactionTable[i].number, TransactionTable[i].date.ToShortDateString(), TransactionTable[i].time.ToShortTimeString(), TransactionTable[i].paper_code, TransactionTable[i].operation, TransactionTable[i].price, TransactionTable[i].volume, TransactionTable[i].strategy);
								index1++;
							}
						}
						else
						{
							DataGridViewRowCollection rows2 = dataGridViewTransaction.Rows;
							rows2.Add(false, TransactionTable[i].number, TransactionTable[i].date.ToShortDateString(), TransactionTable[i].time.ToShortTimeString(), TransactionTable[i].paper_code, TransactionTable[i].operation, TransactionTable[i].price, TransactionTable[i].volume, TransactionTable[i].strategy);
							index1++;
						}
					}
				}
			}
			if (index1 < dataGridViewTransaction.RowCount)
			{
				int num = dataGridViewTransaction.RowCount - index1;
				for (int j = 1; j <= num; j++)
				{
					dataGridViewTransaction.Rows.RemoveAt(index1);
				}
			}
		}

		public string NameInstrument(string strategy)
		{
			string str = "";
			for (int index = 0; index < TransactionTable.Count; index++)
			{
				if (TransactionTable[index].strategy == strategy)
				{
					return TransactionTable[index].paper_code.Remove(2);
				}
			}
			return str;
		}

		public bool SearchTransaction(string iNumber)
		{
			bool flag = false;
			for (int index = 0; index < TransactionTable.Count; index++)
			{
				if (TransactionTable[index].number == iNumber)
				{
					TransactionPaper.number = TransactionTable[index].number;
					TransactionPaper.date = TransactionTable[index].date;
					TransactionPaper.time = TransactionTable[index].time;
					TransactionPaper.paper_code = TransactionTable[index].paper_code;
					TransactionPaper.operation = TransactionTable[index].operation;
					TransactionPaper.price = TransactionTable[index].price;
					TransactionPaper.volume = TransactionTable[index].volume;
					flag = true;
					break;
				}
			}
			return flag;
		}

		public void AddTransaction()
		{
			SetAddTransaction setAddTransaction = AddTransaction;
			int num = 0;
			if (dataGridViewTransaction.InvokeRequired)
			{
				Invoke(setAddTransaction, new object[0]);
				return;
			}
			lock (TransactionTable)
			{
				TransactionTable.Add(TransactionPaper);
				num = TransactionTable.Count - 1;
			}
		}

		private void PaintColorTheme()
		{
			BackColor = ClassColorTheme.BackColor;
			ForeColor = ClassColorTheme.HeadersColorFore;
			groupBoxTransaction.BackColor = ClassColorTheme.BackColor;
			groupBoxTransaction.ForeColor = ClassColorTheme.BackColorFore;
			groupBoxInformation.BackColor = ClassColorTheme.BackColor;
			groupBoxInformation.ForeColor = ClassColorTheme.BackColorFore;
			splitContainerTransaction.BackColor = ClassColorTheme.HeadersColor;
			splitContainerTransaction.Panel1.BackColor = ClassColorTheme.BackColor;
			splitContainerTransaction.Panel2.BackColor = ClassColorTheme.BackColor;
			splitContainerTransaction.BorderStyle = BorderStyle.None;
			comboBoxTransaction.FlatStyle = FlatStyle.System;
			comboBoxFilter.FlatStyle = FlatStyle.System;
			checkBoxFilter.ForeColor = ClassColorTheme.BackColorFore;
			buttonAddTransaction.FlatStyle = FlatStyle.System;
			buttonDeleteTransaction.FlatStyle = FlatStyle.System;
			buttonApply.FlatStyle = FlatStyle.System;
			dataGridViewTransaction.ColumnHeadersDefaultCellStyle.BackColor = ClassColorTheme.HeadersColor;
			dataGridViewTransaction.BackgroundColor = ClassColorTheme.BackColor;
			dataGridViewTransaction.ForeColor = ClassColorTheme.BackColorFore;
			dataGridViewTransaction.DefaultCellStyle.BackColor = ClassColorTheme.BackColor;
			dataGridViewTransaction.ColumnHeadersDefaultCellStyle.ForeColor = ClassColorTheme.HeadersColorFore;
			dataGridViewTransaction.GridColor = ClassColorTheme.GridColor;
			dataGridViewTransaction.AlternatingRowsDefaultCellStyle.BackColor = ClassColorTheme.HeadersColor;
			richTextBoxInformation.BackColor = ClassColorTheme.BackColor;
			richTextBoxInformation.ForeColor = ClassColorTheme.BackColorFore;
		}

		private void buttonAddTransaction_Click(object sender, EventArgs e)
		{
			PaintColorTheme();
		}

		private void buttonDeleteTransaction_Click(object sender, EventArgs e)
		{
			richTextBoxInformation.Text = "";
			for (int index1 = 0; index1 < dataGridViewTransaction.RowCount; index1++)
			{
				if (!(Convert.ToString(dataGridViewTransaction.Rows[index1].Cells[0].Value) == "True"))
				{
					continue;
				}
				string str = Convert.ToString(dataGridViewTransaction.Rows[index1].Cells[1].Value);
				for (int i = 0; i < TransactionTable.Count; i++)
				{
					if (TransactionTable[i].number == str)
					{
						TransactionTable.RemoveAt(i);
						richTextBoxInformation.AppendText("Удалили сделку под №" + str + "\n");
						break;
					}
				}
				dataGridViewTransaction.Rows.RemoveAt(index1);
				index1--;
			}
		}

		public void CreateStrategyTable()
		{
			StrategyTable.Clear();
			for (int index1 = 0; index1 < TransactionTable.Count; index1++)
			{
				bool flag = false;
				string strategy = TransactionTable[index1].strategy;
				if (strategy != "" && StrategyTable.Count == 0)
				{
					StrategyPaper.name_strategy = TransactionTable[index1].strategy;
					StrategyPaper.profit = 0.0;
					StrategyPaper.GO = 0.0;
					StrategyTable.Add(StrategyPaper);
				}
				else
				{
					if (!(strategy != ""))
					{
						continue;
					}
					for (int i = 0; i < StrategyTable.Count; i++)
					{
						if (strategy == StrategyTable[i].name_strategy)
						{
							flag = true;
							break;
						}
					}
					if (!flag)
					{
						StrategyPaper.name_strategy = TransactionTable[index1].strategy;
						StrategyPaper.profit = 0.0;
						StrategyPaper.GO = 0.0;
						StrategyTable.Add(StrategyPaper);
					}
				}
			}
		}

		public void FillComboBoxCurrentStrategy(string CurrentStrategy)
		{
			comboBoxTransaction.Items.Clear();
			int num = 0;
			for (int index = 0; index < StrategyTable.Count; index++)
			{
				comboBoxTransaction.Items.Add(StrategyTable[index].name_strategy);
				if (StrategyTable[index].name_strategy == nameFiltrStrategy && nameFiltrStrategy != "")
				{
					num = comboBoxTransaction.Items.Count - 1;
				}
			}
			if (StrategyTable.Count > 0)
			{
				comboBoxTransaction.SelectedIndex = num;
			}
		}

		public void FillComboBoxFilter(string CurrentStrategy)
		{
			comboBoxFilter.Items.Clear();
			int num = 0;
			for (int index = 0; index < StrategyTable.Count; index++)
			{
				comboBoxFilter.Items.Add(StrategyTable[index].name_strategy);
				if (StrategyTable[index].name_strategy == CurrentStrategy)
				{
					num = index;
				}
			}
			if (StrategyTable.Count > 0)
			{
				comboBoxFilter.SelectedIndex = num;
			}
		}

		private void buttonApply_Click(object sender, EventArgs e)
		{
			string text = comboBoxTransaction.Text;
			richTextBoxInformation.Text = "";
			for (int index1 = 0; index1 < dataGridViewTransaction.RowCount; index1++)
			{
				if (!(Convert.ToString(dataGridViewTransaction.Rows[index1].Cells[0].Value) == "True"))
				{
					continue;
				}
				for (int i = 0; i < TransactionTable.Count; i++)
				{
					if (Convert.ToString(TransactionTable[i].number) == Convert.ToString(dataGridViewTransaction.Rows[index1].Cells[1].Value))
					{
						TransactionPaper = TransactionTable[i];
						TransactionPaper.strategy = text;
						TransactionTable[i] = TransactionPaper;
						richTextBoxInformation.AppendText("В сделке под №" + TransactionPaper.number + " поменяли стратегию на " + text + "\n");
						break;
					}
				}
				dataGridViewTransaction.Rows[index1].Cells[0].Value = false;
			}
		}

		private void comboBoxFilter_Click(object sender, EventArgs e)
		{
			CreateStrategyTable();
			FillComboBoxFilter(nameFiltrStrategy);
		}

		private void comboBoxTransaction_Click(object sender, EventArgs e)
		{
			CreateStrategyTable();
			FillComboBoxCurrentStrategy(ClassSettings.gCurrentStrategy);
		}

		private void checkBoxFilter_Click(object sender, EventArgs e)
		{
			if (checkBoxFilter.Checked)
			{
				dataGridViewTransaction.Rows.Clear();
				nameFiltrStrategy = comboBoxFilter.Text;
			}
			else
			{
				dataGridViewTransaction.Rows.Clear();
			}
			FillBoard();
		}

		private void comboBoxFilter_TextChanged(object sender, EventArgs e)
		{
			if (nameFiltrStrategy != comboBoxFilter.Text && comboBoxFilter.Text != "")
			{
				if (checkBoxFilter.Checked)
				{
					dataGridViewTransaction.Rows.Clear();
				}
				nameFiltrStrategy = comboBoxFilter.Text;
			}
			FillBoard();
		}

		protected override void Dispose(bool disposing)
		{
			if (disposing && components != null)
			{
				components.Dispose();
			}
			base.Dispose(disposing);
		}

		private void InitializeComponent()
		{
			this.splitContainerTransaction = new System.Windows.Forms.SplitContainer();
			this.groupBoxTransaction = new System.Windows.Forms.GroupBox();
			this.checkBoxFilter = new System.Windows.Forms.CheckBox();
			this.comboBoxFilter = new System.Windows.Forms.ComboBox();
			this.buttonAddTransaction = new System.Windows.Forms.Button();
			this.buttonApply = new System.Windows.Forms.Button();
			this.comboBoxTransaction = new System.Windows.Forms.ComboBox();
			this.buttonDeleteTransaction = new System.Windows.Forms.Button();
			this.groupBoxInformation = new System.Windows.Forms.GroupBox();
			this.richTextBoxInformation = new System.Windows.Forms.RichTextBox();
			this.dataGridViewTransaction = new System.Windows.Forms.DataGridView();
			this.splitContainerTransaction.BeginInit();
			this.splitContainerTransaction.Panel1.SuspendLayout();
			this.splitContainerTransaction.Panel2.SuspendLayout();
			this.splitContainerTransaction.SuspendLayout();
			this.groupBoxTransaction.SuspendLayout();
			this.groupBoxInformation.SuspendLayout();
			((System.ComponentModel.ISupportInitialize)this.dataGridViewTransaction).BeginInit();
			base.SuspendLayout();
			this.splitContainerTransaction.Dock = System.Windows.Forms.DockStyle.Fill;
			this.splitContainerTransaction.Location = new System.Drawing.Point(0, 0);
			this.splitContainerTransaction.Name = "splitContainerTransaction";
			this.splitContainerTransaction.Panel1.Controls.Add(this.groupBoxTransaction);
			this.splitContainerTransaction.Panel1.Controls.Add(this.groupBoxInformation);
			this.splitContainerTransaction.Panel1MinSize = 100;
			this.splitContainerTransaction.Panel2.Controls.Add(this.dataGridViewTransaction);
			this.splitContainerTransaction.Panel2MinSize = 100;
			this.splitContainerTransaction.Size = new System.Drawing.Size(1277, 505);
			this.splitContainerTransaction.SplitterDistance = 206;
			this.splitContainerTransaction.TabIndex = 0;
			this.groupBoxTransaction.Anchor = System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left | System.Windows.Forms.AnchorStyles.Right;
			this.groupBoxTransaction.Controls.Add(this.checkBoxFilter);
			this.groupBoxTransaction.Controls.Add(this.comboBoxFilter);
			this.groupBoxTransaction.Controls.Add(this.buttonAddTransaction);
			this.groupBoxTransaction.Controls.Add(this.buttonApply);
			this.groupBoxTransaction.Controls.Add(this.comboBoxTransaction);
			this.groupBoxTransaction.Controls.Add(this.buttonDeleteTransaction);
			this.groupBoxTransaction.Location = new System.Drawing.Point(3, 3);
			this.groupBoxTransaction.Name = "groupBoxTransaction";
			this.groupBoxTransaction.Size = new System.Drawing.Size(200, 202);
			this.groupBoxTransaction.TabIndex = 1;
			this.groupBoxTransaction.TabStop = false;
			this.groupBoxTransaction.Text = "Работа со сделками";
			this.checkBoxFilter.AutoSize = true;
			this.checkBoxFilter.Location = new System.Drawing.Point(9, 177);
			this.checkBoxFilter.Name = "checkBoxFilter";
			this.checkBoxFilter.Size = new System.Drawing.Size(66, 17);
			this.checkBoxFilter.TabIndex = 2;
			this.checkBoxFilter.Text = "Фильтр";
			this.checkBoxFilter.UseVisualStyleBackColor = true;
			this.checkBoxFilter.Click += new System.EventHandler(checkBoxFilter_Click);
			this.comboBoxFilter.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
			this.comboBoxFilter.FormattingEnabled = true;
			this.comboBoxFilter.Location = new System.Drawing.Point(81, 175);
			this.comboBoxFilter.Name = "comboBoxFilter";
			this.comboBoxFilter.Size = new System.Drawing.Size(113, 21);
			this.comboBoxFilter.TabIndex = 1;
			this.comboBoxFilter.TextChanged += new System.EventHandler(comboBoxFilter_TextChanged);
			this.comboBoxFilter.Click += new System.EventHandler(comboBoxFilter_Click);
			this.buttonAddTransaction.Anchor = System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left | System.Windows.Forms.AnchorStyles.Right;
			this.buttonAddTransaction.Enabled = false;
			this.buttonAddTransaction.Location = new System.Drawing.Point(9, 19);
			this.buttonAddTransaction.Name = "buttonAddTransaction";
			this.buttonAddTransaction.Size = new System.Drawing.Size(185, 23);
			this.buttonAddTransaction.TabIndex = 1;
			this.buttonAddTransaction.Text = "Добавить";
			this.buttonAddTransaction.UseVisualStyleBackColor = true;
			this.buttonAddTransaction.Click += new System.EventHandler(buttonAddTransaction_Click);
			this.buttonApply.Anchor = System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left | System.Windows.Forms.AnchorStyles.Right;
			this.buttonApply.Location = new System.Drawing.Point(9, 112);
			this.buttonApply.Name = "buttonApply";
			this.buttonApply.Size = new System.Drawing.Size(185, 23);
			this.buttonApply.TabIndex = 1;
			this.buttonApply.Text = "Заменить стратегии на";
			this.buttonApply.UseVisualStyleBackColor = true;
			this.buttonApply.Click += new System.EventHandler(buttonApply_Click);
			this.comboBoxTransaction.Anchor = System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left | System.Windows.Forms.AnchorStyles.Right;
			this.comboBoxTransaction.FormattingEnabled = true;
			this.comboBoxTransaction.Location = new System.Drawing.Point(9, 141);
			this.comboBoxTransaction.Name = "comboBoxTransaction";
			this.comboBoxTransaction.Size = new System.Drawing.Size(185, 21);
			this.comboBoxTransaction.TabIndex = 1;
			this.comboBoxTransaction.Click += new System.EventHandler(comboBoxTransaction_Click);
			this.buttonDeleteTransaction.Anchor = System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left | System.Windows.Forms.AnchorStyles.Right;
			this.buttonDeleteTransaction.Location = new System.Drawing.Point(9, 48);
			this.buttonDeleteTransaction.Name = "buttonDeleteTransaction";
			this.buttonDeleteTransaction.Size = new System.Drawing.Size(185, 23);
			this.buttonDeleteTransaction.TabIndex = 1;
			this.buttonDeleteTransaction.Text = "Удалить";
			this.buttonDeleteTransaction.UseVisualStyleBackColor = true;
			this.buttonDeleteTransaction.Click += new System.EventHandler(buttonDeleteTransaction_Click);
			this.groupBoxInformation.Anchor = System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left | System.Windows.Forms.AnchorStyles.Right;
			this.groupBoxInformation.Controls.Add(this.richTextBoxInformation);
			this.groupBoxInformation.Location = new System.Drawing.Point(3, 211);
			this.groupBoxInformation.Name = "groupBoxInformation";
			this.groupBoxInformation.Size = new System.Drawing.Size(200, 291);
			this.groupBoxInformation.TabIndex = 2;
			this.groupBoxInformation.TabStop = false;
			this.groupBoxInformation.Text = "Информация";
			this.richTextBoxInformation.Dock = System.Windows.Forms.DockStyle.Fill;
			this.richTextBoxInformation.Location = new System.Drawing.Point(3, 16);
			this.richTextBoxInformation.Name = "richTextBoxInformation";
			this.richTextBoxInformation.Size = new System.Drawing.Size(194, 272);
			this.richTextBoxInformation.TabIndex = 1;
			this.richTextBoxInformation.Text = "";
			this.dataGridViewTransaction.AllowUserToAddRows = false;
			this.dataGridViewTransaction.AllowUserToDeleteRows = false;
			this.dataGridViewTransaction.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
			this.dataGridViewTransaction.Dock = System.Windows.Forms.DockStyle.Fill;
			this.dataGridViewTransaction.Location = new System.Drawing.Point(0, 0);
			this.dataGridViewTransaction.Name = "dataGridViewTransaction";
			this.dataGridViewTransaction.Size = new System.Drawing.Size(1067, 505);
			this.dataGridViewTransaction.TabIndex = 0;
			base.AutoScaleDimensions = new System.Drawing.SizeF(6f, 13f);
			base.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
			base.ClientSize = new System.Drawing.Size(1277, 505);
			base.Controls.Add(this.splitContainerTransaction);
			base.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
			base.Load += new System.EventHandler(FormTransaction_Load);
			this.splitContainerTransaction.Panel1.ResumeLayout(false);
			this.splitContainerTransaction.Panel2.ResumeLayout(false);
			this.splitContainerTransaction.EndInit();
			this.splitContainerTransaction.ResumeLayout(false);
			this.groupBoxTransaction.ResumeLayout(false);
			this.groupBoxTransaction.PerformLayout();
			this.groupBoxInformation.ResumeLayout(false);
			((System.ComponentModel.ISupportInitialize)this.dataGridViewTransaction).EndInit();
			base.ResumeLayout(false);
		}
	}
}
