namespace OptionFVV
{
	public static class CallBackMy
	{
		public delegate void callbackEventColorThemeFormChart();

		public delegate void callbackEventColorThemeFormMain();

		public delegate void callbackEventColorThemeFormPortfolio();

		public delegate void callbackEventColorThemeFormBoard();

		public delegate void callbackEventColorThemeFormSmile();

		public delegate void callbackEventColorThemeFormCalculator();

		public delegate void callbackEventColorThemeFormData();

		public delegate void callbackEventColorThemeFormLog();

		public delegate void callbackEventColorThemeFormTransaction();

		public delegate void callbackEventUpdateTime(int updatetime);

		public delegate void callbackEventTickChart();

		public delegate void callbackEventAddTransactionFromBoard(string paper_code, double volume, double open_price);

		public delegate void callbackEventError(string iTimeDate, string iMessage);

		public delegate void callbackEventHeightPortfolio(int iHeightPortfolio);

		public delegate void callbackEventStatusLabelInfoWrite(string iText);

		public delegate void callbackEventUpdatePortfolio(string iText);

		public delegate void callbackEventOpenGlass(string iText);

		public delegate string callbackEventCurrentStrategy();

		public delegate double callbackEventDVP();

		public delegate double callbackEventSettingsModelSmile();

		public delegate bool callbackEventSettingsModelChecked();

		public delegate string callbackEventSettingsModelName();

		public static callbackEventColorThemeFormChart callbackEventHandlerColorThemeFormChart;

		public static callbackEventColorThemeFormMain callbackEventHandlerColorThemeFormMain;

		public static callbackEventColorThemeFormPortfolio callbackEventHandlerColorThemeFormPortfolio;

		public static callbackEventColorThemeFormBoard callbackEventHandlerColorThemeFormBoard;

		public static callbackEventColorThemeFormSmile callbackEventHandlerColorThemeFormSmile;

		public static callbackEventColorThemeFormCalculator callbackEventHandlerColorThemeFormCalculator;

		public static callbackEventColorThemeFormData callbackEventHandlerColorThemeFormData;

		public static callbackEventColorThemeFormLog callbackEventHandlerColorThemeFormLog;

		public static callbackEventColorThemeFormTransaction callbackEventHandlerColorThemeFormTransaction;

		public static callbackEventUpdateTime callbackEventHandlerUpdateTime;

		public static callbackEventTickChart callbackEventHandlerTickChart;

		public static callbackEventAddTransactionFromBoard callbackEventHandlerAddTransactionFromBoard;

		public static callbackEventError callbackEventHandlerError;

		public static callbackEventHeightPortfolio callbackEventHandlerHeightPortfolio;

		public static callbackEventStatusLabelInfoWrite callbackEventHandlerStatusLabelInfoWrite;

		public static callbackEventUpdatePortfolio callbackEventHandlerUpdatePortfolio;

		public static callbackEventOpenGlass callbackEventHandlerOpenGlass;

		public static callbackEventCurrentStrategy callbackEventHandlerCurrentStrategy;

		public static callbackEventDVP callbackEventHandlerD;

		public static callbackEventDVP callbackEventHandlerV;

		public static callbackEventDVP callbackEventHandlerP;

		public static callbackEventSettingsModelSmile callbackEventHandlerModelSmileVolatility;

		public static callbackEventSettingsModelSmile callbackEventHandlerModelSmileSkew;

		public static callbackEventSettingsModelSmile callbackEventHandlerModelSmileKink;

		public static callbackEventSettingsModelSmile callbackEventHandlerModelSmileCurrentStrike;

		public static callbackEventSettingsModelChecked callbackEventHandlerModelSmileChecked;

		public static callbackEventSettingsModelChecked callbackEventHandlerModelSmileVolatilityChecked;

		public static callbackEventSettingsModelName callbackEventHandlerModelSmileName;
	}
}
