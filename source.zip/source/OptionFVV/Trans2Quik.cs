using System;
using System.Runtime.InteropServices;
using System.Runtime.InteropServices.ComTypes;
using System.Text;

namespace OptionFVV
{
	internal class Trans2Quik
	{
		public delegate void OrderStatusHandler(int nMode, int dwTransID, double dNumber, [MarshalAs(UnmanagedType.LPStr)] string ClassCode, [MarshalAs(UnmanagedType.LPStr)] string SecCode, double dPrice, int nBalance, double dValue, int nIsSell, int nStatus, int nOrderDescriptor);

		public delegate void TradeStatusHandler(int nMode, double dNumber, double dOrderNumber, [MarshalAs(UnmanagedType.LPStr)] string ClassCode, [MarshalAs(UnmanagedType.LPStr)] string SecCode, double dPrice, int nQty, double dValue, int nIsSell, int nOrderDescriptor);

		public delegate void ConnectionStatusHandler(int nConnectionEvent, uint nExtendedErrorCode, byte[] lpstrInfoMessage);

		public delegate void TransactionStatusHandler(int nTransactionResult, int nTransactionExtendedErrorCode, int nTransactionReplyCode, uint dwTransId, double dOrderNum, [MarshalAs(UnmanagedType.LPStr)] string TransactionReplyMessage);

		public const int TRANS2QUIK_SUCCESS = 0;

		public const int TRANS2QUIK_FAILED = 1;

		public const int TRANS2QUIK_QUIK_TERMINAL_NOT_FOUND = 2;

		public const int TRANS2QUIK_DLL_VERSION_NOT_SUPPORTED = 3;

		public const int TRANS2QUIK_ALREADY_CONNECTED_TO_QUIK = 4;

		public const int TRANS2QUIK_WRONG_SYNTAX = 5;

		public const int TRANS2QUIK_QUIK_NOT_CONNECTED = 6;

		public const int TRANS2QUIK_DLL_NOT_CONNECTED = 7;

		public const int TRANS2QUIK_QUIK_CONNECTED = 8;

		public const int TRANS2QUIK_QUIK_DISCONNECTED = 9;

		public const int TRANS2QUIK_DLL_CONNECTED = 10;

		public const int TRANS2QUIK_DLL_DISCONNECTED = 11;

		public const int TRANS2QUIK_MEMORY_ALLOCATION_ERROR = 12;

		public const int TRANS2QUIK_WRONG_CONNECTION_HANDLE = 13;

		public const int TRANS2QUIK_WRONG_INPUT_PARAMS = 14;

		public const int ORDER_QUIKDATE = 0;

		public const int ORDER_QUIKTIME = 1;

		public const int ORDER_MICROSEC = 2;

		public const int ORDER_WITHDRAW_QUIKDATE = 3;

		public const int ORDER_WITHDRAW_QUIKTIME = 4;

		public const int ORDER_WITHDRAW_MICROSEC = 5;

		public const int TRADE_QUIKDATE = 0;

		public const int TRADE_QUIKTIME = 1;

		public const int TRADE_MICROSEC = 2;

		public static string PATH_2_QUIK = "D:\\QUIK\\DimaScub\\QUIK_OpenBroker\\";

		public event OrderStatusHandler OrderStatusChanged;

		public event TradeStatusHandler TradeStatusChanged;

		public event ConnectionStatusHandler ConnectionStatusChanged;

		public event TransactionStatusHandler TransactionStatusChanged;

		public string ResultToString(int Result)
		{
			switch (Result)
			{
			case 0:
				return "TRANS2QUIK_SUCCESS";
			case 1:
				return "TRANS2QUIK_FAILED";
			case 2:
				return "TRANS2QUIK_QUIK_TERMINAL_NOT_FOUND";
			case 3:
				return "TRANS2QUIK_DLL_VERSION_NOT_SUPPORTED";
			case 4:
				return "TRANS2QUIK_ALREADY_CONNECTED_TO_QUIK";
			case 5:
				return "TRANS2QUIK_WRONG_SYNTAX";
			case 6:
				return "TRANS2QUIK_QUIK_NOT_CONNECTED";
			case 7:
				return "TRANS2QUIK_DLL_NOT_CONNECTED";
			case 8:
				return "TRANS2QUIK_QUIK_CONNECTED";
			case 9:
				return "TRANS2QUIK_QUIK_DISCONNECTED";
			case 10:
				return "TRANS2QUIK_DLL_CONNECTED";
			case 11:
				return "TRANS2QUIK_DLL_DISCONNECTED";
			case 12:
				return "TRANS2QUIK_MEMORY_ALLOCATION_ERROR";
			case 13:
				return "TRANS2QUIK_WRONG_CONNECTION_HANDLE";
			case 14:
				return "TRANS2QUIK_WRONG_INPUT_PARAMS";
			default:
				return "UNKNOWN_VALUE";
			}
		}

		public string ByteToString(byte[] Str)
		{
			int count = 0;
			for (int index = 0; index < Str.Length; index++)
			{
				if (Str[index] == 0)
				{
					count = index;
					break;
				}
			}
			return Encoding.Default.GetString(Str, 0, count);
		}

		public string DateTimeStr(System.Runtime.InteropServices.ComTypes.FILETIME filetime)
		{
			return DateTime.FromFileTime((long)filetime.dwHighDateTime << 32 + filetime.dwLowDateTime).ToString();
		}

		[DllImport("TRANS2QUIK.DLL", CallingConvention = CallingConvention.StdCall, EntryPoint = "_TRANS2QUIK_CONNECT@16")]
		private static extern int connect(string lpcstrConnectionParamsString, ref int pnExtendedErrorCode, byte[] lpstrErrorMessage, uint dwErrorMessageSize);

		public string connect_test()
		{
			byte[] lpstrErrorMessage = new byte[50];
			uint dwErrorMessageSize = 50u;
			int pnExtendedErrorCode = 0;
			int num = connect(PATH_2_QUIK, ref pnExtendedErrorCode, lpstrErrorMessage, dwErrorMessageSize);
			return string.Format("\r\n{0} {1} ", num & 0xFF, ResultToString(num & 0xFF)) + string.Format("  ExtEC={0}, EMsg={1}, EMsgSz={2}\r\n", pnExtendedErrorCode & 0xFF, lpstrErrorMessage, dwErrorMessageSize);
		}

		public int connect_test1()
		{
			byte[] lpstrErrorMessage = new byte[50];
			uint dwErrorMessageSize = 50u;
			int pnExtendedErrorCode = 0;
			int num = connect(PATH_2_QUIK, ref pnExtendedErrorCode, lpstrErrorMessage, dwErrorMessageSize);
			string str = string.Format("\r\n{0} {1} ", num & 0xFF, ResultToString(num & 0xFF)) + string.Format("  ExtEC={0}, EMsg={1}, EMsgSz={2}\r\n", pnExtendedErrorCode & 0xFF, lpstrErrorMessage, dwErrorMessageSize);
			return num;
		}

		[DllImport("TRANS2QUIK.DLL", CallingConvention = CallingConvention.StdCall, EntryPoint = "_TRANS2QUIK_IS_DLL_CONNECTED@12")]
		private static extern int is_dll_connected(ref int pnExtendedErrorCode, byte[] lpstrErrorMessage, uint dwErrorMessageSize);

		public void is_dll_connected_test()
		{
			byte[] lpstrErrorMessage = new byte[50];
			uint dwErrorMessageSize = 50u;
			int pnExtendedErrorCode = 0;
			int num = -1;
			num = is_dll_connected(ref pnExtendedErrorCode, lpstrErrorMessage, dwErrorMessageSize);
		}

		public bool IsDLLConnected()
		{
			byte[] lpstrErrorMessage = new byte[50];
			uint dwErrorMessageSize = 50u;
			int pnExtendedErrorCode = 0;
			return (is_dll_connected(ref pnExtendedErrorCode, lpstrErrorMessage, dwErrorMessageSize) & 0xFF) == 10;
		}

		[DllImport("TRANS2QUIK.DLL", CallingConvention = CallingConvention.StdCall, EntryPoint = "_TRANS2QUIK_DISCONNECT@12")]
		private static extern int disconnect(ref int pnExtendedErrorCode, byte[] lpstrErrorMessage, uint dwErrorMessageSize);

		public void disconnect_test()
		{
			byte[] lpstrErrorMessage = new byte[50];
			uint dwErrorMessageSize = 50u;
			int pnExtendedErrorCode = 0;
			int num = -1;
			num = disconnect(ref pnExtendedErrorCode, lpstrErrorMessage, dwErrorMessageSize);
		}

		[DllImport("TRANS2QUIK.DLL", CallingConvention = CallingConvention.StdCall, EntryPoint = "_TRANS2QUIK_IS_QUIK_CONNECTED@12")]
		private static extern int is_quik_connected(ref int pnExtendedErrorCode, byte[] lpstrErrorMessage, uint dwErrorMessageSize);

		public void IsQuikConnected(ref bool ret)
		{
			byte[] lpstrErrorMessage = new byte[50];
			int pnExtendedErrorCode = 0;
			uint dwErrorMessageSize = 50u;
			if ((is_quik_connected(ref pnExtendedErrorCode, lpstrErrorMessage, dwErrorMessageSize) & 0xFF) == 8)
			{
				ret = true;
			}
			else
			{
				ret = false;
			}
		}

		public bool IsQuikConnected()
		{
			byte[] lpstrErrorMessage = new byte[50];
			int pnExtendedErrorCode = 0;
			uint dwErrorMessageSize = 50u;
			return (is_quik_connected(ref pnExtendedErrorCode, lpstrErrorMessage, dwErrorMessageSize) & 0xFF) == 8;
		}

		public void is_quik_connected_test()
		{
			byte[] lpstrErrorMessage = new byte[50];
			int pnExtendedErrorCode = 0;
			int num = -1;
			uint dwErrorMessageSize = 50u;
			num = is_quik_connected(ref pnExtendedErrorCode, lpstrErrorMessage, dwErrorMessageSize);
		}

		[DllImport("TRANS2QUIK.DLL", CallingConvention = CallingConvention.StdCall, EntryPoint = "_TRANS2QUIK_SEND_SYNC_TRANSACTION@36")]
		private static extern int send_sync_transaction(string lpstTransactionString, ref int pnReplyCode, ref int pdwTransId, ref double pdOrderNum, byte[] lpstrResultMessage, uint dwResultMessageSize, ref int pnExtendedErrorCode, byte[] lpstrErrorMessage, uint dwErrorMessageSize);

		public void send_sync_transaction_test(string transactionStr, ref double OrderNum, ref int TransID)
		{
			byte[] lpstrErrorMessage = new byte[50];
			byte[] numArray = new byte[50];
			int pnExtendedErrorCode = -100;
			int num = -1;
			int pnReplyCode = 0;
			uint dwResultMessageSize = 50u;
			uint dwErrorMessageSize = 50u;
			num = send_sync_transaction(transactionStr, ref pnReplyCode, ref TransID, ref OrderNum, numArray, dwResultMessageSize, ref pnExtendedErrorCode, lpstrErrorMessage, dwErrorMessageSize);
			ByteToString(numArray).Trim();
		}

		[DllImport("TRANS2QUIK.DLL", CallingConvention = CallingConvention.StdCall, EntryPoint = "_TRANS2QUIK_SET_TRANSACTIONS_REPLY_CALLBACK@16")]
		public static extern int set_transaction_reply_callback(TransactionStatusHandler pfTransactionReplyCallback, ref int pnExtendedErrorCode, byte[] lpstrErrorMessage, uint dwErrorMessageSize);

		[DllImport("TRANS2QUIK.DLL", CallingConvention = CallingConvention.StdCall, EntryPoint = "_TRANS2QUIK_SEND_ASYNC_TRANSACTION@16")]
		public static extern int send_async_transaction([MarshalAs(UnmanagedType.LPStr)] string transactionString, ref int nExtendedErrorCode, byte[] lpstrErrorMessage, uint dwErrorMessageSize);

		public int send_async_transaction_test(string transactionString)
		{
			uint dwErrorMessageSize = 256u;
			byte[] lpstrErrorMessage = new byte[dwErrorMessageSize];
			int nExtendedErrorCode = 0;
			return send_async_transaction(transactionString, ref nExtendedErrorCode, lpstrErrorMessage, dwErrorMessageSize);
		}

		[DllImport("TRANS2QUIK.DLL", CallingConvention = CallingConvention.StdCall, EntryPoint = "_TRANS2QUIK_SUBSCRIBE_ORDERS@8")]
		public static extern int subscribe_orders([MarshalAs(UnmanagedType.LPStr)] string class_code, [MarshalAs(UnmanagedType.LPStr)] string sec_code);

		[DllImport("TRANS2QUIK.DLL", CallingConvention = CallingConvention.StdCall, EntryPoint = "_TRANS2QUIK_UNSUBSCRIBE_ORDERS@0")]
		public static extern int ubsubscribe_orders();

		[DllImport("TRANS2QUIK.DLL", CallingConvention = CallingConvention.StdCall, EntryPoint = "_TRANS2QUIK_START_ORDERS@4")]
		public static extern int start_orders(OrderStatusHandler pfOrderStatusCallback);

		[DllImport("TRANS2QUIK.DLL", CallingConvention = CallingConvention.StdCall, EntryPoint = "_TRANS2QUIK_ORDER_QTY@4")]
		public static extern int TRANS2QUIK_ORDER_QTY(int nOrderDescriptor);

		[DllImport("TRANS2QUIK.DLL", CallingConvention = CallingConvention.StdCall, EntryPoint = "_TRANS2QUIK_ORDER_DATE@4")]
		public static extern int TRANS2QUIK_ORDER_DATE(int nOrderDescriptor);

		[DllImport("TRANS2QUIK.DLL", CallingConvention = CallingConvention.StdCall, EntryPoint = "_TRANS2QUIK_ORDER_TIME@4")]
		public static extern int TRANS2QUIK_ORDER_TIME(int nOrderDescriptor);

		[DllImport("TRANS2QUIK.DLL", CallingConvention = CallingConvention.StdCall, EntryPoint = "_TRANS2QUIK_ORDER_DATE_TIME@8")]
		public static extern int TRANS2QUIK_ORDER_DATE_TIME(int nOrderDescriptor, int nTimeType);

		[DllImport("TRANS2QUIK.DLL", CallingConvention = CallingConvention.StdCall, EntryPoint = "_TRANS2QUIK_ORDER_ACTIVATION_TIME@4")]
		public static extern int TRANS2QUIK_ORDER_ACTIVATION_TIME(int nOrderDescriptor);

		[DllImport("TRANS2QUIK.DLL", CallingConvention = CallingConvention.StdCall, EntryPoint = "_TRANS2QUIK_ORDER_WITHDRAW_TIME@4")]
		public static extern int TRANS2QUIK_ORDER_WITHDRAW_TIME(int nOrderDescriptor);

		[DllImport("TRANS2QUIK.DLL", CallingConvention = CallingConvention.StdCall, EntryPoint = "_TRANS2QUIK_ORDER_EXPIRY@4")]
		public static extern int TRANS2QUIK_ORDER_EXPIRY(int nOrderDescriptor);

		[DllImport("TRANS2QUIK.DLL", CallingConvention = CallingConvention.StdCall, EntryPoint = "_TRANS2QUIK_ORDER_ACCRUED_INT@4")]
		public static extern double TRANS2QUIK_ORDER_ACCRUED_INT(int nOrderDescriptor);

		[DllImport("TRANS2QUIK.DLL", CallingConvention = CallingConvention.StdCall, EntryPoint = "_TRANS2QUIK_ORDER_YIELD@4")]
		public static extern double TRANS2QUIK_ORDER_YIELD(int nOrderDescriptor);

		[DllImport("TRANS2QUIK.DLL", CallingConvention = CallingConvention.StdCall, EntryPoint = "_TRANS2QUIK_ORDER_UID@4")]
		public static extern int TRANS2QUIK_ORDER_UID(int nOrderDescriptor);

		[DllImport("TRANS2QUIK.DLL", CallingConvention = CallingConvention.StdCall, EntryPoint = "_TRANS2QUIK_ORDER_VISIBLE_QTY@4")]
		public static extern int TRANS2QUIK_ORDER_VISIBLE_QTY(int nOrderDescriptor);

		[DllImport("TRANS2QUIK.DLL", CallingConvention = CallingConvention.StdCall, EntryPoint = "_TRANS2QUIK_ORDER_PERIOD@4")]
		public static extern int TRANS2QUIK_ORDER_PERIOD(int nOrderDescriptor);

		[DllImport("TRANS2QUIK.DLL", CallingConvention = CallingConvention.StdCall, EntryPoint = "_TRANS2QUIK_ORDER_FILETIME@4")]
		public static extern System.Runtime.InteropServices.ComTypes.FILETIME TRANS2QUIK_ORDER_FILETIME(int nOrderDescriptor);

		[DllImport("TRANS2QUIK.DLL", CallingConvention = CallingConvention.StdCall, EntryPoint = "_TRANS2QUIK_ORDER_WITHDRAW_FILETIME@4")]
		public static extern System.Runtime.InteropServices.ComTypes.FILETIME TRANS2QUIK_ORDER_WITHDRAW_FILETIME(int nOrderDescriptor);

		[DllImport("TRANS2QUIK.DLL", CallingConvention = CallingConvention.StdCall, EntryPoint = "_TRANS2QUIK_ORDER_USERID@4")]
		public static extern IntPtr TRANS2QUIK_ORDER_USERID_IMPL(int nOrderDescriptor);

		public string TRANS2QUIK_ORDER_USERID(int nOrderDescriptor)
		{
			return Marshal.PtrToStringAnsi(TRANS2QUIK_ORDER_USERID_IMPL(nOrderDescriptor));
		}

		[DllImport("TRANS2QUIK.DLL", CallingConvention = CallingConvention.StdCall, EntryPoint = "_TRANS2QUIK_ORDER_ACCOUNT@4")]
		public static extern IntPtr TRANS2QUIK_ORDER_ACCOUNT_IMPL(int nOrderDescriptor);

		public static string TRANS2QUIK_ORDER_ACCOUNT(int nOrderDescriptor)
		{
			return Marshal.PtrToStringAnsi(TRANS2QUIK_ORDER_ACCOUNT_IMPL(nOrderDescriptor));
		}

		[DllImport("TRANS2QUIK.DLL", CallingConvention = CallingConvention.StdCall, EntryPoint = "_TRANS2QUIK_ORDER_BROKERREF@4")]
		public static extern IntPtr TRANS2QUIK_ORDER_BROKERREF_IMPL(int nOrderDescriptor);

		public static string TRANS2QUIK_ORDER_BROKERREF(int nOrderDescriptor)
		{
			return Marshal.PtrToStringAnsi(TRANS2QUIK_ORDER_BROKERREF_IMPL(nOrderDescriptor));
		}

		[DllImport("TRANS2QUIK.DLL", CallingConvention = CallingConvention.StdCall, EntryPoint = "_TRANS2QUIK_ORDER_CLIENT_CODE@4")]
		public static extern IntPtr TRANS2QUIK_ORDER_CLIENT_CODE_IMPL(int nOrderDescriptor);

		public static string TRANS2QUIK_ORDER_CLIENT_CODE(int nOrderDescriptor)
		{
			return Marshal.PtrToStringAnsi(TRANS2QUIK_ORDER_CLIENT_CODE_IMPL(nOrderDescriptor));
		}

		[DllImport("TRANS2QUIK.DLL", CallingConvention = CallingConvention.StdCall, EntryPoint = "_TRANS2QUIK_ORDER_FIRMID@4")]
		public static extern IntPtr TRANS2QUIK_ORDER_FIRMID_IMPL(int nOrderDescriptor);

		public static string TRANS2QUIK_ORDER_FIRMID(int nOrderDescriptor)
		{
			return Marshal.PtrToStringAnsi(TRANS2QUIK_ORDER_FIRMID_IMPL(nOrderDescriptor));
		}

		[DllImport("TRANS2QUIK.DLL", CallingConvention = CallingConvention.StdCall, EntryPoint = "_TRANS2QUIK_SUBSCRIBE_TRADES@8")]
		public static extern int subscribe_trades([MarshalAs(UnmanagedType.LPStr)] string class_code, [MarshalAs(UnmanagedType.LPStr)] string sec_code);

		[DllImport("TRANS2QUIK.DLL", CallingConvention = CallingConvention.StdCall, EntryPoint = "_TRANS2QUIK_UNSUBSCRIBE_TRADES@0")]
		public static extern int ubsubscribe_trades();

		[DllImport("TRANS2QUIK.DLL", CallingConvention = CallingConvention.StdCall, EntryPoint = "_TRANS2QUIK_START_TRADES@4")]
		public static extern int start_trades(TradeStatusHandler pfTradeStatusCallback);

		[DllImport("TRANS2QUIK.DLL", CallingConvention = CallingConvention.StdCall, EntryPoint = "_TRANS2QUIK_TRADE_DATE@4")]
		public static extern int TRANS2QUIK_TRADE_DATE(int nTradeDescriptor);

		[DllImport("TRANS2QUIK.DLL", CallingConvention = CallingConvention.StdCall, EntryPoint = "_TRANS2QUIK_TRADE_SETTLE_DATE@4")]
		public static extern int TRANS2QUIK_TRADE_SETTLE_DATE(int nTradeDescriptor);

		[DllImport("TRANS2QUIK.DLL", CallingConvention = CallingConvention.StdCall, EntryPoint = "_TRANS2QUIK_TRADE_TIME@4")]
		public static extern int TRANS2QUIK_TRADE_TIME(int nTradeDescriptor);

		[DllImport("TRANS2QUIK.DLL", CallingConvention = CallingConvention.StdCall, EntryPoint = "_TRANS2QUIK_TRADE_IS_MARGINAL@4")]
		public static extern int TRANS2QUIK_TRADE_IS_MARGINAL(int nTradeDescriptor);

		[DllImport("TRANS2QUIK.DLL", CallingConvention = CallingConvention.StdCall, EntryPoint = "_TRANS2QUIK_TRADE_ACCRUED_INT@4")]
		public static extern double TRANS2QUIK_TRADE_ACCRUED_INT(int nTradeDescriptor);

		[DllImport("TRANS2QUIK.DLL", CallingConvention = CallingConvention.StdCall, EntryPoint = "_TRANS2QUIK_TRADE_YIELD@4")]
		public static extern double TRANS2QUIK_TRADE_YIELD(int nTradeDescriptor);

		[DllImport("TRANS2QUIK.DLL", CallingConvention = CallingConvention.StdCall, EntryPoint = "_TRANS2QUIK_TRADE_TS_COMMISSION@4")]
		public static extern double TRANS2QUIK_TRADE_TS_COMMISSION(int nTradeDescriptor);

		[DllImport("TRANS2QUIK.DLL", CallingConvention = CallingConvention.StdCall, EntryPoint = "_TRANS2QUIK_TRADE_CLEARING_CENTER_COMMISSION@4")]
		public static extern double TRANS2QUIK_TRADE_CLEARING_CENTER_COMMISSION(int nTradeDescriptor);

		[DllImport("TRANS2QUIK.DLL", CallingConvention = CallingConvention.StdCall, EntryPoint = "_TRANS2QUIK_TRADE_EXCHANGE_COMMISSION@4")]
		public static extern double TRANS2QUIK_TRADE_EXCHANGE_COMMISSION(int nTradeDescriptor);

		[DllImport("TRANS2QUIK.DLL", CallingConvention = CallingConvention.StdCall, EntryPoint = "_TRANS2QUIK_TRADE_TRADING_SYSTEM_COMMISSION@4")]
		public static extern double TRANS2QUIK_TRADE_TRADING_SYSTEM_COMMISSION(int nTradeDescriptor);

		[DllImport("TRANS2QUIK.DLL", CallingConvention = CallingConvention.StdCall, EntryPoint = "_TRANS2QUIK_TRADE_PRICE2@4")]
		public static extern double TRANS2QUIK_TRADE_PRICE2(int nTradeDescriptor);

		[DllImport("TRANS2QUIK.DLL", CallingConvention = CallingConvention.StdCall, EntryPoint = "_TRANS2QUIK_TRADE_REPO_RATE@4")]
		public static extern double TRANS2QUIK_TRADE_REPO_RATE(int nTradeDescriptor);

		[DllImport("TRANS2QUIK.DLL", CallingConvention = CallingConvention.StdCall, EntryPoint = "_TRANS2QUIK_TRADE_REPO_VALUE@4")]
		public static extern double TRANS2QUIK_TRADE_REPO_VALUE(int nTradeDescriptor);

		[DllImport("TRANS2QUIK.DLL", CallingConvention = CallingConvention.StdCall, EntryPoint = "_TRANS2QUIK_TRADE_REPO2_VALUE@4")]
		public static extern double TRANS2QUIK_TRADE_REPO2_VALUE(int nTradeDescriptor);

		[DllImport("TRANS2QUIK.DLL", CallingConvention = CallingConvention.StdCall, EntryPoint = "_TRANS2QUIK_TRADE_ACCRUED_INT2@4")]
		public static extern double TRANS2QUIK_TRADE_ACCRUED_INT2(int nTradeDescriptor);

		[DllImport("TRANS2QUIK.DLL", CallingConvention = CallingConvention.StdCall, EntryPoint = "_TRANS2QUIK_TRADE_REPO_TERM@4")]
		public static extern int TRANS2QUIK_TRADE_REPO_TERM(int nTradeDescriptor);

		[DllImport("TRANS2QUIK.DLL", CallingConvention = CallingConvention.StdCall, EntryPoint = "_TRANS2QUIK_TRADE_START_DISCOUNT@4")]
		public static extern double TRANS2QUIK_TRADE_START_DISCOUNT(int nTradeDescriptor);

		[DllImport("TRANS2QUIK.DLL", CallingConvention = CallingConvention.StdCall, EntryPoint = "_TRANS2QUIK_TRADE_LOWER_DISCOUNT@4")]
		public static extern double TRANS2QUIK_TRADE_LOWER_DISCOUNT(int nTradeDescriptor);

		[DllImport("TRANS2QUIK.DLL", CallingConvention = CallingConvention.StdCall, EntryPoint = "_TRANS2QUIK_TRADE_UPPER_DISCOUNT@4")]
		public static extern double TRANS2QUIK_TRADE_UPPER_DISCOUNT(int nTradeDescriptor);

		[DllImport("TRANS2QUIK.DLL", CallingConvention = CallingConvention.StdCall, EntryPoint = "_TRANS2QUIK_TRADE_BLOCK_SECURITIES@4")]
		public static extern int TRANS2QUIK_TRADE_BLOCK_SECURITIES(int nTradeDescriptor);

		[DllImport("TRANS2QUIK.DLL", CallingConvention = CallingConvention.StdCall, EntryPoint = "_TRANS2QUIK_TRADE_PERIOD@4")]
		public static extern int TRANS2QUIK_TRADE_PERIOD(int nTradeDescriptor);

		[DllImport("TRANS2QUIK.DLL", CallingConvention = CallingConvention.StdCall, EntryPoint = "_TRANS2QUIK_TRADE_DATE_TIME@8")]
		public static extern int TRANS2QUIK_TRADE_DATE_TIME(int nTradeDescriptor, int nTimeType);

		[DllImport("TRANS2QUIK.DLL", CallingConvention = CallingConvention.StdCall, EntryPoint = "_TRANS2QUIK_TRADE_FILETIME@4")]
		public static extern System.Runtime.InteropServices.ComTypes.FILETIME TRANS2QUIK_TRADE_FILETIME(int nTradeDescriptor);

		[DllImport("TRANS2QUIK.DLL", CallingConvention = CallingConvention.StdCall, EntryPoint = "_TRANS2QUIK_TRADE_KIND@4")]
		public static extern int TRANS2QUIK_TRADE_KIND(int nTradeDescriptor);

		[DllImport("TRANS2QUIK.DLL", CallingConvention = CallingConvention.StdCall, EntryPoint = "_TRANS2QUIK_TRADE_CURRENCY@4")]
		public static extern IntPtr TRANS2QUIK_TRADE_CURRENCY_IMPL(int nTradeDescriptor);

		public static string TRANS2QUIK_TRADE_CURRENCY(int nTradeDescriptor)
		{
			return Marshal.PtrToStringAnsi(TRANS2QUIK_TRADE_CURRENCY_IMPL(nTradeDescriptor));
		}

		[DllImport("TRANS2QUIK.DLL", CallingConvention = CallingConvention.StdCall, EntryPoint = "_TRANS2QUIK_TRADE_SETTLE_CURRENCY@4")]
		public static extern IntPtr TRANS2QUIK_TRADE_SETTLE_CURRENCY_IMPL(int nTradeDescriptor);

		public static string TRANS2QUIK_TRADE_SETTLE_CURRENCY(int nTradeDescriptor)
		{
			return Marshal.PtrToStringAnsi(TRANS2QUIK_TRADE_SETTLE_CURRENCY_IMPL(nTradeDescriptor));
		}

		[DllImport("TRANS2QUIK.DLL", CallingConvention = CallingConvention.StdCall, EntryPoint = "_TRANS2QUIK_TRADE_SETTLE_CODE@4")]
		public static extern IntPtr TRANS2QUIK_TRADE_SETTLE_CODE_IMPL(int nTradeDescriptor);

		public static string TRANS2QUIK_TRADE_SETTLE_CODE(int nTradeDescriptor)
		{
			return Marshal.PtrToStringAnsi(TRANS2QUIK_TRADE_SETTLE_CODE_IMPL(nTradeDescriptor));
		}

		[DllImport("TRANS2QUIK.DLL", CallingConvention = CallingConvention.StdCall, EntryPoint = "_TRANS2QUIK_TRADE_ACCOUNT@4")]
		public static extern IntPtr TRANS2QUIK_TRADE_ACCOUNT_IMPL(int nTradeDescriptor);

		public static string TRANS2QUIK_TRADE_ACCOUNT(int nTradeDescriptor)
		{
			return Marshal.PtrToStringAnsi(TRANS2QUIK_TRADE_ACCOUNT_IMPL(nTradeDescriptor));
		}

		[DllImport("TRANS2QUIK.DLL", CallingConvention = CallingConvention.StdCall, EntryPoint = "_TRANS2QUIK_TRADE_BROKERREF@4")]
		public static extern IntPtr TRANS2QUIK_TRADE_BROKERREF_IMPL(int nTradeDescriptor);

		public static string TRANS2QUIK_TRADE_BROKERREF(int nTradeDescriptor)
		{
			return Marshal.PtrToStringAnsi(TRANS2QUIK_TRADE_BROKERREF_IMPL(nTradeDescriptor));
		}

		[DllImport("TRANS2QUIK.DLL", CallingConvention = CallingConvention.StdCall, EntryPoint = "_TRANS2QUIK_TRADE_CLIENT_CODE@4")]
		public static extern IntPtr TRANS2QUIK_TRADE_CLIENT_CODE_IMPL(int nTradeDescriptor);

		public static string TRANS2QUIK_TRADE_CLIENT_CODE(int nTradeDescriptor)
		{
			return Marshal.PtrToStringAnsi(TRANS2QUIK_TRADE_CLIENT_CODE_IMPL(nTradeDescriptor));
		}

		[DllImport("TRANS2QUIK.DLL", CallingConvention = CallingConvention.StdCall, EntryPoint = "_TRANS2QUIK_TRADE_USERID@4")]
		public static extern IntPtr TRANS2QUIK_TRADE_USERID_IMPL(int nTradeDescriptor);

		public static string TRANS2QUIK_TRADE_USERID(int nTradeDescriptor)
		{
			return Marshal.PtrToStringAnsi(TRANS2QUIK_TRADE_USERID_IMPL(nTradeDescriptor));
		}

		[DllImport("TRANS2QUIK.DLL", CallingConvention = CallingConvention.StdCall, EntryPoint = "_TRANS2QUIK_TRADE_FIRMID@4")]
		public static extern IntPtr TRANS2QUIK_TRADE_FIRMID_IMPL(int nTradeDescriptor);

		public static string TRANS2QUIK_TRADE_FIRMID(int nTradeDescriptor)
		{
			return Marshal.PtrToStringAnsi(TRANS2QUIK_TRADE_FIRMID_IMPL(nTradeDescriptor));
		}

		[DllImport("TRANS2QUIK.DLL", CallingConvention = CallingConvention.StdCall, EntryPoint = "_TRANS2QUIK_TRADE_PARTNER_FIRMID@4")]
		public static extern IntPtr TRANS2QUIK_TRADE_PARTNER_FIRMID_IMPL(int nTradeDescriptor);

		public static string TRANS2QUIK_TRADE_PARTNER_FIRMID(int nTradeDescriptor)
		{
			return Marshal.PtrToStringAnsi(TRANS2QUIK_TRADE_PARTNER_FIRMID_IMPL(nTradeDescriptor));
		}

		[DllImport("TRANS2QUIK.DLL", CallingConvention = CallingConvention.StdCall, EntryPoint = "_TRANS2QUIK_TRADE_EXCHANGE_CODE@4")]
		public static extern IntPtr TRANS2QUIK_TRADE_EXCHANGE_CODE_IMPL(int nTradeDescriptor);

		public static string TRANS2QUIK_TRADE_EXCHANGE_CODE(int nTradeDescriptor)
		{
			return Marshal.PtrToStringAnsi(TRANS2QUIK_TRADE_EXCHANGE_CODE_IMPL(nTradeDescriptor));
		}

		[DllImport("TRANS2QUIK.DLL", CallingConvention = CallingConvention.StdCall, EntryPoint = "_TRANS2QUIK_TRADE_STATION_ID@4")]
		public static extern IntPtr TRANS2QUIK_TRADE_STATION_ID_IMPL(int nTradeDescriptor);

		public static string TRANS2QUIK_TRADE_STATION_ID(int nTradeDescriptor)
		{
			return Marshal.PtrToStringAnsi(TRANS2QUIK_TRADE_STATION_ID_IMPL(nTradeDescriptor));
		}

		[DllImport("TRANS2QUIK.DLL", CallingConvention = CallingConvention.StdCall, EntryPoint = "_TRANS2QUIK_SET_CONNECTION_STATUS_CALLBACK@16")]
		public static extern int set_connection_status_callback(ConnectionStatusHandler pfConnectionStatusCallback, uint pnExtendedErrorCode, byte[] lpstrErrorMessage, uint dwErrorMessageSize);
	}
}
