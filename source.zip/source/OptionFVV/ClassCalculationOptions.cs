using System;

namespace OptionFVV
{
	internal class ClassCalculationOptions
	{
		private const double Pi = 3.1415926535;

		private double iTheoPrice;

		private double iVola;

		private double iDelta;

		private double iGamma;

		private double iVega;

		private double iTheta;

		private double iVomma;

		private double iVanna;

		private double iCharm;

		private string iMessageError;

		private string iTypeO;

		private double iStrike;

		private DateTime iDateExp;

		private DateTime iDate;

		private double iTheo;

		private double iVolaO;

		private double iLastF;

		private int iQ;

		public string TypeO
		{
			get
			{
				return iTypeO;
			}
			set
			{
				if (value != null)
				{
					iTypeO = value.ToUpper();
					if (iTypeO == "")
					{
						iTypeO = "FUT";
					}
				}
			}
		}

		public double Strike
		{
			get
			{
				return iStrike;
			}
			set
			{
				iStrike = value;
			}
		}

		public DateTime DateExp
		{
			get
			{
				return iDateExp;
			}
			set
			{
				iDateExp = value;
			}
		}

		public DateTime DateCurrent
		{
			get
			{
				return iDate;
			}
			set
			{
				iDate = value;
			}
		}

		public double Theo
		{
			get
			{
				return iTheo;
			}
			set
			{
				iTheo = value;
			}
		}

		public double VolaO
		{
			get
			{
				return iVolaO;
			}
			set
			{
				iVolaO = value;
			}
		}

		public double LastF
		{
			get
			{
				return iLastF;
			}
			set
			{
				iLastF = value;
			}
		}

		public int Q
		{
			get
			{
				return iQ;
			}
			set
			{
				iQ = value;
			}
		}

		public double calcTheoPrice
		{
			get
			{
				return iTheoPrice;
			}
			set
			{
				iTheoPrice = value;
			}
		}

		public double calcVola
		{
			get
			{
				return iVola;
			}
			set
			{
				iVola = value;
			}
		}

		public double calcDelta
		{
			get
			{
				return iDelta;
			}
			set
			{
				iDelta = value;
			}
		}

		public double calcGamma
		{
			get
			{
				return iGamma;
			}
			set
			{
				iGamma = value;
			}
		}

		public double calcVega
		{
			get
			{
				return iVega;
			}
			set
			{
				iVega = value;
			}
		}

		public double calcTheta
		{
			get
			{
				return iTheta;
			}
			set
			{
				iTheta = value;
			}
		}

		public double calcVomma
		{
			get
			{
				return iVomma;
			}
			set
			{
				iVomma = value;
			}
		}

		public double calcVanna
		{
			get
			{
				return iVanna;
			}
			set
			{
				iVanna = value;
			}
		}

		public double calcCharm
		{
			get
			{
				return iCharm;
			}
			set
			{
				iCharm = value;
			}
		}

		public string calcMessageError
		{
			get
			{
				return iMessageError;
			}
			set
			{
				iMessageError = value;
			}
		}

		public ClassCalculationOptions()
		{
			iTheoPrice = 0.0;
			iVola = 0.0;
			iDelta = 0.0;
			iGamma = 0.0;
			iVega = 0.0;
			iTheta = 0.0;
			iVomma = 0.0;
			iVanna = 0.0;
			iCharm = 0.0;
			iMessageError = "";
			iTypeO = "";
			iStrike = 0.0;
			iDateExp = DateTime.Now;
			iDate = DateTime.Now;
			iTheo = 0.0;
			iVolaO = 0.0;
			iLastF = 0.0;
			iQ = 0;
		}

		public bool CalculationVola()
		{
			bool flag1 = true;
			double num1 = 0.01;
			double num2 = 0.0;
			double num3 = 0.0;
			double num4 = 0.0;
			double num5 = 0.0;
			int num6 = 0;
			bool flag2 = false;
			double num7 = 50.0;
			double num8 = 25.0;
			for (int index = 1; index <= 10000; index++)
			{
				double num9;
				if (num7 <= 1.0)
				{
					num7 = 0.0;
					num9 = 0.0;
					num2 = 0.0;
					num3 = 0.0;
					num4 = 0.0;
					num5 = 0.0;
				}
				else
				{
					iVolaO = num7;
					if (!CalculationOpt())
					{
						return false;
					}
					num9 = iTheoPrice;
					num2 = iDelta;
					num3 = iGamma;
					num4 = iVega;
					num5 = iTheta;
				}
				if (100.0 * Math.Abs((num9 - iTheo) / iTheo) < num1)
				{
					flag2 = true;
					break;
				}
				if (num9 > iTheo)
				{
					switch (num6)
					{
					case 0:
						num7 -= num8;
						num6 = -1;
						break;
					case 1:
						num8 /= 2.0;
						num7 -= num8;
						num6 = -1;
						break;
					default:
						num7 -= num8;
						num6 = -1;
						break;
					}
				}
				else if (num9 < iTheo)
				{
					switch (num6)
					{
					case 0:
						num7 += num8;
						num6 = 1;
						break;
					case 1:
						num7 += num8;
						num6 = 1;
						break;
					default:
						num8 /= 2.0;
						num7 += num8;
						num6 = 1;
						break;
					}
				}
				else if (num9 == iTheo)
				{
					flag2 = true;
					break;
				}
			}
			if (flag2)
			{
				iVola = num7;
				iDelta = num2;
				iTheta = num5;
				iGamma = num3;
				iVega = num4;
			}
			else
			{
				flag1 = false;
				iMessageError += "Не удалось рассчитать волу";
				iVola = 0.0;
				iDelta = 0.0;
				iTheta = 0.0;
				iGamma = 0.0;
				iVega = 0.0;
			}
			return flag1;
		}

		public bool CalculationOpt()
		{
			bool flag1 = true;
			if (iDateExp == iDate)
			{
				bool flag2 = true;
				if (iTypeO == "CALL" && iQ > 0)
				{
					iTheoPrice = Math.Max(0.0, this.iLastF - this.iStrike);
				}
				else if (iTypeO == "CALL" && iQ < 0)
				{
					iTheoPrice = Math.Abs(Math.Min(0.0, this.iStrike - this.iLastF));
				}
				else if (iTypeO == "PUT" && iQ > 0)
				{
					iTheoPrice = Math.Max(0.0, this.iStrike - this.iLastF);
				}
				else if (iTypeO == "PUT" && iQ < 0)
				{
					iTheoPrice = Math.Abs(Math.Min(0.0, this.iLastF - this.iStrike));
				}
				else if (iTypeO == "FUT" && iQ != 0)
				{
					iTheoPrice = this.iLastF;
				}
				iDelta = 0.0;
				iTheta = 0.0;
				iGamma = 0.0;
				iVega = 0.0;
				iVomma = 0.0;
				iCharm = 0.0;
				iVanna = 0.0;
				return flag2;
			}
			if (f_checkGreks())
			{
				double d1 = 0.0;
				double d2 = 0.0;
				double num1 = 0.0;
				double num2 = 0.0;
				double nd1 = 0.0;
				double num4 = 0.0;
				double num5 = 0.0;
				iTheoPrice = 0.0;
				iDelta = 0.0;
				iTheta = 0.0;
				iGamma = 0.0;
				iVega = 0.0;
				iVomma = 0.0;
				iCharm = 0.0;
				iVanna = 0.0;
				double T = f_CalculationT(iDate, iDateExp);
				double iLastF = this.iLastF;
				double iStrike = this.iStrike;
				double sigma = iVolaO / 100.0;
				if (iTypeO == "CALL" || iTypeO == "PUT")
				{
					d1 = (Math.Log(iLastF / iStrike) + 0.5 * Math.Pow(sigma, 2.0) * T) / (sigma * Math.Sqrt(T));
					d2 = (Math.Log(iLastF / iStrike) - 0.5 * Math.Pow(sigma, 2.0) * T) / (sigma * Math.Sqrt(T));
					num1 = f_N(d1);
					num2 = f_N(-1.0 * d1);
					double num6 = f_N(d2);
					nd1 = 1.0 / Math.Sqrt(Math.PI * 2.0) * Math.Exp((0.0 - d1) * d1 / 2.0);
					num4 = iLastF * num1 - iStrike * num6;
					num5 = num4 + iStrike - iLastF;
				}
				if (iTypeO == "CALL")
				{
					iTheoPrice = num4;
					iDelta = (double)iQ * num1;
					iTheta = (double)iQ * (-1.0 * iLastF * sigma * nd1 / (2.0 * Math.Sqrt(T))) / 365.0;
					iGamma = (double)iQ * nd1 / (iLastF * sigma * Math.Sqrt(T));
					double vega = iLastF * nd1 * Math.Sqrt(T);
					iVega = (double)iQ * (vega / 100.0);
					iVomma = iVega * (d1 * d2) / sigma / 100.0;
					iVanna = (double)iQ * ((0.0 - d2) / sigma * nd1 / 100.0);
					double vegaBleed = (0.0 - (1.0 + d1 * d2)) / 2.0 / T * vega;
					double charmClassic = d2 / 2.0 / T * nd1;
					iCharm = (double)iQ * (charmClassic / 365.0);
				}
				else if (iTypeO == "PUT")
				{
					iTheoPrice = num5;
					iDelta = (double)(iQ * -1) * num2;
					iTheta = (double)iQ * (-1.0 * iLastF * sigma * nd1 / (2.0 * Math.Sqrt(T))) / 365.0;
					iGamma = (double)iQ * nd1 / (iLastF * sigma * Math.Sqrt(T));
					double vega2 = iLastF * nd1 * Math.Sqrt(T);
					iVega = (double)iQ * (vega2 / 100.0);
					iVomma = iVega * (d1 * d2) / sigma / 100.0;
					iVanna = (double)iQ * ((0.0 - d2) / sigma * nd1 / 100.0);
					double vegaBleed2 = (0.0 - (1.0 + d1 * d2)) / 2.0 / T * vega2;
					double charmClassic2 = d2 / 2.0 / T * nd1;
					iCharm = (double)iQ * (charmClassic2 / 365.0);
				}
				else if (iTypeO == "FUT")
				{
					iTheoPrice = iLastF;
					iDelta = iQ;
					iTheta = 0.0;
					iGamma = 0.0;
					iVega = 0.0;
					iVomma = 0.0;
					iVanna = 0.0;
					iCharm = 0.0;
				}
				else
				{
					iTheoPrice = 0.0;
					iDelta = 0.0;
					iTheta = 0.0;
					iGamma = 0.0;
					iVega = 0.0;
					iVomma = 0.0;
					iVanna = 0.0;
					iCharm = 0.0;
				}
			}
			else
			{
				flag1 = false;
			}
			return flag1;
		}

		private double f_CalculationT(DateTime f_Date, DateTime f_Exp)
		{
			DateTime dateTime1 = new DateTime(f_Exp.Year, 1, 1, 0, 0, 0);
			DateTime dateTime2 = new DateTime(f_Exp.Year, 12, 31, 23, 59, 59);
			return (double)(int)(f_Exp - f_Date).TotalSeconds / (double)(int)(dateTime2 - dateTime1).TotalSeconds;
		}

		private double f_N(double x)
		{
			double num1;
			if (x > 10.0)
			{
				num1 = 1.0;
			}
			else if (x < -10.0)
			{
				num1 = 0.0;
			}
			else
			{
				double num2 = 1.0 / (1.0 + 0.2316419 * Math.Abs(x));
				num1 = 0.3989423 * Math.Exp(-0.5 * x * x) * num2 * ((((1.330274 * num2 - 1.821256) * num2 + 1.781478) * num2 - 0.3565638) * num2 + 0.3193815);
				if (x > 0.0)
				{
					num1 = 1.0 - num1;
				}
			}
			return num1;
		}

		public double f_CalculationVolaFromSmile(double f_Strike, double f_FUTURES_PRICE, double f_S, double f_A, double f_B, double f_C, double f_D, double f_E, double f_T)
		{
			double num = Math.Log(f_Strike / f_FUTURES_PRICE) / Math.Sqrt(f_T) - f_S;
			return f_A + f_B * (1.0 - Math.Pow(Math.Exp(1.0), (0.0 - f_C) * num * num)) + f_D * Math.Atan(Math.Exp(1.0) * num) / Math.Exp(1.0);
		}

		private bool f_checkGreks()
		{
			bool flag1 = true;
			iMessageError = "";
			if (iDateExp < iDate)
			{
				bool flag2 = false;
				iMessageError = "Дата открытия более или равна дате экспирации.";
				return flag2;
			}
			if (!(iTypeO == "PUT") && !(iTypeO == "CALL") && !(iTypeO == "FUT"))
			{
				bool flag3 = false;
				iMessageError = "Неправильно введен тип опциона,только FUT PUT или CALL.";
				return flag3;
			}
			if ((!(iTypeO == "PUT") && !(iTypeO == "CALL")) || iStrike > 0.0)
			{
				return flag1;
			}
			bool flag4 = false;
			iMessageError = "Некорректно введен страйк. Должно быть число более 0.";
			return flag4;
		}

		public double RoundStepPrice(double value, double stepprice)
		{
			if (stepprice <= 0.0)
			{
				return value;
			}
			double decimals = Math.Log10(stepprice);
			decimals = ((!(decimals > 0.0)) ? (decimals * -1.0) : 0.0);
			double v = value / stepprice;
			v += v % stepprice;
			return Math.Round(v * stepprice, Convert.ToInt32(decimals));
		}

		public double RoundStepPriceFloor(double value, double stepprice)
		{
			return (stepprice <= 0.0) ? value : (Math.Floor(value / stepprice) * stepprice);
		}

		public double RoundStepPriceCeiling(double value, double stepprice)
		{
			return (stepprice <= 0.0) ? value : (Math.Ceiling(value / stepprice) * stepprice);
		}

		public double RoundNearestNumber(double value)
		{
			if (value <= 0.0)
			{
			}
			string s = "";
			bool flag1 = false;
			bool flag2 = true;
			double num1 = 1.0;
			double result = 0.0;
			int num2 = ((value >= 0.0) ? 1 : (-1));
			try
			{
				string str = Math.Abs(value).ToString("F10");
				for (int index = 0; index < str.Length; index++)
				{
					if (flag2)
					{
						if (s.Length == 0)
						{
							if (Convert.ToDouble(Convert.ToString(str[index])) == 0.0)
							{
								s = "0";
								continue;
							}
							if (Math.Abs(Convert.ToDouble(Convert.ToString(str[index])) - 2.0) < Math.Abs(Convert.ToDouble(Convert.ToString(str[index])) - num1))
							{
								num1 = 2.0;
							}
							if (Math.Abs(Convert.ToDouble(Convert.ToString(str[index])) - 5.0) < Math.Abs(Convert.ToDouble(Convert.ToString(str[index])) - num1))
							{
								num1 = 5.0;
							}
							if (Math.Abs(Convert.ToDouble(Convert.ToString(str[index])) - 10.0) < Math.Abs(Convert.ToDouble(Convert.ToString(str[index])) - num1))
							{
								num1 = 10.0;
							}
							s = "1";
							flag1 = true;
							continue;
						}
						char ch = str[index];
						if (str[index] == ',' || str[index] == '.')
						{
							flag2 = false;
							if (flag1)
							{
								break;
							}
							s += Convert.ToString(str[index]);
						}
						else
						{
							s += "0";
						}
					}
					else
					{
						if (flag1)
						{
							continue;
						}
						if (Convert.ToDouble(Convert.ToString(str[index])) != 0.0)
						{
							if (Math.Abs(Convert.ToDouble(Convert.ToString(str[index])) - 2.0) < Math.Abs(Convert.ToDouble(Convert.ToString(str[index])) - num1))
							{
								num1 = 2.0;
							}
							if (Math.Abs(Convert.ToDouble(Convert.ToString(str[index])) - 5.0) < Math.Abs(Convert.ToDouble(Convert.ToString(str[index])) - num1))
							{
								num1 = 5.0;
							}
							if (Math.Abs(Convert.ToDouble(Convert.ToString(str[index])) - 10.0) < Math.Abs(Convert.ToDouble(Convert.ToString(str[index])) - num1))
							{
								num1 = 10.0;
							}
							s += "1";
							break;
						}
						s += "0";
					}
				}
			}
			catch
			{
				result = 0.0;
			}
			double num3 = ((!double.TryParse(s, out result)) ? 0.0 : Math.Abs(result));
			return (double)num2 * num3 * num1;
		}
	}
}
