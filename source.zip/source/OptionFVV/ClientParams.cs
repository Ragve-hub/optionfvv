namespace OptionFVV
{
	internal class ClientParams
	{
		private string account;

		private string client;

		public string Account
		{
			get
			{
				return account;
			}
			set
			{
				account = value;
			}
		}

		public string Client
		{
			get
			{
				return client;
			}
			set
			{
				client = value;
			}
		}

		public ClientParams(string account, string client)
		{
			this.account = account;
			this.client = client;
		}
	}
}
