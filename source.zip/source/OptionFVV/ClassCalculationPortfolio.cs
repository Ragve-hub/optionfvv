using System;
using System.Collections.Generic;

namespace OptionFVV
{
	internal class ClassCalculationPortfolio
	{
		public struct PortfolioTotal
		{
			public double profit;

			public double delta;

			public double gamma;

			public double vega;

			public double theta;

			public double vomma;
		}

		public struct Portfolio
		{
			public string paper_code;

			public string base_asset;

			public string option_type;

			public double strike;

			public DateTime expiration_date;

			public DateTime current_date;

			public double volume;

			public double open_price;

			public double open_volatility;

			public double teoretical_price;

			public double futures_price;

			public double profit;

			public double accumulated_profit;

			public double volatility;

			public double delta;

			public double gamma;

			public double vega;

			public double theta;

			public double step_price;

			public int decimal_points;

			public bool check_calculation;

			public bool check;
		}

		public struct Quotes
		{
			public string paper_code;

			public DateTime expiration_date;

			public string base_asset;

			public double demand;

			public double sentence;

			public double last_price;

			public double strike;

			public string option_type;

			public double volatility;

			public double teoretical_price;

			public double step_price;

			public bool F;
		}

		private ClassDataDDE cDataDDE = new ClassDataDDE(false);

		private ClassCalculationOptions cCalculationOptions = new ClassCalculationOptions();

		private FormTransaction fTransaction = new FormTransaction();

		private string gCurrentStrategy = "";

		private double gFuturesPrice1 = 0.0;

		private double gFuturesPrice2 = 0.0;

		private double gFixedProfit = 0.0;

		private bool gCheckFixedProfit = true;

		public double gD = 0.0;

		public double gV1 = 0.0;

		public double gV2 = 0.0;

		public double gP1 = 0.0;

		public double gP2 = 0.0;

		public double AddD1 = 0.0;

		public double AddD2 = 0.0;

		public static bool AbsWhatIf;

		public PortfolioTotal PortfolioTotalCurrent = default(PortfolioTotal);

		public PortfolioTotal PortfolioTotalAdd1 = default(PortfolioTotal);

		public PortfolioTotal PortfolioTotalAdd2 = default(PortfolioTotal);

		public PortfolioTotal PortfolioTotalExpiration = default(PortfolioTotal);

		private List<Portfolio> PortfolioTable = new List<Portfolio>();

		private Portfolio PortfolioPaper = default(Portfolio);

		private List<Portfolio> PortfolioTableAdd1 = new List<Portfolio>();

		private Portfolio PortfolioPaperAdd1 = default(Portfolio);

		private List<Portfolio> PortfolioTableAdd2 = new List<Portfolio>();

		private Portfolio PortfolioPaperAdd2 = default(Portfolio);

		private List<Portfolio> PortfolioTableExpiration = new List<Portfolio>();

		private Portfolio PortfolioPaperExpiration = default(Portfolio);

		private Quotes FuturePaper1 = default(Quotes);

		private Quotes FuturePaper2 = default(Quotes);

		public string CurrentStrategy
		{
			get
			{
				return gCurrentStrategy;
			}
			set
			{
				gCurrentStrategy = value;
			}
		}

		public double FuturesPrice1
		{
			get
			{
				return gFuturesPrice1;
			}
		}

		public double FuturesPrice2
		{
			get
			{
				return gFuturesPrice2;
			}
		}

		public double FixedProfit
		{
			get
			{
				return gFixedProfit;
			}
		}

		public bool CheckFixedProfit
		{
			get
			{
				return gCheckFixedProfit;
			}
			set
			{
				gCheckFixedProfit = value;
			}
		}

		public ClassCalculationPortfolio()
		{
			ClearPortfolio();
		}

		public void CreateTransactionTableFromDDE()
		{
			string str = fTransaction.NameInstrument(gCurrentStrategy);
			int num = cDataDDE.QuantityTransaction();
			for (int iNumber = 1; iNumber <= num; iNumber++)
			{
				if (cDataDDE.SearchTransactionLineNumber(iNumber) && !fTransaction.SearchTransaction(ClassDataDDE.TransactionPaper.number) && (ClassDataDDE.TransactionPaper.paper_code.Remove(2) == str || str == ""))
				{
					FormTransaction.TransactionPaper.number = ClassDataDDE.TransactionPaper.number;
					FormTransaction.TransactionPaper.date = ClassDataDDE.TransactionPaper.date;
					FormTransaction.TransactionPaper.time = ClassDataDDE.TransactionPaper.time;
					FormTransaction.TransactionPaper.paper_code = ClassDataDDE.TransactionPaper.paper_code;
					FormTransaction.TransactionPaper.operation = ClassDataDDE.TransactionPaper.operation;
					FormTransaction.TransactionPaper.price = ClassDataDDE.TransactionPaper.price;
					FormTransaction.TransactionPaper.volume = ClassDataDDE.TransactionPaper.volume;
					FormTransaction.TransactionPaper.strategy = gCurrentStrategy;
					fTransaction.AddTransaction();
				}
			}
		}

		public void CreatePortfolioTableFromTransaction()
		{
			int num1 = 0;
			double num2 = 0.0;
			PortfolioTable.Clear();
			PortfolioTableAdd1.Clear();
			PortfolioTableAdd2.Clear();
			PortfolioTableExpiration.Clear();
			for (int index1 = 0; index1 < FormTransaction.TransactionTable.Count; index1++)
			{
				if (!(gCurrentStrategy == FormTransaction.TransactionTable[index1].strategy))
				{
					continue;
				}
				int num3 = ((FormTransaction.TransactionTable[index1].operation == "Купля") ? 1 : ((FormTransaction.TransactionTable[index1].operation == "Продажа") ? (-1) : 0));
				if (num1 == 0)
				{
					PortfolioPaper.paper_code = FormTransaction.TransactionTable[index1].paper_code;
					PortfolioPaper.volume = (double)num3 * FormTransaction.TransactionTable[index1].volume;
					PortfolioPaper.open_price = FormTransaction.TransactionTable[index1].price;
					PortfolioPaper.accumulated_profit = 0.0;
					PortfolioPaper.check = false;
					PortfolioTable.Add(PortfolioPaper);
					PortfolioTableAdd1.Add(PortfolioPaper);
					PortfolioTableAdd2.Add(PortfolioPaper);
					PortfolioTableExpiration.Add(PortfolioPaper);
					num1++;
					continue;
				}
				bool flag = false;
				int i;
				for (i = 0; i < PortfolioTable.Count; i++)
				{
					if (FormTransaction.TransactionTable[index1].paper_code == PortfolioTable[i].paper_code)
					{
						flag = true;
						break;
					}
				}
				if (flag)
				{
					int num4 = Convert.ToInt32(PortfolioTable[i].volume);
					int int32 = Convert.ToInt32((double)num4 + (double)num3 * FormTransaction.TransactionTable[index1].volume);
					double num5 = PortfolioTable[i].open_price;
					if (num4 >= 0 && int32 > num4)
					{
						num5 = (num5 * (double)num4 + FormTransaction.TransactionTable[index1].price * (double)num3 * FormTransaction.TransactionTable[index1].volume) / (double)int32;
						num4 = int32;
						num2 = 0.0;
					}
					else if (num4 <= 0 && int32 < num4)
					{
						num5 = (num5 * (double)Math.Abs(num4) + FormTransaction.TransactionTable[index1].price * Math.Abs((double)num3 * FormTransaction.TransactionTable[index1].volume)) / (double)Math.Abs(int32);
						num4 = int32;
						num2 = 0.0;
					}
					else if (num4 >= 0 && int32 < num4)
					{
						if (int32 >= 0)
						{
							num2 = (FormTransaction.TransactionTable[index1].price - num5) * Math.Abs((double)num3 * FormTransaction.TransactionTable[index1].volume);
							num4 = int32;
						}
						else
						{
							num2 = (FormTransaction.TransactionTable[index1].price - num5) * Math.Abs(Math.Abs((double)num3 * FormTransaction.TransactionTable[index1].volume) - (double)Math.Abs(int32));
							num4 = int32;
							num5 = FormTransaction.TransactionTable[index1].price;
						}
					}
					else if (num4 <= 0 && int32 > num4)
					{
						if (int32 <= 0)
						{
							num2 = (num5 - FormTransaction.TransactionTable[index1].price) * Math.Abs((double)num3 * FormTransaction.TransactionTable[index1].volume);
							num4 = int32;
						}
						else
						{
							num2 = (num5 - FormTransaction.TransactionTable[index1].price) * Math.Abs(Math.Abs((double)num3 * FormTransaction.TransactionTable[index1].volume) - (double)Math.Abs(int32));
							num4 = int32;
							num5 = FormTransaction.TransactionTable[index1].price;
						}
					}
					PortfolioPaper = PortfolioTable[i];
					PortfolioPaper.volume = Convert.ToDouble(num4);
					PortfolioPaper.open_price = num5;
					if (num2 != 0.0)
					{
						PortfolioPaper.accumulated_profit += num2;
					}
					PortfolioTable[i] = PortfolioPaper;
					PortfolioTableAdd1[i] = PortfolioPaper;
					PortfolioTableAdd2[i] = PortfolioPaper;
					PortfolioTableExpiration[i] = PortfolioPaper;
				}
				else
				{
					PortfolioPaper.paper_code = FormTransaction.TransactionTable[index1].paper_code;
					PortfolioPaper.volume = (double)num3 * FormTransaction.TransactionTable[index1].volume;
					PortfolioPaper.open_price = FormTransaction.TransactionTable[index1].price;
					PortfolioPaper.accumulated_profit = 0.0;
					PortfolioPaper.check = false;
					PortfolioTable.Add(PortfolioPaper);
					PortfolioTableAdd1.Add(PortfolioPaper);
					PortfolioTableAdd2.Add(PortfolioPaper);
					PortfolioTableExpiration.Add(PortfolioPaper);
				}
			}
			UpdateFixedProfit();
			PortfolioPaper.paper_code = "FixedProfit";
			PortfolioPaper.delta = 0.0;
			PortfolioPaper.gamma = 0.0;
			PortfolioPaper.vega = 0.0;
			PortfolioPaper.theta = 0.0;
			PortfolioPaper.profit = gFixedProfit;
			PortfolioPaper.check = true;
			PortfolioPaper.check_calculation = true;
			PortfolioTable.Add(PortfolioPaper);
			PortfolioTableAdd1.Add(PortfolioPaper);
			PortfolioTableAdd2.Add(PortfolioPaper);
			PortfolioTableExpiration.Add(PortfolioPaper);
			PortfolioPaper.paper_code = "Итого:";
			PortfolioPaper.delta = 0.0;
			PortfolioPaper.gamma = 0.0;
			PortfolioPaper.vega = 0.0;
			PortfolioPaper.theta = 0.0;
			PortfolioPaper.profit = 0.0;
			PortfolioPaper.check = true;
			PortfolioPaper.check_calculation = true;
			PortfolioTable.Add(PortfolioPaper);
			PortfolioTableAdd1.Add(PortfolioPaper);
			PortfolioTableAdd2.Add(PortfolioPaper);
			PortfolioTableExpiration.Add(PortfolioPaper);
			FillFuturePaper();
		}

		public void ReplaceFuturePrice(string futureCode, double futurePrice)
		{
			gFuturesPrice1 = 0.0;
			gFuturesPrice2 = 0.0;
			if (futurePrice <= 0.0 || Helpers.IsOption(futureCode) || !cDataDDE.SearchPaper(futureCode))
			{
				return;
			}
			double num = ClassDataDDE.QuotesPaper.last_price - futurePrice;
			if (FuturePaper1.F)
			{
				if (!cDataDDE.SearchPaper(FuturePaper1.base_asset))
				{
					return;
				}
				gFuturesPrice1 = ClassDataDDE.QuotesPaper.last_price - num;
				FuturePaper1.last_price = gFuturesPrice1;
			}
			if (FuturePaper2.F && cDataDDE.SearchPaper(FuturePaper2.base_asset))
			{
				gFuturesPrice2 = ClassDataDDE.QuotesPaper.last_price - num;
				FuturePaper2.last_price = gFuturesPrice2;
			}
		}

		public void FillFuturePaper()
		{
			FuturePaper1.base_asset = "";
			FuturePaper1.last_price = 0.0;
			FuturePaper1.step_price = 0.0;
			FuturePaper1.F = false;
			FuturePaper2.base_asset = "";
			FuturePaper2.last_price = 0.0;
			FuturePaper2.step_price = 0.0;
			FuturePaper2.F = false;
			int num = 0;
			for (int index = 0; index < PortfolioTable.Count; index++)
			{
				if (PortfolioTable[index].volume == 0.0 || !(PortfolioTable[index].paper_code != "FixedProfit") || !(PortfolioTable[index].paper_code != "Итого:") || !cDataDDE.SearchPaper(PortfolioTable[index].paper_code))
				{
					continue;
				}
				if (num == 0)
				{
					FuturePaper1.paper_code = PortfolioTable[index].paper_code;
					FuturePaper1.base_asset = (Helpers.IsOption(FuturePaper1.paper_code) ? ClassDataDDE.QuotesPaper.base_asset : FuturePaper1.paper_code);
					FuturePaper1.expiration_date = ClassDataDDE.QuotesPaper.expiration_date;
					FuturePaper1.F = true;
					num++;
				}
				else if (ClassDataDDE.QuotesPaper.expiration_date < FuturePaper1.expiration_date)
				{
					if (Helpers.IsOption(FuturePaper1.paper_code))
					{
						FuturePaper2.paper_code = FuturePaper1.paper_code;
						FuturePaper2.base_asset = FuturePaper1.base_asset;
						FuturePaper2.expiration_date = FuturePaper1.expiration_date;
						FuturePaper2.F = FuturePaper1.F;
					}
					FuturePaper1.paper_code = PortfolioTable[index].paper_code;
					FuturePaper1.base_asset = ClassDataDDE.QuotesPaper.base_asset;
					FuturePaper1.expiration_date = ClassDataDDE.QuotesPaper.expiration_date;
					FuturePaper1.F = true;
				}
				else if (ClassDataDDE.QuotesPaper.expiration_date > FuturePaper1.expiration_date)
				{
					if (Helpers.IsOption(PortfolioTable[index].paper_code))
					{
						FuturePaper2.paper_code = PortfolioTable[index].paper_code;
						FuturePaper2.base_asset = ClassDataDDE.QuotesPaper.base_asset;
						FuturePaper2.expiration_date = ClassDataDDE.QuotesPaper.expiration_date;
						FuturePaper2.F = true;
					}
				}
				else if (ClassDataDDE.QuotesPaper.expiration_date == FuturePaper1.expiration_date && Helpers.IsOption(PortfolioTable[index].paper_code))
				{
					FuturePaper1.paper_code = PortfolioTable[index].paper_code;
					FuturePaper1.base_asset = ClassDataDDE.QuotesPaper.base_asset;
					FuturePaper1.expiration_date = ClassDataDDE.QuotesPaper.expiration_date;
					FuturePaper1.F = true;
				}
			}
		}

		public void UpdatePortfolioTableFromPortfolio()
		{
			for (int index = 0; index < PortfolioTable.Count; index++)
			{
				if (PortfolioTable[index].paper_code != "FixedProfit" && PortfolioTable[index].paper_code != "Итого:")
				{
					if (PortfolioTable[index].volume != 0.0 && cDataDDE.SearchPaper(PortfolioTable[index].paper_code))
					{
						PortfolioPaper.paper_code = PortfolioTable[index].paper_code;
						PortfolioPaper.base_asset = (Helpers.IsOption(PortfolioPaper.paper_code) ? ClassDataDDE.QuotesPaper.base_asset : PortfolioPaper.paper_code);
						PortfolioPaper.volume = PortfolioTable[index].volume;
						PortfolioPaper.open_price = PortfolioTable[index].open_price;
						PortfolioPaper.option_type = ClassDataDDE.QuotesPaper.option_type;
						PortfolioPaper.expiration_date = ClassDataDDE.QuotesPaper.expiration_date;
						PortfolioPaper.accumulated_profit = 0.0;
						if (AbsWhatIf)
						{
							double v2 = ClassDataDDE.QuotesPaper.volatility;
							double v3 = ClassDataDDE.QuotesPaper.volatility;
							if (gV2 > 0.0)
							{
								v2 = gV2;
							}
							if (gV1 > 0.0)
							{
								v3 = gV1;
							}
							PortfolioPaper.volatility = ((PortfolioPaper.expiration_date == FuturePaper1.expiration_date && FuturePaper1.F) ? Math.Round(v3, 2) : ((!(PortfolioPaper.expiration_date == FuturePaper2.expiration_date) || !FuturePaper2.F) ? Math.Round(ClassDataDDE.QuotesPaper.volatility, 2) : Math.Round(v2, 2)));
						}
						else
						{
							PortfolioPaper.volatility = ((PortfolioPaper.expiration_date == FuturePaper1.expiration_date && FuturePaper1.F) ? Math.Round(ClassDataDDE.QuotesPaper.volatility + gV1, 2) : ((!(PortfolioPaper.expiration_date == FuturePaper2.expiration_date) || !FuturePaper2.F) ? Math.Round(ClassDataDDE.QuotesPaper.volatility, 2) : Math.Round(ClassDataDDE.QuotesPaper.volatility + gV2, 2)));
						}
						PortfolioPaper.step_price = ClassDataDDE.QuotesPaper.step_price;
						PortfolioPaper.decimal_points = ClassDataDDE.QuotesPaper.decimal_points;
						cCalculationOptions.TypeO = PortfolioPaper.option_type;
						cCalculationOptions.Strike = ClassDataDDE.QuotesPaper.strike;
						PortfolioPaper.strike = ClassDataDDE.QuotesPaper.strike;
						cCalculationOptions.DateExp = PortfolioPaper.expiration_date;
						if (AbsWhatIf && gD > 0.0)
						{
							if (PortfolioPaper.base_asset == PortfolioPaper.paper_code)
							{
								cCalculationOptions.DateCurrent = DateTime.Now;
							}
							else
							{
								cCalculationOptions.DateCurrent = cCalculationOptions.DateExp.AddDays(0.0 - gD);
							}
						}
						else
						{
							cCalculationOptions.DateCurrent = DateTime.Now.AddDays(gD);
						}
						PortfolioPaper.current_date = cCalculationOptions.DateCurrent;
						cCalculationOptions.Q = Convert.ToInt32(PortfolioPaper.volume);
						cCalculationOptions.VolaO = PortfolioPaper.volatility;
						if (cDataDDE.SearchPaper(PortfolioPaper.base_asset))
						{
							if (PortfolioPaper.base_asset == FuturePaper1.base_asset)
							{
								if (AbsWhatIf && gP1 > 0.0)
								{
									cCalculationOptions.LastF = gP1;
								}
								else
								{
									cCalculationOptions.LastF = ((gFuturesPrice1 == 0.0) ? (ClassDataDDE.QuotesPaper.last_price + gP1) : (gFuturesPrice1 + gP1));
								}
							}
							else
							{
								if (!(PortfolioPaper.base_asset == FuturePaper2.base_asset))
								{
									break;
								}
								if (AbsWhatIf && gP2 > 0.0)
								{
									cCalculationOptions.LastF = gP2;
								}
								else
								{
									cCalculationOptions.LastF = ((gFuturesPrice2 == 0.0) ? (ClassDataDDE.QuotesPaper.last_price + gP2) : (gFuturesPrice2 + gP2));
								}
							}
							PortfolioPaper.futures_price = cCalculationOptions.LastF;
							if (cCalculationOptions.CalculationOpt())
							{
								PortfolioPaper.teoretical_price = (Helpers.IsOption(PortfolioPaper.paper_code) ? Math.Round(cCalculationOptions.calcTheoPrice, PortfolioPaper.decimal_points) : PortfolioPaper.futures_price);
								PortfolioPaper.delta = Math.Round(cCalculationOptions.calcDelta, 2);
								PortfolioPaper.gamma = Math.Round(cCalculationOptions.calcGamma, 6);
								PortfolioPaper.vega = Math.Round(cCalculationOptions.calcVega, 2);
								PortfolioPaper.theta = Math.Round(cCalculationOptions.calcTheta, 2);
								PortfolioPaper.profit = ((PortfolioPaper.option_type == "Call") ? ((PortfolioPaper.teoretical_price - PortfolioPaper.open_price) * PortfolioPaper.volume) : ((!(PortfolioPaper.option_type == "Put")) ? ((cCalculationOptions.LastF - PortfolioPaper.open_price) * PortfolioPaper.volume) : ((PortfolioPaper.teoretical_price - PortfolioPaper.open_price) * PortfolioPaper.volume)));
								PortfolioPaper.open_volatility = 0.0;
								PortfolioPaper.check = true;
								PortfolioPaper.check_calculation = PortfolioTable[index].check_calculation;
							}
							else
							{
								PortfolioPaper.delta = 0.0;
								PortfolioPaper.gamma = 0.0;
								PortfolioPaper.vega = 0.0;
								PortfolioPaper.theta = 0.0;
								PortfolioPaper.profit = 0.0;
								PortfolioPaper.check = false;
								PortfolioPaper.check_calculation = PortfolioTable[index].check_calculation;
							}
						}
						else
						{
							PortfolioPaper.delta = 0.0;
							PortfolioPaper.gamma = 0.0;
							PortfolioPaper.vega = 0.0;
							PortfolioPaper.theta = 0.0;
							PortfolioPaper.profit = 0.0;
							PortfolioPaper.check = false;
							PortfolioPaper.check_calculation = PortfolioTable[index].check_calculation;
						}
					}
					else
					{
						PortfolioPaper.paper_code = PortfolioTable[index].paper_code;
						PortfolioPaper.base_asset = "";
						PortfolioPaper.volume = PortfolioTable[index].volume;
						PortfolioPaper.open_price = PortfolioTable[index].open_price;
						PortfolioPaper.option_type = "";
						PortfolioPaper.strike = 0.0;
						PortfolioPaper.teoretical_price = 0.0;
						PortfolioPaper.futures_price = 0.0;
						PortfolioPaper.accumulated_profit = 0.0;
						PortfolioPaper.volatility = 0.0;
						PortfolioPaper.step_price = 0.0;
						PortfolioPaper.decimal_points = 0;
						PortfolioPaper.delta = 0.0;
						PortfolioPaper.gamma = 0.0;
						PortfolioPaper.vega = 0.0;
						PortfolioPaper.theta = 0.0;
						PortfolioPaper.profit = 0.0;
						PortfolioPaper.check = false;
						PortfolioPaper.check_calculation = PortfolioTable[index].check_calculation;
					}
					PortfolioTable[index] = PortfolioPaper;
				}
				else if (PortfolioTable[index].paper_code == "FixedProfit")
				{
				}
			}
		}

		public void UpdatePortfolioTableAdd1FromPortfolio()
		{
			for (int index = 0; index < PortfolioTableAdd1.Count; index++)
			{
				if (!(PortfolioTableAdd1[index].paper_code != "FixedProfit") || !(PortfolioTableAdd1[index].paper_code != "Итого:"))
				{
					continue;
				}
				if (PortfolioTableAdd1[index].volume != 0.0 && cDataDDE.SearchPaper(PortfolioTableAdd1[index].paper_code))
				{
					PortfolioPaperAdd1.paper_code = PortfolioTableAdd1[index].paper_code;
					PortfolioPaperAdd1.base_asset = (Helpers.IsOption(PortfolioPaperAdd1.paper_code) ? ClassDataDDE.QuotesPaper.base_asset : PortfolioPaperAdd1.paper_code);
					PortfolioPaperAdd1.volume = PortfolioTableAdd1[index].volume;
					PortfolioPaperAdd1.open_price = PortfolioTableAdd1[index].open_price;
					PortfolioPaperAdd1.option_type = ClassDataDDE.QuotesPaper.option_type;
					PortfolioPaperAdd1.expiration_date = ClassDataDDE.QuotesPaper.expiration_date;
					PortfolioPaperAdd1.accumulated_profit = 0.0;
					PortfolioPaperAdd1.volatility = ((PortfolioPaperAdd1.expiration_date == FuturePaper1.expiration_date && FuturePaper1.F) ? Math.Round(ClassDataDDE.QuotesPaper.volatility + gV1, 2) : ((!(PortfolioPaperAdd1.expiration_date == FuturePaper2.expiration_date) || !FuturePaper2.F) ? Math.Round(ClassDataDDE.QuotesPaper.volatility, 2) : Math.Round(ClassDataDDE.QuotesPaper.volatility + gV2, 2)));
					PortfolioPaperAdd1.step_price = ClassDataDDE.QuotesPaper.step_price;
					PortfolioPaperAdd1.decimal_points = ClassDataDDE.QuotesPaper.decimal_points;
					cCalculationOptions.TypeO = PortfolioPaperAdd1.option_type;
					cCalculationOptions.Strike = ClassDataDDE.QuotesPaper.strike;
					PortfolioPaperAdd1.strike = ClassDataDDE.QuotesPaper.strike;
					cCalculationOptions.DateExp = PortfolioPaperAdd1.expiration_date;
					if (AbsWhatIf && gD > 0.0)
					{
						cCalculationOptions.DateCurrent = cCalculationOptions.DateExp.AddDays(0.0 - gD + AddD1);
					}
					else
					{
						cCalculationOptions.DateCurrent = DateTime.Now.AddDays(gD + AddD1);
					}
					PortfolioPaperAdd1.current_date = cCalculationOptions.DateCurrent;
					cCalculationOptions.Q = Convert.ToInt32(PortfolioPaperAdd1.volume);
					cCalculationOptions.VolaO = PortfolioPaperAdd1.volatility;
					if (cDataDDE.SearchPaper(PortfolioPaperAdd1.base_asset))
					{
						if (PortfolioPaperAdd1.base_asset == FuturePaper1.base_asset)
						{
							cCalculationOptions.LastF = ((gFuturesPrice1 == 0.0) ? (ClassDataDDE.QuotesPaper.last_price + gP1) : (gFuturesPrice1 + gP1));
						}
						else
						{
							if (!(PortfolioPaperAdd1.base_asset == FuturePaper2.base_asset))
							{
								break;
							}
							cCalculationOptions.LastF = ((gFuturesPrice2 == 0.0) ? (ClassDataDDE.QuotesPaper.last_price + gP2) : (gFuturesPrice2 + gP2));
						}
						PortfolioPaperAdd1.futures_price = cCalculationOptions.LastF;
						if (cCalculationOptions.CalculationOpt())
						{
							PortfolioPaperAdd1.teoretical_price = (Helpers.IsOption(PortfolioPaperAdd1.paper_code) ? Math.Round(cCalculationOptions.calcTheoPrice, PortfolioPaperAdd1.decimal_points) : PortfolioPaperAdd1.futures_price);
							PortfolioPaperAdd1.delta = Math.Round(cCalculationOptions.calcDelta, 2);
							PortfolioPaperAdd1.gamma = Math.Round(cCalculationOptions.calcGamma, 6);
							PortfolioPaperAdd1.vega = Math.Round(cCalculationOptions.calcVega, 2);
							PortfolioPaperAdd1.theta = Math.Round(cCalculationOptions.calcTheta, 2);
							PortfolioPaperAdd1.profit = ((PortfolioPaperAdd1.option_type == "Call") ? ((PortfolioPaperAdd1.teoretical_price - PortfolioPaperAdd1.open_price) * PortfolioPaperAdd1.volume) : ((!(PortfolioPaperAdd1.option_type == "Put")) ? ((cCalculationOptions.LastF - PortfolioPaperAdd1.open_price) * PortfolioPaperAdd1.volume) : ((PortfolioPaperAdd1.teoretical_price - PortfolioPaperAdd1.open_price) * PortfolioPaperAdd1.volume)));
							PortfolioPaperAdd1.open_volatility = 0.0;
							PortfolioPaperAdd1.check = true;
							PortfolioPaperAdd1.check_calculation = PortfolioTableAdd1[index].check_calculation;
						}
						else
						{
							PortfolioPaperAdd1.delta = 0.0;
							PortfolioPaperAdd1.gamma = 0.0;
							PortfolioPaperAdd1.vega = 0.0;
							PortfolioPaperAdd1.theta = 0.0;
							PortfolioPaperAdd1.profit = 0.0;
							PortfolioPaperAdd1.check = false;
							PortfolioPaperAdd1.check_calculation = PortfolioTableAdd1[index].check_calculation;
						}
					}
					else
					{
						PortfolioPaperAdd1.delta = 0.0;
						PortfolioPaperAdd1.gamma = 0.0;
						PortfolioPaperAdd1.vega = 0.0;
						PortfolioPaperAdd1.theta = 0.0;
						PortfolioPaperAdd1.profit = 0.0;
						PortfolioPaperAdd1.check = false;
						PortfolioPaperAdd1.check_calculation = PortfolioTableAdd1[index].check_calculation;
					}
				}
				else
				{
					PortfolioPaperAdd1.paper_code = PortfolioTableAdd1[index].paper_code;
					PortfolioPaperAdd1.base_asset = "";
					PortfolioPaperAdd1.volume = PortfolioTableAdd1[index].volume;
					PortfolioPaperAdd1.open_price = PortfolioTableAdd1[index].open_price;
					PortfolioPaperAdd1.option_type = "";
					PortfolioPaperAdd1.strike = 0.0;
					PortfolioPaperAdd1.teoretical_price = 0.0;
					PortfolioPaperAdd1.futures_price = 0.0;
					PortfolioPaperAdd1.accumulated_profit = 0.0;
					PortfolioPaperAdd1.volatility = 0.0;
					PortfolioPaperAdd1.step_price = 0.0;
					PortfolioPaperAdd1.decimal_points = 0;
					PortfolioPaperAdd1.delta = 0.0;
					PortfolioPaperAdd1.gamma = 0.0;
					PortfolioPaperAdd1.vega = 0.0;
					PortfolioPaperAdd1.theta = 0.0;
					PortfolioPaperAdd1.profit = 0.0;
					PortfolioPaperAdd1.check = false;
					PortfolioPaperAdd1.check_calculation = PortfolioTableAdd1[index].check_calculation;
				}
				PortfolioTableAdd1[index] = PortfolioPaperAdd1;
			}
		}

		public void UpdatePortfolioTableAdd2FromPortfolio()
		{
			for (int index = 0; index < PortfolioTableAdd2.Count; index++)
			{
				if (!(PortfolioTableAdd2[index].paper_code != "FixedProfit") || !(PortfolioTableAdd2[index].paper_code != "Итого:"))
				{
					continue;
				}
				if (PortfolioTableAdd2[index].volume != 0.0 && cDataDDE.SearchPaper(PortfolioTableAdd2[index].paper_code))
				{
					PortfolioPaperAdd2.paper_code = PortfolioTableAdd2[index].paper_code;
					PortfolioPaperAdd2.base_asset = (Helpers.IsOption(PortfolioPaperAdd2.paper_code) ? ClassDataDDE.QuotesPaper.base_asset : PortfolioPaperAdd2.paper_code);
					PortfolioPaperAdd2.volume = PortfolioTableAdd2[index].volume;
					PortfolioPaperAdd2.open_price = PortfolioTableAdd2[index].open_price;
					PortfolioPaperAdd2.option_type = ClassDataDDE.QuotesPaper.option_type;
					PortfolioPaperAdd2.expiration_date = ClassDataDDE.QuotesPaper.expiration_date;
					PortfolioPaperAdd2.accumulated_profit = 0.0;
					PortfolioPaperAdd2.volatility = ((PortfolioPaperAdd2.expiration_date == FuturePaper1.expiration_date && FuturePaper1.F) ? Math.Round(ClassDataDDE.QuotesPaper.volatility + gV1, 2) : ((!(PortfolioPaperAdd2.expiration_date == FuturePaper2.expiration_date) || !FuturePaper2.F) ? Math.Round(ClassDataDDE.QuotesPaper.volatility, 2) : Math.Round(ClassDataDDE.QuotesPaper.volatility + gV2, 2)));
					PortfolioPaperAdd2.step_price = ClassDataDDE.QuotesPaper.step_price;
					PortfolioPaperAdd2.decimal_points = ClassDataDDE.QuotesPaper.decimal_points;
					cCalculationOptions.TypeO = PortfolioPaperAdd2.option_type;
					cCalculationOptions.Strike = ClassDataDDE.QuotesPaper.strike;
					PortfolioPaperAdd2.strike = ClassDataDDE.QuotesPaper.strike;
					cCalculationOptions.DateExp = PortfolioPaperAdd2.expiration_date;
					if (AbsWhatIf && gD > 0.0)
					{
						cCalculationOptions.DateCurrent = cCalculationOptions.DateExp.AddDays(0.0 - gD + AddD2);
					}
					else
					{
						cCalculationOptions.DateCurrent = DateTime.Now.AddDays(gD + AddD2);
					}
					PortfolioPaperAdd2.current_date = cCalculationOptions.DateCurrent;
					cCalculationOptions.Q = Convert.ToInt32(PortfolioPaperAdd2.volume);
					cCalculationOptions.VolaO = PortfolioPaperAdd2.volatility;
					if (cDataDDE.SearchPaper(PortfolioPaperAdd2.base_asset))
					{
						if (PortfolioPaperAdd2.base_asset == FuturePaper1.base_asset)
						{
							cCalculationOptions.LastF = ((gFuturesPrice1 == 0.0) ? (ClassDataDDE.QuotesPaper.last_price + gP1) : (gFuturesPrice1 + gP1));
						}
						else
						{
							if (!(PortfolioPaperAdd2.base_asset == FuturePaper2.base_asset))
							{
								break;
							}
							cCalculationOptions.LastF = ((gFuturesPrice2 == 0.0) ? (ClassDataDDE.QuotesPaper.last_price + gP2) : (gFuturesPrice2 + gP2));
						}
						PortfolioPaperAdd2.futures_price = cCalculationOptions.LastF;
						if (cCalculationOptions.CalculationOpt())
						{
							PortfolioPaperAdd2.teoretical_price = (Helpers.IsOption(PortfolioPaperAdd2.paper_code) ? Math.Round(cCalculationOptions.calcTheoPrice, PortfolioPaperAdd2.decimal_points) : PortfolioPaperAdd2.futures_price);
							PortfolioPaperAdd2.delta = Math.Round(cCalculationOptions.calcDelta, 2);
							PortfolioPaperAdd2.gamma = Math.Round(cCalculationOptions.calcGamma, 6);
							PortfolioPaperAdd2.vega = Math.Round(cCalculationOptions.calcVega, 2);
							PortfolioPaperAdd2.theta = Math.Round(cCalculationOptions.calcTheta, 2);
							PortfolioPaperAdd2.profit = ((PortfolioPaperAdd2.option_type == "Call") ? ((PortfolioPaperAdd2.teoretical_price - PortfolioPaperAdd2.open_price) * PortfolioPaperAdd2.volume) : ((!(PortfolioPaperAdd2.option_type == "Put")) ? ((cCalculationOptions.LastF - PortfolioPaperAdd2.open_price) * PortfolioPaperAdd2.volume) : ((PortfolioPaperAdd2.teoretical_price - PortfolioPaperAdd2.open_price) * PortfolioPaperAdd2.volume)));
							PortfolioPaperAdd2.open_volatility = 0.0;
							PortfolioPaperAdd2.check = true;
							PortfolioPaperAdd2.check_calculation = PortfolioTableAdd2[index].check_calculation;
						}
						else
						{
							PortfolioPaperAdd2.delta = 0.0;
							PortfolioPaperAdd2.gamma = 0.0;
							PortfolioPaperAdd2.vega = 0.0;
							PortfolioPaperAdd2.theta = 0.0;
							PortfolioPaperAdd2.profit = 0.0;
							PortfolioPaperAdd2.check = false;
							PortfolioPaperAdd2.check_calculation = PortfolioTableAdd2[index].check_calculation;
						}
					}
					else
					{
						PortfolioPaperAdd2.delta = 0.0;
						PortfolioPaperAdd2.gamma = 0.0;
						PortfolioPaperAdd2.vega = 0.0;
						PortfolioPaperAdd2.theta = 0.0;
						PortfolioPaperAdd2.profit = 0.0;
						PortfolioPaperAdd2.check = false;
						PortfolioPaperAdd2.check_calculation = PortfolioTableAdd2[index].check_calculation;
					}
				}
				else
				{
					PortfolioPaperAdd2.paper_code = PortfolioTableAdd2[index].paper_code;
					PortfolioPaperAdd2.base_asset = "";
					PortfolioPaperAdd2.volume = PortfolioTableAdd2[index].volume;
					PortfolioPaperAdd2.open_price = PortfolioTableAdd2[index].open_price;
					PortfolioPaperAdd2.option_type = "";
					PortfolioPaperAdd2.strike = 0.0;
					PortfolioPaperAdd2.teoretical_price = 0.0;
					PortfolioPaperAdd2.futures_price = 0.0;
					PortfolioPaperAdd2.accumulated_profit = 0.0;
					PortfolioPaperAdd2.volatility = 0.0;
					PortfolioPaperAdd2.step_price = 0.0;
					PortfolioPaperAdd2.decimal_points = 0;
					PortfolioPaperAdd2.delta = 0.0;
					PortfolioPaperAdd2.gamma = 0.0;
					PortfolioPaperAdd2.vega = 0.0;
					PortfolioPaperAdd2.theta = 0.0;
					PortfolioPaperAdd2.profit = 0.0;
					PortfolioPaperAdd2.check = false;
					PortfolioPaperAdd2.check_calculation = PortfolioTableAdd2[index].check_calculation;
				}
				PortfolioTableAdd2[index] = PortfolioPaperAdd2;
			}
		}

		public void UpdatePortfolioTableExpirationFromPortfolio()
		{
			for (int index = 0; index < PortfolioTableExpiration.Count; index++)
			{
				if (!(PortfolioTableExpiration[index].paper_code != "FixedProfit") || !(PortfolioTableExpiration[index].paper_code != "Итого:"))
				{
					continue;
				}
				if (PortfolioTableExpiration[index].volume != 0.0 && cDataDDE.SearchPaper(PortfolioTableExpiration[index].paper_code))
				{
					PortfolioPaperExpiration.paper_code = PortfolioTableExpiration[index].paper_code;
					PortfolioPaperExpiration.base_asset = (Helpers.IsOption(PortfolioPaperExpiration.paper_code) ? ClassDataDDE.QuotesPaper.base_asset : PortfolioPaperExpiration.paper_code);
					PortfolioPaperExpiration.volume = PortfolioTableExpiration[index].volume;
					PortfolioPaperExpiration.open_price = PortfolioTableExpiration[index].open_price;
					PortfolioPaperExpiration.option_type = ClassDataDDE.QuotesPaper.option_type;
					PortfolioPaperExpiration.expiration_date = ClassDataDDE.QuotesPaper.expiration_date;
					PortfolioPaperExpiration.accumulated_profit = 0.0;
					PortfolioPaperExpiration.volatility = ((PortfolioPaperExpiration.expiration_date == FuturePaper1.expiration_date && FuturePaper1.F) ? Math.Round(ClassDataDDE.QuotesPaper.volatility + gV1, 2) : ((!(PortfolioPaperExpiration.expiration_date == FuturePaper2.expiration_date) || !FuturePaper2.F) ? Math.Round(ClassDataDDE.QuotesPaper.volatility, 2) : Math.Round(ClassDataDDE.QuotesPaper.volatility + gV2, 2)));
					PortfolioPaperExpiration.step_price = ClassDataDDE.QuotesPaper.step_price;
					PortfolioPaperExpiration.decimal_points = ClassDataDDE.QuotesPaper.decimal_points;
					cCalculationOptions.TypeO = PortfolioPaperExpiration.option_type;
					cCalculationOptions.Strike = ClassDataDDE.QuotesPaper.strike;
					PortfolioPaperExpiration.strike = ClassDataDDE.QuotesPaper.strike;
					cCalculationOptions.DateExp = PortfolioPaperExpiration.expiration_date;
					if (FuturePaper1.F)
					{
						cCalculationOptions.DateCurrent = FuturePaper1.expiration_date;
					}
					PortfolioPaperExpiration.current_date = cCalculationOptions.DateCurrent;
					cCalculationOptions.Q = Convert.ToInt32(PortfolioPaperExpiration.volume);
					cCalculationOptions.VolaO = PortfolioPaperExpiration.volatility;
					if (cDataDDE.SearchPaper(PortfolioPaperExpiration.base_asset))
					{
						if (PortfolioPaperExpiration.base_asset == FuturePaper1.base_asset)
						{
							cCalculationOptions.LastF = ((gFuturesPrice1 == 0.0) ? (ClassDataDDE.QuotesPaper.last_price + gP1) : (gFuturesPrice1 + gP1));
						}
						else
						{
							if (!(PortfolioPaperExpiration.base_asset == FuturePaper2.base_asset))
							{
								break;
							}
							cCalculationOptions.LastF = ((gFuturesPrice2 == 0.0) ? (ClassDataDDE.QuotesPaper.last_price + gP2) : (gFuturesPrice2 + gP2));
						}
						PortfolioPaperExpiration.futures_price = cCalculationOptions.LastF;
						if (cCalculationOptions.CalculationOpt())
						{
							PortfolioPaperExpiration.teoretical_price = (Helpers.IsOption(PortfolioPaperExpiration.paper_code) ? Math.Round(cCalculationOptions.calcTheoPrice, PortfolioPaperExpiration.decimal_points) : PortfolioPaperExpiration.futures_price);
							PortfolioPaperExpiration.delta = Math.Round(cCalculationOptions.calcDelta, 2);
							PortfolioPaperExpiration.gamma = Math.Round(cCalculationOptions.calcGamma, 6);
							PortfolioPaperExpiration.vega = Math.Round(cCalculationOptions.calcVega, 2);
							PortfolioPaperExpiration.theta = Math.Round(cCalculationOptions.calcTheta, 2);
							PortfolioPaperExpiration.profit = ((PortfolioPaperExpiration.option_type == "Call") ? ((PortfolioPaperExpiration.teoretical_price - PortfolioPaperExpiration.open_price) * PortfolioPaperExpiration.volume) : ((!(PortfolioPaperExpiration.option_type == "Put")) ? ((cCalculationOptions.LastF - PortfolioPaperExpiration.open_price) * PortfolioPaperExpiration.volume) : ((PortfolioPaperExpiration.teoretical_price - PortfolioPaperExpiration.open_price) * PortfolioPaperExpiration.volume)));
							PortfolioPaperExpiration.open_volatility = 0.0;
							PortfolioPaperExpiration.check = true;
							PortfolioPaperExpiration.check_calculation = PortfolioTableExpiration[index].check_calculation;
						}
						else
						{
							PortfolioPaperExpiration.delta = 0.0;
							PortfolioPaperExpiration.gamma = 0.0;
							PortfolioPaperExpiration.vega = 0.0;
							PortfolioPaperExpiration.theta = 0.0;
							PortfolioPaperExpiration.profit = 0.0;
							PortfolioPaperExpiration.check = false;
							PortfolioPaperExpiration.check_calculation = PortfolioTableExpiration[index].check_calculation;
						}
					}
					else
					{
						PortfolioPaperExpiration.delta = 0.0;
						PortfolioPaperExpiration.gamma = 0.0;
						PortfolioPaperExpiration.vega = 0.0;
						PortfolioPaperExpiration.theta = 0.0;
						PortfolioPaperExpiration.profit = 0.0;
						PortfolioPaperExpiration.check = false;
						PortfolioPaperExpiration.check_calculation = PortfolioTableExpiration[index].check_calculation;
					}
				}
				else
				{
					PortfolioPaperExpiration.paper_code = PortfolioTableExpiration[index].paper_code;
					PortfolioPaperExpiration.base_asset = "";
					PortfolioPaperExpiration.volume = PortfolioTableExpiration[index].volume;
					PortfolioPaperExpiration.open_price = PortfolioTableExpiration[index].open_price;
					PortfolioPaperExpiration.option_type = "";
					PortfolioPaperExpiration.strike = 0.0;
					PortfolioPaperExpiration.teoretical_price = 0.0;
					PortfolioPaperExpiration.futures_price = 0.0;
					PortfolioPaperExpiration.accumulated_profit = 0.0;
					PortfolioPaperExpiration.volatility = 0.0;
					PortfolioPaperExpiration.step_price = 0.0;
					PortfolioPaperExpiration.decimal_points = 0;
					PortfolioPaperExpiration.delta = 0.0;
					PortfolioPaperExpiration.gamma = 0.0;
					PortfolioPaperExpiration.vega = 0.0;
					PortfolioPaperExpiration.theta = 0.0;
					PortfolioPaperExpiration.profit = 0.0;
					PortfolioPaperExpiration.check = false;
					PortfolioPaperExpiration.check_calculation = PortfolioTableExpiration[index].check_calculation;
				}
				PortfolioTableExpiration[index] = PortfolioPaperExpiration;
			}
		}

		public void ClearPortfolio()
		{
			gCurrentStrategy = "";
			gFuturesPrice1 = 0.0;
			gFuturesPrice2 = 0.0;
			gD = 0.0;
			gV1 = 0.0;
			gV2 = 0.0;
			gP1 = 0.0;
			gP2 = 0.0;
			PortfolioTable.Clear();
			PortfolioTableAdd1.Clear();
			PortfolioTableAdd2.Clear();
			PortfolioTableExpiration.Clear();
			PortfolioPaper.paper_code = "FixedProfit";
			PortfolioPaper.profit = 0.0;
			PortfolioPaper.check = true;
			PortfolioPaper.check_calculation = true;
			PortfolioTable.Add(PortfolioPaper);
			PortfolioTableAdd1.Add(PortfolioPaper);
			PortfolioTableAdd2.Add(PortfolioPaper);
			PortfolioTableExpiration.Add(PortfolioPaper);
			PortfolioPaper.paper_code = "Итого:";
			PortfolioPaper.delta = 0.0;
			PortfolioPaper.gamma = 0.0;
			PortfolioPaper.vega = 0.0;
			PortfolioPaper.theta = 0.0;
			PortfolioPaper.profit = 0.0;
			PortfolioPaper.check = true;
			PortfolioPaper.check_calculation = true;
			PortfolioTable.Add(PortfolioPaper);
			PortfolioTableAdd1.Add(PortfolioPaper);
			PortfolioTableAdd2.Add(PortfolioPaper);
			PortfolioTableExpiration.Add(PortfolioPaper);
		}

		public void UpdateFixedProfit()
		{
			gFixedProfit = 0.0;
			double num = 0.0;
			for (int index = 0; index < PortfolioTable.Count; index++)
			{
				PortfolioPaper = PortfolioTable[index];
				double accumulatedProfit = PortfolioPaper.accumulated_profit;
				num += accumulatedProfit;
			}
			gFixedProfit = Math.Round(num, PortfolioPaper.decimal_points);
		}

		public void UpdatePortfolioTotal()
		{
			double num1 = 0.0;
			double num2 = 0.0;
			double num3 = 0.0;
			double num4 = 0.0;
			double num5 = 0.0;
			for (int index = 0; index < PortfolioTable.Count; index++)
			{
				if (PortfolioTable[index].paper_code == "FixedProfit")
				{
					if (PortfolioTable[index].check_calculation && gCheckFixedProfit)
					{
						double profit = PortfolioTable[index].profit;
						num1 += profit;
					}
				}
				else
				{
					if (PortfolioTable[index].paper_code == "Итого:")
					{
						continue;
					}
					if (Helpers.IsFutures(PortfolioTable[index].paper_code))
					{
						if (PortfolioTable[index].check_calculation)
						{
							double delta = PortfolioTable[index].delta;
							num2 += delta;
							double profit2 = PortfolioTable[index].profit;
							num1 += profit2;
						}
					}
					else if (PortfolioTable[index].check_calculation)
					{
						double delta2 = PortfolioTable[index].delta;
						num2 += delta2;
						double gamma = PortfolioTable[index].gamma;
						num3 += gamma;
						double vega = PortfolioTable[index].vega;
						num4 += vega;
						double theta = PortfolioTable[index].theta;
						num5 += theta;
						double profit3 = PortfolioTable[index].profit;
						num1 += profit3;
					}
				}
			}
			for (int i = 0; i < PortfolioTable.Count; i++)
			{
				if (PortfolioTable[i].paper_code == "Итого:")
				{
					PortfolioPaper.paper_code = PortfolioTable[i].paper_code;
					PortfolioPaper.base_asset = "";
					PortfolioPaper.volume = 0.0;
					PortfolioPaper.open_price = 0.0;
					PortfolioPaper.option_type = "";
					PortfolioPaper.strike = 0.0;
					PortfolioPaper.teoretical_price = 0.0;
					PortfolioPaper.futures_price = 0.0;
					PortfolioPaper.accumulated_profit = 0.0;
					PortfolioPaper.volatility = 0.0;
					PortfolioPaper.step_price = 0.0;
					PortfolioPaper.decimal_points = 0;
					PortfolioPaper.delta = Math.Round(num2, 2);
					PortfolioPaper.gamma = Math.Round(num3, 6);
					PortfolioPaper.vega = Math.Round(num4, 2);
					PortfolioPaper.theta = Math.Round(num5, 2);
					PortfolioPaper.profit = Math.Round(num1, PortfolioPaper.decimal_points);
					PortfolioPaper.check = true;
					PortfolioPaper.check_calculation = true;
					PortfolioTable[i] = PortfolioPaper;
					PortfolioTotalCurrent.profit = PortfolioPaper.profit;
					break;
				}
			}
		}

		public void UpdatePortfolioTotalAdd1()
		{
			double num1 = 0.0;
			double num2 = 0.0;
			double num3 = 0.0;
			double num4 = 0.0;
			double num5 = 0.0;
			for (int index = 0; index < PortfolioTableAdd1.Count; index++)
			{
				if (PortfolioTableAdd1[index].paper_code == "FixedProfit")
				{
					if (PortfolioTableAdd1[index].check_calculation && gCheckFixedProfit)
					{
						double profit = PortfolioTableAdd1[index].profit;
						num1 += profit;
					}
				}
				else
				{
					if (PortfolioTableAdd1[index].paper_code == "Итого:")
					{
						continue;
					}
					if (Helpers.IsFutures(PortfolioTableAdd1[index].paper_code))
					{
						if (PortfolioTableAdd1[index].check_calculation)
						{
							double delta = PortfolioTableAdd1[index].delta;
							num2 += delta;
							double profit2 = PortfolioTableAdd1[index].profit;
							num1 += profit2;
						}
					}
					else if (PortfolioTableAdd1[index].check_calculation)
					{
						double delta2 = PortfolioTableAdd1[index].delta;
						num2 += delta2;
						double gamma = PortfolioTableAdd1[index].gamma;
						num3 += gamma;
						double vega = PortfolioTableAdd1[index].vega;
						num4 += vega;
						double theta = PortfolioTableAdd1[index].theta;
						num5 += theta;
						double profit3 = PortfolioTableAdd1[index].profit;
						num1 += profit3;
					}
				}
			}
			for (int i = 0; i < PortfolioTableAdd1.Count; i++)
			{
				if (PortfolioTableAdd1[i].paper_code == "Итого:")
				{
					PortfolioPaperAdd1.paper_code = PortfolioTableAdd1[i].paper_code;
					PortfolioPaperAdd1.base_asset = "";
					PortfolioPaperAdd1.volume = 0.0;
					PortfolioPaperAdd1.open_price = 0.0;
					PortfolioPaperAdd1.option_type = "";
					PortfolioPaperAdd1.strike = 0.0;
					PortfolioPaperAdd1.teoretical_price = 0.0;
					PortfolioPaperAdd1.futures_price = 0.0;
					PortfolioPaperAdd1.accumulated_profit = 0.0;
					PortfolioPaperAdd1.volatility = 0.0;
					PortfolioPaperAdd1.step_price = 0.0;
					PortfolioPaperAdd1.decimal_points = 0;
					PortfolioPaperAdd1.delta = Math.Round(num2, 2);
					PortfolioPaperAdd1.gamma = Math.Round(num3, 6);
					PortfolioPaperAdd1.vega = Math.Round(num4, 2);
					PortfolioPaperAdd1.theta = Math.Round(num5, 2);
					PortfolioPaperAdd1.profit = Math.Round(num1, PortfolioPaperAdd1.decimal_points);
					PortfolioPaperAdd1.check = true;
					PortfolioPaperAdd1.check_calculation = true;
					PortfolioTableAdd1[i] = PortfolioPaperAdd1;
					PortfolioTotalAdd1.profit = PortfolioPaperAdd1.profit;
					break;
				}
			}
		}

		public void UpdatePortfolioTotalAdd2()
		{
			double num1 = 0.0;
			double num2 = 0.0;
			double num3 = 0.0;
			double num4 = 0.0;
			double num5 = 0.0;
			for (int index = 0; index < PortfolioTableAdd2.Count; index++)
			{
				if (PortfolioTableAdd2[index].paper_code == "FixedProfit")
				{
					if (PortfolioTableAdd2[index].check_calculation && gCheckFixedProfit)
					{
						double profit = PortfolioTableAdd2[index].profit;
						num1 += profit;
					}
				}
				else
				{
					if (PortfolioTableAdd2[index].paper_code == "Итого:")
					{
						continue;
					}
					if (Helpers.IsFutures(PortfolioTableAdd2[index].paper_code))
					{
						if (PortfolioTableAdd2[index].check_calculation)
						{
							double delta = PortfolioTableAdd2[index].delta;
							num2 += delta;
							double profit2 = PortfolioTableAdd2[index].profit;
							num1 += profit2;
						}
					}
					else if (PortfolioTableAdd2[index].check_calculation)
					{
						double delta2 = PortfolioTableAdd2[index].delta;
						num2 += delta2;
						double gamma = PortfolioTableAdd2[index].gamma;
						num3 += gamma;
						double vega = PortfolioTableAdd2[index].vega;
						num4 += vega;
						double theta = PortfolioTableAdd2[index].theta;
						num5 += theta;
						double profit3 = PortfolioTableAdd2[index].profit;
						num1 += profit3;
					}
				}
			}
			for (int i = 0; i < PortfolioTableAdd2.Count; i++)
			{
				if (PortfolioTableAdd2[i].paper_code == "Итого:")
				{
					PortfolioPaperAdd2.paper_code = PortfolioTableAdd2[i].paper_code;
					PortfolioPaperAdd2.base_asset = "";
					PortfolioPaperAdd2.volume = 0.0;
					PortfolioPaperAdd2.open_price = 0.0;
					PortfolioPaperAdd2.option_type = "";
					PortfolioPaperAdd2.strike = 0.0;
					PortfolioPaperAdd2.teoretical_price = 0.0;
					PortfolioPaperAdd2.futures_price = 0.0;
					PortfolioPaperAdd2.accumulated_profit = 0.0;
					PortfolioPaperAdd2.volatility = 0.0;
					PortfolioPaperAdd2.step_price = 0.0;
					PortfolioPaperAdd2.decimal_points = 0;
					PortfolioPaperAdd2.delta = Math.Round(num2, 2);
					PortfolioPaperAdd2.gamma = Math.Round(num3, 6);
					PortfolioPaperAdd2.vega = Math.Round(num4, 2);
					PortfolioPaperAdd2.theta = Math.Round(num5, 2);
					PortfolioPaperAdd2.profit = Math.Round(num1, PortfolioPaperAdd2.decimal_points);
					PortfolioPaperAdd2.check = true;
					PortfolioPaperAdd2.check_calculation = true;
					PortfolioTableAdd2[i] = PortfolioPaperAdd2;
					PortfolioTotalAdd2.profit = PortfolioPaperAdd2.profit;
					break;
				}
			}
		}

		public void UpdatePortfolioTotalExpiration()
		{
			double num1 = 0.0;
			double num2 = 0.0;
			double num3 = 0.0;
			double num4 = 0.0;
			double num5 = 0.0;
			for (int index = 0; index < PortfolioTableExpiration.Count; index++)
			{
				if (PortfolioTableExpiration[index].paper_code == "FixedProfit")
				{
					if (PortfolioTableExpiration[index].check_calculation && gCheckFixedProfit)
					{
						double profit = PortfolioTableExpiration[index].profit;
						num1 += profit;
					}
				}
				else
				{
					if (PortfolioTableExpiration[index].paper_code == "Итого:")
					{
						continue;
					}
					if (Helpers.IsFutures(PortfolioTableExpiration[index].paper_code))
					{
						if (PortfolioTableExpiration[index].check_calculation)
						{
							double delta = PortfolioTableExpiration[index].delta;
							num2 += delta;
							double profit2 = PortfolioTableExpiration[index].profit;
							num1 += profit2;
						}
					}
					else if (PortfolioTableExpiration[index].check_calculation)
					{
						double delta2 = PortfolioTableExpiration[index].delta;
						num2 += delta2;
						double gamma = PortfolioTableExpiration[index].gamma;
						num3 += gamma;
						double vega = PortfolioTableExpiration[index].vega;
						num4 += vega;
						double theta = PortfolioTableExpiration[index].theta;
						num5 += theta;
						double profit3 = PortfolioTableExpiration[index].profit;
						num1 += profit3;
					}
				}
			}
			for (int i = 0; i < PortfolioTableExpiration.Count; i++)
			{
				if (PortfolioTableExpiration[i].paper_code == "Итого:")
				{
					PortfolioPaperExpiration.paper_code = PortfolioTableExpiration[i].paper_code;
					PortfolioPaperExpiration.base_asset = "";
					PortfolioPaperExpiration.volume = 0.0;
					PortfolioPaperExpiration.open_price = 0.0;
					PortfolioPaperExpiration.option_type = "";
					PortfolioPaperExpiration.strike = 0.0;
					PortfolioPaperExpiration.teoretical_price = 0.0;
					PortfolioPaperExpiration.futures_price = 0.0;
					PortfolioPaperExpiration.accumulated_profit = 0.0;
					PortfolioPaperExpiration.volatility = 0.0;
					PortfolioPaperExpiration.step_price = 0.0;
					PortfolioPaperExpiration.decimal_points = 0;
					PortfolioPaperExpiration.delta = Math.Round(num2, 2);
					PortfolioPaperExpiration.gamma = Math.Round(num3, 6);
					PortfolioPaperExpiration.vega = Math.Round(num4, 2);
					PortfolioPaperExpiration.theta = Math.Round(num5, 2);
					PortfolioPaperExpiration.profit = Math.Round(num1, PortfolioPaperExpiration.decimal_points);
					PortfolioPaperExpiration.check = true;
					PortfolioPaperExpiration.check_calculation = true;
					PortfolioTableExpiration[i] = PortfolioPaperExpiration;
					PortfolioTotalExpiration.profit = PortfolioPaperExpiration.profit;
					break;
				}
			}
		}
	}
}
