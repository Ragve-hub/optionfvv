using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Globalization;
using System.Linq;
using System.Windows.Forms;
using QuikDDE.Data;

namespace OptionFVV
{
	public class FormData : Form
	{
		public struct Strategy
		{
			public string name_strategy;

			public double profit;

			public double GO;
		}

		private struct QuotesData
		{
			public string paper_code;

			public DateTime expiration_date;

			public string base_asset;

			public double demand;

			public double sentence;

			public double last_price;

			public double strike;

			public string option_type;

			public double volatility;

			public double teoretical_price;

			public double step_price;

			public int i;
		}

		private static int quantityStrQuotesTable;

		private static int quantityStrFuturesQuotesTable;

		private static int quantityStrTransactionTable;

		private static bool F_OptionFilter;

		private static bool F_FillQuotesTable;

		private static bool F_FillFuturesQuotesTable;

		private static bool F_FillStrategyTable;

		private ClassDataDDE cDataDDE = new ClassDataDDE(false);

		public static List<Strategy> StrategyTable = new List<Strategy>();

		private Strategy StrategyPaper = default(Strategy);

		private List<Quotes> qQuotesTable = new List<Quotes>(10000);

		private Quotes qQuotesPaper = default(Quotes);

		private List<Quotes> qFuturesQuotesTable = new List<Quotes>(100);

		private Quotes qFuturesQuotesPaper = default(Quotes);

		private List<QuotesData> SortedQuotesTable = new List<QuotesData>(10000);

		private QuotesData SortedQuotesPaper = default(QuotesData);

		private List<QuotesData> SortedFuturesQuotesTable = new List<QuotesData>(10000);

		private QuotesData SortedFuturesQuotesPaper = default(QuotesData);

		private List<string> OptionsBaseAssetTable = new List<string>();

		private List<string> OptionsExpirationDateTable = new List<string>();

		private IContainer components = null;

		private SplitContainer splitContainer1;

		private DataGridView dataGridViewQuotes;

		private SplitContainer splitContainer2;

		private GroupBox groupBoxCurrentOptions;

		private GroupBox groupBoxInformation;

		private GroupBox groupBoxTransaction;

		private GroupBox groupBoxDDE;

		private Button buttonAddToStrategy;

		private ComboBox comboBoxStrategy;

		private Button buttonClearDDE;

		private CheckBox checkBoxTransactionTable;

		private CheckBox checkBoxQuotesTable;

		private RichTextBox richTextBoxInfo;

		private SplitContainer splitContainer3;

		private GroupBox groupBoxCurrentFutures;

		private DataGridView dataGridViewFuturesQuotes;

		private Label label2;

		private ComboBox comboBoxOptionsBaseAsset;

		private Label label4;

		private Label label3;

		private ComboBox comboBoxOptionsType;

		private ComboBox comboBoxOptionsExpirationDate;

		private CheckBox cbFutAsCLT;

		private TextBox textBoxFutLot;

		private Label label1;

		private TextBox textBoxFutTimeValue;

		private Label label5;

		private Button buttonImport;

		private RichTextBox textboxTotalPosition;

		private GroupBox groupBoxTableTransaction;

		private DataGridView dataGridViewTransaction;

		private Button buttonCheckAllTransactions;

		private Button buttonUnCheckAllTransaction;

		private CheckBox checkBoxFilterOptions;

		public FormData()
		{
			quantityStrQuotesTable = 0;
			quantityStrFuturesQuotesTable = 0;
			quantityStrTransactionTable = 0;
			F_OptionFilter = true;
			F_FillQuotesTable = true;
			F_FillFuturesQuotesTable = true;
			F_FillStrategyTable = true;
			CallBackMy.callbackEventHandlerColorThemeFormData = PaintColorTheme;
			InitializeComponent();
		}

		private void FormData_Load(object sender, EventArgs e)
		{
			checkBoxFilterOptions.Checked = false;
			comboBoxOptionsBaseAsset.Items.Clear();
			comboBoxOptionsBaseAsset.Items.Add("NULL");
			comboBoxOptionsBaseAsset.SelectedIndex = 0;
			comboBoxOptionsExpirationDate.Items.Clear();
			comboBoxOptionsExpirationDate.Items.Add("NULL");
			comboBoxOptionsExpirationDate.SelectedIndex = 0;
			comboBoxOptionsType.Items.Clear();
			comboBoxOptionsType.Items.Add("NULL");
			comboBoxOptionsType.SelectedIndex = 0;
			comboBoxOptionsBaseAsset.Enabled = false;
			comboBoxOptionsExpirationDate.Enabled = false;
			comboBoxOptionsType.Enabled = false;
			base.FormBorderStyle = FormBorderStyle.None;
			Dock = DockStyle.Fill;
			Create();
			dataGridViewQuotes.EnableHeadersVisualStyles = false;
			dataGridViewFuturesQuotes.EnableHeadersVisualStyles = false;
			dataGridViewTransaction.EnableHeadersVisualStyles = false;
			dataGridViewQuotes.AutoGenerateColumns = false;
			dataGridViewFuturesQuotes.AutoGenerateColumns = false;
			dataGridViewTransaction.AutoGenerateColumns = false;
			CreateStrategyTable();
			FillComboBoxCurrentStrategy(ClassSettings.gCurrentStrategy);
			PaintColorTheme();
		}

		public void Tick()
		{
			int f_iUp = 0;
			int f_iDn = -1;
			int f_iUpF = 0;
			int f_iDnF = -1;
			bool flag1 = false;
			bool flag2 = false;
			bool flag3 = false;
			bool flag4 = false;
			lock (ClassDataDDE.QuotesTable)
			{
				int count1 = ClassDataDDE.QuotesTable.Count;
				if (quantityStrQuotesTable != count1 || F_OptionFilter)
				{
					if (F_OptionFilter)
					{
						F_OptionFilter = false;
					}
					SortedQuotesTable.Clear();
					for (int index = 0; index < count1; index++)
					{
						if (checkBoxFilterOptions.Checked)
						{
							flag1 = true;
							if ((comboBoxOptionsBaseAsset.Text == ClassDataDDE.QuotesTable[index].base_asset || comboBoxOptionsBaseAsset.Text == "NULL") & (comboBoxOptionsExpirationDate.Text == ClassDataDDE.QuotesTable[index].expiration_date.Date.ToShortDateString() || comboBoxOptionsExpirationDate.Text == "NULL") & (comboBoxOptionsType.Text == ClassDataDDE.QuotesTable[index].option_type || comboBoxOptionsType.Text == "NULL"))
							{
								SortedQuotesPaper.paper_code = ClassDataDDE.QuotesTable[index].paper_code;
								SortedQuotesPaper.expiration_date = ClassDataDDE.QuotesTable[index].expiration_date;
								SortedQuotesPaper.base_asset = ClassDataDDE.QuotesTable[index].base_asset;
								SortedQuotesPaper.demand = ClassDataDDE.QuotesTable[index].demand;
								SortedQuotesPaper.sentence = ClassDataDDE.QuotesTable[index].sentence;
								SortedQuotesPaper.last_price = ClassDataDDE.QuotesTable[index].last_price;
								SortedQuotesPaper.strike = ClassDataDDE.QuotesTable[index].strike;
								SortedQuotesPaper.option_type = ClassDataDDE.QuotesTable[index].option_type;
								SortedQuotesPaper.volatility = ClassDataDDE.QuotesTable[index].volatility;
								SortedQuotesPaper.teoretical_price = ClassDataDDE.QuotesTable[index].teoretical_price;
								SortedQuotesPaper.step_price = ClassDataDDE.QuotesTable[index].step_price;
								SortedQuotesPaper.i = index;
								SortedQuotesTable.Add(SortedQuotesPaper);
							}
						}
						else
						{
							flag1 = false;
							flag2 = true;
							flag3 = true;
							flag4 = true;
							SortedQuotesPaper.paper_code = ClassDataDDE.QuotesTable[index].paper_code;
							SortedQuotesPaper.expiration_date = ClassDataDDE.QuotesTable[index].expiration_date;
							SortedQuotesPaper.base_asset = ClassDataDDE.QuotesTable[index].base_asset;
							SortedQuotesPaper.demand = ClassDataDDE.QuotesTable[index].demand;
							SortedQuotesPaper.sentence = ClassDataDDE.QuotesTable[index].sentence;
							SortedQuotesPaper.last_price = ClassDataDDE.QuotesTable[index].last_price;
							SortedQuotesPaper.strike = ClassDataDDE.QuotesTable[index].strike;
							SortedQuotesPaper.option_type = ClassDataDDE.QuotesTable[index].option_type;
							SortedQuotesPaper.volatility = ClassDataDDE.QuotesTable[index].volatility;
							SortedQuotesPaper.teoretical_price = ClassDataDDE.QuotesTable[index].teoretical_price;
							SortedQuotesPaper.step_price = ClassDataDDE.QuotesTable[index].step_price;
							SortedQuotesPaper.i = index;
							SortedQuotesTable.Add(SortedQuotesPaper);
						}
					}
					quantityStrQuotesTable = count1;
					F_FillQuotesTable = true;
				}
				else
				{
					if (dataGridViewQuotes.FirstDisplayedScrollingRowIndex >= 0 && dataGridViewQuotes.DisplayedRowCount(false) > 0)
					{
						f_iUp = dataGridViewQuotes.FirstDisplayedScrollingRowIndex - 1;
						if (f_iUp < 0)
						{
							f_iUp = 0;
						}
						f_iDn = dataGridViewQuotes.FirstDisplayedScrollingRowIndex + dataGridViewQuotes.DisplayedRowCount(false) + 1;
						if (f_iDn >= SortedQuotesTable.Count)
						{
							f_iDn = SortedQuotesTable.Count - 1;
						}
						for (int i = f_iUp; i <= f_iDn; i++)
						{
							if (i < dataGridViewQuotes.RowCount)
							{
								int i2 = SortedQuotesTable[i].i;
								if (i2 >= 0 && i2 < count1)
								{
									SortedQuotesPaper.paper_code = ClassDataDDE.QuotesTable[SortedQuotesTable[i].i].paper_code;
									SortedQuotesPaper.expiration_date = ClassDataDDE.QuotesTable[SortedQuotesTable[i].i].expiration_date;
									SortedQuotesPaper.base_asset = ClassDataDDE.QuotesTable[SortedQuotesTable[i].i].base_asset;
									SortedQuotesPaper.demand = ClassDataDDE.QuotesTable[SortedQuotesTable[i].i].demand;
									SortedQuotesPaper.sentence = ClassDataDDE.QuotesTable[SortedQuotesTable[i].i].sentence;
									SortedQuotesPaper.last_price = ClassDataDDE.QuotesTable[SortedQuotesTable[i].i].last_price;
									SortedQuotesPaper.strike = ClassDataDDE.QuotesTable[SortedQuotesTable[i].i].strike;
									SortedQuotesPaper.option_type = ClassDataDDE.QuotesTable[SortedQuotesTable[i].i].option_type;
									SortedQuotesPaper.volatility = ClassDataDDE.QuotesTable[SortedQuotesTable[i].i].volatility;
									SortedQuotesPaper.teoretical_price = ClassDataDDE.QuotesTable[SortedQuotesTable[i].i].teoretical_price;
									SortedQuotesPaper.step_price = ClassDataDDE.QuotesTable[SortedQuotesTable[i].i].step_price;
									SortedQuotesPaper.i = SortedQuotesTable[i].i;
									SortedQuotesTable[i] = SortedQuotesPaper;
								}
							}
						}
					}
					F_FillQuotesTable = false;
				}
				int count2 = ClassDataDDE.FuturesQuotesTable.Count;
				if (quantityStrFuturesQuotesTable != count2)
				{
					SortedFuturesQuotesTable.Clear();
					for (int j = 0; j < count2; j++)
					{
						SortedFuturesQuotesPaper.paper_code = ClassDataDDE.FuturesQuotesTable[j].paper_code;
						SortedFuturesQuotesPaper.expiration_date = ClassDataDDE.FuturesQuotesTable[j].expiration_date;
						SortedFuturesQuotesPaper.base_asset = ClassDataDDE.FuturesQuotesTable[j].base_asset;
						SortedFuturesQuotesPaper.demand = ClassDataDDE.FuturesQuotesTable[j].demand;
						SortedFuturesQuotesPaper.sentence = ClassDataDDE.FuturesQuotesTable[j].sentence;
						SortedFuturesQuotesPaper.last_price = ClassDataDDE.FuturesQuotesTable[j].last_price;
						SortedFuturesQuotesPaper.strike = 0.0;
						SortedFuturesQuotesPaper.option_type = "";
						SortedFuturesQuotesPaper.volatility = 0.0;
						SortedFuturesQuotesPaper.teoretical_price = 0.0;
						SortedFuturesQuotesPaper.step_price = ClassDataDDE.FuturesQuotesTable[j].step_price;
						SortedFuturesQuotesPaper.i = j;
						SortedFuturesQuotesTable.Add(SortedFuturesQuotesPaper);
					}
					quantityStrFuturesQuotesTable = count2;
					F_FillFuturesQuotesTable = true;
				}
				else
				{
					if (dataGridViewFuturesQuotes.FirstDisplayedScrollingRowIndex >= 0 && dataGridViewFuturesQuotes.DisplayedRowCount(false) > 0)
					{
						f_iUpF = dataGridViewFuturesQuotes.FirstDisplayedScrollingRowIndex - 1;
						if (f_iUpF < 0)
						{
							f_iUpF = 0;
						}
						f_iDnF = dataGridViewFuturesQuotes.FirstDisplayedScrollingRowIndex + dataGridViewFuturesQuotes.DisplayedRowCount(false) + 1;
						if (f_iDnF >= SortedFuturesQuotesTable.Count)
						{
							f_iDnF = SortedFuturesQuotesTable.Count - 1;
						}
						for (int k = f_iUpF; k <= f_iDnF; k++)
						{
							if (k < dataGridViewFuturesQuotes.RowCount)
							{
								int i3 = SortedFuturesQuotesTable[k].i;
								if (i3 >= 0 && i3 < count2)
								{
									SortedFuturesQuotesPaper.paper_code = ClassDataDDE.FuturesQuotesTable[SortedFuturesQuotesTable[k].i].paper_code;
									SortedFuturesQuotesPaper.expiration_date = ClassDataDDE.FuturesQuotesTable[SortedFuturesQuotesTable[k].i].expiration_date;
									SortedFuturesQuotesPaper.base_asset = ClassDataDDE.FuturesQuotesTable[SortedFuturesQuotesTable[k].i].base_asset;
									SortedFuturesQuotesPaper.demand = ClassDataDDE.FuturesQuotesTable[SortedFuturesQuotesTable[k].i].demand;
									SortedFuturesQuotesPaper.sentence = ClassDataDDE.FuturesQuotesTable[SortedFuturesQuotesTable[k].i].sentence;
									SortedFuturesQuotesPaper.last_price = ClassDataDDE.FuturesQuotesTable[SortedFuturesQuotesTable[k].i].last_price;
									SortedFuturesQuotesPaper.strike = 0.0;
									SortedFuturesQuotesPaper.option_type = "";
									SortedFuturesQuotesPaper.volatility = 0.0;
									SortedFuturesQuotesPaper.teoretical_price = 0.0;
									SortedFuturesQuotesPaper.step_price = ClassDataDDE.FuturesQuotesTable[SortedFuturesQuotesTable[k].i].step_price;
									SortedFuturesQuotesPaper.i = SortedFuturesQuotesTable[k].i;
									SortedFuturesQuotesTable[k] = SortedFuturesQuotesPaper;
								}
							}
						}
					}
					F_FillFuturesQuotesTable = false;
				}
			}
			if (F_FillQuotesTable)
			{
				FillFullQuotesTable();
			}
			else
			{
				FillQuotesTable(f_iUp, f_iDn);
			}
			if (F_FillFuturesQuotesTable)
			{
				FillFullFuturesQuotesTable();
			}
			else
			{
				FillFuturesQuotesTable(f_iUpF, f_iDnF);
			}
			lock (ClassDataDDE.TransactionTable)
			{
				int count3 = ClassDataDDE.TransactionTable.Count;
				if (quantityStrTransactionTable != count3)
				{
					if (count3 > quantityStrTransactionTable)
					{
						for (int transactionTable = quantityStrTransactionTable; transactionTable < count3; transactionTable++)
						{
							if (dataGridViewTransaction.ColumnCount == 8)
							{
								DataGridViewRowCollection rows = dataGridViewTransaction.Rows;
								rows.Add(false, ClassDataDDE.TransactionTable[transactionTable].number, ClassDataDDE.TransactionTable[transactionTable].date.ToShortDateString(), ClassDataDDE.TransactionTable[transactionTable].time.ToShortTimeString(), ClassDataDDE.TransactionTable[transactionTable].paper_code, ClassDataDDE.TransactionTable[transactionTable].operation, ClassDataDDE.TransactionTable[transactionTable].price, ClassDataDDE.TransactionTable[transactionTable].volume);
							}
						}
						quantityStrTransactionTable = count3;
					}
					else
					{
						dataGridViewTransaction.Rows.Clear();
						for (int l = 0; l < count3; l++)
						{
							DataGridViewRowCollection rows2 = dataGridViewTransaction.Rows;
							rows2.Add(false, ClassDataDDE.TransactionTable[l].number, ClassDataDDE.TransactionTable[l].date.ToShortDateString(), ClassDataDDE.TransactionTable[l].time.ToShortTimeString(), ClassDataDDE.TransactionTable[l].paper_code, ClassDataDDE.TransactionTable[l].operation, ClassDataDDE.TransactionTable[l].price, ClassDataDDE.TransactionTable[l].volume);
						}
						quantityStrTransactionTable = count3;
					}
				}
			}
			richTextBoxInfo.Clear();
			richTextBoxInfo.AppendText("FuturesQuotesTable " + quantityStrFuturesQuotesTable + "\n");
			richTextBoxInfo.AppendText("QuotesTable " + quantityStrQuotesTable + "\n");
			richTextBoxInfo.AppendText("TransactionTable " + quantityStrTransactionTable);
		}

		public void Create()
		{
			DataGridViewTextBoxColumn viewTextBoxColumn1 = new DataGridViewTextBoxColumn();
			viewTextBoxColumn1.HeaderText = "Код бумаги";
			viewTextBoxColumn1.Name = "paper_code";
			viewTextBoxColumn1.AutoSizeMode = DataGridViewAutoSizeColumnMode.DisplayedCells;
			viewTextBoxColumn1.DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;
			DataGridViewTextBoxColumn viewTextBoxColumn2 = new DataGridViewTextBoxColumn();
			viewTextBoxColumn2.HeaderText = "Погашение";
			viewTextBoxColumn2.Name = "expiration_date";
			viewTextBoxColumn2.DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;
			DataGridViewTextBoxColumn viewTextBoxColumn3 = new DataGridViewTextBoxColumn();
			viewTextBoxColumn3.HeaderText = "Баз. актив";
			viewTextBoxColumn3.Name = "base_asset";
			viewTextBoxColumn3.DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;
			DataGridViewTextBoxColumn viewTextBoxColumn4 = new DataGridViewTextBoxColumn();
			viewTextBoxColumn4.HeaderText = "Спрос";
			viewTextBoxColumn4.Name = "demand";
			viewTextBoxColumn4.DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;
			DataGridViewTextBoxColumn viewTextBoxColumn5 = new DataGridViewTextBoxColumn();
			viewTextBoxColumn5.HeaderText = "Предложение";
			viewTextBoxColumn5.Name = "sentence";
			viewTextBoxColumn5.DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;
			DataGridViewTextBoxColumn viewTextBoxColumn6 = new DataGridViewTextBoxColumn();
			viewTextBoxColumn6.HeaderText = "Цена послед.";
			viewTextBoxColumn6.Name = "last_price";
			viewTextBoxColumn6.DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;
			DataGridViewTextBoxColumn viewTextBoxColumn7 = new DataGridViewTextBoxColumn();
			viewTextBoxColumn7.HeaderText = "Страйк";
			viewTextBoxColumn7.Name = "strike";
			viewTextBoxColumn7.DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;
			DataGridViewTextBoxColumn viewTextBoxColumn8 = new DataGridViewTextBoxColumn();
			viewTextBoxColumn8.HeaderText = "Тип опциона";
			viewTextBoxColumn8.Name = "option_type";
			viewTextBoxColumn8.DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;
			DataGridViewTextBoxColumn viewTextBoxColumn9 = new DataGridViewTextBoxColumn();
			viewTextBoxColumn9.HeaderText = "Волатильность";
			viewTextBoxColumn9.Name = "volatility";
			viewTextBoxColumn9.DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;
			DataGridViewTextBoxColumn viewTextBoxColumn10 = new DataGridViewTextBoxColumn();
			viewTextBoxColumn10.HeaderText = "Теор. цена";
			viewTextBoxColumn10.Name = "teoretical_price";
			viewTextBoxColumn10.DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;
			DataGridViewTextBoxColumn viewTextBoxColumn11 = new DataGridViewTextBoxColumn();
			viewTextBoxColumn11.HeaderText = "Шаг цены";
			viewTextBoxColumn11.Name = "step_price";
			viewTextBoxColumn11.DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;
			dataGridViewQuotes.Columns.Add(viewTextBoxColumn1);
			dataGridViewQuotes.Columns.Add(viewTextBoxColumn2);
			dataGridViewQuotes.Columns.Add(viewTextBoxColumn3);
			dataGridViewQuotes.Columns.Add(viewTextBoxColumn4);
			dataGridViewQuotes.Columns.Add(viewTextBoxColumn5);
			dataGridViewQuotes.Columns.Add(viewTextBoxColumn6);
			dataGridViewQuotes.Columns.Add(viewTextBoxColumn7);
			dataGridViewQuotes.Columns.Add(viewTextBoxColumn8);
			dataGridViewQuotes.Columns.Add(viewTextBoxColumn9);
			dataGridViewQuotes.Columns.Add(viewTextBoxColumn10);
			dataGridViewQuotes.Columns.Add(viewTextBoxColumn11);
			dataGridViewQuotes.RowHeadersVisible = false;
			dataGridViewQuotes.ColumnHeadersDefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;
			viewTextBoxColumn2.AutoSizeMode = DataGridViewAutoSizeColumnMode.AllCells;
			viewTextBoxColumn3.AutoSizeMode = DataGridViewAutoSizeColumnMode.AllCells;
			viewTextBoxColumn4.AutoSizeMode = DataGridViewAutoSizeColumnMode.AllCells;
			viewTextBoxColumn5.AutoSizeMode = DataGridViewAutoSizeColumnMode.AllCells;
			viewTextBoxColumn6.AutoSizeMode = DataGridViewAutoSizeColumnMode.AllCells;
			viewTextBoxColumn7.AutoSizeMode = DataGridViewAutoSizeColumnMode.AllCells;
			viewTextBoxColumn8.AutoSizeMode = DataGridViewAutoSizeColumnMode.AllCells;
			viewTextBoxColumn9.AutoSizeMode = DataGridViewAutoSizeColumnMode.AllCells;
			viewTextBoxColumn10.AutoSizeMode = DataGridViewAutoSizeColumnMode.AllCells;
			viewTextBoxColumn11.AutoSizeMode = DataGridViewAutoSizeColumnMode.AllCells;
			viewTextBoxColumn1.AutoSizeMode = DataGridViewAutoSizeColumnMode.Fill;
			viewTextBoxColumn1.MinimumWidth = 100;
			DataGridViewTextBoxColumn viewTextBoxColumn12 = new DataGridViewTextBoxColumn();
			viewTextBoxColumn12.HeaderText = "Код бумаги";
			viewTextBoxColumn12.Name = "paper_code";
			viewTextBoxColumn12.AutoSizeMode = DataGridViewAutoSizeColumnMode.DisplayedCells;
			viewTextBoxColumn12.DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;
			DataGridViewTextBoxColumn viewTextBoxColumn13 = new DataGridViewTextBoxColumn();
			viewTextBoxColumn13.HeaderText = "Погашение";
			viewTextBoxColumn13.Name = "expiration_date";
			viewTextBoxColumn13.DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;
			DataGridViewTextBoxColumn viewTextBoxColumn14 = new DataGridViewTextBoxColumn();
			viewTextBoxColumn14.HeaderText = "Баз. актив";
			viewTextBoxColumn14.Name = "base_asset";
			viewTextBoxColumn14.DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;
			DataGridViewTextBoxColumn viewTextBoxColumn15 = new DataGridViewTextBoxColumn();
			viewTextBoxColumn15.HeaderText = "Спрос";
			viewTextBoxColumn15.Name = "demand";
			viewTextBoxColumn15.DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;
			DataGridViewTextBoxColumn viewTextBoxColumn16 = new DataGridViewTextBoxColumn();
			viewTextBoxColumn16.HeaderText = "Предложение";
			viewTextBoxColumn16.Name = "sentence";
			viewTextBoxColumn16.DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;
			DataGridViewTextBoxColumn viewTextBoxColumn17 = new DataGridViewTextBoxColumn();
			viewTextBoxColumn17.HeaderText = "Цена послед.";
			viewTextBoxColumn17.Name = "last_price";
			viewTextBoxColumn17.DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;
			DataGridViewTextBoxColumn viewTextBoxColumn18 = new DataGridViewTextBoxColumn();
			viewTextBoxColumn18.HeaderText = "Шаг цены";
			viewTextBoxColumn18.Name = "step_price";
			viewTextBoxColumn18.DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;
			dataGridViewFuturesQuotes.Columns.Add(viewTextBoxColumn12);
			dataGridViewFuturesQuotes.Columns.Add(viewTextBoxColumn13);
			dataGridViewFuturesQuotes.Columns.Add(viewTextBoxColumn14);
			dataGridViewFuturesQuotes.Columns.Add(viewTextBoxColumn15);
			dataGridViewFuturesQuotes.Columns.Add(viewTextBoxColumn16);
			dataGridViewFuturesQuotes.Columns.Add(viewTextBoxColumn17);
			dataGridViewFuturesQuotes.Columns.Add(viewTextBoxColumn18);
			dataGridViewFuturesQuotes.RowHeadersVisible = false;
			dataGridViewFuturesQuotes.ColumnHeadersDefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;
			viewTextBoxColumn13.AutoSizeMode = DataGridViewAutoSizeColumnMode.AllCells;
			viewTextBoxColumn14.AutoSizeMode = DataGridViewAutoSizeColumnMode.AllCells;
			viewTextBoxColumn15.AutoSizeMode = DataGridViewAutoSizeColumnMode.AllCells;
			viewTextBoxColumn16.AutoSizeMode = DataGridViewAutoSizeColumnMode.AllCells;
			viewTextBoxColumn17.AutoSizeMode = DataGridViewAutoSizeColumnMode.AllCells;
			viewTextBoxColumn18.AutoSizeMode = DataGridViewAutoSizeColumnMode.AllCells;
			viewTextBoxColumn12.AutoSizeMode = DataGridViewAutoSizeColumnMode.Fill;
			viewTextBoxColumn12.MinimumWidth = 100;
			DataGridViewCheckBoxColumn viewCheckBoxColumn = new DataGridViewCheckBoxColumn();
			viewCheckBoxColumn.HeaderText = "";
			viewCheckBoxColumn.Name = "check";
			viewCheckBoxColumn.AutoSizeMode = DataGridViewAutoSizeColumnMode.DisplayedCells;
			viewCheckBoxColumn.DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;
			DataGridViewTextBoxColumn viewTextBoxColumn19 = new DataGridViewTextBoxColumn();
			viewTextBoxColumn19.HeaderText = "Номер";
			viewTextBoxColumn19.Name = "number";
			viewTextBoxColumn19.AutoSizeMode = DataGridViewAutoSizeColumnMode.DisplayedCells;
			viewTextBoxColumn19.DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;
			DataGridViewTextBoxColumn viewTextBoxColumn20 = new DataGridViewTextBoxColumn();
			viewTextBoxColumn20.HeaderText = "Дата";
			viewTextBoxColumn20.Name = "date";
			viewTextBoxColumn20.DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;
			DataGridViewTextBoxColumn viewTextBoxColumn21 = new DataGridViewTextBoxColumn();
			viewTextBoxColumn21.HeaderText = "Время";
			viewTextBoxColumn21.Name = "time";
			viewTextBoxColumn21.DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;
			DataGridViewTextBoxColumn viewTextBoxColumn22 = new DataGridViewTextBoxColumn();
			viewTextBoxColumn22.HeaderText = "Код бумаги";
			viewTextBoxColumn22.Name = "paper_code";
			viewTextBoxColumn22.DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;
			DataGridViewTextBoxColumn viewTextBoxColumn23 = new DataGridViewTextBoxColumn();
			viewTextBoxColumn23.HeaderText = "Операция";
			viewTextBoxColumn23.Name = "operation";
			viewTextBoxColumn23.DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;
			DataGridViewTextBoxColumn viewTextBoxColumn24 = new DataGridViewTextBoxColumn();
			viewTextBoxColumn24.HeaderText = "Цена";
			viewTextBoxColumn24.Name = "price";
			viewTextBoxColumn24.DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;
			DataGridViewTextBoxColumn viewTextBoxColumn25 = new DataGridViewTextBoxColumn();
			viewTextBoxColumn25.HeaderText = "Количество";
			viewTextBoxColumn25.Name = "volume";
			viewTextBoxColumn25.DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;
			dataGridViewTransaction.Columns.Add(viewCheckBoxColumn);
			dataGridViewTransaction.Columns.Add(viewTextBoxColumn19);
			dataGridViewTransaction.Columns.Add(viewTextBoxColumn20);
			dataGridViewTransaction.Columns.Add(viewTextBoxColumn21);
			dataGridViewTransaction.Columns.Add(viewTextBoxColumn22);
			dataGridViewTransaction.Columns.Add(viewTextBoxColumn23);
			dataGridViewTransaction.Columns.Add(viewTextBoxColumn24);
			dataGridViewTransaction.Columns.Add(viewTextBoxColumn25);
			dataGridViewTransaction.RowHeadersVisible = false;
			dataGridViewTransaction.ColumnHeadersDefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;
			viewCheckBoxColumn.AutoSizeMode = DataGridViewAutoSizeColumnMode.AllCells;
			viewTextBoxColumn20.AutoSizeMode = DataGridViewAutoSizeColumnMode.AllCells;
			viewTextBoxColumn21.AutoSizeMode = DataGridViewAutoSizeColumnMode.AllCells;
			viewTextBoxColumn22.AutoSizeMode = DataGridViewAutoSizeColumnMode.AllCells;
			viewTextBoxColumn23.AutoSizeMode = DataGridViewAutoSizeColumnMode.AllCells;
			viewTextBoxColumn24.AutoSizeMode = DataGridViewAutoSizeColumnMode.AllCells;
			viewTextBoxColumn25.AutoSizeMode = DataGridViewAutoSizeColumnMode.AllCells;
			viewTextBoxColumn19.AutoSizeMode = DataGridViewAutoSizeColumnMode.Fill;
			viewTextBoxColumn19.MinimumWidth = 100;
		}

		public void Clear()
		{
			dataGridViewQuotes.Rows.Clear();
		}

		public void FillFullQuotesTable()
		{
			dataGridViewQuotes.Rows.Clear();
			for (int index = 0; index < SortedQuotesTable.Count; index++)
			{
				dataGridViewQuotes.Rows.Add(SortedQuotesTable[index].paper_code, SortedQuotesTable[index].expiration_date.ToShortDateString(), SortedQuotesTable[index].base_asset, SortedQuotesTable[index].demand, SortedQuotesTable[index].sentence, SortedQuotesTable[index].last_price, SortedQuotesTable[index].strike, SortedQuotesTable[index].option_type, SortedQuotesTable[index].volatility, SortedQuotesTable[index].teoretical_price, SortedQuotesTable[index].step_price);
			}
		}

		public void FillFullFuturesQuotesTable()
		{
			dataGridViewFuturesQuotes.Rows.Clear();
			for (int index = 0; index < SortedFuturesQuotesTable.Count; index++)
			{
				dataGridViewFuturesQuotes.Rows.Add(SortedFuturesQuotesTable[index].paper_code, SortedFuturesQuotesTable[index].expiration_date.ToShortDateString(), SortedFuturesQuotesTable[index].base_asset, SortedFuturesQuotesTable[index].demand, SortedFuturesQuotesTable[index].sentence, SortedFuturesQuotesTable[index].last_price, SortedFuturesQuotesTable[index].step_price);
			}
		}

		public void FillQuotesTable(int f_iUp, int f_iDn)
		{
			if (f_iDn == -1)
			{
				return;
			}
			for (int index = f_iUp; index <= f_iDn; index++)
			{
				if (index < dataGridViewQuotes.RowCount)
				{
					dataGridViewQuotes.Rows[index].Cells[0].Value = SortedQuotesTable[index].paper_code;
					dataGridViewQuotes.Rows[index].Cells[1].Value = SortedQuotesTable[index].expiration_date.ToShortDateString();
					dataGridViewQuotes.Rows[index].Cells[2].Value = SortedQuotesTable[index].base_asset;
					dataGridViewQuotes.Rows[index].Cells[3].Value = SortedQuotesTable[index].demand;
					dataGridViewQuotes.Rows[index].Cells[4].Value = SortedQuotesTable[index].sentence;
					dataGridViewQuotes.Rows[index].Cells[5].Value = SortedQuotesTable[index].last_price;
					dataGridViewQuotes.Rows[index].Cells[6].Value = SortedQuotesTable[index].strike;
					dataGridViewQuotes.Rows[index].Cells[7].Value = SortedQuotesTable[index].option_type;
					dataGridViewQuotes.Rows[index].Cells[8].Value = SortedQuotesTable[index].volatility;
					dataGridViewQuotes.Rows[index].Cells[9].Value = SortedQuotesTable[index].teoretical_price;
					dataGridViewQuotes.Rows[index].Cells[10].Value = SortedQuotesTable[index].step_price;
				}
			}
		}

		public void FillFuturesQuotesTable(int f_iUpF, int f_iDnF)
		{
			if (f_iDnF == -1)
			{
				return;
			}
			for (int index = f_iUpF; index <= f_iDnF; index++)
			{
				if (index < dataGridViewFuturesQuotes.RowCount)
				{
					dataGridViewFuturesQuotes.Rows[index].Cells[0].Value = SortedFuturesQuotesTable[index].paper_code;
					dataGridViewFuturesQuotes.Rows[index].Cells[1].Value = SortedFuturesQuotesTable[index].expiration_date.ToShortDateString();
					dataGridViewFuturesQuotes.Rows[index].Cells[2].Value = SortedFuturesQuotesTable[index].base_asset;
					dataGridViewFuturesQuotes.Rows[index].Cells[3].Value = SortedFuturesQuotesTable[index].demand;
					dataGridViewFuturesQuotes.Rows[index].Cells[4].Value = SortedFuturesQuotesTable[index].sentence;
					dataGridViewFuturesQuotes.Rows[index].Cells[5].Value = SortedFuturesQuotesTable[index].last_price;
					dataGridViewFuturesQuotes.Rows[index].Cells[6].Value = SortedFuturesQuotesTable[index].step_price;
				}
			}
		}

		public void ClearDDE()
		{
			if (checkBoxQuotesTable.Checked)
			{
				cDataDDE.ClearQuotes();
				dataGridViewQuotes.Rows.Clear();
				dataGridViewFuturesQuotes.Rows.Clear();
				quantityStrFuturesQuotesTable = 0;
				quantityStrQuotesTable = 0;
			}
			if (checkBoxTransactionTable.Checked)
			{
				cDataDDE.ClearTransaction();
				dataGridViewTransaction.Rows.Clear();
				quantityStrTransactionTable = 0;
			}
		}

		private void PaintColorTheme()
		{
			BackColor = ClassColorTheme.BackColor;
			ForeColor = ClassColorTheme.HeadersColorFore;
			groupBoxDDE.BackColor = ClassColorTheme.BackColor;
			groupBoxDDE.ForeColor = ClassColorTheme.BackColorFore;
			groupBoxTransaction.BackColor = ClassColorTheme.BackColor;
			groupBoxTransaction.ForeColor = ClassColorTheme.BackColorFore;
			groupBoxInformation.BackColor = ClassColorTheme.BackColor;
			groupBoxInformation.ForeColor = ClassColorTheme.BackColorFore;
			groupBoxCurrentOptions.BackColor = ClassColorTheme.BackColor;
			groupBoxCurrentOptions.ForeColor = ClassColorTheme.BackColorFore;
			groupBoxCurrentFutures.BackColor = ClassColorTheme.BackColor;
			groupBoxCurrentFutures.ForeColor = ClassColorTheme.BackColorFore;
			groupBoxTableTransaction.BackColor = ClassColorTheme.BackColor;
			groupBoxTableTransaction.ForeColor = ClassColorTheme.BackColorFore;
			splitContainer1.BackColor = ClassColorTheme.HeadersColor;
			splitContainer1.Panel1.BackColor = ClassColorTheme.BackColor;
			splitContainer1.Panel2.BackColor = ClassColorTheme.BackColor;
			splitContainer1.BorderStyle = BorderStyle.None;
			splitContainer2.BackColor = ClassColorTheme.HeadersColor;
			splitContainer2.Panel1.BackColor = ClassColorTheme.BackColor;
			splitContainer2.Panel2.BackColor = ClassColorTheme.BackColor;
			splitContainer2.BorderStyle = BorderStyle.None;
			splitContainer3.BackColor = ClassColorTheme.HeadersColor;
			splitContainer3.Panel1.BackColor = ClassColorTheme.BackColor;
			splitContainer3.Panel2.BackColor = ClassColorTheme.BackColor;
			splitContainer3.BorderStyle = BorderStyle.None;
			checkBoxQuotesTable.ForeColor = ClassColorTheme.BackColorFore;
			checkBoxFilterOptions.ForeColor = ClassColorTheme.BackColorFore;
			checkBoxTransactionTable.ForeColor = ClassColorTheme.BackColorFore;
			comboBoxStrategy.FlatStyle = FlatStyle.System;
			comboBoxOptionsBaseAsset.FlatStyle = FlatStyle.System;
			comboBoxOptionsExpirationDate.FlatStyle = FlatStyle.System;
			comboBoxOptionsType.FlatStyle = FlatStyle.System;
			buttonClearDDE.FlatStyle = FlatStyle.System;
			buttonAddToStrategy.FlatStyle = FlatStyle.System;
			buttonCheckAllTransactions.FlatStyle = FlatStyle.System;
			buttonUnCheckAllTransaction.FlatStyle = FlatStyle.System;
			richTextBoxInfo.BackColor = ClassColorTheme.BackColor;
			richTextBoxInfo.ForeColor = ClassColorTheme.BackColorFore;
			dataGridViewQuotes.ColumnHeadersDefaultCellStyle.BackColor = ClassColorTheme.HeadersColor;
			dataGridViewQuotes.BackgroundColor = ClassColorTheme.BackColor;
			dataGridViewQuotes.ForeColor = ClassColorTheme.BackColorFore;
			dataGridViewQuotes.DefaultCellStyle.BackColor = ClassColorTheme.BackColor;
			dataGridViewQuotes.ColumnHeadersDefaultCellStyle.ForeColor = ClassColorTheme.HeadersColorFore;
			dataGridViewQuotes.GridColor = ClassColorTheme.GridColor;
			dataGridViewQuotes.RowsDefaultCellStyle.BackColor = ClassColorTheme.BackColor;
			dataGridViewQuotes.AlternatingRowsDefaultCellStyle.BackColor = ClassColorTheme.HeadersColor;
			dataGridViewFuturesQuotes.ColumnHeadersDefaultCellStyle.BackColor = ClassColorTheme.HeadersColor;
			dataGridViewFuturesQuotes.BackgroundColor = ClassColorTheme.BackColor;
			dataGridViewFuturesQuotes.ForeColor = ClassColorTheme.BackColorFore;
			dataGridViewFuturesQuotes.DefaultCellStyle.BackColor = ClassColorTheme.BackColor;
			dataGridViewFuturesQuotes.ColumnHeadersDefaultCellStyle.ForeColor = ClassColorTheme.HeadersColorFore;
			dataGridViewFuturesQuotes.GridColor = ClassColorTheme.GridColor;
			dataGridViewFuturesQuotes.RowsDefaultCellStyle.BackColor = ClassColorTheme.BackColor;
			dataGridViewFuturesQuotes.AlternatingRowsDefaultCellStyle.BackColor = ClassColorTheme.HeadersColor;
			dataGridViewTransaction.ColumnHeadersDefaultCellStyle.BackColor = ClassColorTheme.HeadersColor;
			dataGridViewTransaction.BackgroundColor = ClassColorTheme.BackColor;
			dataGridViewTransaction.ForeColor = ClassColorTheme.BackColorFore;
			dataGridViewTransaction.DefaultCellStyle.BackColor = ClassColorTheme.BackColor;
			dataGridViewTransaction.ColumnHeadersDefaultCellStyle.ForeColor = ClassColorTheme.HeadersColorFore;
			dataGridViewTransaction.GridColor = ClassColorTheme.GridColor;
			dataGridViewTransaction.RowsDefaultCellStyle.BackColor = ClassColorTheme.BackColor;
			dataGridViewTransaction.AlternatingRowsDefaultCellStyle.BackColor = ClassColorTheme.HeadersColor;
		}

		private void buttonClearDDE_Click(object sender, EventArgs e)
		{
			ClearDDE();
		}

		public void CreateStrategyTable()
		{
			StrategyTable.Clear();
			for (int index1 = 0; index1 < FormTransaction.TransactionTable.Count; index1++)
			{
				bool flag = false;
				string strategy = FormTransaction.TransactionTable[index1].strategy;
				if (strategy != "" && StrategyTable.Count == 0)
				{
					StrategyPaper.name_strategy = FormTransaction.TransactionTable[index1].strategy;
					StrategyPaper.profit = 0.0;
					StrategyPaper.GO = 0.0;
					StrategyTable.Add(StrategyPaper);
				}
				else
				{
					if (!(strategy != ""))
					{
						continue;
					}
					for (int i = 0; i < StrategyTable.Count; i++)
					{
						if (strategy == StrategyTable[i].name_strategy)
						{
							flag = true;
							break;
						}
					}
					if (!flag)
					{
						StrategyPaper.name_strategy = FormTransaction.TransactionTable[index1].strategy;
						StrategyPaper.profit = 0.0;
						StrategyPaper.GO = 0.0;
						StrategyTable.Add(StrategyPaper);
					}
				}
			}
		}

		public void FillComboBoxCurrentStrategy(string CurrentStrategy)
		{
			comboBoxStrategy.Items.Clear();
			int num = 0;
			for (int index = 0; index < StrategyTable.Count; index++)
			{
				comboBoxStrategy.Items.Add(StrategyTable[index].name_strategy);
				if (StrategyTable[index].name_strategy == CurrentStrategy)
				{
					num = index;
				}
			}
			if (StrategyTable.Count > 0)
			{
				comboBoxStrategy.SelectedIndex = num;
			}
		}

		public void CreateOptionsBaseAssetTable()
		{
			OptionsBaseAssetTable.Clear();
			OptionsBaseAssetTable.Add("NULL");
			for (int index1 = 0; index1 < qQuotesTable.Count; index1++)
			{
				bool flag = false;
				string baseAsset = qQuotesTable[index1].base_asset;
				if (baseAsset != "" && OptionsBaseAssetTable.Count == 0)
				{
					OptionsBaseAssetTable.Add(baseAsset);
				}
				else
				{
					if (!(baseAsset != ""))
					{
						continue;
					}
					for (int i = 0; i < OptionsBaseAssetTable.Count; i++)
					{
						if (baseAsset == OptionsBaseAssetTable[i])
						{
							flag = true;
							break;
						}
					}
					if (!flag)
					{
						OptionsBaseAssetTable.Add(baseAsset);
					}
				}
			}
		}

		public void FillComboBoxOptionsBaseAsset(string CurrentBaseAsset)
		{
			comboBoxOptionsBaseAsset.Items.Clear();
			int num = 0;
			for (int index = 0; index < OptionsBaseAssetTable.Count; index++)
			{
				comboBoxOptionsBaseAsset.Items.Add(OptionsBaseAssetTable[index]);
				if (OptionsBaseAssetTable[index] == CurrentBaseAsset)
				{
					num = index;
				}
			}
			if (OptionsBaseAssetTable.Count > 0)
			{
				comboBoxOptionsBaseAsset.SelectedIndex = num;
			}
		}

		public void CreateOptionsExpirationDateTable()
		{
			OptionsExpirationDateTable.Clear();
			OptionsExpirationDateTable.Add("NULL");
			for (int index1 = 0; index1 < qQuotesTable.Count; index1++)
			{
				if (!(qQuotesTable[index1].base_asset == comboBoxOptionsBaseAsset.Text))
				{
					continue;
				}
				bool flag = false;
				string shortDateString = qQuotesTable[index1].expiration_date.Date.ToShortDateString();
				if (shortDateString != "" && OptionsExpirationDateTable.Count == 0)
				{
					OptionsExpirationDateTable.Add(shortDateString);
				}
				else
				{
					if (!(shortDateString != ""))
					{
						continue;
					}
					for (int i = 0; i < OptionsExpirationDateTable.Count; i++)
					{
						if (shortDateString == OptionsExpirationDateTable[i])
						{
							flag = true;
							break;
						}
					}
					if (!flag)
					{
						OptionsExpirationDateTable.Add(shortDateString);
					}
				}
			}
		}

		public void FillComboBoxOptionsExpirationDate(string Current)
		{
			comboBoxOptionsExpirationDate.Items.Clear();
			int num = 0;
			for (int index = 0; index < OptionsExpirationDateTable.Count; index++)
			{
				comboBoxOptionsExpirationDate.Items.Add(OptionsExpirationDateTable[index]);
				if (OptionsExpirationDateTable[index] == Current)
				{
					num = index;
				}
			}
			if (OptionsExpirationDateTable.Count > 0)
			{
				comboBoxOptionsExpirationDate.SelectedIndex = num;
				return;
			}
			comboBoxOptionsExpirationDate.Items.Clear();
			comboBoxOptionsExpirationDate.Items.Add("NULL");
			comboBoxOptionsExpirationDate.SelectedIndex = 0;
		}

		public void FillComboBoxOptionsType(string Current)
		{
			comboBoxOptionsType.Items.Clear();
			int num = 0;
			comboBoxOptionsType.Items.Add("NULL");
			if ("NULL" == Current)
			{
				num = 0;
			}
			comboBoxOptionsType.Items.Add("Call");
			if ("Call" == Current)
			{
				num = 1;
			}
			comboBoxOptionsType.Items.Add("Put");
			if ("Put" == Current)
			{
				num = 2;
			}
			comboBoxOptionsType.SelectedIndex = num;
		}

		private void comboBoxStrategy_Click(object sender, EventArgs e)
		{
			CreateStrategyTable();
			FillComboBoxCurrentStrategy(ClassSettings.gCurrentStrategy);
		}

		private void buttonImportToStrategy_Click(object sender, EventArgs e)
		{
			string text = comboBoxStrategy.Text;
			bool futAsClt = cbFutAsCLT.Checked;
			double lot = double.Parse(textBoxFutLot.Text);
			double timeValue = double.Parse(textBoxFutTimeValue.Text);
			char[] razdel1 = new char[1] { '\t' };
			string alltext = textboxTotalPosition.Text;
			string[] rows = alltext.Split('\n');
			NumberFormatInfo nfi = new NumberFormatInfo
			{
				NumberDecimalSeparator = ".",
				NumberGroupSeparator = " "
			};
			Random randomGenerator = new Random();
			for (int i = 1; i < rows.Count(); i++)
			{
				string[] cells = rows[i].Split(razdel1);
				int cellsCount = cells.Count();
				if (cellsCount < 4)
				{
					cells = rows[i].Split(' ');
					cellsCount = cells.Count();
				}
				if (cellsCount < 4)
				{
					continue;
				}
				FormTransaction.TransactionPaper.number = "IMP" + Convert.ToString(randomGenerator.Next(100000000, 900000000));
				FormTransaction.TransactionPaper.date = DateTime.Now;
				FormTransaction.TransactionPaper.time = DateTime.Now;
				FormTransaction.TransactionPaper.paper_code = Convert.ToString(cells[2]);
				FormTransaction.TransactionPaper.operation = ((Convert.ToInt32(cells[3]) > 0) ? "Купля" : "Продажа");
				FormTransaction.TransactionPaper.volume = Math.Abs(double.Parse(Convert.ToString(cells[3]), nfi));
				if (Helpers.IsFutures(FormTransaction.TransactionPaper.paper_code) && futAsClt)
				{
					FormTransaction.TransactionPaper.volume *= lot;
				}
				double price;
				if (!double.TryParse(Convert.ToString(cells[4]), out price))
				{
					price = double.Parse(Convert.ToString(cells[4]), CultureInfo.CurrentCulture);
				}
				FormTransaction.TransactionPaper.price = price;
				if (Helpers.IsFutures(FormTransaction.TransactionPaper.paper_code) && !FormTransaction.TransactionPaper.paper_code.EndsWith("_CLT") && futAsClt)
				{
					FormTransaction.TransactionPaper.price /= lot;
					FormTransaction.TransactionPaper.price += timeValue;
					FormTransaction.TransactionPaper.price = Math.Round(FormTransaction.TransactionPaper.price, 2);
					if (cDataDDE.SearchPaper(FormTransaction.TransactionPaper.paper_code))
					{
						string futures = ClassDataDDE.QuotesPaper.base_asset;
						if (Helpers.CheckHasClt(futures))
						{
							string clt_code = Helpers.MapCodeClt(futures) + "_CLT";
							FormTransaction.TransactionPaper.paper_code = clt_code;
						}
					}
				}
				FormTransaction.TransactionPaper.strategy = text;
				FormTransaction.TransactionTable.Add(FormTransaction.TransactionPaper);
			}
		}

		private void buttonAddToStrategy_Click(object sender, EventArgs e)
		{
			string text = comboBoxStrategy.Text;
			bool futAsClt = cbFutAsCLT.Checked;
			double lot = double.Parse(textBoxFutLot.Text);
			double timeValue = double.Parse(textBoxFutTimeValue.Text);
			bool flag = false;
			for (int index1 = 0; index1 < dataGridViewTransaction.RowCount; index1++)
			{
				if (!(Convert.ToString(dataGridViewTransaction.Rows[index1].Cells[0].Value) == "True"))
				{
					continue;
				}
				for (int i = 0; i < FormTransaction.TransactionTable.Count; i++)
				{
					if (Convert.ToString(FormTransaction.TransactionTable[i].number) == Convert.ToString(dataGridViewTransaction.Rows[index1].Cells[1].Value))
					{
						flag = true;
						int num = (int)MessageBox.Show("Сделка с номером " + Convert.ToString(dataGridViewTransaction.Rows[index1].Cells[1].Value) + " в базе уже есть, сохранить не получится");
						break;
					}
				}
				if (flag)
				{
					continue;
				}
				FormTransaction.TransactionPaper.number = Convert.ToString(dataGridViewTransaction.Rows[index1].Cells[1].Value);
				FormTransaction.TransactionPaper.date = Convert.ToDateTime(dataGridViewTransaction.Rows[index1].Cells[2].Value);
				FormTransaction.TransactionPaper.time = Convert.ToDateTime(dataGridViewTransaction.Rows[index1].Cells[3].Value);
				FormTransaction.TransactionPaper.paper_code = Convert.ToString(dataGridViewTransaction.Rows[index1].Cells[4].Value);
				FormTransaction.TransactionPaper.operation = Convert.ToString(dataGridViewTransaction.Rows[index1].Cells[5].Value);
				FormTransaction.TransactionPaper.volume = ((!double.TryParse(Convert.ToString(dataGridViewTransaction.Rows[index1].Cells[7].Value), out FormTransaction.TransactionPaper.volume)) ? 0.0 : Math.Abs(FormTransaction.TransactionPaper.volume));
				if (Helpers.IsFutures(FormTransaction.TransactionPaper.paper_code) && futAsClt)
				{
					FormTransaction.TransactionPaper.volume *= lot;
				}
				if (double.TryParse(Convert.ToString(dataGridViewTransaction.Rows[index1].Cells[6].Value), out FormTransaction.TransactionPaper.price))
				{
					if (FormTransaction.TransactionPaper.price < 0.0)
					{
						FormTransaction.TransactionPaper.price = 0.0;
					}
				}
				else
				{
					FormTransaction.TransactionPaper.price = 0.0;
				}
				if (Helpers.IsFutures(FormTransaction.TransactionPaper.paper_code) && !FormTransaction.TransactionPaper.paper_code.EndsWith("_CLT") && futAsClt)
				{
					FormTransaction.TransactionPaper.price /= lot;
					FormTransaction.TransactionPaper.price += timeValue;
					FormTransaction.TransactionPaper.price = Math.Round(FormTransaction.TransactionPaper.price, 2);
					if (cDataDDE.SearchPaper(FormTransaction.TransactionPaper.paper_code))
					{
						string futures = ClassDataDDE.QuotesPaper.base_asset;
						if (Helpers.CheckHasClt(futures))
						{
							string clt_code = Helpers.MapCodeClt(futures) + "_CLT";
							FormTransaction.TransactionPaper.paper_code = clt_code;
						}
					}
				}
				FormTransaction.TransactionPaper.strategy = text;
				FormTransaction.TransactionTable.Add(FormTransaction.TransactionPaper);
			}
		}

		private void buttonCheckAllTransactions_Click(object sender, EventArgs e)
		{
			for (int index1 = 0; index1 < dataGridViewTransaction.RowCount; index1++)
			{
				dataGridViewTransaction.Rows[index1].Cells[0].Value = true;
			}
		}

		private void buttonUnCheckAllTransaction_Click(object sender, EventArgs e)
		{
			for (int index1 = 0; index1 < dataGridViewTransaction.RowCount; index1++)
			{
				dataGridViewTransaction.Rows[index1].Cells[0].Value = false;
			}
		}

		private void checkBoxFiltrOptions_CheckStateChanged(object sender, EventArgs e)
		{
			if (checkBoxFilterOptions.Checked)
			{
				qQuotesTable.Clear();
				lock (ClassDataDDE.QuotesTable)
				{
					qQuotesTable.AddRange(ClassDataDDE.QuotesTable);
				}
				CreateOptionsBaseAssetTable();
				FillComboBoxOptionsBaseAsset(comboBoxOptionsBaseAsset.Text);
				comboBoxOptionsBaseAsset.Enabled = true;
				if (comboBoxOptionsBaseAsset.Text == "NULL")
				{
					FillComboBoxOptionsExpirationDate("NULL");
					FillComboBoxOptionsType("NULL");
					comboBoxOptionsExpirationDate.Enabled = false;
					comboBoxOptionsType.Enabled = false;
				}
				else
				{
					comboBoxOptionsExpirationDate.Enabled = true;
					comboBoxOptionsType.Enabled = true;
				}
				if (!(comboBoxOptionsBaseAsset.Text == "NULL") || !(comboBoxOptionsExpirationDate.Text == "NULL") || !(comboBoxOptionsType.Text == "NULL"))
				{
					F_OptionFilter = true;
					Tick();
				}
			}
			else
			{
				comboBoxOptionsBaseAsset.Enabled = false;
				comboBoxOptionsExpirationDate.Enabled = false;
				comboBoxOptionsType.Enabled = false;
				if (!(comboBoxOptionsBaseAsset.Text == "NULL") || !(comboBoxOptionsExpirationDate.Text == "NULL") || !(comboBoxOptionsType.Text == "NULL"))
				{
					F_OptionFilter = true;
					Tick();
				}
			}
		}

		private void comboBoxOptionsBaseAsset_SelectionChangeCommitted(object sender, EventArgs e)
		{
			F_OptionFilter = true;
			if (comboBoxOptionsBaseAsset.Text == "NULL")
			{
				FillComboBoxOptionsExpirationDate("NULL");
				FillComboBoxOptionsType("NULL");
				comboBoxOptionsExpirationDate.Enabled = false;
				comboBoxOptionsType.Enabled = false;
			}
			else
			{
				comboBoxOptionsExpirationDate.Enabled = true;
				comboBoxOptionsType.Enabled = true;
			}
			Tick();
		}

		private void comboBoxOptionsExpirationDate_Click(object sender, EventArgs e)
		{
			CreateOptionsExpirationDateTable();
			FillComboBoxOptionsExpirationDate(comboBoxOptionsExpirationDate.Text);
		}

		private void comboBoxOptionsExpirationDate_SelectionChangeCommitted(object sender, EventArgs e)
		{
			F_OptionFilter = true;
			Tick();
		}

		private void comboBoxOptionsType_Click(object sender, EventArgs e)
		{
			FillComboBoxOptionsType(comboBoxOptionsType.Text);
		}

		private void comboBoxOptionsType_SelectionChangeCommitted(object sender, EventArgs e)
		{
			F_OptionFilter = true;
			Tick();
		}

		private void comboBoxOptionsBaseAsset_Click(object sender, EventArgs e)
		{
		}

		protected override void Dispose(bool disposing)
		{
			if (disposing && components != null)
			{
				components.Dispose();
			}
			base.Dispose(disposing);
		}

		private void InitializeComponent()
		{
			this.splitContainer1 = new System.Windows.Forms.SplitContainer();
			this.groupBoxInformation = new System.Windows.Forms.GroupBox();
			this.richTextBoxInfo = new System.Windows.Forms.RichTextBox();
			this.groupBoxTransaction = new System.Windows.Forms.GroupBox();
			this.buttonUnCheckAllTransaction = new System.Windows.Forms.Button();
			this.buttonCheckAllTransactions = new System.Windows.Forms.Button();
			this.buttonImport = new System.Windows.Forms.Button();
			this.textboxTotalPosition = new System.Windows.Forms.RichTextBox();
			this.textBoxFutTimeValue = new System.Windows.Forms.TextBox();
			this.label5 = new System.Windows.Forms.Label();
			this.textBoxFutLot = new System.Windows.Forms.TextBox();
			this.label1 = new System.Windows.Forms.Label();
			this.cbFutAsCLT = new System.Windows.Forms.CheckBox();
			this.buttonAddToStrategy = new System.Windows.Forms.Button();
			this.comboBoxStrategy = new System.Windows.Forms.ComboBox();
			this.groupBoxDDE = new System.Windows.Forms.GroupBox();
			this.buttonClearDDE = new System.Windows.Forms.Button();
			this.checkBoxTransactionTable = new System.Windows.Forms.CheckBox();
			this.checkBoxQuotesTable = new System.Windows.Forms.CheckBox();
			this.splitContainer2 = new System.Windows.Forms.SplitContainer();
			this.splitContainer3 = new System.Windows.Forms.SplitContainer();
			this.groupBoxCurrentFutures = new System.Windows.Forms.GroupBox();
			this.dataGridViewFuturesQuotes = new System.Windows.Forms.DataGridView();
			this.groupBoxCurrentOptions = new System.Windows.Forms.GroupBox();
			this.label4 = new System.Windows.Forms.Label();
			this.checkBoxFilterOptions = new System.Windows.Forms.CheckBox();
			this.label3 = new System.Windows.Forms.Label();
			this.label2 = new System.Windows.Forms.Label();
			this.dataGridViewQuotes = new System.Windows.Forms.DataGridView();
			this.comboBoxOptionsType = new System.Windows.Forms.ComboBox();
			this.comboBoxOptionsExpirationDate = new System.Windows.Forms.ComboBox();
			this.comboBoxOptionsBaseAsset = new System.Windows.Forms.ComboBox();
			this.groupBoxTableTransaction = new System.Windows.Forms.GroupBox();
			this.dataGridViewTransaction = new System.Windows.Forms.DataGridView();
			((System.ComponentModel.ISupportInitialize)this.splitContainer1).BeginInit();
			this.splitContainer1.Panel1.SuspendLayout();
			this.splitContainer1.Panel2.SuspendLayout();
			this.splitContainer1.SuspendLayout();
			this.groupBoxInformation.SuspendLayout();
			this.groupBoxTransaction.SuspendLayout();
			this.groupBoxDDE.SuspendLayout();
			((System.ComponentModel.ISupportInitialize)this.splitContainer2).BeginInit();
			this.splitContainer2.Panel1.SuspendLayout();
			this.splitContainer2.Panel2.SuspendLayout();
			this.splitContainer2.SuspendLayout();
			((System.ComponentModel.ISupportInitialize)this.splitContainer3).BeginInit();
			this.splitContainer3.Panel1.SuspendLayout();
			this.splitContainer3.Panel2.SuspendLayout();
			this.splitContainer3.SuspendLayout();
			this.groupBoxCurrentFutures.SuspendLayout();
			((System.ComponentModel.ISupportInitialize)this.dataGridViewFuturesQuotes).BeginInit();
			this.groupBoxCurrentOptions.SuspendLayout();
			((System.ComponentModel.ISupportInitialize)this.dataGridViewQuotes).BeginInit();
			this.groupBoxTableTransaction.SuspendLayout();
			((System.ComponentModel.ISupportInitialize)this.dataGridViewTransaction).BeginInit();
			base.SuspendLayout();
			this.splitContainer1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
			this.splitContainer1.Dock = System.Windows.Forms.DockStyle.Fill;
			this.splitContainer1.FixedPanel = System.Windows.Forms.FixedPanel.Panel1;
			this.splitContainer1.IsSplitterFixed = true;
			this.splitContainer1.Location = new System.Drawing.Point(0, 0);
			this.splitContainer1.Name = "splitContainer1";
			this.splitContainer1.Panel1.Controls.Add(this.groupBoxInformation);
			this.splitContainer1.Panel1.Controls.Add(this.groupBoxTransaction);
			this.splitContainer1.Panel1.Controls.Add(this.groupBoxDDE);
			this.splitContainer1.Panel2.Controls.Add(this.splitContainer2);
			this.splitContainer1.Size = new System.Drawing.Size(1284, 537);
			this.splitContainer1.SplitterDistance = 173;
			this.splitContainer1.TabIndex = 0;
			this.groupBoxInformation.Anchor = System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left | System.Windows.Forms.AnchorStyles.Right;
			this.groupBoxInformation.Controls.Add(this.richTextBoxInfo);
			this.groupBoxInformation.Location = new System.Drawing.Point(3, 458);
			this.groupBoxInformation.Name = "groupBoxInformation";
			this.groupBoxInformation.Size = new System.Drawing.Size(165, 74);
			this.groupBoxInformation.TabIndex = 2;
			this.groupBoxInformation.TabStop = false;
			this.groupBoxInformation.Text = "Информация";
			this.richTextBoxInfo.Dock = System.Windows.Forms.DockStyle.Fill;
			this.richTextBoxInfo.Location = new System.Drawing.Point(3, 16);
			this.richTextBoxInfo.Name = "richTextBoxInfo";
			this.richTextBoxInfo.Size = new System.Drawing.Size(159, 55);
			this.richTextBoxInfo.TabIndex = 1;
			this.richTextBoxInfo.Text = "";
			this.groupBoxTransaction.Anchor = System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left | System.Windows.Forms.AnchorStyles.Right;
			this.groupBoxTransaction.Controls.Add(this.buttonUnCheckAllTransaction);
			this.groupBoxTransaction.Controls.Add(this.buttonCheckAllTransactions);
			this.groupBoxTransaction.Controls.Add(this.buttonImport);
			this.groupBoxTransaction.Controls.Add(this.textboxTotalPosition);
			this.groupBoxTransaction.Controls.Add(this.textBoxFutTimeValue);
			this.groupBoxTransaction.Controls.Add(this.label5);
			this.groupBoxTransaction.Controls.Add(this.textBoxFutLot);
			this.groupBoxTransaction.Controls.Add(this.label1);
			this.groupBoxTransaction.Controls.Add(this.cbFutAsCLT);
			this.groupBoxTransaction.Controls.Add(this.buttonAddToStrategy);
			this.groupBoxTransaction.Controls.Add(this.comboBoxStrategy);
			this.groupBoxTransaction.Location = new System.Drawing.Point(3, 109);
			this.groupBoxTransaction.Name = "groupBoxTransaction";
			this.groupBoxTransaction.Size = new System.Drawing.Size(165, 343);
			this.groupBoxTransaction.TabIndex = 1;
			this.groupBoxTransaction.TabStop = false;
			this.groupBoxTransaction.Text = "Сделки";
			this.buttonUnCheckAllTransaction.Location = new System.Drawing.Point(6, 313);
			this.buttonUnCheckAllTransaction.Name = "buttonUnCheckAllTransaction";
			this.buttonUnCheckAllTransaction.Size = new System.Drawing.Size(152, 23);
			this.buttonUnCheckAllTransaction.TabIndex = 3;
			this.buttonUnCheckAllTransaction.Text = "Снять выделение";
			this.buttonUnCheckAllTransaction.UseVisualStyleBackColor = true;
			this.buttonUnCheckAllTransaction.Click += new System.EventHandler(buttonUnCheckAllTransaction_Click);
			this.buttonCheckAllTransactions.Location = new System.Drawing.Point(6, 284);
			this.buttonCheckAllTransactions.Name = "buttonCheckAllTransactions";
			this.buttonCheckAllTransactions.Size = new System.Drawing.Size(152, 23);
			this.buttonCheckAllTransactions.TabIndex = 2;
			this.buttonCheckAllTransactions.Text = "Выбрать все";
			this.buttonCheckAllTransactions.UseVisualStyleBackColor = true;
			this.buttonCheckAllTransactions.Click += new System.EventHandler(buttonCheckAllTransactions_Click);
			this.buttonImport.Location = new System.Drawing.Point(6, 255);
			this.buttonImport.Name = "buttonImport";
			this.buttonImport.Size = new System.Drawing.Size(152, 23);
			this.buttonImport.TabIndex = 10;
			this.buttonImport.Text = "Импортировать";
			this.buttonImport.UseVisualStyleBackColor = true;
			this.buttonImport.Click += new System.EventHandler(buttonImportToStrategy_Click);
			this.textboxTotalPosition.Location = new System.Drawing.Point(4, 147);
			this.textboxTotalPosition.Name = "textboxTotalPosition";
			this.textboxTotalPosition.Size = new System.Drawing.Size(155, 102);
			this.textboxTotalPosition.TabIndex = 9;
			this.textboxTotalPosition.Text = "";
			this.textBoxFutTimeValue.Location = new System.Drawing.Point(81, 121);
			this.textBoxFutTimeValue.Name = "textBoxFutTimeValue";
			this.textBoxFutTimeValue.Size = new System.Drawing.Size(81, 20);
			this.textBoxFutTimeValue.TabIndex = 8;
			this.textBoxFutTimeValue.Text = "0";
			this.label5.AutoSize = true;
			this.label5.Location = new System.Drawing.Point(9, 125);
			this.label5.Name = "label5";
			this.label5.Size = new System.Drawing.Size(66, 13);
			this.label5.TabIndex = 7;
			this.label5.Text = "Конт./бэкв.";
			this.textBoxFutLot.Location = new System.Drawing.Point(81, 97);
			this.textBoxFutLot.Name = "textBoxFutLot";
			this.textBoxFutLot.Size = new System.Drawing.Size(81, 20);
			this.textBoxFutLot.TabIndex = 6;
			this.textBoxFutLot.Text = "1";
			this.label1.AutoSize = true;
			this.label1.Location = new System.Drawing.Point(9, 101);
			this.label1.Name = "label1";
			this.label1.Size = new System.Drawing.Size(55, 13);
			this.label1.TabIndex = 5;
			this.label1.Text = "Лотность";
			this.cbFutAsCLT.AutoSize = true;
			this.cbFutAsCLT.Location = new System.Drawing.Point(9, 78);
			this.cbFutAsCLT.Name = "cbFutAsCLT";
			this.cbFutAsCLT.Size = new System.Drawing.Size(117, 17);
			this.cbFutAsCLT.TabIndex = 4;
			this.cbFutAsCLT.Text = "Фьючерсы -> CLT";
			this.cbFutAsCLT.UseVisualStyleBackColor = true;
			this.buttonAddToStrategy.Location = new System.Drawing.Point(9, 49);
			this.buttonAddToStrategy.Name = "buttonAddToStrategy";
			this.buttonAddToStrategy.Size = new System.Drawing.Size(152, 23);
			this.buttonAddToStrategy.TabIndex = 1;
			this.buttonAddToStrategy.Text = "Добавить";
			this.buttonAddToStrategy.UseVisualStyleBackColor = true;
			this.buttonAddToStrategy.Click += new System.EventHandler(buttonAddToStrategy_Click);
			this.comboBoxStrategy.FormattingEnabled = true;
			this.comboBoxStrategy.Location = new System.Drawing.Point(9, 22);
			this.comboBoxStrategy.Name = "comboBoxStrategy";
			this.comboBoxStrategy.Size = new System.Drawing.Size(152, 21);
			this.comboBoxStrategy.TabIndex = 0;
			this.comboBoxStrategy.Click += new System.EventHandler(comboBoxStrategy_Click);
			this.groupBoxDDE.Anchor = System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left | System.Windows.Forms.AnchorStyles.Right;
			this.groupBoxDDE.Controls.Add(this.buttonClearDDE);
			this.groupBoxDDE.Controls.Add(this.checkBoxTransactionTable);
			this.groupBoxDDE.Controls.Add(this.checkBoxQuotesTable);
			this.groupBoxDDE.Location = new System.Drawing.Point(3, 3);
			this.groupBoxDDE.Name = "groupBoxDDE";
			this.groupBoxDDE.Size = new System.Drawing.Size(165, 100);
			this.groupBoxDDE.TabIndex = 0;
			this.groupBoxDDE.TabStop = false;
			this.groupBoxDDE.Text = "ДДЕ сервер";
			this.buttonClearDDE.Location = new System.Drawing.Point(9, 65);
			this.buttonClearDDE.Name = "buttonClearDDE";
			this.buttonClearDDE.Size = new System.Drawing.Size(152, 23);
			this.buttonClearDDE.TabIndex = 2;
			this.buttonClearDDE.Text = "Очистить";
			this.buttonClearDDE.UseVisualStyleBackColor = true;
			this.buttonClearDDE.Click += new System.EventHandler(buttonClearDDE_Click);
			this.checkBoxTransactionTable.AutoSize = true;
			this.checkBoxTransactionTable.Location = new System.Drawing.Point(9, 42);
			this.checkBoxTransactionTable.Name = "checkBoxTransactionTable";
			this.checkBoxTransactionTable.Size = new System.Drawing.Size(63, 17);
			this.checkBoxTransactionTable.TabIndex = 1;
			this.checkBoxTransactionTable.Text = "Сделки";
			this.checkBoxTransactionTable.UseVisualStyleBackColor = true;
			this.checkBoxQuotesTable.AutoSize = true;
			this.checkBoxQuotesTable.Location = new System.Drawing.Point(9, 19);
			this.checkBoxQuotesTable.Name = "checkBoxQuotesTable";
			this.checkBoxQuotesTable.Size = new System.Drawing.Size(115, 17);
			this.checkBoxQuotesTable.TabIndex = 0;
			this.checkBoxQuotesTable.Text = "Текущая таблица";
			this.checkBoxQuotesTable.UseVisualStyleBackColor = true;
			this.splitContainer2.Dock = System.Windows.Forms.DockStyle.Fill;
			this.splitContainer2.Location = new System.Drawing.Point(0, 0);
			this.splitContainer2.Name = "splitContainer2";
			this.splitContainer2.Panel1.Controls.Add(this.splitContainer3);
			this.splitContainer2.Panel2.Controls.Add(this.groupBoxTableTransaction);
			this.splitContainer2.Size = new System.Drawing.Size(1105, 535);
			this.splitContainer2.SplitterDistance = 558;
			this.splitContainer2.TabIndex = 0;
			this.splitContainer3.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
			this.splitContainer3.Dock = System.Windows.Forms.DockStyle.Fill;
			this.splitContainer3.FixedPanel = System.Windows.Forms.FixedPanel.Panel1;
			this.splitContainer3.Location = new System.Drawing.Point(0, 0);
			this.splitContainer3.Name = "splitContainer3";
			this.splitContainer3.Orientation = System.Windows.Forms.Orientation.Horizontal;
			this.splitContainer3.Panel1.Controls.Add(this.groupBoxCurrentFutures);
			this.splitContainer3.Panel2.Controls.Add(this.groupBoxCurrentOptions);
			this.splitContainer3.Size = new System.Drawing.Size(558, 535);
			this.splitContainer3.SplitterDistance = 186;
			this.splitContainer3.TabIndex = 0;
			this.groupBoxCurrentFutures.Controls.Add(this.dataGridViewFuturesQuotes);
			this.groupBoxCurrentFutures.Dock = System.Windows.Forms.DockStyle.Fill;
			this.groupBoxCurrentFutures.Location = new System.Drawing.Point(0, 0);
			this.groupBoxCurrentFutures.Name = "groupBoxCurrentFutures";
			this.groupBoxCurrentFutures.Size = new System.Drawing.Size(556, 184);
			this.groupBoxCurrentFutures.TabIndex = 0;
			this.groupBoxCurrentFutures.TabStop = false;
			this.groupBoxCurrentFutures.Text = "Текущая таблица Фьючерсы";
			this.dataGridViewFuturesQuotes.AllowUserToAddRows = false;
			this.dataGridViewFuturesQuotes.AllowUserToDeleteRows = false;
			this.dataGridViewFuturesQuotes.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
			this.dataGridViewFuturesQuotes.Dock = System.Windows.Forms.DockStyle.Fill;
			this.dataGridViewFuturesQuotes.Location = new System.Drawing.Point(3, 16);
			this.dataGridViewFuturesQuotes.Name = "dataGridViewFuturesQuotes";
			this.dataGridViewFuturesQuotes.ReadOnly = true;
			this.dataGridViewFuturesQuotes.Size = new System.Drawing.Size(550, 165);
			this.dataGridViewFuturesQuotes.TabIndex = 0;
			this.groupBoxCurrentOptions.Controls.Add(this.label4);
			this.groupBoxCurrentOptions.Controls.Add(this.checkBoxFilterOptions);
			this.groupBoxCurrentOptions.Controls.Add(this.label3);
			this.groupBoxCurrentOptions.Controls.Add(this.label2);
			this.groupBoxCurrentOptions.Controls.Add(this.dataGridViewQuotes);
			this.groupBoxCurrentOptions.Controls.Add(this.comboBoxOptionsType);
			this.groupBoxCurrentOptions.Controls.Add(this.comboBoxOptionsExpirationDate);
			this.groupBoxCurrentOptions.Controls.Add(this.comboBoxOptionsBaseAsset);
			this.groupBoxCurrentOptions.Dock = System.Windows.Forms.DockStyle.Fill;
			this.groupBoxCurrentOptions.Location = new System.Drawing.Point(0, 0);
			this.groupBoxCurrentOptions.Name = "groupBoxCurrentOptions";
			this.groupBoxCurrentOptions.Size = new System.Drawing.Size(556, 343);
			this.groupBoxCurrentOptions.TabIndex = 0;
			this.groupBoxCurrentOptions.TabStop = false;
			this.groupBoxCurrentOptions.Text = "Текущая таблица Опционы";
			this.label4.AutoSize = true;
			this.label4.Location = new System.Drawing.Point(406, 22);
			this.label4.Name = "label4";
			this.label4.Size = new System.Drawing.Size(71, 13);
			this.label4.TabIndex = 1;
			this.label4.Text = "Тип опциона";
			this.checkBoxFilterOptions.AutoSize = true;
			this.checkBoxFilterOptions.Location = new System.Drawing.Point(6, 21);
			this.checkBoxFilterOptions.Name = "checkBoxFilterOptions";
			this.checkBoxFilterOptions.Size = new System.Drawing.Size(66, 17);
			this.checkBoxFilterOptions.TabIndex = 1;
			this.checkBoxFilterOptions.Text = "Фильтр";
			this.checkBoxFilterOptions.UseVisualStyleBackColor = true;
			this.checkBoxFilterOptions.CheckStateChanged += new System.EventHandler(checkBoxFiltrOptions_CheckStateChanged);
			this.label3.AutoSize = true;
			this.label3.Location = new System.Drawing.Point(241, 22);
			this.label3.Name = "label3";
			this.label3.Size = new System.Drawing.Size(63, 13);
			this.label3.TabIndex = 1;
			this.label3.Text = "Дата эксп.";
			this.label2.AutoSize = true;
			this.label2.Location = new System.Drawing.Point(94, 22);
			this.label2.Name = "label2";
			this.label2.Size = new System.Drawing.Size(61, 13);
			this.label2.TabIndex = 1;
			this.label2.Text = "Баз. актив";
			this.dataGridViewQuotes.AllowUserToAddRows = false;
			this.dataGridViewQuotes.AllowUserToDeleteRows = false;
			this.dataGridViewQuotes.Anchor = System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left | System.Windows.Forms.AnchorStyles.Right;
			this.dataGridViewQuotes.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
			this.dataGridViewQuotes.Location = new System.Drawing.Point(3, 54);
			this.dataGridViewQuotes.Name = "dataGridViewQuotes";
			this.dataGridViewQuotes.ReadOnly = true;
			this.dataGridViewQuotes.Size = new System.Drawing.Size(550, 287);
			this.dataGridViewQuotes.TabIndex = 0;
			this.comboBoxOptionsType.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
			this.comboBoxOptionsType.FormattingEnabled = true;
			this.comboBoxOptionsType.Location = new System.Drawing.Point(483, 19);
			this.comboBoxOptionsType.Name = "comboBoxOptionsType";
			this.comboBoxOptionsType.Size = new System.Drawing.Size(63, 21);
			this.comboBoxOptionsType.TabIndex = 0;
			this.comboBoxOptionsType.SelectionChangeCommitted += new System.EventHandler(comboBoxOptionsType_SelectionChangeCommitted);
			this.comboBoxOptionsType.Click += new System.EventHandler(comboBoxOptionsType_Click);
			this.comboBoxOptionsExpirationDate.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
			this.comboBoxOptionsExpirationDate.FormattingEnabled = true;
			this.comboBoxOptionsExpirationDate.Location = new System.Drawing.Point(308, 19);
			this.comboBoxOptionsExpirationDate.Name = "comboBoxOptionsExpirationDate";
			this.comboBoxOptionsExpirationDate.Size = new System.Drawing.Size(90, 21);
			this.comboBoxOptionsExpirationDate.TabIndex = 0;
			this.comboBoxOptionsExpirationDate.SelectionChangeCommitted += new System.EventHandler(comboBoxOptionsExpirationDate_SelectionChangeCommitted);
			this.comboBoxOptionsExpirationDate.Click += new System.EventHandler(comboBoxOptionsExpirationDate_Click);
			this.comboBoxOptionsBaseAsset.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
			this.comboBoxOptionsBaseAsset.FormattingEnabled = true;
			this.comboBoxOptionsBaseAsset.Location = new System.Drawing.Point(161, 19);
			this.comboBoxOptionsBaseAsset.Name = "comboBoxOptionsBaseAsset";
			this.comboBoxOptionsBaseAsset.Size = new System.Drawing.Size(63, 21);
			this.comboBoxOptionsBaseAsset.TabIndex = 0;
			this.comboBoxOptionsBaseAsset.SelectionChangeCommitted += new System.EventHandler(comboBoxOptionsBaseAsset_SelectionChangeCommitted);
			this.comboBoxOptionsBaseAsset.Click += new System.EventHandler(comboBoxOptionsBaseAsset_Click);
			this.groupBoxTableTransaction.Controls.Add(this.dataGridViewTransaction);
			this.groupBoxTableTransaction.Dock = System.Windows.Forms.DockStyle.Fill;
			this.groupBoxTableTransaction.Location = new System.Drawing.Point(0, 0);
			this.groupBoxTableTransaction.Name = "groupBoxTableTransaction";
			this.groupBoxTableTransaction.Size = new System.Drawing.Size(543, 535);
			this.groupBoxTableTransaction.TabIndex = 0;
			this.groupBoxTableTransaction.TabStop = false;
			this.groupBoxTableTransaction.Text = "Сделки";
			this.dataGridViewTransaction.AllowUserToAddRows = false;
			this.dataGridViewTransaction.AllowUserToDeleteRows = false;
			this.dataGridViewTransaction.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
			this.dataGridViewTransaction.Dock = System.Windows.Forms.DockStyle.Fill;
			this.dataGridViewTransaction.Location = new System.Drawing.Point(3, 16);
			this.dataGridViewTransaction.Name = "dataGridViewTransaction";
			this.dataGridViewTransaction.Size = new System.Drawing.Size(537, 516);
			this.dataGridViewTransaction.TabIndex = 0;
			base.AutoScaleDimensions = new System.Drawing.SizeF(6f, 13f);
			base.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
			base.ClientSize = new System.Drawing.Size(1284, 537);
			base.Controls.Add(this.splitContainer1);
			base.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
			base.Name = "FormData";
			base.Load += new System.EventHandler(FormData_Load);
			this.splitContainer1.Panel1.ResumeLayout(false);
			this.splitContainer1.Panel2.ResumeLayout(false);
			((System.ComponentModel.ISupportInitialize)this.splitContainer1).EndInit();
			this.splitContainer1.ResumeLayout(false);
			this.groupBoxInformation.ResumeLayout(false);
			this.groupBoxTransaction.ResumeLayout(false);
			this.groupBoxTransaction.PerformLayout();
			this.groupBoxDDE.ResumeLayout(false);
			this.groupBoxDDE.PerformLayout();
			this.splitContainer2.Panel1.ResumeLayout(false);
			this.splitContainer2.Panel2.ResumeLayout(false);
			((System.ComponentModel.ISupportInitialize)this.splitContainer2).EndInit();
			this.splitContainer2.ResumeLayout(false);
			this.splitContainer3.Panel1.ResumeLayout(false);
			this.splitContainer3.Panel2.ResumeLayout(false);
			((System.ComponentModel.ISupportInitialize)this.splitContainer3).EndInit();
			this.splitContainer3.ResumeLayout(false);
			this.groupBoxCurrentFutures.ResumeLayout(false);
			((System.ComponentModel.ISupportInitialize)this.dataGridViewFuturesQuotes).EndInit();
			this.groupBoxCurrentOptions.ResumeLayout(false);
			this.groupBoxCurrentOptions.PerformLayout();
			((System.ComponentModel.ISupportInitialize)this.dataGridViewQuotes).EndInit();
			this.groupBoxTableTransaction.ResumeLayout(false);
			((System.ComponentModel.ISupportInitialize)this.dataGridViewTransaction).EndInit();
			base.ResumeLayout(false);
		}

		private void buttonCheckAllTransactions_Click_1(object sender, EventArgs e)
		{
		}
	}
}
