using System;
using System.ComponentModel;
using System.Drawing;
using System.Windows.Forms;

namespace OptionFVV
{
	public class FormLog : Form
	{
		private IContainer components = null;

		private DataGridView dataGridViewLog;

		public FormLog()
		{
			InitializeComponent();
		}

		private void FormLog_Load(object sender, EventArgs e)
		{
			CallBackMy.callbackEventHandlerColorThemeFormLog = PaintColorTheme;
			CallBackMy.callbackEventHandlerError = AddRow;
			base.FormBorderStyle = FormBorderStyle.None;
			Dock = DockStyle.Fill;
			Create();
			dataGridViewLog.EnableHeadersVisualStyles = false;
			AddRow(DateTime.Now.ToLocalTime().ToString(), "Запустили приложение");
			PaintColorTheme();
		}

		public void AddRow(string iTimeDate, string iMessage)
		{
			if (dataGridViewLog.InvokeRequired)
			{
				Invoke(CallBackMy.callbackEventHandlerError, iTimeDate, iMessage);
			}
			else
			{
				dataGridViewLog.Rows.Add(iTimeDate, iMessage);
			}
		}

		public void Create()
		{
			DataGridViewTextBoxColumn viewTextBoxColumn1 = new DataGridViewTextBoxColumn();
			viewTextBoxColumn1.HeaderText = "Время Дата";
			viewTextBoxColumn1.Name = "TimeDate";
			viewTextBoxColumn1.AutoSizeMode = DataGridViewAutoSizeColumnMode.DisplayedCells;
			viewTextBoxColumn1.DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleLeft;
			DataGridViewTextBoxColumn viewTextBoxColumn2 = new DataGridViewTextBoxColumn();
			viewTextBoxColumn2.HeaderText = "Сообщение";
			viewTextBoxColumn2.Name = "Message";
			viewTextBoxColumn2.DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleLeft;
			dataGridViewLog.Columns.Add(viewTextBoxColumn1);
			dataGridViewLog.Columns.Add(viewTextBoxColumn2);
			dataGridViewLog.RowHeadersVisible = false;
			dataGridViewLog.ColumnHeadersDefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleLeft;
			viewTextBoxColumn1.AutoSizeMode = DataGridViewAutoSizeColumnMode.AllCells;
			viewTextBoxColumn2.AutoSizeMode = DataGridViewAutoSizeColumnMode.Fill;
		}

		public void Clear()
		{
			dataGridViewLog.Rows.Clear();
		}

		private void PaintColorTheme()
		{
			BackColor = ClassColorTheme.BackColor;
			ForeColor = ClassColorTheme.HeadersColorFore;
			dataGridViewLog.ColumnHeadersDefaultCellStyle.BackColor = ClassColorTheme.HeadersColor;
			dataGridViewLog.BackgroundColor = ClassColorTheme.BackColor;
			dataGridViewLog.ForeColor = ClassColorTheme.BackColorFore;
			dataGridViewLog.DefaultCellStyle.BackColor = ClassColorTheme.BackColor;
			dataGridViewLog.ColumnHeadersDefaultCellStyle.ForeColor = ClassColorTheme.HeadersColorFore;
			dataGridViewLog.GridColor = ClassColorTheme.GridColor;
		}

		protected override void Dispose(bool disposing)
		{
			if (disposing && components != null)
			{
				components.Dispose();
			}
			base.Dispose(disposing);
		}

		private void InitializeComponent()
		{
			this.dataGridViewLog = new System.Windows.Forms.DataGridView();
			((System.ComponentModel.ISupportInitialize)this.dataGridViewLog).BeginInit();
			base.SuspendLayout();
			this.dataGridViewLog.AllowUserToAddRows = false;
			this.dataGridViewLog.AllowUserToDeleteRows = false;
			this.dataGridViewLog.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
			this.dataGridViewLog.Dock = System.Windows.Forms.DockStyle.Fill;
			this.dataGridViewLog.Location = new System.Drawing.Point(0, 0);
			this.dataGridViewLog.Name = "dataGridViewLog";
			this.dataGridViewLog.ReadOnly = true;
			this.dataGridViewLog.Size = new System.Drawing.Size(527, 262);
			this.dataGridViewLog.TabIndex = 0;
			base.AutoScaleDimensions = new System.Drawing.SizeF(6f, 13f);
			base.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
			base.ClientSize = new System.Drawing.Size(527, 262);
			base.Controls.Add(this.dataGridViewLog);
			base.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
			base.Load += new System.EventHandler(FormLog_Load);
			((System.ComponentModel.ISupportInitialize)this.dataGridViewLog).EndInit();
			base.ResumeLayout(false);
		}
	}
}
