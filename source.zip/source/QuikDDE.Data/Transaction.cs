using System;

namespace QuikDDE.Data
{
	public struct Transaction
	{
		public string number;

		public DateTime date;

		public DateTime time;

		public string paper_code;

		public string operation;

		public double price;

		public double volume;

		public string strategy;
	}
}
