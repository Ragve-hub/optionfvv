using System;

namespace QuikDDE.Data
{
	public struct Quotes
	{
		public string paper_code;

		public DateTime expiration_date;

		public string base_asset;

		public double demand;

		public double sentence;

		public double last_price;

		public double strike;

		public string option_type;

		public double volatility;

		public double teoretical_price;

		public double step_price;

		public string class_code;

		public double lot;

		public int decimal_points;
	}
}
