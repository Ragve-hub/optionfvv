namespace QuikDDE.Data
{
	public struct Order
	{
		public double number;

		public string paper_code;

		public int operation;

		public double price;

		public int volume;

		public int status;

		public int ID;
	}
}
