namespace QuikDDE.Data
{
	public class XLTable
	{
		private ushort tdt;
	}
}
