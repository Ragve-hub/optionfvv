using System.Diagnostics;
using System.Reflection;
using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;
using System.Runtime.Versioning;

[assembly: AssemblyTitle("OptionFVV")]
[assembly: AssemblyDescription("Анализатор опционных позиций")]
[assembly: AssemblyConfiguration("")]
[assembly: AssemblyCompany("OptionFVV")]
[assembly: AssemblyProduct("OptionFVV")]
[assembly: AssemblyCopyright("Фатеев Виктор Вячеславович")]
[assembly: AssemblyTrademark("")]
[assembly: ComVisible(false)]
[assembly: Guid("84031273-9975-43fd-ae4a-9d13511b631f")]
[assembly: AssemblyFileVersion("1.0.0.0")]
[assembly: AssemblyVersion("1.0.0.0")]
